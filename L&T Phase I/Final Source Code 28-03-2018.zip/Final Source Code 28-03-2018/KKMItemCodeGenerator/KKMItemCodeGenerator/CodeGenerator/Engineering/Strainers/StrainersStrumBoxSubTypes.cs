﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersStrumBoxSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersStrumBoxSubTypes LoadList()
        {
            StrainersStrumBoxSubTypes items = new StrainersStrumBoxSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "STRAIGHT TYPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANGLE TYPE" });
            return items;
        }
        public static StrainersStrumBoxSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersStrumBoxSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersStrumBoxSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersStrumBoxSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersStrumBoxSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersStrumBoxSubTypes.xml");
        }

    }
}
