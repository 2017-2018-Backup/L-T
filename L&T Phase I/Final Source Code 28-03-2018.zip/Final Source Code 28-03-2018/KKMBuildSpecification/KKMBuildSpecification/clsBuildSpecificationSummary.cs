﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Autodesk.Connectivity.WebServices;

namespace KKMBuildSpecification
{

    public class clsBuildSpecificationSummary
    {
        public List<SingleBuildSpecificationSummary> collectionBuildSpecification = new List<SingleBuildSpecificationSummary> { };
    }

    public class SingleBuildSpecificationSummary
    {
        public int BuildSpecificationCount { get; set; }
        public int BuildSpecificationNumber { get; set; }
        public string BuildSpecificationUniqNumber { get; set; }
        public string BuildSpecificationFileName { get; set; }
        public string BuildSpecificationFileFullPath { get; set; }

        public string BuildSpecificationProjectCode { get; set; }
        public string BuildSpecificationSECTION { get; set; }
        public string BuildSpecificationParaNumber { get; set; }

        public string BuildSpecificationSubParaNumber { get; set; }
        public string BuildSpecificationSFI { get; set; }
        public string BuildSpecificationSFIDesc { get; set; }
        public string BuildSpecificationReferenceBuildSpecificationLine { get; set; }
        public string BuildSpecificationResponsiblePerson { get; set; }
        public string BuildSpecificationSubResponsiblePerson { get; set; }
        public string BuildSpecificationResponsibleCoordinator { get; set; }
        public string BuildSpecificationSubResponsibleCoordinator { get; set; }
        public string BuildSpecificationFunction { get; set; }
        public List<string> BuildSpecificationFunctions = new List<string> { };
        public string BuildSpecificationSOTRRequired { get; set; }

        public ObservableCollection<SOTRNumber> ListSOTRNumber = new ObservableCollection<SOTRNumber> { };
        public ObservableCollection<ClassDrawing> ListClassDrawing = new ObservableCollection<ClassDrawing> { };
        public ObservableCollection<DADDrawing> ListDADDrawing = new ObservableCollection<DADDrawing> { };
        public ObservableCollection<ProductionDrawing> ListProductionDrawing = new ObservableCollection<ProductionDrawing> { };

        public string BuildSpecificationSOTRNumber { get; set; }
        public string BuildSpecificationClassDrawing { get; set; }
        public string BuildSpecificationDADDrawing { get; set; }
        public string BuildSpecificationProductionDrawing { get; set; }

        public string BuildSpecificationLifeCycle { get; set; }
        public string BuildSpecificationRemark { get; set; }
        public string BuildSpecificationExtension { get; set; }

        public string BuildSpecificationInReleaseMode { get; set; }

        public string BuildSpecificationCompletionofActivity { get; set; }

        public bool BuildSpecificationIsDocumentsInRelease { get; set; }

        public bool BuildSpecificationIsSuccess { get; set; }
    }

    public class MasterDrawingFile
    {
        public string DocumentType { get; set; }
        public string DocumentNumber { get; set; }
        public string DocumentDescription { get; set; }
        public string RevisionNumber { get; set; }
    }


    public class SOTRNumber : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileNumber { get; set; }

        public string FileDesc { get; set; }
        public string FileType { get; set; }

        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }
        public string FileSection { get; set; }
        public string FileLink { get; set; }

        private bool _IsCheckedSOTRNumber;
        public bool IsCheckedSOTRNumber
        {
            get { return _IsCheckedSOTRNumber; }
            set
            {
                _IsCheckedSOTRNumber = value;
                OnPropertychanged("IsCheckedSOTRNumber");
            }
        }               
       
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertychanged(string propertyName)
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

    }
   
    public class ClassDrawing : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileNumber { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }
        public string FileSection { get; set; }
        public string FileRelatedDAD { get; set; }
        public string FileUsedIn { get; set; }
        public string FileLink { get; set; }
        private bool _IsCheckedClassDrawing;
        public bool IsCheckedClassDrawing
        {
            get { return _IsCheckedClassDrawing; }
            set
            {
                _IsCheckedClassDrawing = value;
                OnPropertyChanged("IsCheckedClassDrawing");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class DADDrawing : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileNumber { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }
        public string FileUsedIn { get; set; }
        public string FileLink { get; set; }
        private bool _IsCheckedDADDrawing;
        public bool IsCheckedDADDrawing
        {
            get { return _IsCheckedDADDrawing; }
            set
            {
                _IsCheckedDADDrawing = value;
                OnPropertyChanged("IsCheckedDADDrawing");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class ProductionDrawing : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileNumber { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }
        public string FileElement { get; set; }
        public string FileSFI { get; set; }
        public string FileRelevantClassApproved { get; set; }
        public string FileUsedIn { get; set; }
        public string FileLink { get; set; }
        private bool _IsCheckedProductionDrawing;
        public bool IsCheckedProductionDrawing
        {
            get { return _IsCheckedProductionDrawing; }
            set
            {
                _IsCheckedProductionDrawing = value;
                OnPropertyChanged("IsCheckedProductionDrawing");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }  

}
