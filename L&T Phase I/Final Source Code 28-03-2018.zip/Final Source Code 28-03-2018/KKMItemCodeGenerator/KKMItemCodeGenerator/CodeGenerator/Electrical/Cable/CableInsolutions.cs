﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableInsolutions : ObservableCollection<NameCodePair>
    {
        public static CableInsolutions LoadList()
        {
            CableInsolutions items = new CableInsolutions();
            items.Add(new NameCodePair() { Code = "01", Name = "XLPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "EPR" });
            items.Add(new NameCodePair() { Code = "03", Name = "PVC" });
            items.Add(new NameCodePair() { Code = "04", Name = "HEPR" });
            items.Add(new NameCodePair() { Code = "05", Name = "MICA TAPE" });
            items.Add(new NameCodePair() { Code = "06", Name = "NA" });
            items.Add(new NameCodePair() { Code = "07", Name = "EBXL" });
            items.Add(new NameCodePair() { Code = "08", Name = "EBXL-ATC" });
            return items;
        }
        public static CableInsolutions LoadFromExcel(String path)
        {
            return null;
        }

        public static CableInsolutions LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableInsolutions>(ElectricalItems.DataPath + @"\Cable\CableInsolutions.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableInsolutions>(this, ElectricalItems.DataPath + @"\Cable\CableInsolutions.xml");
        }

    }
}
