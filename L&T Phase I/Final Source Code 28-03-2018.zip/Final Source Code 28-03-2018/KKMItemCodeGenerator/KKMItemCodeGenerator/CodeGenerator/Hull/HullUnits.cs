﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HullUnits : ObservableCollection<NameCodePair>
    {
        public static HullUnits LoadList()
        {
            HullUnits items = new HullUnits();
            items.Add(new NameCodePair() { Code = "T", Name = "Metric Tonnes" });
            items.Add(new NameCodePair() { Code = "cms", Name = "Centimeters" });
            items.Add(new NameCodePair() { Code = "cub", Name = "Cubic Metres" });
            items.Add(new NameCodePair() { Code = "gms", Name = "Grams" });
            items.Add(new NameCodePair() { Code = "kgs", Name = "Kilograms" });
            items.Add(new NameCodePair() { Code = "kms", Name = "Kilometers" });
            items.Add(new NameCodePair() { Code = "mm", Name = "Millimeter" });
            items.Add(new NameCodePair() { Code = "mtr", Name = "Meters" });
            items.Add(new NameCodePair() { Code = "nm", Name = "Nanometer" });
            items.Add(new NameCodePair() { Code = "nos", Name = "Numbers" });
            items.Add(new NameCodePair() { Code = "scm", Name = "Square Centimeters" });
            items.Add(new NameCodePair() { Code = "set", Name = "Set" });
            items.Add(new NameCodePair() { Code = "skm", Name = "Sqaure Kilometers" });
            items.Add(new NameCodePair() { Code = "sqm", Name = "Square metres" });
            items.Add(new NameCodePair() { Code = "ug", Name = "Micrograms" });
            items.Add(new NameCodePair() { Code = "um", Name = "Micrometer" });
            return items;
        }

        public static HullUnits LoadFromExcel(String path)
        {
            return null;
        }

        public static HullUnits LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HullUnits>(HullItems.HullDataPath + @"\HullUnits.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HullUnits>(this, HullItems.HullDataPath + @"\HullUnits.xml");
        }

    }
}
