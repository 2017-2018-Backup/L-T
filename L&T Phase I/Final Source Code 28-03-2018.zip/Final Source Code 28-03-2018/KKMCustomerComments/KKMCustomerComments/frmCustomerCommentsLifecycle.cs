﻿using KKMCustomerComment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Connectivity.WebServices;

namespace KKMCustomerComments
{
    public partial class frmCustomerCommentsLifecycle : Form
    {
        public SingleCustomerCommentsummary _objSingleCustomerCommentsummary;

        public bool IsEditMode = false;

        public frmCustomerCommentsLifecycle()
        {
            InitializeComponent();
        }

        public frmCustomerCommentsLifecycle(ref SingleCustomerCommentsummary objSingleCustomerCommentsummary, bool _IsEditMode)
        {
            InitializeComponent();
            _objSingleCustomerCommentsummary = objSingleCustomerCommentsummary;
            IsEditMode = _IsEditMode;
        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdProceed_Click(object sender, EventArgs e)
        {
            _objSingleCustomerCommentsummary.CustomerCommentLifeCycle = ((LifecycleStateListItem)cmdCustomerLifecycle.SelectedItem).LifecycleState.DispName;
            _objSingleCustomerCommentsummary.CustomerCommentRemark = txtLifeCycleComment.Text;
            try
            {

                File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleCustomerCommentsummary.CustomerCommentFileFullPath });
                if (SingleFile.Length != 0)
                {
                    newFile = SingleFile[0];
                    LfCycDef lcDef = null;
                    LifecycleDefinitionListItem lcDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
                    if (lcDefItem != null)
                        lcDef = lcDefItem.LifecycleDefinition;

                    LifecycleStateListItem lcStateItem = cmdCustomerLifecycle.SelectedItem as LifecycleStateListItem;

                    if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId != lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null && lcStateItem.LifecycleState.Id > 0)
                    {
                        // here we are setting both the lifecycle definition and the state
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleDefinitions(
                            new long[] { newFile.MasterId },
                            new long[] { lcDef.Id }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleCustomerCommentsummary.CustomerCommentRemark);

                        newFile = files[0];
                    }
                    else if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId == lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null &&
                        lcStateItem.LifecycleState.Id > 0 &&
                        newFile.FileLfCyc.LfCycStateId != lcStateItem.LifecycleState.Id)
                    {
                        // here the definition is correct but we need to change the lifecycle
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                            new long[] { newFile.MasterId }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleCustomerCommentsummary.CustomerCommentRemark);

                        newFile = files[0];
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            this.Close();
        }

        private void GetLifecycles()
        {
            try
            {
                LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
                int index = 1;

                LfCycDef noneDef = new LfCycDef()
                {
                    Id = -1,
                    DispName = "<None>",
                    StateArray = new LfCycState[0]
                };

                m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(noneDef));

                foreach (LfCycDef lcDef in lcDefs)
                {
                    index = m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(lcDef));
                    if ((lcDef.DispName.ToUpper() == "Customer Comment") || (lcDef.Name.ToUpper() == "Customer Comment") || (lcDef.Name.ToUpper() == "PD_CRAR") || (lcDef.DispName.ToUpper() == "PD_CRAR"))
                    {
                        m_lifecycleDefComboBox.SelectedIndex = index;
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void GetCategories()
        {
            try
            {
                Cat[] categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FILE", true);
                // create a dummy category
                Cat baseCategory = new Cat()
                {
                    Id = -1,
                    Name = "<Base>"
                };

                int index = m_categoryComboBox.Items.Add(new CategoryListItem(baseCategory));
                m_categoryComboBox.SelectedIndex = index;

                if (categories == null)
                    return;

                foreach (Cat category in categories)
                {
                    index = m_categoryComboBox.Items.Add(new CategoryListItem(category));
                    if (category.Name.ToUpper() == "Customer Comment")
                    {
                        m_categoryComboBox.SelectedIndex = index;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmCustomerCommentLifecycle_Load(object sender, EventArgs e)
        {
            try
            {
                GetCategories();
                GetLifecycles();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            try
            {
                if (IsEditMode == true)
                {
                    txtCustomerCommentCustomerNumber.Text = _objSingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                    txtLifeCycleComment.Text = _objSingleCustomerCommentsummary.CustomerCommentRemark;
                }
                else
                {
                    _objSingleCustomerCommentsummary.CustomerCustomerCommentNumber = txtCustomerCommentCustomerNumber.Text;
                    _objSingleCustomerCommentsummary.CustomerCommentRemark = txtLifeCycleComment.Text;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }       

        private void cmdCustomerLifecycle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void m_lifecycleDefComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LifecycleDefinitionListItem lifecycleDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
            if (lifecycleDefItem == null || lifecycleDefItem.LifecycleDefinition == null)
                return;

            LfCycDef lifecycleDef = lifecycleDefItem.LifecycleDefinition;
            LfCycState[] states = lifecycleDef.StateArray;
            if (states == null)
                return;

            cmdCustomerLifecycle.Items.Clear();
            cmdCustomerLifecycle.Text = String.Empty;

            int index;
            foreach (LfCycState state in states)
            {
                index = cmdCustomerLifecycle.Items.Add(new LifecycleStateListItem(state));
                if ((state.DispName.ToUpper() == _objSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper()) || (state.Name.ToUpper() == _objSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper()))
                {
                    cmdCustomerLifecycle.SelectedIndex = index;
                }
            }
        }
    }

    public class CategoryListItem
    {
        public Cat Category;

        public CategoryListItem(Cat category)
        {
            this.Category = category;
        }

        public override string ToString()
        {
            return Category.Name;
        }
    }

    public class LifecycleStateListItem
    {
        public LfCycState LifecycleState;

        public LifecycleStateListItem(LfCycState lifecycleState)
        {
            this.LifecycleState = lifecycleState;
        }

        public override string ToString()
        {
            return LifecycleState.DispName;
        }
    }

    public class LifecycleDefinitionListItem
    {
        public LfCycDef LifecycleDefinition;

        public LifecycleDefinitionListItem(LfCycDef lifecycleDefinition)
        {
            this.LifecycleDefinition = lifecycleDefinition;
        }

        public override string ToString()
        {
            return LifecycleDefinition.DispName;
        }
    }

}
