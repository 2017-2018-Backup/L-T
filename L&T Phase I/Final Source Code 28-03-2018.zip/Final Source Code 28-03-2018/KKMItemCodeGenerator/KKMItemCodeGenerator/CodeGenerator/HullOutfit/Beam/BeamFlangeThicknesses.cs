﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamFlangeThicknesses : ObservableCollection<NameCodePair>
    {
        public static BeamFlangeThicknesses LoadList()
        {
            BeamFlangeThicknesses items = new BeamFlangeThicknesses();
            items.Add(new NameCodePair() { Code = "04A", Name = "4.1 mm" });
            items.Add(new NameCodePair() { Code = "04F", Name = "4.6 mm" });
            items.Add(new NameCodePair() { Code = "04H", Name = "4.8 mm" });
            items.Add(new NameCodePair() { Code = "005", Name = "5 mm" });
            items.Add(new NameCodePair() { Code = "06D", Name = "6.4 mm" });
            items.Add(new NameCodePair() { Code = "06E", Name = "6.5 mm" });
            items.Add(new NameCodePair() { Code = "06H", Name = "6.8 mm" });
            items.Add(new NameCodePair() { Code = "06I", Name = "6.9 mm" });
            items.Add(new NameCodePair() { Code = "007", Name = "7.0 mm" });
            items.Add(new NameCodePair() { Code = "07C", Name = "7.3 mm" });
            items.Add(new NameCodePair() { Code = "07D", Name = "7.4 mm" });
            items.Add(new NameCodePair() { Code = "07G", Name = "7.7 mm" });
            items.Add(new NameCodePair() { Code = "008", Name = "8.0 mm" });
            items.Add(new NameCodePair() { Code = "08B", Name = "8.2 mm" });
            items.Add(new NameCodePair() { Code = "08F", Name = "8.6 mm" });
            items.Add(new NameCodePair() { Code = "08H", Name = "8.8 mm" });
            items.Add(new NameCodePair() { Code = "009", Name = "9.0 mm" });
            items.Add(new NameCodePair() { Code = "09A", Name = "9.1 mm" });
            items.Add(new NameCodePair() { Code = "09D", Name = "9.4 mm" });
            items.Add(new NameCodePair() { Code = "09G", Name = "9.7 mm" });
            items.Add(new NameCodePair() { Code = "09H", Name = "9.8 mm" });
            items.Add(new NameCodePair() { Code = "09I", Name = "9.9 mm" });
            items.Add(new NameCodePair() { Code = "010", Name = "10.0 mm" });
            items.Add(new NameCodePair() { Code = "10F", Name = "10.6 mm" });
            items.Add(new NameCodePair() { Code = "011", Name = "11.0 mm" });
            items.Add(new NameCodePair() { Code = "11D", Name = "11.4 mm" });
            items.Add(new NameCodePair() { Code = "11F", Name = "11.6 mm" });
            items.Add(new NameCodePair() { Code = "11H", Name = "11.8 mm" });
            items.Add(new NameCodePair() { Code = "11I", Name = "11.9 mm" });
            items.Add(new NameCodePair() { Code = "12E", Name = "12.5 mm" });
            items.Add(new NameCodePair() { Code = "12G", Name = "12.7 mm" });
            items.Add(new NameCodePair() { Code = "013", Name = "13.0 mm" });
            items.Add(new NameCodePair() { Code = "13A", Name = "13.1 mm" });
            items.Add(new NameCodePair() { Code = "13D", Name = "13.4 mm" });
            items.Add(new NameCodePair() { Code = "13G", Name = "13.7 mm" });
            items.Add(new NameCodePair() { Code = "014", Name = "14.0 mm" });
            items.Add(new NameCodePair() { Code = "14B", Name = "14.2 mm" });
            items.Add(new NameCodePair() { Code = "14G", Name = "14.7 mm" });
            items.Add(new NameCodePair() { Code = "015", Name = "15.0 mm" });
            items.Add(new NameCodePair() { Code = "15D", Name = "15.4 mm" });
            items.Add(new NameCodePair() { Code = "15E", Name = "15.5 mm" });
            items.Add(new NameCodePair() { Code = "016", Name = "16.0 mm" });
            items.Add(new NameCodePair() { Code = "16E", Name = "16.5 mm" });
            items.Add(new NameCodePair() { Code = "017", Name = "17.0 mm" });
            items.Add(new NameCodePair() { Code = "17B", Name = "17.2 mm" });
            items.Add(new NameCodePair() { Code = "17D", Name = "17.4 mm" });
            items.Add(new NameCodePair() { Code = "17F", Name = "17.6 mm" });
            items.Add(new NameCodePair() { Code = "19C", Name = "19.3 mm" });
            items.Add(new NameCodePair() { Code = "20C", Name = "20.3 mm" });
            items.Add(new NameCodePair() { Code = "21C", Name = "21.3 mm" });
            items.Add(new NameCodePair() { Code = "23F", Name = "23.6 mm" });

            return items;
        }
        public static BeamFlangeThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamFlangeThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamFlangeThicknesses>(HullOutfitItems.DataPath + @"\Beam\BeamFlangeThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamFlangeThicknesses>(this, HullOutfitItems.DataPath + @"\Beam\BeamFlangeThicknesses.xml");
        }
    }
}
