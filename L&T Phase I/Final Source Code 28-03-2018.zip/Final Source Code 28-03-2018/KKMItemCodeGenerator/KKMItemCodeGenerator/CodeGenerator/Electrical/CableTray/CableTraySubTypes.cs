﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTraySubTypes : ObservableCollection<NameCodePair>
    {
        public static CableTraySubTypes LoadList()
        {
            CableTraySubTypes items = new CableTraySubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "STRAIGHT" });
            items.Add(new NameCodePair() { Code = "02", Name = "DROPPER" });
            items.Add(new NameCodePair() { Code = "03", Name = "RAISER" });
            items.Add(new NameCodePair() { Code = "04", Name = "BEND 90 DEG" });
            items.Add(new NameCodePair() { Code = "05", Name = "BEND 45 DEG" });
            items.Add(new NameCodePair() { Code = "06", Name = "TEE TYPE" });
            items.Add(new NameCodePair() { Code = "07", Name = "CROSS TYPE" });
            items.Add(new NameCodePair() { Code = "08", Name = "BRANCH TYPE" });
            items.Add(new NameCodePair() { Code = "09", Name = "REDUCER" });
            items.Add(new NameCodePair() { Code = "10", Name = "CONNECTING PIECE" });
            items.Add(new NameCodePair() { Code = "11", Name = "AUXILIARIES" });
            items.Add(new NameCodePair() { Code = "12", Name = "COUPLING PLATE" });
            items.Add(new NameCodePair() { Code = "13", Name = "TEE WITH REDUCER" });
            return items;
        }
        public static CableTraySubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTraySubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTraySubTypes>(ElectricalItems.DataPath + @"\CableTray\CableTrayTypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTraySubTypes>(this, ElectricalItems.DataPath + @"\CableTray\CableTrayTypes.xml");
        }

    }
}
