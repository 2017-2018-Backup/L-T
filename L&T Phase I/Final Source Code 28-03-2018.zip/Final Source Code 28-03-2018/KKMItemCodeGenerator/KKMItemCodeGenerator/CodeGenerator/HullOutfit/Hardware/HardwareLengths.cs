﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareLengths : ObservableCollection<NameCodePair>
    {
        public static HardwareLengths LoadList()
        {
            HardwareLengths items = new HardwareLengths();
            
            items.Add(new NameCodePair() { Code = "000", Name = "For Nut & Washer" });
            items.Add(new NameCodePair() { Code = "006", Name = "6 mm" });
            items.Add(new NameCodePair() { Code = "008", Name = "8 mm" });
            items.Add(new NameCodePair() { Code = "010", Name = "10 mm" });
            items.Add(new NameCodePair() { Code = "012", Name = "12 mm" });
            items.Add(new NameCodePair() { Code = "014", Name = "14 mm" });
            items.Add(new NameCodePair() { Code = "016", Name = "16 mm" });
            items.Add(new NameCodePair() { Code = "020", Name = "20 mm" });
            items.Add(new NameCodePair() { Code = "025", Name = "25 mm" });
            items.Add(new NameCodePair() { Code = "030", Name = "30 mm" });
            items.Add(new NameCodePair() { Code = "035", Name = "35 mm" });
            items.Add(new NameCodePair() { Code = "040", Name = "40 mm" });
            items.Add(new NameCodePair() { Code = "045", Name = "45 mm" });
            items.Add(new NameCodePair() { Code = "050", Name = "50 mm" });
            items.Add(new NameCodePair() { Code = "055", Name = "55 mm" });
            items.Add(new NameCodePair() { Code = "060", Name = "60 mm" });
            items.Add(new NameCodePair() { Code = "065", Name = "65 mm" });
            items.Add(new NameCodePair() { Code = "070", Name = "70 mm" });
            items.Add(new NameCodePair() { Code = "145", Name = "145 mm" });
            items.Add(new NameCodePair() { Code = "195", Name = "195 mm" });
            items.Add(new NameCodePair() { Code = "080", Name = "80 mm" });
            items.Add(new NameCodePair() { Code = "085", Name = "85mm" });
            items.Add(new NameCodePair() { Code = "090", Name = "90 mm" });
            items.Add(new NameCodePair() { Code = "115", Name = "115 mm" });
            items.Add(new NameCodePair() { Code = "075", Name = "75 mm" });
            items.Add(new NameCodePair() { Code = "100", Name = "100 mm" });
            items.Add(new NameCodePair() { Code = "105", Name = "105 mm" });
            items.Add(new NameCodePair() { Code = "125", Name = "125 mm" });
            items.Add(new NameCodePair() { Code = "130", Name = "130 mm" });
            items.Add(new NameCodePair() { Code = "140", Name = "140 mm" });
            items.Add(new NameCodePair() { Code = "150", Name = "150 mm" });
            items.Add(new NameCodePair() { Code = "160", Name = "160 mm" });
            items.Add(new NameCodePair() { Code = "200", Name = "200 mm" });
            items.Add(new NameCodePair() { Code = "170", Name = "170 mm" });
            items.Add(new NameCodePair() { Code = "180", Name = "180 mm" });
            items.Add(new NameCodePair() { Code = "01M", Name = "1000 mm" });
            items.Add(new NameCodePair() { Code = "240", Name = "240 mm" });
            items.Add(new NameCodePair() { Code = "570", Name = "570 mm" });
            items.Add(new NameCodePair() { Code = "210", Name = "210 mm" });
            items.Add(new NameCodePair() { Code = "230", Name = "230 mm" });
            items.Add(new NameCodePair() { Code = "120", Name = "120 mm" });
            items.Add(new NameCodePair() { Code = "470", Name = "470 mm" });
            items.Add(new NameCodePair() { Code = "550", Name = "550 mm" });
            items.Add(new NameCodePair() { Code = "190", Name = "190 mm" });
            items.Add(new NameCodePair() { Code = "110", Name = "110 mm" });


            return items;
        }
        public static HardwareLengths LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareLengths LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareLengths>(HullOutfitItems.DataPath + @"\Hardware\HardwareLengths.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareLengths>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareLengths.xml");
        }
    }
}
