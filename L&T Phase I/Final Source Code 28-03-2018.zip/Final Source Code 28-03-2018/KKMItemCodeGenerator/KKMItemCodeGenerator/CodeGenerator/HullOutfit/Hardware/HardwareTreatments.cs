﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareTreatments : ObservableCollection<NameCodePair>
    {
        public static HardwareTreatments LoadList()
        {
            HardwareTreatments items = new HardwareTreatments();
            items.Add(new NameCodePair() { Code = "P", Name = "NO TREATMENT" });
            items.Add(new NameCodePair() { Code = "G", Name = "GALVANISED" });
            items.Add(new NameCodePair() { Code = "B", Name = "BLACKENED" });
            items.Add(new NameCodePair() { Code = "Z", Name = "ZINC COATED" });

            return items;
        }
        public static HardwareTreatments LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareTreatments LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareTreatments>(HullOutfitItems.DataPath + @"\Hardware\HardwareTreatments.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareTreatments>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareTreatments.xml");
        }
    }
}
