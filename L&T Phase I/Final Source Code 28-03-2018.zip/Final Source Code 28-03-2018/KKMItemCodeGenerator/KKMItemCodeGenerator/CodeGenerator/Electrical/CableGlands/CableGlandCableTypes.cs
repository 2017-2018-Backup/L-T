﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandCableTypes : ObservableCollection<NameCodePair>
    {
        public static CableGlandCableTypes LoadList()
        {
            CableGlandCableTypes items = new CableGlandCableTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "UNARMOURED CABLE" });
            items.Add(new NameCodePair() { Code = "02", Name = "ARMOURED CABLE" });
            items.Add(new NameCodePair() { Code = "03", Name = "NA" });

            return items;
        }
        public static CableGlandCableTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandCableTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandCableTypes>(ElectricalItems.DataPath + @"\CableGland\CableGlandCableTypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandCableTypes>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandCableTypes.xml");
        }

    }
}
