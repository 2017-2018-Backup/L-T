﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsHODimention2 : ObservableCollection<NameCodePair>
    {
        public static BarsHODimention2 LoadList()
        {
            BarsHODimention2 items = new BarsHODimention2();
            items.Add(new NameCodePair() { Code = "000", Name = "FOR SQUARE BAR, HOLLOW SQUARE BAR" });
            items.Add(new NameCodePair() { Code = "000", Name = "FOR ROUND BAR" });
            return items;
        }
        public static BarsHODimention2 LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsHODimention2 LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsHODimention2>(HullOutfitItems.DataPath + @"\Bars\BarsHODimention2.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsHODimention2>(this, HullOutfitItems.DataPath + @"\Bars\BarsHODimention2.xml");
        }
    }
}
