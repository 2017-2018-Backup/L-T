﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class EngineeringItems : ObservableCollection<NameCodePair>
    {
       public static String DataPath ="";
        public static EngineeringItems LoadList()
        {
            EngineeringItems items = new EngineeringItems();
            items.Add(new NameCodePair() { Code = "PI", Name = "PIPES" });
            items.Add(new NameCodePair() { Code = "PF", Name = "FLANGES AND GASKETS" });
            items.Add(new NameCodePair() { Code = "PW", Name = "FITTINGS BW" });
            items.Add(new NameCodePair() { Code = "PT", Name = "PIPE FITTINGS" });
            items.Add(new NameCodePair() { Code = "PV", Name = "VALVES" });
            items.Add(new NameCodePair() { Code = "PS", Name = "STRAINER" });
            items.Add(new NameCodePair() { Code = "PC", Name = "SUPPORTS" });
            return items;
        }
        public static EngineeringItems LoadFromExcel(String path)
        {
            return null;
        }

        public static EngineeringItems LoadFromXml(string path)
        {            
            EngineeringItems.DataPath = path + @"\Engineering";
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<EngineeringItems>(EngineeringItems.DataPath + @"\EngineeringItems.xml");
        }

        public void ExportToXml(string path)
        {
            EngineeringItems.DataPath = path + @"\Engineering";
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath);
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<EngineeringItems>(this, EngineeringItems.DataPath + @"\EngineeringItems.xml");
        }

    }
}
