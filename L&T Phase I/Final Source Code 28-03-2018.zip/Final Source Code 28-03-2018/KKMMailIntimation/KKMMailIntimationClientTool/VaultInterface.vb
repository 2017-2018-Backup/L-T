﻿Imports Autodesk.Connectivity.Explorer.Extensibility
Imports Autodesk.Connectivity.WebServicesTools
Imports Autodesk.Connectivity.WebServices
Imports Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections
Imports Autodesk.Connectivity.Extensibility.Framework
Imports System.Windows.Interop
Imports System.Text
Imports System.Windows.Forms.Integration





' Make sure to generate your own ID when writing your own extension.
<Assembly: Autodesk.Connectivity.Extensibility.Framework.ExtensionId("34503DAE-AC22-49E4-8ACB-39F7DEC5BDCA")>

' This number gets incremented for each Vault release.
<Assembly: Autodesk.Connectivity.Extensibility.Framework.ApiVersion("11.0")>

Namespace KKMMailIntimationClientTool

    Public Class CommandExtension
        Implements IExplorerExtension

        Public vConnection As Connection
        '    Dim cred As UserIdTicketCredentials
        Public Shared _remoteHost, _knowledgeVault As String
        Public Shared isAdministrator As Boolean


#Region "IExplorerExtension Members"


        Public Function CommandSites() As IEnumerable(Of CommandSite) Implements IExplorerExtension.CommandSites
            Dim _cmdItem As New CommandItem("KKMiVaultTools", "Mail Intimation")
            _cmdItem.Image = My.Resources.L_T


            _cmdItem.Hint = "Custom Tools For Vault"
            AddHandler _cmdItem.Execute, AddressOf _cmdItem_Execute


            Dim _toolbarBtn As New CommandSite("KKMiVaultTools.Toolbar", "Mail Intimation") With
                {
                    .Location = CommandSiteLocation.AdvancedToolbar,
                    .DeployAsPulldownMenu = False
                }
            _toolbarBtn.AddCommand(_cmdItem)

            '         Dim _Publish_file As New CommandItem("PublishFile", "Publish File") With {
            ' .NavigationTypes = New SelectionTypeId() {SelectionTypeId.File},
            ' .MultiSelectEnabled = True
            '}

            '         _Publish_file.Image = My.Resources.pdf
            '         _Publish_file.Hint = "Publish selected file in PDF format"
            '         AddHandler _Publish_file.Execute, AddressOf _Publish_file_CmdHandler

            '         Dim PublishFile_CmdSite As New CommandSite("PublishFile.FileContextMenu", "Publish File") With {
            '   .Location = CommandSiteLocation.FileContextMenu,
            '   .DeployAsPulldownMenu = False
            '  }
            '         PublishFile_CmdSite.AddCommand(_Publish_file)


            Dim sites As New List(Of CommandSite)()


            sites.Add(_toolbarBtn)
            ''sites.Add(PublishFile_CmdSite)


            Return sites
        End Function

        Public Function CustomEntityHandlers() As IEnumerable(Of CustomEntityHandler) Implements IExplorerExtension.CustomEntityHandlers
            Return Nothing
        End Function

        Public Function DetailTabs() As IEnumerable(Of DetailPaneTab) Implements IExplorerExtension.DetailTabs
            Return Nothing
        End Function

        Public Function HiddenCommands() As IEnumerable(Of String) Implements IExplorerExtension.HiddenCommands
            Return Nothing
        End Function

        Public Sub OnLogOff(ByVal application As IApplication) Implements IExplorerExtension.OnLogOff

        End Sub

        Public Sub OnLogOn(ByVal application As IApplication) Implements IExplorerExtension.OnLogOn
            If vConnection IsNot Nothing Then
                vConnection.ClearCache(CachedObjects.All)
            End If

            ' Use the IApplication object to create a credentials object.
            AddHandler application.CommandBegin, AddressOf application_CommandBegin
            AddHandler application.CommandEnd, AddressOf application_CommandEnd

            ' Use the credentials to create a new WebServiceManager object.
            vConnection = application.Connection 'application.Connection.WebServiceManager()
        End Sub

        Private Sub application_CommandEnd(ByVal sender As Object, ByVal e As CommandEndEventArgs)

        End Sub

        Private Sub application_CommandBegin(ByVal sender As Object, ByVal e As CommandBeginEventArgs)

        End Sub
        Public Sub OnShutdown(ByVal application As IApplication) Implements IExplorerExtension.OnShutdown

        End Sub

        Public Sub OnStartup(ByVal application As IApplication) Implements IExplorerExtension.OnStartup

        End Sub

#End Region


        Private Sub _Publish_file_CmdHandler(ByVal _obj As Object, ByVal e As CommandItemEventArgs)
            Try
                ' MessageBox.Show("Development in Progress!", "Vault Publish Tool", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Dim _fileId As Long
                Dim msg = String.Empty
                Dim count As Int16 = 0
                For Each selection As ISelection In e.Context.CurrentSelectionSet
                    If selection.TypeId = SelectionTypeId.File Then
                        '_fileId = selection.Id
                        Dim _file As File = vConnection.WebServiceManager.DocumentService.GetLatestFileByMasterId(selection.Id)


                        Dim _filename As String = _file.Name ' vConnection.WebServiceManager.DocumentService.GetLatestFileByMasterId(selection.Id).Name
                        _fileId = _file.Id
                        '  Dim ids(0) As Long
                        '  ids(0) = _fileId
                        ' m_mgr.DocumentService.GetLinksByIds(ids)
                        If System.IO.Path.GetExtension(_filename).Equals(".idw", StringComparison.InvariantCultureIgnoreCase) Or System.IO.Path.GetExtension(_filename).Equals(".dwg", StringComparison.InvariantCultureIgnoreCase) Then
                            Const PublishJobTypeName As String = "KKMiVaultJobProcessor.Publish.File"
                            Const PublishJob_FileId As String = "FileId"
                            Const PublishJob_FileName As String = "FileName"



                            ' For Each vaultObj As ISelection In e.Context.CurrentSelectionSet
                            Dim paramList As JobParam() = New JobParam(2) {}
                            Dim masterIdParam As New JobParam()
                            masterIdParam.Name = PublishJob_FileId
                            masterIdParam.Val = _fileId.ToString() ' vaultObj.Id.ToString()
                            paramList(0) = masterIdParam

                            Dim fileNameParam As New JobParam()
                            fileNameParam.Name = PublishJob_FileName
                            fileNameParam.Val = _filename
                            paramList(1) = fileNameParam

                            Dim isMasterId As New JobParam()
                            isMasterId.Name = "isMasterId"
                            isMasterId.Val = "False" ' vaultObj.Label
                            paramList(2) = isMasterId
                            ' Add the job to the queue
                            '
                            vConnection.WebServiceManager.JobService.AddJob(PublishJobTypeName, [String].Format("Publish File - {0}", fileNameParam.Val), paramList, 2)



                            '     Next
                            msg = msg + _filename + vbNewLine
                            count = count + 1
                            'If GenerateXml("FILE", _fileId, System.IO.Path.GetFileNameWithoutExtension(_filename)) Then
                            '    MessageBox.Show(_filename & " has been submitted to the Publish Queue!", "Vault Publish Tool", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            'End If
                        End If
                    End If
                Next
                If msg.Equals(String.Empty) Then
                    MessageBox.Show("Only *.idw and *.dwg files can be Published!" + vbNewLine + msg, "Mail Intimation", MessageBoxButton.OK, MessageBoxImage.Information) ' Forms.MessageBoxIcon.Information)
                Else
                    If count.Equals(1) Then
                        MessageBox.Show("The Following File has been added to KKM iVault Publish Tool Job Queue" + msg, "Mail Intimation", MessageBoxButton.OK, MessageBoxImage.Information)
                    Else
                        MessageBox.Show("The Following Files has been added to KKM iVault Publish Tool Job Queue!" + vbNewLine + msg, "Mail Intimation", MessageBoxButton.OK, MessageBoxImage.Information)
                    End If
                End If

            Catch ex As Exception
                If ex.Message.Equals("237", StringComparison.InvariantCultureIgnoreCase) Then
                    MessageBox.Show("The Selected File/Files has been already added to KKM iVault Publish Tool Job Queue!", "Mail Intimation", MessageBoxButton.OK, MessageBoxImage.Information)
                End If
            End Try
        End Sub

        Private Sub _cmdItem_Execute(ByVal sender As Object, ByVal e As CommandItemEventArgs)


            vConnection = e.Context.Application.Connection
            Try
                'Dim selection As ISelection = e.Context.CurrentSelectionSet.First()

                'Dim linkText As String = [String].Empty
                'Dim htmlText As String = [String].Empty
                'If selection.TypeId = SelectionTypeId.File OrElse selection.TypeId = SelectionTypeId.FileVersion Then


                '    Dim vaultFolder As Folder = vConnection.WebServiceManager.DocumentService.GetFoldersByFileMasterId(selection.Id)(0)
                '    Dim vaultFile As File = Nothing

                '    If selection.TypeId = SelectionTypeId.File Then
                '        vaultFile = vConnection.WebServiceManager.DocumentService.GetLatestFileByMasterId(selection.Id)
                '    ElseIf selection.TypeId = SelectionTypeId.FileVersion Then
                '        vaultFile = vConnection.WebServiceManager.DocumentService.GetFileById(selection.Id)
                '    End If


                '    Dim newUri As New UriBuilder(vConnection.WebServiceManager.DocumentService.Url)
                '    newUri.Path = "AutodeskDM/Services/EntityDataCommandRequest.aspx"
                '    newUri.Query = String.Format("Vault={0}&ObjectId={1}&ObjectType={2}&Command=Select", vConnection.Vault, EscapeHTML(VaultPath.Combine(vaultFolder.FullName, vaultFile.Name)), "File")

                '    ConvertUri(newUri, vaultFile.Name, linkText, htmlText)


                '    'Dim newUri = New UriBuilder(vConnection.WebServiceManager.DocumentService.Url)
                '    'newUri.Path = "AutodeskDM/webclient/FilePreviewPage.aspx"
                '    'newUri.Query = "iterationId=" + vaultFile.Id.ToString()
                '    'ConvertUri(newUri, vaultFile.Name, linkText, htmlText)
                'End If

                isAdministrator = False
                Dim _roles As Autodesk.Connectivity.WebServices.Role() = Nothing
                Try
                    _roles = vConnection.WebServiceManager.AdminService.GetRolesByUserId(vConnection.UserID)
                Catch ex As Exception

                End Try
                If _roles IsNot Nothing Then
                    For Each _role As Role In _roles
                        If _role.Name.Equals("Administrator", StringComparison.InvariantCultureIgnoreCase) Then
                            isAdministrator = True
                            Exit For
                        End If
                    Next
                End If


                If isAdministrator Then
                    Dim obj As New UI(vConnection)
                    obj.ShowDialog()
                Else
                    MessageBox.Show("Only users with Administrator rights can access Settings!", "Mail Intimation", Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Information)
                End If

            Catch ex As Exception

            End Try
        End Sub

        Private Sub ConvertUri(ByVal baseLink As UriBuilder, ByVal title As String, ByVal linkText As String, ByVal htmlText As String)
            'Dim hosts As New List(Of String)() With { _
            '	baseLink.Host _
            '}

            '     If settings.MultiWorkgroups Then
            'If m_sitelist Is Nothing Then
            '    m_sitelist = SiteList.Load()
            'End If

            'If m_sitelist.Sites.Count = 0 Then
            '    MessageBox.Show("Multi-site links required a configured site list.  See your Vault administrator.")
            '    linkText = [String].Empty
            '    htmlText = [String].Empty
            'End If

            'Dim linkTextBuilder As New StringBuilder()
            'Dim htmlTextBuilder As New StringBuilder()
            'htmlTextBuilder.Append(String.Format("<i>{0}</i> (", title))

            'For i As Integer = 0 To m_sitelist.Sites.Count() - 1
            '    Dim site As Site = m_sitelist.Sites(i)
            '    baseLink.Host = site.Hostname
            '    baseLink.Scheme = If(site.IsSSL, "https", "http")
            '    If site.Port <> 0 Then
            '        baseLink.Port = site.Port
            '    Else
            '        baseLink.Port = If(site.IsSSL, 443, 80)
            '    End If

            '    linkTextBuilder.AppendLine(site.Name + " - " + baseLink.ToString())

            '    If i > 0 Then
            '        htmlTextBuilder.Append(" - ")
            '    End If

            '    htmlTextBuilder.Append(String.Format("<a href=""{0}"">{1}</a>", baseLink.ToString(), site.Name))
            'Next
            'htmlTextBuilder.Append(")")
            'linkText = linkTextBuilder.ToString()
            'htmlText = htmlTextBuilder.ToString()
            'Else
            linkText = baseLink.ToString()
            htmlText = String.Format("<a href=""{0}"">{1}</a>", baseLink.ToString(), title)
            '    End If
        End Sub

        Public Shared Function EscapeHTML(ByVal value As [String]) As String
            Dim retVal As String = value
            retVal = retVal.Replace("$", "%24")
            retVal = retVal.Replace("/", "%2f")
            retVal = retVal.Replace(" ", "+")
            Return retVal
        End Function


    End Class





End Namespace

