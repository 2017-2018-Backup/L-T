﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingElbowSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingElbowSubTypes LoadList()
        {
            PipeFittingElbowSubTypes items = new PipeFittingElbowSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "1.5D 90˚" });
            items.Add(new NameCodePair() { Code = "02", Name = "1.5D 45˚" });
            items.Add(new NameCodePair() { Code = "03", Name = "1.5D 30˚" });
            items.Add(new NameCodePair() { Code = "04", Name = "1.5D 180˚" });
            items.Add(new NameCodePair() { Code = "05", Name = "1.5D 100˚" });
            items.Add(new NameCodePair() { Code = "06", Name = "1.5D 22.5˚" });
            items.Add(new NameCodePair() { Code = "07", Name = "1.5D 10˚" });
            items.Add(new NameCodePair() { Code = "08", Name = "1D 90˚" });
            items.Add(new NameCodePair() { Code = "09", Name = "1D 45˚" });
            items.Add(new NameCodePair() { Code = "10", Name = "1D 30˚" });
            items.Add(new NameCodePair() { Code = "11", Name = "1D 180˚" });
            items.Add(new NameCodePair() { Code = "12", Name = "1D 100˚" });
            items.Add(new NameCodePair() { Code = "13", Name = "1D 22.5˚" });
            items.Add(new NameCodePair() { Code = "14", Name = "1D 10˚" });
            items.Add(new NameCodePair() { Code = "15", Name = "2D 90˚" });
            items.Add(new NameCodePair() { Code = "16", Name = "3D 90˚" });
            items.Add(new NameCodePair() { Code = "17", Name = "5D 90˚" });
            return items;
        }
        public static PipeFittingElbowSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingElbowSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingElbowSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingElbowSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingElbowSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingElbowSubTypes.xml");
        }

    }
}
