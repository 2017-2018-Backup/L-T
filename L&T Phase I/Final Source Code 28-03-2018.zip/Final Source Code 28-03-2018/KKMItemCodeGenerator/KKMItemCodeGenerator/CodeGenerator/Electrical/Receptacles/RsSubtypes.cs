﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class RsSubtypes : ObservableCollection<NameCodePair>
    {
       public static RsSubtypes LoadList()
        {
            RsSubtypes items = new RsSubtypes();
            items.Add(new NameCodePair() { Code = "01", Name = "WATER TIGHT" });
            items.Add(new NameCodePair() { Code = "02", Name = "NON WATER TIGHT" });
            items.Add(new NameCodePair() { Code = "03", Name = "EXPLOSION PROOF" });
            return items;
        }
        public static RsSubtypes LoadFromExcel(String path)
        {
            return null;
        }

        public static RsSubtypes LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<RsSubtypes>(ElectricalItems.DataPath + @"\Receptacles\RsSubtypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<RsSubtypes>(this, ElectricalItems.DataPath + @"\Receptacles\RsSubtypes.xml");
        }

    }
}
