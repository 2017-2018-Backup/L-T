﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingAdaptorSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingAdaptorSubTypes LoadList()
        {
            PipeFittingAdaptorSubTypes items = new PipeFittingAdaptorSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "UNION" });
            items.Add(new NameCodePair() { Code = "02", Name = "FEMALE UNION" });
            items.Add(new NameCodePair() { Code = "03", Name = "UNION ANGLE" });
            items.Add(new NameCodePair() { Code = "04", Name = "REDUCING ADAPTOR" });
            items.Add(new NameCodePair() { Code = "05", Name = "SWIVEL TYPE" });
            items.Add(new NameCodePair() { Code = "06", Name = "WELD NIPPLE" });
            return items;
        }
        public static PipeFittingAdaptorSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingAdaptorSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingAdaptorSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingAdaptorSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingAdaptorSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingAdaptorSubTypes.xml");
        }

    }
}
