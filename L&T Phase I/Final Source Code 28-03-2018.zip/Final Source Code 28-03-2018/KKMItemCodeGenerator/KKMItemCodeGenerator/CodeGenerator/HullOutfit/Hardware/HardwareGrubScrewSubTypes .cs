﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareGrubScrewSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareGrubScrewSubTypes LoadList()
        {
            HardwareGrubScrewSubTypes items = new HardwareGrubScrewSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Slotted Stub Screw" });
            items.Add(new NameCodePair() { Code = "02", Name = "Hex.Soc. Grub Screw" });
            return items;
        }
        public static HardwareGrubScrewSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareGrubScrewSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareGrubScrewSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareGrubScrewSubTypes .xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareGrubScrewSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareGrubScrewSubTypes .xml");
        }
    }
}
