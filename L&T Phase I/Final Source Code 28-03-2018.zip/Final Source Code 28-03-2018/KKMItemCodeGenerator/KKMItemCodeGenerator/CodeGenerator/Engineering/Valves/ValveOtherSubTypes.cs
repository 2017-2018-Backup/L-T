﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveOtherSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveOtherSubTypes LoadList()
        {
            ValveOtherSubTypes items = new ValveOtherSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Storm Valve" });
            items.Add(new NameCodePair() { Code = "02", Name = "Self Closing" });
            items.Add(new NameCodePair() { Code = "03", Name = "Diaphram Valve" });
            items.Add(new NameCodePair() { Code = "04", Name = "Air Hood" });
            items.Add(new NameCodePair() { Code = "05", Name = "Foot Valve with Strainer" });
            items.Add(new NameCodePair() { Code = "06", Name = "Quick Closing Valve" });
            items.Add(new NameCodePair() { Code = "07", Name = "High Velocity PV Valve" });
            items.Add(new NameCodePair() { Code = "08", Name = "Blind Flange Valve" });
            items.Add(new NameCodePair() { Code = "09", Name = "Air hood with Insect Screen" });
            items.Add(new NameCodePair() { Code = "10", Name = "Air hood with Flame Screen" });
            items.Add(new NameCodePair() { Code = "11", Name = "Fire Hydrant - Right angled" });
            items.Add(new NameCodePair() { Code = "12", Name = "Flow Meter with Strainer" });
            items.Add(new NameCodePair() { Code = "13", Name = "Flow Meter" });
            items.Add(new NameCodePair() { Code = "14", Name = "Temperature Regulating Valve" });
            items.Add(new NameCodePair() { Code = "15", Name = "BIB Valve" });
            items.Add(new NameCodePair() { Code = "16", Name = "Storm Valve - Angled" });
            items.Add(new NameCodePair() { Code = "17", Name = "Self Closing Flushing Valve" });
            items.Add(new NameCodePair() { Code = "18", Name = "Air hood for Mud Tank" });
            items.Add(new NameCodePair() { Code = "19", Name = "Self Closing Sounding Cock" });
            items.Add(new NameCodePair() { Code = "20", Name = "Fire Hydrant - Straight type" });
            items.Add(new NameCodePair() { Code = "21", Name = "Screwed Cap" });
            items.Add(new NameCodePair() { Code = "22", Name = "Gauge Glass" });
            items.Add(new NameCodePair() { Code = "23", Name = "Sight Galss" });
            items.Add(new NameCodePair() { Code = "24", Name = "Purge valve" });

            return items;
        }
        public static ValveOtherSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveOtherSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveOtherSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveOtherSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveOtherSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveOtherSubTypes.xml");
        }

    }
}
