﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingTeeSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingTeeSubTypes LoadList()
        {
            PipeFittingTeeSubTypes items = new PipeFittingTeeSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "TEE EQUAL" });
            items.Add(new NameCodePair() { Code = "02", Name = "TEE UNEQUAL" });
            items.Add(new NameCodePair() { Code = "03", Name = "Y BRANCH 45DEG" });
            items.Add(new NameCodePair() { Code = "04", Name = "SADDLE" });
            items.Add(new NameCodePair() { Code = "05", Name = "SWEPT TYPE" });
            return items;
        }
        public static PipeFittingTeeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingTeeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingTeeSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingTeeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingTeeSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingTeeSubTypes.xml");
        }

    }
}
