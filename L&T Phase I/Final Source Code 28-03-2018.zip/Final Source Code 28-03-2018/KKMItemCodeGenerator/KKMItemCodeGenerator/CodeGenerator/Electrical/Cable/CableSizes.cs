﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableSizes : ObservableCollection<NameCodePair>
    {
        public static CableSizes LoadList()
        {
            CableSizes items = new CableSizes();
            items.Add(new NameCodePair() { Code = "01", Name = "1x2x0.75" });
            items.Add(new NameCodePair() { Code = "02", Name = "1x2x1" });
            items.Add(new NameCodePair() { Code = "03", Name = "1x35" });
            items.Add(new NameCodePair() { Code = "04", Name = "1x3x0.75" });
            items.Add(new NameCodePair() { Code = "05", Name = "1x4x0.75" });
            items.Add(new NameCodePair() { Code = "06", Name = "1x6" });
            items.Add(new NameCodePair() { Code = "07", Name = "1x70" });
            items.Add(new NameCodePair() { Code = "08", Name = "1x95" });
            items.Add(new NameCodePair() { Code = "09", Name = "1x16" });
            items.Add(new NameCodePair() { Code = "10", Name = "2x0.75" });
            items.Add(new NameCodePair() { Code = "11", Name = "2x1" });
            items.Add(new NameCodePair() { Code = "12", Name = "2x1.5" });
            items.Add(new NameCodePair() { Code = "13", Name = "2x10" });
            items.Add(new NameCodePair() { Code = "14", Name = "2x2.5" });
            items.Add(new NameCodePair() { Code = "15", Name = "2x2x0.75" });
            items.Add(new NameCodePair() { Code = "16", Name = "2x3x0.75" });
            items.Add(new NameCodePair() { Code = "17", Name = "2x4" });
            items.Add(new NameCodePair() { Code = "18", Name = "2x6" });
            items.Add(new NameCodePair() { Code = "19", Name = "3x0.75" });
            items.Add(new NameCodePair() { Code = "20", Name = "3x1" });
            items.Add(new NameCodePair() { Code = "21", Name = "3x1.5" });
            items.Add(new NameCodePair() { Code = "22", Name = "3x10" });
            items.Add(new NameCodePair() { Code = "23", Name = "3x120" });
            items.Add(new NameCodePair() { Code = "24", Name = "3x16" });
            items.Add(new NameCodePair() { Code = "25", Name = "3x2.5" });
            items.Add(new NameCodePair() { Code = "26", Name = "3x25" });
            items.Add(new NameCodePair() { Code = "27", Name = "3x2x0.75" });
            items.Add(new NameCodePair() { Code = "28", Name = "3x35" });
            items.Add(new NameCodePair() { Code = "29", Name = "3x3x0.75" });
            items.Add(new NameCodePair() { Code = "30", Name = "3x4" });
            items.Add(new NameCodePair() { Code = "31", Name = "3x50" });
            items.Add(new NameCodePair() { Code = "32", Name = "3x6" });
            items.Add(new NameCodePair() { Code = "33", Name = "3x70" });
            items.Add(new NameCodePair() { Code = "34", Name = "3x95" });
            items.Add(new NameCodePair() { Code = "35", Name = "4x0.75" });
            items.Add(new NameCodePair() { Code = "36", Name = "4x1.0" });
            items.Add(new NameCodePair() { Code = "37", Name = "4x1.5" });
            items.Add(new NameCodePair() { Code = "38", Name = "4x2x0.75" });
            items.Add(new NameCodePair() { Code = "39", Name = "4x2x1.5" });
            items.Add(new NameCodePair() { Code = "40", Name = "5x0.75" });
            items.Add(new NameCodePair() { Code = "41", Name = "5x1" });
            items.Add(new NameCodePair() { Code = "42", Name = "5x1.5" });
            items.Add(new NameCodePair() { Code = "43", Name = "6x0.75" });
            items.Add(new NameCodePair() { Code = "44", Name = "6x1.0" });
            items.Add(new NameCodePair() { Code = "45", Name = "6x1.5" });
            items.Add(new NameCodePair() { Code = "46", Name = "6x2x0.75" });
            items.Add(new NameCodePair() { Code = "47", Name = "7x0.75" });
            items.Add(new NameCodePair() { Code = "48", Name = "7x1.5" });
            items.Add(new NameCodePair() { Code = "49", Name = "7x2x0.75" });
            items.Add(new NameCodePair() { Code = "50", Name = "8x0.75" });
            items.Add(new NameCodePair() { Code = "51", Name = "8x1.5" });
            items.Add(new NameCodePair() { Code = "52", Name = "8x2x0.75" });
            items.Add(new NameCodePair() { Code = "53", Name = "8x3x1.0" });
            items.Add(new NameCodePair() { Code = "54", Name = "10x0.75" });
            items.Add(new NameCodePair() { Code = "55", Name = "10x1" });
            items.Add(new NameCodePair() { Code = "56", Name = "10x1.5" });
            items.Add(new NameCodePair() { Code = "57", Name = "10x2x0.75" });
            items.Add(new NameCodePair() { Code = "58", Name = "12x0.75" });
            items.Add(new NameCodePair() { Code = "59", Name = "12x1.5" });
            items.Add(new NameCodePair() { Code = "60", Name = "14x1.5" });
            items.Add(new NameCodePair() { Code = "61", Name = "14x2x0.75" });
            items.Add(new NameCodePair() { Code = "62", Name = "15x0.75" });
            items.Add(new NameCodePair() { Code = "63", Name = "16x0.75" });
            items.Add(new NameCodePair() { Code = "64", Name = "18x0.75" });
            items.Add(new NameCodePair() { Code = "65", Name = "18x1.5" });
            items.Add(new NameCodePair() { Code = "66", Name = "19x0.75" });
            items.Add(new NameCodePair() { Code = "67", Name = "19x1" });
            items.Add(new NameCodePair() { Code = "68", Name = "19x1.5" });
            items.Add(new NameCodePair() { Code = "69", Name = "20x1" });
            items.Add(new NameCodePair() { Code = "70", Name = "20x1.5" });
            items.Add(new NameCodePair() { Code = "71", Name = "24x0.75" });
            items.Add(new NameCodePair() { Code = "72", Name = "29x0.75" });
            items.Add(new NameCodePair() { Code = "73", Name = "30x0.75" });
            items.Add(new NameCodePair() { Code = "74", Name = "30x1.5" });
            items.Add(new NameCodePair() { Code = "75", Name = "32x1.5" });
            items.Add(new NameCodePair() { Code = "76", Name = "37x1.5" });
            items.Add(new NameCodePair() { Code = "77", Name = "6x62.5" });
            items.Add(new NameCodePair() { Code = "78", Name = "2x2x0.48" });
            items.Add(new NameCodePair() { Code = "79", Name = "2x0.35" });
            items.Add(new NameCodePair() { Code = "80", Name = "3x185" });
            items.Add(new NameCodePair() { Code = "81", Name = "3x150" });
            items.Add(new NameCodePair() { Code = "82", Name = "2x35" });
            items.Add(new NameCodePair() { Code = "83", Name = "1x25" });
            items.Add(new NameCodePair() { Code = "84", Name = "1x10" });
            items.Add(new NameCodePair() { Code = "85", Name = "19x2x0.75" });
            items.Add(new NameCodePair() { Code = "86", Name = "NA" });
            items.Add(new NameCodePair() { Code = "87", Name = "3x185+3x35" });
            items.Add(new NameCodePair() { Code = "88", Name = "16x1.5" });
            items.Add(new NameCodePair() { Code = "89", Name = "27x1.5" });
            items.Add(new NameCodePair() { Code = "90", Name = "1x2x1.5" });
            items.Add(new NameCodePair() { Code = "91", Name = "2x2x1.5" });
            items.Add(new NameCodePair() { Code = "92", Name = "5x3x1.5" });
            items.Add(new NameCodePair() { Code = "93", Name = "7x2x1.5" });
            items.Add(new NameCodePair() { Code = "94", Name = "4Gx16" });
            items.Add(new NameCodePair() { Code = "95", Name = "2x0.5" });
            items.Add(new NameCodePair() { Code = "96", Name = "10x2x1.5" });
            items.Add(new NameCodePair() { Code = "97", Name = "19x2x1.5" });
            items.Add(new NameCodePair() { Code = "98", Name = "5x2x1.5" });
            items.Add(new NameCodePair() { Code = "99", Name = "5x2x0.75" });
            items.Add(new NameCodePair() { Code = "100", Name = "2x16" });
            items.Add(new NameCodePair() { Code = "101", Name = "2x25" });
            items.Add(new NameCodePair() { Code = "102", Name = "1x3x0.75" });
            items.Add(new NameCodePair() { Code = "103", Name = "1x240" });
            items.Add(new NameCodePair() { Code = "104", Name = "1x185" });
            items.Add(new NameCodePair() { Code = "105", Name = "1x120" });
            items.Add(new NameCodePair() { Code = "106", Name = "1x50" });
            items.Add(new NameCodePair() { Code = "107", Name = "4x25" });
            items.Add(new NameCodePair() { Code = "108", Name = "4x10" });
            items.Add(new NameCodePair() { Code = "109", Name = "4x35" });
            items.Add(new NameCodePair() { Code = "110", Name = "4x6" });
            items.Add(new NameCodePair() { Code = "111", Name = "4x70" });
            items.Add(new NameCodePair() { Code = "112", Name = "7x1" });
            items.Add(new NameCodePair() { Code = "113", Name = "5x2x0.5" });
            items.Add(new NameCodePair() { Code = "114", Name = "25x2x0.5" });
            items.Add(new NameCodePair() { Code = "115", Name = "24x2x0.75" });
            return items;
        }
        public static CableSizes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableSizes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableSizes>(ElectricalItems.DataPath + @"\Cable\CableSizes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableSizes>(this, ElectricalItems.DataPath + @"\Cable\CableSizes.xml");
        }

    }
}
