﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingPlugSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingPlugSubTypes LoadList()
        {
            PipeFittingPlugSubTypes items = new PipeFittingPlugSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "PLUG HEX. HEAD" });
            items.Add(new NameCodePair() { Code = "02", Name = "HEX. HEAD PIPE PLUG" });
            items.Add(new NameCodePair() { Code = "03", Name = "HOLLOW HEX. PLUG" });
            items.Add(new NameCodePair() { Code = "04", Name = "DRAIN PLUG" });
            items.Add(new NameCodePair() { Code = "05", Name = "PLUG" });
            items.Add(new NameCodePair() { Code = "06", Name = "HEX DOUBLE NIPPLE" });
            items.Add(new NameCodePair() { Code = "07", Name = "PLUG ROUND HEAD" });
            items.Add(new NameCodePair() { Code = "08", Name = "PLUG SQUARE HEAD" });
            items.Add(new NameCodePair() { Code = "09", Name = "HEX. PLUG" });
            return items;
        }
        public static PipeFittingPlugSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingPlugSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingPlugSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingPlugSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingPlugSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingPlugSubTypes.xml");
        }

    }
}
