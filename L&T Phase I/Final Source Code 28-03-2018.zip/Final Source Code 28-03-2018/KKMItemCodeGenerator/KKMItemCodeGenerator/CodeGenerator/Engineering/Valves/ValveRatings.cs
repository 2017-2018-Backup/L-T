﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveRatings : ObservableCollection<NameCodePair>
    {
        public static ValveRatings LoadList()
        {
            ValveRatings items = new ValveRatings();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "PN6" });
            items.Add(new NameCodePair() { Code = "02", Name = "PN10" });
            items.Add(new NameCodePair() { Code = "03", Name = "PN16" });
            items.Add(new NameCodePair() { Code = "04", Name = "PN25" });
            items.Add(new NameCodePair() { Code = "05", Name = "PN40" });
            items.Add(new NameCodePair() { Code = "06", Name = "PN64" });
            items.Add(new NameCodePair() { Code = "07", Name = "PN125" });
            items.Add(new NameCodePair() { Code = "08", Name = "ASME-150#" });
            items.Add(new NameCodePair() { Code = "09", Name = "ASME 200#" });
            items.Add(new NameCodePair() { Code = "10", Name = "ASME 300#" });
            items.Add(new NameCodePair() { Code = "11", Name = "ASME 600#" });
            items.Add(new NameCodePair() { Code = "12", Name = "ASME 900#" });
            items.Add(new NameCodePair() { Code = "13", Name = "ASME 1500#" });
            items.Add(new NameCodePair() { Code = "14", Name = "ASME 2500#" });
            items.Add(new NameCodePair() { Code = "15", Name = "ASME 4500#" });
            items.Add(new NameCodePair() { Code = "16", Name = "PN100" });
            return items;
        }
        public static ValveRatings LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveRatings LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveRatings>(EngineeringItems.DataPath + @"\Valves\ValveRatings.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveRatings>(this, EngineeringItems.DataPath + @"\Valves\ValveRatings.xml");
        }

    }
}
