﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeTypes : ObservableCollection<NameCodePair>
    {
        public static FlangeTypes LoadList()
        {
            FlangeTypes items = new FlangeTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Slip-on Flange" });
            items.Add(new NameCodePair() { Code = "02", Name = "Weld Neck Flange" });
            items.Add(new NameCodePair() { Code = "03", Name = "Blind Flange" });
            items.Add(new NameCodePair() { Code = "04", Name = "Spectacle Flange" });
            items.Add(new NameCodePair() { Code = "05", Name = "Socket Weld Flange" });
            items.Add(new NameCodePair() { Code = "06", Name = "Lap Joint Flange" });
            items.Add(new NameCodePair() { Code = "07", Name = "Screwed Joint Flange" });
            items.Add(new NameCodePair() { Code = "08", Name = "Raised Face Flange" });
            items.Add(new NameCodePair() { Code = "09", Name = "Reducing Flange" });
            items.Add(new NameCodePair() { Code = "10", Name = "Stud Pad Type 5B/5C" });
            items.Add(new NameCodePair() { Code = "11", Name = "Stud Pad Type 5A" });
            items.Add(new NameCodePair() { Code = "12", Name = "Composite Flange" });
            items.Add(new NameCodePair() { Code = "13", Name = "FLANGED BHD PENETRATION-WITH SLEEVE" });
            items.Add(new NameCodePair() { Code = "14", Name = "Stud Pad Type 9A" });
            items.Add(new NameCodePair() { Code = "15", Name = "Stud Pad Type (WDC) 5A" });
            items.Add(new NameCodePair() { Code = "16", Name = "Stud Pad Type 4A" });
            items.Add(new NameCodePair() { Code = "17", Name = "Stud Pad Type 4B" });
            items.Add(new NameCodePair() { Code = "18", Name = "Stud Pad Type 9B" });
            items.Add(new NameCodePair() { Code = "19", Name = "Stud Pad Type 7A" });
            items.Add(new NameCodePair() { Code = "20", Name = "STRAUB TYPE FLEX 2LS" });
            items.Add(new NameCodePair() { Code = "21", Name = "STRAUB TYPE FLEX 2LV" });
            items.Add(new NameCodePair() { Code = "22", Name = "STRAUB TYPE FLEX 2LU" });
            items.Add(new NameCodePair() { Code = "23", Name = "STRAUB TYPE FLEX 2H" });
            items.Add(new NameCodePair() { Code = "24", Name = "Stud Pad Type 18C" });
            items.Add(new NameCodePair() { Code = "25", Name = "Stud Pad Type 18B" });
            items.Add(new NameCodePair() { Code = "26", Name = "Stud Pad Type 18A" });
            items.Add(new NameCodePair() { Code = "27", Name = "Inner Flange_Stub End" });
            items.Add(new NameCodePair() { Code = "28", Name = "Stud Pad Type 18D" });
            items.Add(new NameCodePair() { Code = "29", Name = "Stud Pad Type 6A (ASME)" });
            items.Add(new NameCodePair() { Code = "30", Name = "Stud Pad Type-7 (With Insulated Flange)" });
            return items;
        }
        public static FlangeTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeTypes>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeTypes>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeTypes.xml");
        }

    }
}
