﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsCClampSubTypes : ObservableCollection<NameCodePair>
    {
        public static SupportsCClampSubTypes LoadList()
        {
            SupportsCClampSubTypes items = new SupportsCClampSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "TWO BOLT" });
            items.Add(new NameCodePair() { Code = "02", Name = "THREE BOLT" });
            return items;
        }
        public static SupportsCClampSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsCClampSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsCClampSubTypes>(EngineeringItems.DataPath + @"\Supports\SupportsCClampSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsCClampSubTypes>(this, EngineeringItems.DataPath + @"\Supports\SupportsCClampSubTypes.xml");
        }

    }
}
