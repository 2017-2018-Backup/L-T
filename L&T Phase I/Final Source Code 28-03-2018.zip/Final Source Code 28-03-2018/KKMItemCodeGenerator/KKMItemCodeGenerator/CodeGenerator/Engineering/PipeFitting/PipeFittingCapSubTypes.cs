﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingCapSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingCapSubTypes LoadList()
        {
            PipeFittingCapSubTypes items = new PipeFittingCapSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "CAP" });
            return items;
        }
        public static PipeFittingCapSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingCapSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingCapSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCapSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingCapSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCapSubTypes.xml");
        }

    }
}
