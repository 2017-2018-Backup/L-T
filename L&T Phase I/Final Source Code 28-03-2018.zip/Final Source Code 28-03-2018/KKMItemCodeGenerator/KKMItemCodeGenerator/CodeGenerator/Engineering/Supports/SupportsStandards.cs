﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsStandards : ObservableCollection<NameCodePair>
    {
        public static SupportsStandards LoadList()
        {
            SupportsStandards items = new SupportsStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ASTM A36" });
            items.Add(new NameCodePair() { Code = "02", Name = "JIS G3101 SS400" });
            items.Add(new NameCodePair() { Code = "03", Name = "IS:2062" });
            items.Add(new NameCodePair() { Code = "04", Name = "JIS F 3022 A100" });
            items.Add(new NameCodePair() { Code = "05", Name = "EN 10025 S235JRG2" });
            items.Add(new NameCodePair() { Code = "06", Name = "SS 316L" });
            items.Add(new NameCodePair() { Code = "07", Name = "NS 5552" });
            items.Add(new NameCodePair() { Code = "08", Name = "DIN 3015-1" });
            return items;
        }
        public static SupportsStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsStandards>(EngineeringItems.DataPath + @"\Supports\SupportsStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsStandards>(this, EngineeringItems.DataPath + @"\Supports\SupportsStandards.xml");
        }

    }
}
