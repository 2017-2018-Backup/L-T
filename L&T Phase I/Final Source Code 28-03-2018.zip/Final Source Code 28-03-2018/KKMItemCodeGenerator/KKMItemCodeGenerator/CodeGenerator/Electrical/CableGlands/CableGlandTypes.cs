﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandTypes : ObservableCollection<NameCodePair>
    {
        public static CableGlandTypes LoadList()
        {
            CableGlandTypes items = new CableGlandTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "EMC TYPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "NON EMC TYPE" });
            items.Add(new NameCodePair() { Code = "03", Name = "NA" });

            return items;
        }
        public static CableGlandTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandTypes>(ElectricalItems.DataPath + @"\CableGland\CableGlandTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath + @"\CableGland"))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath + @"\CableGland");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandTypes>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandTypes.xml");
        }

    }
}
