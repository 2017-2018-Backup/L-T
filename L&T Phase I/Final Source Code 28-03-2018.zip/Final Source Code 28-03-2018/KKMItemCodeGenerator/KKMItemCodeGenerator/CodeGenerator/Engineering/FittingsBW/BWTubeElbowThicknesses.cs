﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWTubeElbowThicknesses : ObservableCollection<NameCodePair>
    {
        public static BWTubeElbowThicknesses LoadList()
        {
            BWTubeElbowThicknesses items = new BWTubeElbowThicknesses();
            items.Add(new NameCodePair() { Code = "01", Name = "0.5 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "0.8 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "1 mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "1.5 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "2 mm" });
            items.Add(new NameCodePair() { Code = "06", Name = "2.5 mm" });
            items.Add(new NameCodePair() { Code = "07", Name = "3 mm" });
            items.Add(new NameCodePair() { Code = "08", Name = "3.5 mm" });
            items.Add(new NameCodePair() { Code = "09", Name = "4 mm" });
            items.Add(new NameCodePair() { Code = "10", Name = "4.5 mm" });
            items.Add(new NameCodePair() { Code = "11", Name = "5 mm" });
            items.Add(new NameCodePair() { Code = "12", Name = "6 mm" });
            items.Add(new NameCodePair() { Code = "13", Name = "7 mm" });
            items.Add(new NameCodePair() { Code = "14", Name = "8 mm" });
            items.Add(new NameCodePair() { Code = "15", Name = "9 mm" });
            items.Add(new NameCodePair() { Code = "16", Name = "0.9 mm" });
            items.Add(new NameCodePair() { Code = "17", Name = "1.6 mm" });
            return items;
        }
        public static BWTubeElbowThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static BWTubeElbowThicknesses LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWTubeElbowThicknesses>(EngineeringItems.DataPath + @"\FittingsBW\BWTubeElbowThicknesses.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWTubeElbowThicknesses>(this, EngineeringItems.DataPath + @"\FittingsBW\BWTubeElbowThicknesses.xml");
        }

    }
}
