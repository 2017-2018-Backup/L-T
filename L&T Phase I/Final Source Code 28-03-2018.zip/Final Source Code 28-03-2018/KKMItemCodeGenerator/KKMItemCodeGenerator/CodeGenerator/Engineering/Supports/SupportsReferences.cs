﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsReferences : ObservableCollection<NameCodePair>
    {
        public static SupportsReferences LoadList()
        {
            SupportsReferences items = new SupportsReferences();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            return items;
        }
        public static SupportsReferences LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsReferences LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsReferences>(EngineeringItems.DataPath + @"\Supports\SupportsReferences.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsReferences>(this, EngineeringItems.DataPath + @"\Supports\SupportsReferences.xml");
        }

    }
}
