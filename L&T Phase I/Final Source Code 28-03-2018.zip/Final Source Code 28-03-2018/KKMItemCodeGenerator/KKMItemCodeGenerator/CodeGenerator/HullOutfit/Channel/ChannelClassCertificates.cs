﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelClassCertificates : ObservableCollection<NameCodePair>
    {
        public static ChannelClassCertificates LoadList()
        {
            ChannelClassCertificates items = new ChannelClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "LR 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "LR 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "GL 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GL 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "NO CERTIFICATE" });
            return items;
        }
        public static ChannelClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelClassCertificates>(HullOutfitItems.DataPath + @"\Channel\ChannelClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelClassCertificates>(this, HullOutfitItems.DataPath + @"\Channel\ChannelClassCertificates.xml");
        }
    }
}
