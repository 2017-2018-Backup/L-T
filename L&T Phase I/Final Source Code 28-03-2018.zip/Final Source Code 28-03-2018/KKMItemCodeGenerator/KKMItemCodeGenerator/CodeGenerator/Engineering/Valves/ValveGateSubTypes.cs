﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveGateSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveGateSubTypes LoadList()
        {
            ValveGateSubTypes items = new ValveGateSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "STRAIGHT" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANGLED" });
            items.Add(new NameCodePair() { Code = "03", Name = "STOP VALVE-STRAIGHT" });
            items.Add(new NameCodePair() { Code = "04", Name = "STOP VALVE-ANGLE TYPE" });
            return items;
        }
        public static ValveGateSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveGateSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveGateSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveGateSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveGateSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveGateSubTypes.xml");
        }

    }
}
