﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeClassSociety : ObservableCollection<NameCodePair>
    {
        public static PipeClassSociety LoadList()
        {
            PipeClassSociety items = new PipeClassSociety();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Non IACS" });
            items.Add(new NameCodePair() { Code = "B", Name = "IACS" });
            return items;
        }
        public static PipeClassSociety LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeClassSociety LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeClassSociety>(EngineeringItems.DataPath + @"\Pipes\PipeClassSociety.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeClassSociety>(this, EngineeringItems.DataPath + @"\Pipes\PipeClassSociety.xml");
        }

    }
}
