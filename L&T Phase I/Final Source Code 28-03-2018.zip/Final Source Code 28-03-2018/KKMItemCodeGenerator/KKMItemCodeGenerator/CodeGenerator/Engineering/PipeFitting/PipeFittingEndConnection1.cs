﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingEndConnection1 : ObservableCollection<NameCodePair>
    {
        public static PipeFittingEndConnection1 LoadList()
        {
            PipeFittingEndConnection1 items = new PipeFittingEndConnection1();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "G- MALE" });
            items.Add(new NameCodePair() { Code = "02", Name = "G- FEMALE" });
            items.Add(new NameCodePair() { Code = "03", Name = "M- MALE" });
            items.Add(new NameCodePair() { Code = "04", Name = "M- FEMALE" });
            items.Add(new NameCodePair() { Code = "05", Name = "NPT MALE" });
            items.Add(new NameCodePair() { Code = "06", Name = "NPT FEMALE" });
            items.Add(new NameCodePair() { Code = "07", Name = "MALE SOCKET" });
            items.Add(new NameCodePair() { Code = "08", Name = "FEMALE SOCKET" });
            items.Add(new NameCodePair() { Code = "09", Name = "FERRULE MALE" });
            items.Add(new NameCodePair() { Code = "10", Name = "FERRULE FEMALE" });
            items.Add(new NameCodePair() { Code = "11", Name = "CUT GROOVE" });
            items.Add(new NameCodePair() { Code = "12", Name = "BUTT WELD" });
            items.Add(new NameCodePair() { Code = "13", Name = "F COUPLER D" });
            items.Add(new NameCodePair() { Code = "14", Name = "PLUG - DP" });
            items.Add(new NameCodePair() { Code = "15", Name = "FLANGED" });
            items.Add(new NameCodePair() { Code = "16", Name = "CODE 61 FLANGE" });
            items.Add(new NameCodePair() { Code = "17", Name = "CODE 62 FLANGE" });
            items.Add(new NameCodePair() { Code = "18", Name = "JIC UNF MALE" });
            items.Add(new NameCodePair() { Code = "19", Name = "JIC UNF FEMALE" });
            items.Add(new NameCodePair() { Code = "20", Name = "PUSH FIT" });
            return items;
        }
        public static PipeFittingEndConnection1 LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingEndConnection1 LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingEndConnection1>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingEndConnection1.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingEndConnection1>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingEndConnection1.xml");
        }

    }
}
