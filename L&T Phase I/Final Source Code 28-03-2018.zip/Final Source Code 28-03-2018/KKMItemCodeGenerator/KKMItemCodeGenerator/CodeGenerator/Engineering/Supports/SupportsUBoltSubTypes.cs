﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsUBoltSubTypes : ObservableCollection<NameCodePair>
    {
        public static SupportsUBoltSubTypes LoadList()
        {
            SupportsUBoltSubTypes items = new SupportsUBoltSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "GRIP TYPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "NON GRIP TYPE" });
            items.Add(new NameCodePair() { Code = "03", Name = "INSULATED TYPE" });
            return items;
        }
        public static SupportsUBoltSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsUBoltSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsUBoltSubTypes>(EngineeringItems.DataPath + @"\Supports\SupportsUBoltSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsUBoltSubTypes>(this, EngineeringItems.DataPath + @"\Supports\SupportsUBoltSubTypes.xml");
        }

    }
}
