﻿using Autodesk.Connectivity.WebServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using VDF = Autodesk.DataManagement.Client.Framework;

namespace KKMEnquiryProjectStructure
{
    public partial class frmCustomer : Form
    {
        public DialogResult dialogres = DialogResult.Cancel;
        public Customer objcust;
        bool isCustomerFileinVault = false;
        public frmCustomer()
        {
            InitializeComponent();
        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            objcust = new Customer();

            try
            {
                VDF.Vault.Currency.Entities.FileIteration fileiteration = null;
                Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions;
                try
                {
                    _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { clsStaticGlobal.VaultCustomerFilePath });

                    if (_LatestFileswithVersions.Length != 0)
                    {
                        if (_LatestFileswithVersions[0].Id != -1)
                        {
                            fileiteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, _LatestFileswithVersions[0]);
                        }
                    }

                    if (fileiteration != null)
                    {
                        isCustomerFileinVault = true;

                        if (clsStaticGlobal.CheckoutFile(clsStaticGlobal.VaultCustomerFilePath, clsStaticGlobal.LocalXMLCustomerFolderPath) == true)
                        {
                            Customer objcust = clsStaticGlobal.ReadCustomerData(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename);

                            if (objcust != null)
                            {
                                try
                                {
                                    if (listView1.Items.Count > 0)
                                    {
                                        listView1.Items.Clear();
                                    }
                                }
                                catch (Exception)
                                {

                                }

                                foreach (string item in objcust.CustomerName)
                                {
                                    ListViewItem _lstitem = new ListViewItem();
                                    _lstitem.Text = item;
                                    _lstitem.Tag = item;
                                    listView1.Items.Add(_lstitem);
                                }
                            }

                        }
                    }

                }
                catch (Exception)
                {

                }

            }
            catch (Exception)
            {

            }

        }

        private void frmCustomer_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (isCustomerFileinVault == true)
                {
                    clsStaticGlobal.CheckinFile(clsStaticGlobal.VaultCustomerFilePath, clsStaticGlobal.LocalXMLCustomerFolderPath);
                }
                else
                {
                    string _XMLfilePath = clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename;
                    VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, clsStaticGlobal.CustomerTemplateFolder);
                    VDF.Vault.Currency.Entities.FileIteration myFile = null;
                    Stream fileStream = new FileStream(_XMLfilePath, FileMode.Open, FileAccess.Read);
                    myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_XMLfilePath), "", DateTime.Now, null, null, FileClassification.None, false, fileStream);

                }
            }
            catch (Exception)
            {

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool isExist = false;

            if (textBox1.Text.Trim() != "")
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    if (textBox1.Text.Trim() == item.Text.Trim())
                    {
                        isExist = true;
                    }
                }
                if (isExist == false)
                {
                    if (textBox1.Text.Trim() != "")
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = textBox1.Text;
                        _lstitem.Tag = textBox1.Text;
                        listView1.Items.Add(_lstitem);
                    }

                    textBox1.Text = "";
                }
                else
                {
                    MessageBox.Show("Customer name already exist..!!", "Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dialogres = DialogResult.Cancel;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            objcust = new Customer();

            try
            {
                List<string> lst = new List<string> { };
                foreach (ListViewItem item in listView1.Items)
                {
                    lst.Add(item.Text);
                }

                objcust.CustomerName = lst;

                if (System.IO.File.Exists(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename))
                {
                    System.IO.File.SetAttributes(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename, FileAttributes.Normal);
                    System.IO.File.Delete(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename);
                }

                XmlSerializer xs = new XmlSerializer(typeof(Customer));
                TextWriter tw = new StreamWriter(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename);
                xs.Serialize(tw, objcust);
                tw.Close();
            }
            catch (Exception)
            {

            }

            dialogres = DialogResult.OK;
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                listView1.Items.Remove(item);
            }
        }
    }
}
