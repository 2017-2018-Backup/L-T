﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;

// The extension ID needs to be unique for each extension.  
// Make sure to generate your own ID when writing your own extension. 
[assembly: Autodesk.Connectivity.Extensibility.Framework.ExtensionId("82409CF2-397B-4F90-9814-ED1AE82CC5E3")]

// This number gets incremented for each Vault release.
[assembly: Autodesk.Connectivity.Extensibility.Framework.ApiVersion("11.0")]
namespace KKMEnquiryProjectStructure
{
    public class KKMEnquiryProjectStructure : IExplorerExtension
    {
        #region IExtension Members

        /// <summary>
        /// This function tells Vault Explorer what custom commands this extension provides.
        /// Part of the IExtension interface.
        /// </summary>
        /// <returns>A collection of CommandSites, which are collections of custom commands.</returns>
        public IEnumerable<CommandSite> CommandSites()
        {
            //// Create the Hello World command object.
            CommandItem KKMCreateNewEnquiryFolderCmdItem = new CommandItem("KKMEnquiryProjectStructureCommand", "Create New Enquiry")
            {
                // this command is active when a File is selected
                NavigationTypes = new SelectionTypeId[] { SelectionTypeId.Folder },
                Image = Properties.Resources.L_T,
                // this command is not active if there are multiple entities selected
                MultiSelectEnabled = false
            };

            // The HelloWorldCommandHandler function is called when the custom command is executed.
            KKMCreateNewEnquiryFolderCmdItem.Execute += KKMCreateNewEnquiryFolderCommandHandler;

            //// Create a command site to hook the command to the Advanced toolbar
            //CommandSite toolbarCmdSite = new CommandSite("HelloWorldCommand.Toolbar", "Hello World Menu")
            //{
            //    Location = CommandSiteLocation.AdvancedToolbar,
            //    DeployAsPulldownMenu = false
            //};
            //toolbarCmdSite.AddCommand(helloWorldCmdItem);

            // Create another command site to hook the command to the right-click menu for Files.
            CommandSite KKMCreateNewEnquiryFolderContextCmdSite = new CommandSite("KKMEnquiryProjectStructureCommand.ProjectContextMenu", "Create New Enquiry")
            {
                Location = CommandSiteLocation.FolderContextMenu,
                DeployAsPulldownMenu = false

            };
            KKMCreateNewEnquiryFolderContextCmdSite.AddCommand(KKMCreateNewEnquiryFolderCmdItem);

            // Now the custom command is available in 2 places.

            // Gather the sites in a List.
            List<CommandSite> sites = new List<CommandSite>();
            //sites.Add(toolbarCmdSite);
            sites.Add(KKMCreateNewEnquiryFolderContextCmdSite);

            // Return the list of CommandSites.
            return sites;
        }


        /// <summary>
        /// This function tells Vault Explorer what custom tabs this extension provides.
        /// Part of the IExtension interface.
        /// </summary>
        /// <returns>A collection of DetailTabs, each object represents a custom tab.</returns>
        public IEnumerable<DetailPaneTab> DetailTabs()
        {
            return null;
        }




        /// <summary>
        /// This function is called after the user logs in to the Vault Server.
        /// Part of the IExtension interface.
        /// </summary>
        /// <param name="application">Provides information about the running application.</param>
        public void OnLogOn(IApplication application)
        {
        }

        /// <summary>
        /// This function is called after the user is logged out of the Vault Server.
        /// Part of the IExtension interface.
        /// </summary>
        /// <param name="application">Provides information about the running application.</param>
        public void OnLogOff(IApplication application)
        {
        }

        /// <summary>
        /// This function is called before the application is closed.
        /// Part of the IExtension interface.
        /// </summary>
        /// <param name="application">Provides information about the running application.</param>
        public void OnShutdown(IApplication application)
        {
            // Although this function is empty for this project, it's still needs to be defined 
            // because it's part of the IExtension interface.
        }

        /// <summary>
        /// This function is called after the application starts up.
        /// Part of the IExtension interface.
        /// </summary>
        /// <param name="application">Provides information about the running application.</param>
        public void OnStartup(IApplication application)
        {
            // Although this function is empty for this project, it's still needs to be defined 
            // because it's part of the IExtension interface.
        }

        /// <summary>
        /// This function tells Vault Exlorer which default commands should be hidden.
        /// Part of the IExtension interface.
        /// </summary>
        /// <returns>A collection of command names.</returns>
        public IEnumerable<string> HiddenCommands()
        {
            // This extension does not hide any commands.
            return null;
        }

        /// <summary>
        /// This function allows the extension to define special behavior for Custom Entity types.
        /// Part of the IExtension interface.
        /// </summary>
        /// <returns>A collection of CustomEntityHandler objects.  Each object defines special behavior
        /// for a specific Custom Entity type.</returns>
        public IEnumerable<CustomEntityHandler> CustomEntityHandlers()
        {
            // This extension does not provide special Custom Entity behavior.
            return null;
        }

        #endregion


        /// <summary>
        /// This is the function that is called whenever the custom command is executed.
        /// </summary>
        /// <param name="s">The sender object.  Usually not used.</param>
        /// <param name="e">The event args.  Provides additional information about the environment.</param>
        void KKMCreateNewEnquiryFolderCommandHandler(object s, CommandItemEventArgs e)
        {
            try
            {

                clsStaticGlobal.connection = e.Context.Application.Connection;
                clsStaticGlobal.vaultConnectionContext = e;

                // The Context part of the event args tells us information about what is selected.
                // Run some checks to make sure that the selection is valid.
                if (e.Context.CurrentSelectionSet.Count() == 0)
                    MessageBox.Show("Please select folder.", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (e.Context.CurrentSelectionSet.Count() > 1)
                    MessageBox.Show("This function does not support multiple selections", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    // we only have one item selected, which is the expected behavior

                    ISelection selection = e.Context.CurrentSelectionSet.First();

                    // Look of the File object.  How we do this depends on what is selected.
                    //File selectedFile = null;
                    Folder selectedFolder = null;
                    if (selection.TypeId == SelectionTypeId.Folder)
                    {
                        // our ISelection.Id is really a File.MasterId
                        //selectedFile = connection.WebServiceManager.DocumentService.GetLatestFileByMasterId(selection.Id);
                        selectedFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(selection.Id);
                    }

                    if (selectedFolder == null)
                    {
                        MessageBox.Show("Please select folder.", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        if (selectedFolder.Name == "$")
                        {
                            if ((clsStaticGlobal.connection.UserName.ToUpper().Contains("ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "SECURITY ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "PROJECT ADMINISTRATOR")))
                            {
                                frmKKMCreateNewEnquiryProject objfrmKKMCreateNewEnquiryProject = new frmKKMCreateNewEnquiryProject();
                                objfrmKKMCreateNewEnquiryProject.ShowDialog();
                            }
                            else
                            {
                               // System.Diagnostics.Debugger.Launch();
                                bool isValidRole = false;
                                UserInfo userInfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                                //Role[] rolesbyUser= clsStaticGlobal.connection.WebServiceManager.AdminService.GetRolesByUserId(clsStaticGlobal.connection.UserID);
                                foreach (Role role in userInfo.Roles)
                                {
                                    if ((role.Name.ToUpper().Trim() == "ADMINISTRATOR") || (role.Name.ToUpper().Trim() == "PROJECT ADMINISTRATOR") || (role.Name.ToUpper().Trim() == "SECURITY ADMINISTRATOR"))
                                    {
                                        isValidRole = true;
                                    }
                                }

                                bool isValidGroup = false;
                                Group[] groups = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllGroups();
                                List<Group> groupsBDG = new List<Group>();
                                foreach (Group item in groups)
                                {
                                    if (item.Name.StartsWith("BDG"))
                                    {
                                        groupsBDG.Add(item);
                                    }
                                }

                                foreach (Group item in groupsBDG)
                                {
                                    User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetMemberUsersByGroupId(item.Id);
                                    foreach (User user in users)
                                    {
                                        if (user.Id == clsStaticGlobal.connection.UserID)
                                        {
                                            isValidGroup = true;
                                            break;
                                        }
                                    }
                                }

                                if ((isValidRole == true) && (isValidGroup == true))
                                {
                                    frmKKMCreateNewEnquiryProject objfrmKKMCreateNewEnquiryProject = new frmKKMCreateNewEnquiryProject();
                                    objfrmKKMCreateNewEnquiryProject.ShowDialog();
                                }
                                else
                                {
                                    if ((isValidRole == false) && (isValidGroup == false))
                                    {
                                        MessageBox.Show("Logged in user does not have sufficient access roles and not coming in BDG group..!!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                    else if (isValidRole == false)
                                    {
                                        MessageBox.Show("Logged in user does not have sufficient access roles..!!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Logged in user not coming in BDG group..!!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    }
                                }
                            }
                        }
                        else
                        {
                            // this is the message we hope to see
                            MessageBox.Show("Please select root folder..!!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }

                e.Context.ForceRefresh = true;
                //try
                //{
                //    System.Diagnostics.Debugger.Launch();
                //     string _GoLocationFolderPath = clsStaticGlobal.GoLocationFolder.FullName;
                //    SelectionTypeId _SelectionTypeId = new Autodesk.Connectivity.Explorer.Extensibility.SelectionTypeId(clsStaticGlobal.GoLocationFolder.Name);
                //    LocationContext _LocationContext = new Autodesk.Connectivity.Explorer.Extensibility.LocationContext(_SelectionTypeId, _GoLocationFolderPath);
                //    e.Context.GoToLocation = _LocationContext;
                //}
                //catch (Exception)
                //{

                //    throw;
                //}              


            }
            catch (Exception ex)
            {
                // If something goes wrong, we don't want the exception to bubble up to Vault Explorer.
                MessageBox.Show("Error: " + ex.Message, "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// This function is called whenever our custom tab is active and the selection has changed in the main grid.
        /// </summary>
        /// <param name="sender">The sender object.  Usually not used.</param>
        /// <param name="e">The event args.  Provides additional information about the environment.</param>
        void propertyTab_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                // The event args has our custom tab object.  We need to cast it to our type.
                //MyCustomTabControl tabControl = e.Context.UserControl as MyCustomTabControl;

                //// Send selection to the tab so that it can display the object.
                //tabControl.SetSelectedObject(e.Context.SelectedObject);
            }
            catch (Exception ex)
            {
                // If something goes wrong, we don't want the exception to bubble up to Vault Explorer.
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}
