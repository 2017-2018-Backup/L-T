﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKMItemCodeGenerator.CodeGenerator
{
    [Serializable()]
    public class CommonItemGroups : ObservableCollection<NameCodePair>
    {

        public static CommonItemGroups LoadFromXml(string Path)
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CommonItemGroups>(Path + @"\AllItemGroups.xml");
        }
    }
    
}
