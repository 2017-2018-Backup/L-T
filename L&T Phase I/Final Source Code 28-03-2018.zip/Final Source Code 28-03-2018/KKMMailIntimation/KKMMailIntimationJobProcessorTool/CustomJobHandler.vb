﻿'=====================================================================
'  
'  This file is part of the Autodesk Vault API Code Samples.
'
'  Copyright (C) Autodesk Inc.  All rights reserved.
'
'THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
'KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
'IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'PARTICULAR PURPOSE.
'=====================================================================


Imports System.Linq
Imports System.IO
Imports Autodesk.DataManagement.Client.Framework
Imports Autodesk.Connectivity.JobProcessor.Extensibility
Imports Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities
Imports System.Reflection
Imports Autodesk.Connectivity.Extensibility.Framework
Imports Autodesk.DataManagement.Client.Framework.Currency
Imports Autodesk.Connectivity.WebServices
Imports Autodesk.DataManagement.Client.Framework.Vault.Settings
Imports Autodesk.DataManagement.Client.Framework.Vault.Results
Imports System.Xml
Imports System.Net.Mail
Imports System.Threading
Imports System.Data

<Assembly: AssemblyProduct("KKMMailIntimationJobProcessorTool")>
<Assembly: ApiVersion("11.0")>
<Assembly: ExtensionId("50A18DD5-892A-477e-911E-1D6E3C647036")>

Namespace KKMMailIntimationJobProcessorTool

    Public Class CustomJobHandler
        Implements IJobHandler

        Public Shared _dirSep As String = System.IO.Path.DirectorySeparatorChar.ToString()
        Public Shared _dllFolder As String = "C:\ProgramData\Autodesk\Vault 2018\Extensions\KKMMailIntimationJobProcessorTool"
        Public Shared _workingFolder As String = "C:\ProgramData\Autodesk\Vault 2018\Extensions\KKMMailIntimationJobProcessorTool" & _dirSep & "KKMTools" & _dirSep
        Public _SourceFolder As String
        Public _TargetFolder As String
        Public vConnection As Vault.Currency.Connections.Connection
        Dim dtEmailNotification As New DataTable
        Dim designFolder, pdfFolder As String

        Public Sub New()

        End Sub

        Public Shared Sub WriteLog(ByVal str As String)
            Try
                Dim log As StreamWriter
                Dim logfile As String = _workingFolder & "log.txt"
                If Not System.IO.File.Exists(logfile) Then
                    log = New StreamWriter(logfile)
                Else
                    log = System.IO.File.AppendText(logfile)
                End If
                log.WriteLine()
                log.WriteLine(Now.ToString() + ": " + str)
                log.Close()
            Catch ex As Exception

            End Try
        End Sub

        Public Shared Sub DeleteFile(ByVal file As String)
            Try
                If IO.File.Exists(file) Then
                    Dim oFileInfo As New IO.FileInfo(file)
                    If (oFileInfo.Attributes And IO.FileAttributes.ReadOnly) > 0 Then
                        oFileInfo.Attributes = oFileInfo.Attributes Xor IO.FileAttributes.ReadOnly
                    End If
                    System.IO.File.Delete(file)
                End If
            Catch ex As Exception
                WriteLog("Deleting " + file + "failed!" + ex.ToString())
            End Try
        End Sub

        Public Shared Sub DeleteDirectory(ByVal dir As String)
            Try
                If IO.Directory.Exists(dir) Then
                    For Each _file In IO.Directory.GetFiles(dir)
                        DeleteFile(_file)
                    Next
                    Dim odirInfo As New IO.DirectoryInfo(dir)
                    If (odirInfo.Attributes And IO.FileAttributes.ReadOnly) > 0 Then
                        odirInfo.Attributes = odirInfo.Attributes Xor IO.FileAttributes.ReadOnly
                    End If
                    System.IO.Directory.Delete(dir, True)
                End If
            Catch ex As Exception
                WriteLog("Deleting " + dir + "failed!" + ex.ToString())
            End Try
        End Sub

        Public Function CanProcess(ByVal jobType As String) As Boolean Implements IJobHandler.CanProcess
            If jobType.StartsWith("KKMMailIntimationJobProcessorTool.EmailNotification.", StringComparison.InvariantCultureIgnoreCase) Then
                Return True
            End If
            Return False
        End Function

        Public Function Execute(ByVal context As IJobProcessorServices, ByVal job As IJob) As JobOutcome Implements IJobHandler.Execute
            Try
                vConnection = context.Connection
                If job.JobType.StartsWith("KKMMailIntimationJobProcessorTool.EmailNotification.", StringComparison.InvariantCultureIgnoreCase) Then
                    Dim IsFile As Boolean = False
                    Dim jobTypeFolderOrFile As String = job.Params("EntityClassId").ToString()
                    If jobTypeFolderOrFile = "FILE" Then
                        IsFile = True
                    ElseIf jobTypeFolderOrFile = "FLDR" Then
                        IsFile = False
                    End If
                    Dim fileId As Long = Convert.ToInt64(job.Params("EntityId"))
                    Dim transitionId As Long = Convert.ToInt64(job.Params("LifeCycleTransitionId"))
                    ''Debugger.Launch()
                    EmailNotificationOnStateChange(fileId, transitionId, IsFile) ' _to, isGroup, _from, _submittedTime, _destState)
                End If
                Return JobOutcome.Success
            Catch ex As Exception
                Return JobOutcome.Failure
            End Try
        End Function

        Public Sub OnJobProcessorShutdown(ByVal context As IJobProcessorServices) Implements IJobHandler.OnJobProcessorShutdown

        End Sub

        Public Sub OnJobProcessorSleep(ByVal context As IJobProcessorServices) Implements IJobHandler.OnJobProcessorSleep

        End Sub

        Public Sub OnJobProcessorStartup(ByVal context As IJobProcessorServices) Implements IJobHandler.OnJobProcessorStartup

        End Sub

        Public Sub OnJobProcessorWake(ByVal context As IJobProcessorServices) Implements IJobHandler.OnJobProcessorWake

        End Sub

#Region "Send Email Notification"

        Public Function GetDinMailContent(ByVal vFile As Autodesk.Connectivity.WebServices.File, ByVal fileProps As Dictionary(Of String, String), ByVal url As String, ByVal prjName As String) As String
            Dim retValue As String = "Business Object: Document Index Note $filename$ $revision$" & vbNewLine & vbNewLine &
                             "Issue No. $revision$ of DIN no. $filename$ of Project $project$ is $state$" & vbNewLine & vbNewLine &
                               "DIN Title: $title$" & vbNewLine & vbNewLine &
                                "DIN Description: $description$" & vbNewLine & vbNewLine
            Try


                retValue = retValue.Replace("$filename$", System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.GetFileNameWithoutExtension(vFile.Name)))
                retValue = retValue.Replace("$revision$", vFile.FileRev.Label)
                retValue = retValue.Replace("$project$", prjName)
                retValue = retValue.Replace("$title$", fileProps("Title"))
                retValue = retValue.Replace("$description$", fileProps("Description"))
                retValue = retValue.Replace("$state$", vFile.FileLfCyc.LfCycStateName)
                Dim dinFile = _workingFolder & vFile.Name
                Dim csvFile = Path.Combine(_workingFolder, Path.GetFileNameWithoutExtension(vFile.Name) + ".csv")
                If System.IO.File.Exists(dinFile) Then
                    DeleteFile(dinFile)
                End If
                If System.IO.File.Exists(csvFile) Then
                    DeleteFile(csvFile)
                End If
                Dim strRevisedList = String.Empty, strAddedList = String.Empty
                If DownlodFile(vFile.Name, _workingFolder) Then
                    If (System.IO.File.Exists(dinFile)) Then
                        Try
                            System.IO.File.Move(dinFile, csvFile)
                            Dim lines = System.IO.File.ReadAllLines(csvFile)
                            For Each line As String In lines.Skip(1)
                                Dim values As String() = line.Split(","c)
                                If values(6).Equals("To be Added.", StringComparison.InvariantCultureIgnoreCase) Or values(6).Equals("Added", StringComparison.InvariantCultureIgnoreCase) Then
                                    strAddedList = values(2) + "(" + values(4) + ") - " + values(5) + vbNewLine
                                ElseIf values(6).Equals("Revised", StringComparison.InvariantCultureIgnoreCase) Then
                                    strRevisedList = values(2) + "(" + values(4) + ") - " + values(5)

                                    'If values(6).Equals("Obsolete", StringComparison.InvariantCultureIgnoreCase) Then
                                    '    dgvRefDoc.Rows(Index).Cells("dcStatus").Style.ForeColor = Color.Purple
                                    'ElseIf values(6).Equals("Attach latest revision", StringComparison.InvariantCultureIgnoreCase) Then
                                    '    dgvRefDoc.Rows(Index).Cells("dcStatus").Style.ForeColor = Color.Red
                                    'ElseIf values(6).Equals("Carried Forward", StringComparison.InvariantCultureIgnoreCase) Then
                                    '    dgvRefDoc.Rows(Index).Cells("dcStatus").Style.ForeColor = Color.DarkGreen
                                    'ElseIf values(6).Equals("Added", StringComparison.InvariantCultureIgnoreCase) Then
                                    '    dgvRefDoc.Rows(Index).Cells("dcStatus").Style.ForeColor = Color.RoyalBlue
                                End If
                            Next
                        Catch ex As Exception
                        End Try
                    End If
                End If

                retValue += "Revised Document List:" + vbNewLine + strRevisedList + vbNewLine + vbNewLine
                retValue += "Added Document List:" + vbNewLine + strAddedList + vbNewLine + vbNewLine
                retValue += "It required your attention." + vbNewLine + vbNewLine

            Catch ex As Exception

            End Try
            retValue += url
            '   "$link$" & vbNewLine & vbNewLine &
            ' "This is an automated mail. Kindly do not reply to this mail."
            Return retValue
        End Function

        Public Function EmailNotificationOnStateChange(ByVal entityId As Long, ByVal transitionId As Long, ByVal _IsFile As Boolean) ', ByVal isGroup As Boolean, ByVal _from As Long, ByVal _submittedTime As String, ByVal _destState As String) As Boolean
            Try

                Dim listOfAssignedUsersForProject As List(Of User) = New List(Of User)

                Dim IsFile As Boolean = _IsFile

                Dim vaultFile As Autodesk.Connectivity.WebServices.File = Nothing

                Dim vaultFolder As Autodesk.Connectivity.WebServices.Folder = Nothing

                If IsFile = True Then
                    vaultFile = vConnection.WebServiceManager.DocumentService.GetFileById(entityId)
                Else
                    vaultFolder = vConnection.WebServiceManager.DocumentService.GetFolderById(entityId)
                End If

                Dim folderProjectpath = ""
                Dim ProjectFolder As Autodesk.Connectivity.WebServices.Folder = Nothing
                Try
                    If IsFile = True Then
                        vaultFile = vConnection.WebServiceManager.DocumentService.GetFileById(entityId)
                        Dim folderid As Long = vaultFile.FolderId
                        Dim FileFolder As Autodesk.Connectivity.WebServices.Folder = vConnection.WebServiceManager.DocumentService.GetFolderById(folderid)
                        Dim filepath = FileFolder.FullName
                        Try
                            Dim Spliteparts As String() = filepath.Split(New Char() {"/"c})
                            If Spliteparts.Length >= 2 Then
                                folderProjectpath = Spliteparts(0) + "/" + Spliteparts(1)
                                ProjectFolder = vConnection.WebServiceManager.DocumentService.GetFolderByPath(folderProjectpath)
                            End If
                        Catch ex As Exception

                        End Try
                    Else
                        vaultFolder = vConnection.WebServiceManager.DocumentService.GetFolderById(entityId)
                        ProjectFolder = vaultFolder
                    End If
                Catch ex As Exception

                End Try

                If Not IsNothing(ProjectFolder) Then
                    Try
                        Dim result As EntsAndACLs = Nothing
                        result = vConnection.WebServiceManager.SecurityService.GetEntACLsByEntityIds(New Long() {Convert.ToInt32(ProjectFolder.Id)})
                        If Not IsNothing(result.ACLArray) Then
                            Dim _aclArray As ACL() = result.ACLArray
                            If Not IsNothing(_aclArray(0)) Then
                                Dim _aceArray As ACE() = _aclArray(0).ACEArray
                                For Each _ace As ACE In _aceArray
                                    Dim isread As Boolean = False
                                    Dim iswrite As Boolean = False
                                    For Each accessPermis In _ace.PermisArray
                                        If accessPermis.Id = 1 Then
                                            isread = accessPermis.Val
                                        End If
                                        If accessPermis.Id = 2 Then
                                            iswrite = accessPermis.Val
                                        End If
                                    Next
                                    If isread = True AndAlso iswrite = True Then
                                        Dim _user As User = vConnection.WebServiceManager.AdminService.GetUserByUserId(_ace.UserGrpId)
                                        listOfAssignedUsersForProject.Add(_user)
                                    End If
                                Next
                            End If
                        End If
                    Catch ex As Exception
                    End Try
                End If

                Dim isDin As Boolean = False
                Dim mailContent As String = String.Empty
                Dim toAddress As String = String.Empty
                Dim _settingsFileName As String = "Settings.xml"

                If System.IO.File.Exists(_workingFolder & _settingsFileName) Then
                    DeleteFile(_workingFolder & _settingsFileName)
                End If

                If DownlodFile(_settingsFileName, _workingFolder) Then

                    Dim mailSubject As String

                    If IsFile = True Then
                        mailSubject = "Notification - File State Change:" + vaultFile.Name
                    Else
                        mailSubject = "Notification - Folder State Change:" + vaultFolder.Name
                    End If

                    Dim vUsers = vConnection.WebServiceManager.AdminService.GetAllUsers()

                    Dim settingsFile = _workingFolder & _settingsFileName
                    Dim tempXml As New XmlDocument
                    tempXml = Encryption.ClsExtention.GetXmlData(settingsFile)

                    If tempXml IsNot Nothing Then
                        Dim xnNode As XmlNode
                        AddColumns()
                        xnNode = tempXml.SelectSingleNode("Settings")
                        LoadEmailNotificationSettings(xnNode, transitionId.ToString())
                    End If

                    Dim newUri1 As New UriBuilder(vConnection.WebServiceManager.DocumentService.Url)

                    newUri1.Path = "AutodeskDM/Services/EntityDataCommandRequest.aspx"

                    If IsFile = True Then
                        newUri1.Query = String.Format("Vault={0}&ObjectId={1}&ObjectType={2}&Command=Select", vConnection.Vault,
                                                      EscapeHTML(VaultPath.Combine(vConnection.WebServiceManager.DocumentService.GetFolderById(vaultFile.FolderId).FullName, vaultFile.Name)), "File")
                    Else
                        newUri1.Query = ""
                    End If

                    Dim isPromoted As Boolean = True
                    Dim transition As LfCycTrans = vConnection.WebServiceManager.LifeCycleService.GetLifeCycleStateTransitionsByIds(New Long() {transitionId}).FirstOrDefault()
                    If (transition.ToId > transition.FromId) Then
                        isPromoted = True
                    Else
                        isPromoted = False
                    End If
                    Dim states = vConnection.WebServiceManager.LifeCycleService.GetLifeCycleStatesByIds(New Long() {transition.FromId, transition.ToId})
                    Dim strTransition = states(0).DispName + " --> " + states(1).DispName

                    Dim fileProps As Dictionary(Of String, String) = Nothing

                    If IsFile = True Then
                        fileProps = getFileProperties(vaultFile.Id)
                        Dim fLifecycle As LfCycDef = vConnection.WebServiceManager.LifeCycleService.GetLifeCycleDefinitionsByIds(New Long() {vaultFile.FileLfCyc.LfCycDefId}).FirstOrDefault()
                        Dim defaultStateId As Long = (From _state As LfCycState In fLifecycle.StateArray
                                                      Where _state.IsDflt.Equals(True)
                                                      Select _state.Id).FirstOrDefault()
                        Dim i As Integer
                        For i = 0 To fLifecycle.StateArray.Length
                            If (fLifecycle.StateArray(i).Id.Equals(vaultFile.FileLfCyc.LfCycStateId)) Then
                                Exit For
                            End If
                        Next
                    Else
                        fileProps = getFolderProperties(vaultFolder.Id)
                        Dim fLifecycle As LfCycDef = vConnection.WebServiceManager.LifeCycleService.GetLifeCycleDefinitionsByIds(New Long() {vaultFolder.LfCyc.LfCycDefId}).FirstOrDefault()
                        Dim defaultStateId As Long = (From _state As LfCycState In fLifecycle.StateArray
                                                      Where _state.IsDflt.Equals(True)
                                                      Select _state.Id).FirstOrDefault()
                        Dim i As Integer
                        For i = 0 To fLifecycle.StateArray.Length
                            If (fLifecycle.StateArray(i).Id.Equals(vaultFolder.LfCyc.LfCycStateId)) Then
                                Exit For
                            End If
                        Next
                    End If

                    For Each dr As DataRow In dtEmailNotification.Select("TransistionId = '" & transitionId & "'")
                        For Each _user As User In listOfAssignedUsersForProject
                            Try
                                If _user.Name.Equals(dr("Users").ToString()) Then
                                    If Not _user.Email.Equals(String.Empty) Then
                                        If toAddress.Equals(String.Empty) Then
                                            toAddress = _user.Email
                                        Else
                                            toAddress = toAddress + "," + _user.Email
                                        End If
                                    End If
                                End If
                            Catch ex As Exception
                            End Try
                        Next
                        'Try
                        '    _userEmail = (From _user As User In vUsers
                        '                  Where _user.Name.Equals(dr("Users").ToString()) And _user.Email IsNot String.Empty
                        '                  Select _user.Email).FirstOrDefault()
                        '    If Not _userEmail.Equals(String.Empty) Then
                        '        If toAddress.Equals(String.Empty) Then
                        '            toAddress = _userEmail
                        '        Else
                        '            toAddress = toAddress + "," + _userEmail
                        '        End If
                        '    End If
                        'Catch ex As Exception
                        'End Try
                    Next

                    Dim vaultFileorFolder As Object = New Object
                    If IsFile = True Then
                        vaultFileorFolder = DirectCast(vaultFile, Object)
                    Else
                        vaultFileorFolder = DirectCast(vaultFolder, Object)
                    End If

                    If Not toAddress.Equals(String.Empty) Then
                        Dim fileDesc As String = String.Empty
                        If (fileProps.Keys.Contains("Description")) Then
                            fileDesc = fileProps("Description")
                        End If
                        If SendEmail(settingsFile, mailSubject, toAddress, vaultFileorFolder, newUri1.ToString(), fileDesc, IsFile, isDin, mailContent, isPromoted) Then
                            Return True
                        End If
                    End If
                End If
            Catch ex As Exception
                WriteLog(ex.ToString() & vbNewLine & ex.StackTrace.ToString() & vbNewLine & ex.InnerException.ToString())
            End Try
            Return False
        End Function

        Private Sub AddColumns()
            If dtEmailNotification.Columns.Count().Equals(0) Then
                dtEmailNotification.Columns.Add("TransistionId")
                dtEmailNotification.Columns.Add("Users")
            End If
        End Sub

        Public Sub LoadEmailNotificationSettings(ByVal xnNode As XmlNode, ByVal transitionID As String)
            Try
                If xnNode IsNot Nothing Then
                    If xnNode.SelectSingleNode("EmailSettings") IsNot Nothing Then
                        dtEmailNotification.Rows.Clear()
                        For Each node As XmlNode In xnNode.SelectSingleNode("EmailSettings").ChildNodes()
                            If transitionID = node.Attributes("TransistionId").Value Then
                                dtEmailNotification.Rows.Add(node.Attributes("TransistionId").Value, node.InnerText)
                            End If
                        Next
                    End If
                End If
            Catch ex As Exception
                WriteLog(ex.ToString() & vbNewLine & ex.StackTrace.ToString())
            End Try
        End Sub

        Public Function SendEmail(ByVal _settingsfile As String, ByVal mailSubject As String, ByVal toAddress As String, ByVal vFileorFolder As Object, ByVal url As String, ByVal desc As String, ByVal _Isfile As Boolean, Optional ByVal isDin As Boolean = False, ByVal Optional content As String = "", Optional ByVal isPromoted As Boolean = True) As Boolean '', ByVal fromLastName As String, ByVal _destState As String, ByVal _submittedTime As String
            Try
                Dim tempXml As New XmlDocument
                tempXml = Encryption.ClsExtention.GetXmlData(_settingsfile)
                If tempXml IsNot Nothing Then
                    Dim xnEmailSettings As XmlNode = tempXml.SelectSingleNode("Settings").SelectSingleNode("EmailConfiguration")

                    If xnEmailSettings IsNot Nothing Then
                        Dim SmtpServer As New SmtpClient()
                        Dim smtpUsername, smtpPwd As String
                        smtpUsername = String.Empty
                        smtpPwd = String.Empty
                        Dim smtpHost = xnEmailSettings.SelectSingleNode("SMTPServer").InnerText
                        Dim smtpPort = xnEmailSettings.SelectSingleNode("SMTPPort").InnerText
                        Dim enableSSL As Boolean = False
                        Try
                            Boolean.TryParse(xnEmailSettings.SelectSingleNode("EnableSSL").InnerText, enableSSL)
                        Catch ex As Exception

                        End Try
                        Dim useDefaultCredentials As Boolean = False
                        Try
                            Boolean.TryParse(xnEmailSettings.SelectSingleNode("UseDefaultCred").InnerText, useDefaultCredentials)
                        Catch ex As Exception

                        End Try
                        If useDefaultCredentials Then
                            SmtpServer.UseDefaultCredentials = True
                        Else
                            smtpUsername = xnEmailSettings.SelectSingleNode("FromEmail").InnerText
                            smtpPwd = xnEmailSettings.SelectSingleNode("Password").InnerText
                            SmtpServer.Credentials = New Net.NetworkCredential(smtpUsername, smtpPwd)
                        End If
                        Dim smtpFromEmail = xnEmailSettings.SelectSingleNode("FromEmail").InnerText
                        Dim smtpDisplayName = xnEmailSettings.SelectSingleNode("DisplayName").InnerText
                        Dim mailcontent As String = String.Empty
                        If xnEmailSettings.SelectSingleNode("MailContent") IsNot Nothing Then
                            mailcontent = xnEmailSettings.SelectSingleNode("MailContent").InnerText
                        Else
                            mailcontent = "This is to notify that the $file$ file state has been Changed and requires your action." & vbNewLine &
                                 "State has been changed from $transition$. " & vbNewLine & vbNewLine &
                                 "This is an automated mail. Kindly do not reply to this mail."
                        End If

                        If _Isfile = True Then
                            Dim vFile As Autodesk.Connectivity.WebServices.File = DirectCast(vFileorFolder, Autodesk.Connectivity.WebServices.File)

                            mailcontent = mailcontent.Replace("$filename$", System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.GetFileNameWithoutExtension(vFile.Name)))
                            mailcontent = mailcontent.Replace("$revision$", vFile.FileRev.Label)
                            mailcontent = mailcontent.Replace("$category$", vFile.Cat.CatName)
                            mailcontent = mailcontent.Replace("$description$", desc)
                            mailcontent = mailcontent.Replace("$state$", vFile.FileLfCyc.LfCycStateName)
                            mailcontent = mailcontent.Replace("$link$", url)
                        Else
                            Dim vFolder As Autodesk.Connectivity.WebServices.Folder = DirectCast(vFileorFolder, Autodesk.Connectivity.WebServices.Folder)
                            Dim folderstate As String = ""
                            Dim lcDefs As LfCycDef() = vConnection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions()
                            Dim folderlfcycledefId As Long = vFolder.LfCyc.LfCycDefId
                            Dim folderlifecycleStateId As Long = vFolder.LfCyc.LfCycStateId

                            For Each lfcycledef As LfCycDef In lcDefs
                                If lfcycledef.Id = folderlfcycledefId Then
                                    For Each LfCycStateitem As LfCycState In lfcycledef.StateArray
                                        If LfCycStateitem.Id = folderlifecycleStateId Then
                                            folderstate = LfCycStateitem.DispName
                                            Exit For
                                        End If
                                    Next
                                End If
                            Next

                            mailcontent = mailcontent.Replace("$filename$", System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.GetFileNameWithoutExtension(vFolder.Name)))
                            mailcontent = mailcontent.Replace("$revision$", "")
                            mailcontent = mailcontent.Replace("$category$", vFolder.Cat.CatName)
                            mailcontent = mailcontent.Replace("$description$", desc)
                            mailcontent = mailcontent.Replace("$state$", folderstate)
                            mailcontent = mailcontent.Replace("$link$", "")
                        End If

                        If isPromoted = False Then
                            mailcontent = mailcontent.Replace("promoted", "depromoted")
                        End If

                        SmtpServer.Port = smtpPort
                        SmtpServer.Host = smtpHost
                        SmtpServer.EnableSsl = enableSSL
                        Dim mail As New MailMessage()
                        mail.From = New MailAddress(smtpFromEmail, smtpDisplayName)
                        If toAddress.Equals(String.Empty) Then
                            WriteLog("Mail Id for Users is missing for the Configured Group!")
                            Return True
                        End If

                        mail.To.Add(toAddress)
                        mail.Subject = mailSubject
                        mail.IsBodyHtml = False
                        mail.Body = mailcontent
                        mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure
                        mail.ReplyToList.Add(smtpFromEmail)
                        SmtpServer.Send(mail)
                        Return True
                    End If
                End If
            Catch ex As Exception
                WriteLog(ex.ToString() & vbNewLine & ex.StackTrace.ToString() & vbNewLine & ex.InnerException.ToString())
            End Try
            Return False
        End Function

        Public Shared Function EscapeHTML(ByVal value As [String]) As String
            Dim retVal As String = value
            retVal = retVal.Replace("$", "%24")
            retVal = retVal.Replace("/", "%2f")
            retVal = retVal.Replace(" ", "+")
            Return retVal
        End Function

        Public Function DownlodFile(ByVal _filename As String, ByVal _outputPath As String) As Boolean
            ' download individual files to a temp location
            Try
                Dim oFileIteration As FileIteration = getFileIteration(_filename, vConnection)
                Dim settings As New AcquireFilesSettings(vConnection)
                settings.LocalPath = New FolderPathAbsolute(_outputPath)

                ' For Each fileIter As VDF.Vault.Currency.Entities.FileIteration In fileIters
                settings.AddFileToAcquire(oFileIteration, AcquireFilesSettings.AcquisitionOption.Download)
                ' Next
                Dim results As AcquireFilesResults = vConnection.FileManager.AcquireFiles(settings)

                If results.FileResults(0).Status.Equals(FileAcquisitionResult.AcquisitionStatus.Success) Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                WriteLog(ex.ToString() & vbNewLine & ex.StackTrace.ToString() & vbNewLine & ex.InnerException.ToString())
                Return False
            End Try
        End Function

        Public Function getFileIteration(ByVal nameOfFile As String, ByVal connection As Vault.Currency.Connections.Connection) _
                                                                      As Vault.Currency.Entities.FileIteration
            Dim conditions As SrchCond()

            ReDim conditions(0)

            Dim lCode As Long = 3

            Dim Defs As PropDef() = connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE")

            Dim Prop As PropDef = Nothing

            For Each def As PropDef In Defs
                If def.DispName = "File Name" Then
                    Prop = def
                    Exit For
                End If
            Next def

            Dim searchCondition As SrchCond = New SrchCond()
            searchCondition.PropDefId = Prop.Id

            searchCondition.PropTyp = PropertySearchType.SingleProperty
            searchCondition.SrchOper = lCode

            searchCondition.SrchTxt = nameOfFile

            conditions(0) = searchCondition

            ' search for files
            Dim FileList As List(Of Autodesk.Connectivity.WebServices.File) = New List(Of Autodesk.Connectivity.WebServices.File)()
            Dim sBookmark As String = String.Empty
            Dim Status As SrchStatus = Nothing

            While (Status Is Nothing OrElse FileList.Count < Status.TotalHits)

                Dim files As Autodesk.Connectivity.WebServices.File() = connection.WebServiceManager.
                                                          DocumentService.FindFilesBySearchConditions(conditions,
                                                                 Nothing, Nothing, True, True, sBookmark, Status)

                If (Not files Is Nothing) Then
                    FileList.AddRange(files)
                End If
            End While

            Dim oFileIteration As Vault.Currency.Entities.FileIteration = Nothing
            For i As Integer = 0 To FileList.Count - 1
                If FileList(i).Name = nameOfFile Then
                    oFileIteration = New Vault.Currency.Entities.FileIteration(connection, FileList(i))
                End If
            Next

            Return oFileIteration

        End Function

        Public Function getFileProperties(ByVal fileId As Long) As Dictionary(Of String, String)
            Try
                Dim props() As PropDef = vConnection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE")
                Dim propDefIds() As Long
                propDefIds = (From prop In props
                              Select prop.Id).ToArray()
                Dim fileProp() As Autodesk.Connectivity.WebServices.PropInst = vConnection.WebServiceManager.PropertyService.GetProperties("FILE", New Long() {fileId}, propDefIds.ToArray())

                Dim ret As Dictionary(Of String, String) = New Dictionary(Of String, String)
                For Each prop In props
                    Dim singlePropValue As String = String.Empty
                    Try
                        singlePropValue = (From _fp In fileProp
                                           Where _fp.PropDefId.Equals(prop.Id)
                                           Select _fp.Val).FirstOrDefault().ToString()
                    Catch ex As Exception

                    End Try
                    If singlePropValue Is Nothing Then
                        singlePropValue = String.Empty
                    End If
                    ret.Add(prop.DispName, singlePropValue)
                Next
                Return ret
            Catch ex As Exception

            End Try
            Return Nothing
        End Function

        Public Function getFolderProperties(ByVal folderID As Long) As Dictionary(Of String, String)
            Try
                Dim props() As PropDef = vConnection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FLDR")
                Dim propDefIds() As Long
                propDefIds = (From prop In props
                              Select prop.Id).ToArray()
                Dim folderProp() As Autodesk.Connectivity.WebServices.PropInst = vConnection.WebServiceManager.PropertyService.GetProperties("FLDR", New Long() {folderID}, propDefIds.ToArray())

                Dim ret As Dictionary(Of String, String) = New Dictionary(Of String, String)
                For Each prop In props
                    Dim singlePropValue As String = String.Empty
                    Try
                        singlePropValue = (From _fp In folderProp
                                           Where _fp.PropDefId.Equals(prop.Id)
                                           Select _fp.Val).FirstOrDefault().ToString()
                    Catch ex As Exception

                    End Try
                    If singlePropValue Is Nothing Then
                        singlePropValue = String.Empty
                    End If
                    ret.Add(prop.DispName, singlePropValue)
                Next
                Return ret
            Catch ex As Exception

            End Try
            Return Nothing
        End Function

#End Region

    End Class

    Public Class PublishSettings
        Public isPDF, isDWF, isDXF, isPublishToSameFolder, saveExternally, isCustomWatermark As Boolean
        Public pdfFolderId, dwfFolderId, dxfFolderId As Long
        Public externalFolderLocation, watermarkIprop, watermarkText As String
        Public lstFileTypes As List(Of FileTypes)


        Public Sub LoadFileTypes(ByVal xnNode As XmlNode, ByVal lfyDefId As Long, ByVal transitionId As Long)
            Try
                lstFileTypes = New List(Of FileTypes)
                Dim _fileType As FileTypes
                Dim _pubType As PublishType
                Dim selNodes = From xn As XmlNode In xnNode.SelectNodes("FileTypes")
                               Where xn.Attributes("LifecycleId").Value = lfyDefId AndAlso xn.Attributes("TransitionId").Value = transitionId
                               Select xn

                For Each node As XmlNode In selNodes 'xnNode.SelectNodes("FileTypes")
                    _fileType = New FileTypes()
                    _fileType.LifecycleId = node.Attributes("LifecycleId").Value
                    _fileType.TransitionId = node.Attributes("TransitionId").Value
                    _fileType.LifecycleName = node.Attributes("LifecycleName").Value
                    _fileType.TransitionName = node.Attributes("TransitionName").Value
                    _fileType.Name = node.Attributes("Name").Value
                    For Each op As XmlNode In node.SelectNodes("ExportOptions")
                        _pubType = New PublishType()
                        _pubType.Name = op.SelectSingleNode("Name").InnerText
                        _pubType.SystemFolder = op.SelectSingleNode("SystemFolder").InnerText
                        _pubType.VaultFolder = op.SelectSingleNode("VaultFolder").InnerText
                        _pubType.IniFile = op.SelectSingleNode("IniFile").InnerText
                        _pubType.IlogicFile = op.SelectSingleNode("IlogicFile").InnerText
                        _pubType.NamingScheme = op.SelectSingleNode("NamingScheme").InnerText
                        _pubType.isEnabled = op.SelectSingleNode("isEnabled").InnerText
                        _pubType.isRmb = op.SelectSingleNode("isRmb").InnerText
                        _pubType.isExternalPublish = op.SelectSingleNode("isExternalPublish").InnerText
                        _pubType.IsSameVaultFolder = op.SelectSingleNode("IsSameVaultFolder").InnerText
                        _pubType.IsIni = op.SelectSingleNode("IsIni").InnerText
                        _pubType.IsILogic = op.SelectSingleNode("IsILogic").InnerText
                        _pubType.VaultFolderId = op.SelectSingleNode("VaultFolderId").InnerText
                        _pubType.IlogicFileId = op.SelectSingleNode("IlogicFileId").InnerText
                        _pubType.IniFileId = op.SelectSingleNode("IniFileId").InnerText
                        _fileType.ExportOptions.Add(_pubType)
                    Next
                    lstFileTypes.Add(_fileType)
                Next
            Catch ex As Exception

            End Try
        End Sub

    End Class

    Public Class FileTypes
        Private _exportOptions As List(Of PublishType)
        Private _lifecycleName, _transitionName, _name As String
        Private _lifecycleId, _transitionId As Long

        Public Sub New()
            ExportOptions = New List(Of PublishType)
            LifecycleId = -1
            TransitionId = -1
            LifecycleName = String.Empty
            TransitionName = String.Empty
            Name = String.Empty
        End Sub

        Public Property LifecycleName As String
            Get
                Return _lifecycleName
            End Get
            Set(value As String)
                _lifecycleName = value
            End Set
        End Property

        Public Property LifecycleId As Long
            Get
                Return _lifecycleId
            End Get
            Set(value As Long)
                _lifecycleId = value
            End Set
        End Property

        Public Property TransitionId As Long
            Get
                Return _transitionId
            End Get
            Set(value As Long)
                _transitionId = value
            End Set
        End Property


        Public Property TransitionName As String
            Get
                Return _transitionName
            End Get
            Set(value As String)
                _transitionName = value.Replace("->", "-")
            End Set
        End Property

        Public Property Name As String
            Get
                Return _name
            End Get
            Set(value As String)
                _name = value
            End Set
        End Property

        Public Property ExportOptions As List(Of PublishType)
            Get
                Return _exportOptions
            End Get
            Set(value As List(Of PublishType))
                _exportOptions = value
            End Set
        End Property
    End Class

    Public Class PublishType
        Private _name, _systemFolder, _vaultFolder, _iniFile, _ilogicFile, _namingScheme As String
        Private _isEnabled, _isRmb, _isExternalPublish, _isSameVaultFolder, _isIni, _isIlogic As Boolean
        Private _vaultFolderId, _ilogicFileId, _iniFileId As Long

        Public Sub New()
            Name = String.Empty
            SystemFolder = String.Empty
            VaultFolder = String.Empty
            IniFile = String.Empty
            NamingScheme = "$vFile Name$ - $vRevision$"

            isEnabled = True
            isRmb = True
            isExternalPublish = False
            IsSameVaultFolder = True
            IsIni = False
            IsILogic = False

            VaultFolderId = -1
            IlogicFileId = -1
            IniFileId = -1
        End Sub

        Public Property Name As String
            Get
                Return _name
            End Get
            Set(value As String)
                _name = value
            End Set
        End Property

        Public Property SystemFolder As String
            Get
                Return _systemFolder
            End Get
            Set(value As String)
                _systemFolder = value
            End Set
        End Property

        Public Property VaultFolder As String
            Get
                Return _vaultFolder
            End Get
            Set(value As String)
                _vaultFolder = value
            End Set
        End Property

        Public Property IniFile As String
            Get
                Return _iniFile
            End Get
            Set(value As String)
                _iniFile = value
            End Set
        End Property

        Public Property IlogicFile As String
            Get
                Return _ilogicFile
            End Get
            Set(value As String)
                _ilogicFile = value
            End Set
        End Property

        Public Property NamingScheme As String
            Get
                Return _namingScheme
            End Get
            Set(value As String)
                _namingScheme = value
            End Set
        End Property

        Public Property isEnabled As Boolean
            Get
                Return _isEnabled
            End Get
            Set(value As Boolean)
                _isEnabled = value
            End Set
        End Property

        Public Property isRmb As Boolean
            Get
                Return _isRmb
            End Get
            Set(value As Boolean)
                _isRmb = value
            End Set
        End Property

        Public Property isExternalPublish As Boolean
            Get
                Return _isExternalPublish
            End Get
            Set(value As Boolean)
                _isExternalPublish = value
            End Set
        End Property

        Public Property IsSameVaultFolder As Boolean
            Get
                Return _isSameVaultFolder
            End Get
            Set(value As Boolean)
                _isSameVaultFolder = value
            End Set
        End Property

        Public Property IsIni As Boolean
            Get
                Return _isIni
            End Get
            Set(value As Boolean)
                If value Then
                    If IsILogic Then
                        IsILogic = False
                    End If
                End If
                _isIni = value
            End Set
        End Property

        Public Property IsILogic As Boolean
            Get
                Return _isIlogic
            End Get
            Set(value As Boolean)
                If value Then
                    If IsIni Then
                        IsIni = False
                    End If
                End If
                _isIlogic = value
            End Set
        End Property

        Public Property VaultFolderId As Long
            Get
                Return _vaultFolderId
            End Get
            Set(value As Long)
                _vaultFolderId = value
            End Set
        End Property

        Public Property IlogicFileId As Long
            Get
                Return _ilogicFileId
            End Get
            Set(value As Long)
                _ilogicFileId = value
            End Set
        End Property

        Public Property IniFileId As Long
            Get
                Return _iniFileId
            End Get
            Set(value As Long)
                _iniFileId = value
            End Set
        End Property
    End Class

End Namespace

