﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersThreadEndTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersThreadEndTypes LoadList()
        {
            StrainersThreadEndTypes items = new StrainersThreadEndTypes();
            return items;
        }
        public static StrainersThreadEndTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersThreadEndTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersThreadEndTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersThreadEndTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersThreadEndTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersThreadEndTypes.xml");
        }

    }
}
