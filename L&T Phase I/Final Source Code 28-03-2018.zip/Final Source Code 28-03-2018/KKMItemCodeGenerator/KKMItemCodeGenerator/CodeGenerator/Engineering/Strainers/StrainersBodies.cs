﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersBodies : ObservableCollection<NameCodePair>
    {
        public static StrainersBodies LoadList()
        {
            StrainersBodies items = new StrainersBodies();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "BRONZE" });
            items.Add(new NameCodePair() { Code = "02", Name = "CAST IRON" });
            items.Add(new NameCodePair() { Code = "03", Name = "HOT DIP GALVANIZED STEEL" });
            items.Add(new NameCodePair() { Code = "04", Name = "STAINLESS STEEL" });
            items.Add(new NameCodePair() { Code = "05", Name = "ALLOY MATERIALS" });
            items.Add(new NameCodePair() { Code = "06", Name = "DUCTILE CAST IRON" });
            items.Add(new NameCodePair() { Code = "07", Name = "STAINLESS STEEL SS316" });
            items.Add(new NameCodePair() { Code = "08", Name = "CAST STEEL" });
            items.Add(new NameCodePair() { Code = "09", Name = "FORGED STEEL" });
            items.Add(new NameCodePair() { Code = "10", Name = "MILD STEEL" });
            items.Add(new NameCodePair() { Code = "11", Name = "GUN METAL" });
            items.Add(new NameCodePair() { Code = "12", Name = "NAB as per NES 747 Part 2" });
            return items;
        }
        public static StrainersBodies LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersBodies LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersBodies>(EngineeringItems.DataPath + @"\Strainers\StrainersBodies.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersBodies>(this, EngineeringItems.DataPath + @"\Strainers\StrainersBodies.xml");
        }

    }
}
