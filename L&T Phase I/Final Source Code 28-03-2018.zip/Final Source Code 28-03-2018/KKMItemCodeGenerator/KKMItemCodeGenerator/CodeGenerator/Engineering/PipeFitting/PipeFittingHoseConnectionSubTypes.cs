﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingHoseConnectionSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingHoseConnectionSubTypes LoadList()
        {
            PipeFittingHoseConnectionSubTypes items = new PipeFittingHoseConnectionSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "HOSE CONNECTION" });
            return items;
        }
        public static PipeFittingHoseConnectionSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingHoseConnectionSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingHoseConnectionSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingHoseConnectionSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingHoseConnectionSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingHoseConnectionSubTypes.xml");
        }

    }
}
