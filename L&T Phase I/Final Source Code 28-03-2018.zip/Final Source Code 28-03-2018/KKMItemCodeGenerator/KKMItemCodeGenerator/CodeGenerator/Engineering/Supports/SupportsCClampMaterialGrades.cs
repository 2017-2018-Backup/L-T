﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsCClampMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static SupportsCClampMaterialGrades LoadList()
        {
            SupportsCClampMaterialGrades items = new SupportsCClampMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "MILD STEEL" });
            items.Add(new NameCodePair() { Code = "02", Name = "MILD STEEL - GALVANIZED" });
            items.Add(new NameCodePair() { Code = "03", Name = "STEEL FLAT BAR" });
            items.Add(new NameCodePair() { Code = "04", Name = "STEEL PLATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "ALLOY STEEL" });
            items.Add(new NameCodePair() { Code = "06", Name = "PVC/RUBBER" });
            items.Add(new NameCodePair() { Code = "07", Name = "STAINLESS STEEL" });
            items.Add(new NameCodePair() { Code = "08", Name = "STEEL FLAT BAR" });
            items.Add(new NameCodePair() { Code = "09", Name = "STEEL PLATE" });
            return items;
        }
        public static SupportsCClampMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsCClampMaterialGrades LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsCClampMaterialGrades>(EngineeringItems.DataPath + @"\Supports\SupportsCClampMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsCClampMaterialGrades>(this, EngineeringItems.DataPath + @"\Supports\SupportsCClampMaterialGrades.xml");
        }

    }
}
