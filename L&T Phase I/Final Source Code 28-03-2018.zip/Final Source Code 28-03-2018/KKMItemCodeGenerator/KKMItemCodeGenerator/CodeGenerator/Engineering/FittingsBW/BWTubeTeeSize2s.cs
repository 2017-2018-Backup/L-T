﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWTubeTeeSize2s : ObservableCollection<NameCodePair>
    {
        public static BWTubeTeeSize2s LoadList()
        {
            BWTubeTeeSize2s items = new BWTubeTeeSize2s();
            items.Add(new NameCodePair() { Code = "01", Name = "6 OD" });
            items.Add(new NameCodePair() { Code = "02", Name = "8 OD" });
            items.Add(new NameCodePair() { Code = "03", Name = "10 OD" });
            items.Add(new NameCodePair() { Code = "04", Name = "12 OD" });
            items.Add(new NameCodePair() { Code = "05", Name = "15 OD" });
            items.Add(new NameCodePair() { Code = "06", Name = "16 OD" });
            items.Add(new NameCodePair() { Code = "07", Name = "18 OD" });
            items.Add(new NameCodePair() { Code = "08", Name = "20 OD" });
            items.Add(new NameCodePair() { Code = "09", Name = "22 OD" });
            items.Add(new NameCodePair() { Code = "10", Name = "25 OD" });
            items.Add(new NameCodePair() { Code = "11", Name = "28 OD" });
            items.Add(new NameCodePair() { Code = "12", Name = "30 OD" });
            items.Add(new NameCodePair() { Code = "13", Name = "35 OD" });
            items.Add(new NameCodePair() { Code = "14", Name = "38 OD" });
            items.Add(new NameCodePair() { Code = "15", Name = "42 OD" });
            items.Add(new NameCodePair() { Code = "16", Name = "55 OD" });
            items.Add(new NameCodePair() { Code = "17", Name = "50 OD" });
            items.Add(new NameCodePair() { Code = "18", Name = "60 OD" });
            items.Add(new NameCodePair() { Code = "19", Name = "65 OD" });
            items.Add(new NameCodePair() { Code = "20", Name = "80 OD" });
            return items;
        }
        public static BWTubeTeeSize2s LoadFromExcel(String path)
        {
            return null;
        }

        public static BWTubeTeeSize2s LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWTubeTeeSize2s>(EngineeringItems.DataPath + @"\FittingsBW\BWTubeTeeSize2s.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWTubeTeeSize2s>(this, EngineeringItems.DataPath + @"\FittingsBW\BWTubeTeeSize2s.xml");
        }

    }
}
