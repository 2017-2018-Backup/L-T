﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleClassCertificates : ObservableCollection<NameCodePair>
    {
        public static AngleClassCertificates LoadList()
        {
            AngleClassCertificates items = new AngleClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NO CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "GL 3.2 certificate" });
            items.Add(new NameCodePair() { Code = "02", Name = "LR 3.2 certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "04", Name = "ABS & IRS Certificate" });
            return items;
        }

        public static AngleClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleClassCertificates>(HullItems.HullDataPath + @"\Angle\AngleClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleClassCertificates>(this, HullItems.HullDataPath + @"\Angle\AngleClassCertificates.xml");
        }
    }
}
