﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWPipeReducerSubTypes : ObservableCollection<NameCodePair>
    {
        public static BWPipeReducerSubTypes LoadList()
        {
            BWPipeReducerSubTypes items = new BWPipeReducerSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Concentric" });
            items.Add(new NameCodePair() { Code = "02", Name = "Eccentric" });
            items.Add(new NameCodePair() { Code = "03", Name = "Suction Bellmouth" });
            return items;
        }
        public static BWPipeReducerSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BWPipeReducerSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWPipeReducerSubTypes>(EngineeringItems.DataPath + @"\FittingsBW\BWPipeReducerSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWPipeReducerSubTypes>(this, EngineeringItems.DataPath + @"\FittingsBW\BWPipeReducerSubTypes.xml");
        }

    }
}
