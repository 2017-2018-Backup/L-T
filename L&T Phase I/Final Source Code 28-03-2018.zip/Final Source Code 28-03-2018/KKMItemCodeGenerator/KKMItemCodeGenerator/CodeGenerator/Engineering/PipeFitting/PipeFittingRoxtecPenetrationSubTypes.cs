﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingRoxtecPenetrationSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingRoxtecPenetrationSubTypes LoadList()
        {
            PipeFittingRoxtecPenetrationSubTypes items = new PipeFittingRoxtecPenetrationSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ROXTEC SLEEVE" });
            items.Add(new NameCodePair() { Code = "02", Name = "ROXTEC SEAL" });
            return items;
        }
        public static PipeFittingRoxtecPenetrationSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingRoxtecPenetrationSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingRoxtecPenetrationSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingRoxtecPenetrationSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingRoxtecPenetrationSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingRoxtecPenetrationSubTypes.xml");
        }

    }
}
