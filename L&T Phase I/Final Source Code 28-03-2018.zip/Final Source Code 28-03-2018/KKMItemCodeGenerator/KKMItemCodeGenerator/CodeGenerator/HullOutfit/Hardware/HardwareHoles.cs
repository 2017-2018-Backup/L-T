﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareHoles : ObservableCollection<NameCodePair>
    {
        public static HardwareHoles LoadList()
        {
            HardwareHoles items = new HardwareHoles();
            items.Add(new NameCodePair() { Code = "", Name = "NO HOLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "3mm dia pin, 7mm from end" });
            items.Add(new NameCodePair() { Code = "02", Name = "3mm dia pin, 5mm from end." });
            items.Add(new NameCodePair() { Code = "03", Name = "" });
            items.Add(new NameCodePair() { Code = "04", Name = "" });
            items.Add(new NameCodePair() { Code = "05", Name = "" });
            items.Add(new NameCodePair() { Code = "06", Name = "" });
            items.Add(new NameCodePair() { Code = "07", Name = "" });
            items.Add(new NameCodePair() { Code = "08", Name = "" });
            items.Add(new NameCodePair() { Code = "09", Name = "" });
            return items;
        }
        public static HardwareHoles LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareHoles LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareHoles>(HullOutfitItems.DataPath + @"\Hardware\HardwareHoles.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareHoles>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareHoles.xml");
        }
    }
}
