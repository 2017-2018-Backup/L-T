﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Autodesk.Connectivity.WebServices;

namespace KKMCustomerComment
{
    public class clsCustomerCommentsummary
    {
        public List<SingleCustomerCommentsummary> collectionCustomerComment = new List<SingleCustomerCommentsummary> { };
    }

    public class SingleCustomerCommentsummary
    {
        public int CustomerCommentCount { get; set; }
        public int CustomerCommentNumber { get; set; }
        public string CustomerCommentFileName { get; set; }
        public string CustomerCommentFileFullPath { get; set; }

        public string CustomerCommentProjectCode { get; set; }
        public string CustomerCustomerCommentNumber { get; set; }
        public string CustomerCustomerComment { get; set; }

        public ObservableCollection<CustomerRelatedDocument> ListCustomerRelatedDocuments = new ObservableCollection<CustomerRelatedDocument> { };
        public ObservableCollection<LandTRelatedDocument> ListLandTRelatedDocuments = new ObservableCollection<LandTRelatedDocument> { };

        public string CustomerCommentCustomerRelatedDocuments { get; set; }
        public string CustomerCommentLandTRelatedDocuments { get; set; }

        public string CustomerCommentsystem { get; set; }
        public string CustomerCommentResponsiblePerson { get; set; }

        public string CustomerCommentLifeCycle { get; set; }
        public string CustomerCommentLatestVersion { get; set; }

        public string CustomerCommentCloserDate { get; set; }
        public string CustomerCommentLandTComment { get; set; }
        public string CustomerCommentTimeImplications { get; set; }
        public string CustomerCommentCostImplications { get; set; }
        public string CustomerCommentFindAcceptanceFromCustomer { get; set; }
        public string CustomerCommentRemark { get; set; }
        public bool CustomerCommentIsSuccess { get; set; }

        public List<int> CustomerCommentHistoryVersions = new List<int> { };
    }

    public class CustomerRelatedDocument : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }

        private bool _IsCheckedCustomerRelatedDocument;
        public bool IsCheckedCustomerRelatedDocument
        {
            get { return _IsCheckedCustomerRelatedDocument; }
            set
            {
                _IsCheckedCustomerRelatedDocument = value;
                OnPropertyChanged("IsCheckedCustomerRelatedDocument");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class LandTRelatedDocument : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set;}
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }

        private bool _IsCheckedLandTRelatedDocument;
        public bool IsCheckedLandTRelatedDocument
        {
            get { return _IsCheckedLandTRelatedDocument; }
            set
            {
                if (_IsCheckedLandTRelatedDocument != value)
                {
                    _IsCheckedLandTRelatedDocument = value;
                    OnPropertyChanged("IsCheckedLandTRelatedDocument");
                }
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

}
