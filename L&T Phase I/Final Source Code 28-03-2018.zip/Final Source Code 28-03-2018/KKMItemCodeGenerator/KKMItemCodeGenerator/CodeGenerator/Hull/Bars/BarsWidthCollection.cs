﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsWidthCollection : ObservableCollection<NameCodePair>
    {
        public static BarsWidthCollection LoadList()
        {
            BarsWidthCollection items = new BarsWidthCollection();
            items.Add(new NameCodePair() { Code = "006", Name = "6" });
            items.Add(new NameCodePair() { Code = "010", Name = "10" });
            items.Add(new NameCodePair() { Code = "012", Name = "12" });
            items.Add(new NameCodePair() { Code = "015", Name = "15" });
            items.Add(new NameCodePair() { Code = "016", Name = "16" });
            items.Add(new NameCodePair() { Code = "020", Name = "20" });
            items.Add(new NameCodePair() { Code = "022", Name = "22" });
            items.Add(new NameCodePair() { Code = "025", Name = "25" });
            items.Add(new NameCodePair() { Code = "030", Name = "30" });
            items.Add(new NameCodePair() { Code = "035", Name = "35" });
            items.Add(new NameCodePair() { Code = "040", Name = "40" });
            items.Add(new NameCodePair() { Code = "045", Name = "45" });
            items.Add(new NameCodePair() { Code = "050", Name = "50" });
            items.Add(new NameCodePair() { Code = "060", Name = "60" });
            items.Add(new NameCodePair() { Code = "065", Name = "65" });
            items.Add(new NameCodePair() { Code = "070", Name = "70" });
            items.Add(new NameCodePair() { Code = "075", Name = "75" });
            items.Add(new NameCodePair() { Code = "080", Name = "80" });
            items.Add(new NameCodePair() { Code = "100", Name = "100" });
            items.Add(new NameCodePair() { Code = "125", Name = "125" });
            items.Add(new NameCodePair() { Code = "140", Name = "140" });
            items.Add(new NameCodePair() { Code = "150", Name = "150" });
            items.Add(new NameCodePair() { Code = "160", Name = "160" });
            items.Add(new NameCodePair() { Code = "175", Name = "175" });
            items.Add(new NameCodePair() { Code = "180", Name = "180" });
            items.Add(new NameCodePair() { Code = "200", Name = "200" });
            items.Add(new NameCodePair() { Code = "220", Name = "220" });
            items.Add(new NameCodePair() { Code = "225", Name = "225" });
            items.Add(new NameCodePair() { Code = "240", Name = "240" });
            items.Add(new NameCodePair() { Code = "250", Name = "250" });
            items.Add(new NameCodePair() { Code = "260", Name = "260" });
            items.Add(new NameCodePair() { Code = "280", Name = "280" });
            items.Add(new NameCodePair() { Code = "300", Name = "300" });
            items.Add(new NameCodePair() { Code = "320", Name = "320" });
            items.Add(new NameCodePair() { Code = "350", Name = "350" });
            items.Add(new NameCodePair() { Code = "370", Name = "370" });
            items.Add(new NameCodePair() { Code = "400", Name = "400" });
            items.Add(new NameCodePair() { Code = "120", Name = "120" });
            items.Add(new NameCodePair() { Code = "170", Name = "170" });
            items.Add(new NameCodePair() { Code = "275", Name = "275" });

            return items;
        }

        public static BarsWidthCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsWidthCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsWidthCollection>(HullItems.HullDataPath + @"\Bars\BarsWidthCollection.xml");
        }
        
        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsWidthCollection>(this, HullItems.HullDataPath + @"\Bars\BarsWidthCollection.xml");
        }
    }
}
