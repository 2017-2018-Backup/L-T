﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class NameCodePair : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void notifyPropertyChange(string propertyName)
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));        
        }

        private String name;
        public String Name
        {
            get { return name; }
            set { if (name != value) { name = value; notifyPropertyChange("Name"); } }
        }

        private String code;
        public String Code
        {
            get { return code; }
            set { if (code != value) { code = value; notifyPropertyChange("Code"); } }
        }

        public override string ToString()
        {
            return this.name;
        }
        
    }
}
