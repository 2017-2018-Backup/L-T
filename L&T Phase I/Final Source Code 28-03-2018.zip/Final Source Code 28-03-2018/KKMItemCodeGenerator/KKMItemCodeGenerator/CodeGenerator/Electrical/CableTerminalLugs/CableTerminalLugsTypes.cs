﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTerminalLugsTypes : ObservableCollection<NameCodePair>
    {
        public static CableTerminalLugsTypes LoadList()
        {
            CableTerminalLugsTypes items = new CableTerminalLugsTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "CABLE TERMINAL LUGS ROUND HEAD" });
            items.Add(new NameCodePair() { Code = "02", Name = "CABLE TERMINAL LUGS INSULATED EYELET" });
            items.Add(new NameCodePair() { Code = "03", Name = "CABLE TERMINAL LUGS INSULATED SPADE" });
            items.Add(new NameCodePair() { Code = "04", Name = "CABLE TERMINAL LUGS INSULATED SPANNER HEAD" });
            items.Add(new NameCodePair() { Code = "05", Name = "CABLE TERMINAL LUGS INSULATED RECEPTACLES" });
            items.Add(new NameCodePair() { Code = "06", Name = "CABLE TERMINAL LUGS INSULATED FLAT PINS" });
            items.Add(new NameCodePair() { Code = "07", Name = "CABLE TERMINAL LUGS INSULATED BUTT" });
            items.Add(new NameCodePair() { Code = "08", Name = "CABLE TERMINAL LUGS INSULATED CABLE TIP" });
            items.Add(new NameCodePair() { Code = "09", Name = "CABLE TERMINAL LUGS BOOT LASE LUG" });
            items.Add(new NameCodePair() { Code = "10", Name = "CABLE TERMINAL LUGS ROUND LUG" });
            return items;
        }
        public static CableTerminalLugsTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTerminalLugsTypes LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTerminalLugsTypes>(ElectricalItems.DataPath + @"\CableTerminalLugs\CableTerminalLugsTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath + @"\CableTerminalLugs"))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath + @"\CableTerminalLugs");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTerminalLugsTypes>(this, ElectricalItems.DataPath + @"\CableTerminalLugs\CableTerminalLugsTypes.xml");
        }

    }
}
