﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareStandards : ObservableCollection<NameCodePair>
    {
        public static HardwareStandards LoadList()
        {
            HardwareStandards items = new HardwareStandards();
            items.Add(new NameCodePair() { Code = "", Name = "NON STANDARD" });
            items.Add(new NameCodePair() { Code = "01", Name = "ISO 4014" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISO 4017" });
            items.Add(new NameCodePair() { Code = "03", Name = "ISO 4032" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 6916" });
            items.Add(new NameCodePair() { Code = "05", Name = "ISO 7089" });
            items.Add(new NameCodePair() { Code = "06", Name = "ISO 7089" });
            items.Add(new NameCodePair() { Code = "07", Name = "DIN 444B" });
            items.Add(new NameCodePair() { Code = "08", Name = "DIN 582" });
            items.Add(new NameCodePair() { Code = "09", Name = "ISO 7089" });
            items.Add(new NameCodePair() { Code = "10", Name = "ASME B 16.5" });
            items.Add(new NameCodePair() { Code = "11", Name = "ASME B 16.10" });
            items.Add(new NameCodePair() { Code = "12", Name = "DIN 976" });
            items.Add(new NameCodePair() { Code = "13", Name = "DIN933" });
            items.Add(new NameCodePair() { Code = "14", Name = "DIN934" });

            return items;
        }
        public static HardwareStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareStandards LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareStandards>(HullOutfitItems.DataPath + @"\Hardware\HardwareStandards.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareStandards>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareStandards.xml");
        }
    }
}
