﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelFlangeThicknesses : ObservableCollection<NameCodePair>
    {
        public static ChannelFlangeThicknesses LoadList()
        {
            ChannelFlangeThicknesses items = new ChannelFlangeThicknesses();
            items.Add(new NameCodePair() { Code = "07E", Name = "7.5 mm" });
            items.Add(new NameCodePair() { Code = "07G", Name = "7.7 mm" });
            items.Add(new NameCodePair() { Code = "08A", Name = "8.1 mm" });
            items.Add(new NameCodePair() { Code = "08B", Name = "8.2 mm" });
            items.Add(new NameCodePair() { Code = "009", Name = "9.0 mm" });
            items.Add(new NameCodePair() { Code = "10B", Name = "10.2 mm" });
            items.Add(new NameCodePair() { Code = "11D", Name = "11.4 mm" });
            items.Add(new NameCodePair() { Code = "12D", Name = "12.4 mm" });
            items.Add(new NameCodePair() { Code = "13E", Name = "13.5 mm" });
            items.Add(new NameCodePair() { Code = "13F", Name = "13.6 mm" });
            items.Add(new NameCodePair() { Code = "14A", Name = "14.1 mm" });
            items.Add(new NameCodePair() { Code = "15C", Name = "15.3 mm" });
            return items;
        }
        public static ChannelFlangeThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelFlangeThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelFlangeThicknesses>(HullOutfitItems.DataPath + @"\Channel\ChannelFlangeThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelFlangeThicknesses>(this, HullOutfitItems.DataPath + @"\Channel\ChannelFlangeThicknesses.xml");
        }
    }
}
