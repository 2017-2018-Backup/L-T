﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsHYDClampPlateMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static SupportsHYDClampPlateMaterialGrades LoadList()
        {
            SupportsHYDClampPlateMaterialGrades items = new SupportsHYDClampPlateMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "SS" });
            items.Add(new NameCodePair() { Code = "02", Name = "MS" });
            return items;
        }
        public static SupportsHYDClampPlateMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsHYDClampPlateMaterialGrades LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsHYDClampPlateMaterialGrades>(EngineeringItems.DataPath + @"\Supports\SupportsHYDClampPlateMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsHYDClampPlateMaterialGrades>(this, EngineeringItems.DataPath + @"\Supports\SupportsHYDClampPlateMaterialGrades.xml");
        }

    }
}
