﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelMaterials : ObservableCollection<NameCodePair>
    {
        public static ChannelMaterials LoadList()
        {
            ChannelMaterials items = new ChannelMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "GR A" });
            items.Add(new NameCodePair() { Code = "02", Name = "GR AH32" });
            items.Add(new NameCodePair() { Code = "03", Name = "GR AH36" });
            items.Add(new NameCodePair() { Code = "04", Name = "GR AH40" });
            items.Add(new NameCodePair() { Code = "05", Name = "GR D" });
            items.Add(new NameCodePair() { Code = "06", Name = "GR DH32" });
            items.Add(new NameCodePair() { Code = "07", Name = "GR DH36" });
            items.Add(new NameCodePair() { Code = "08", Name = "GR DH40" });
            items.Add(new NameCodePair() { Code = "09", Name = "GR E" });
            items.Add(new NameCodePair() { Code = "10", Name = "GR EH32" });
            items.Add(new NameCodePair() { Code = "11", Name = "GR EH36" });
            items.Add(new NameCodePair() { Code = "12", Name = "GR EH40" });
            items.Add(new NameCodePair() { Code = "13", Name = "GR B" });
            items.Add(new NameCodePair() { Code = "14", Name = "IS2062 GRA" });
            items.Add(new NameCodePair() { Code = "15", Name = "GALV  IS 2062 GR A" });
            items.Add(new NameCodePair() { Code = "16", Name = "IS2062GRB" });
            items.Add(new NameCodePair() { Code = "17", Name = "SS304" });
            items.Add(new NameCodePair() { Code = "18", Name = "SS310" });
            items.Add(new NameCodePair() { Code = "19", Name = "SS316" });
            items.Add(new NameCodePair() { Code = "20", Name = "SS316L" });
            items.Add(new NameCodePair() { Code = "21", Name = "AISI316" });
            items.Add(new NameCodePair() { Code = "22", Name = "AISI316L" });
            items.Add(new NameCodePair() { Code = "23", Name = "AISI410" });
            items.Add(new NameCodePair() { Code = "24", Name = "GR AH 36 Z" });
            items.Add(new NameCodePair() { Code = "25", Name = "GR DH 36 Z" });
            items.Add(new NameCodePair() { Code = "26", Name = "GR EH 36 Z" });
            items.Add(new NameCodePair() { Code = "27", Name = "GR DH36+EN10164-Z25" });
            items.Add(new NameCodePair() { Code = "28", Name = "GR A Z" });
            items.Add(new NameCodePair() { Code = "29", Name = "S355J2G3" });
            items.Add(new NameCodePair() { Code = "30", Name = "S355J2G4" });
            items.Add(new NameCodePair() { Code = "31", Name = "S355J2GN" });
            items.Add(new NameCodePair() { Code = "32", Name = "S690 QL" });
            items.Add(new NameCodePair() { Code = "33", Name = "42 CR MO 4 V" });
            items.Add(new NameCodePair() { Code = "34", Name = "WELDOX 700" });
            items.Add(new NameCodePair() { Code = "35", Name = "MTL57" });
            items.Add(new NameCodePair() { Code = "36", Name = "ST52 – 3 N" });
            items.Add(new NameCodePair() { Code = "37", Name = "ASTM A 105/53 GRADE B" });
            items.Add(new NameCodePair() { Code = "38", Name = "GALVANISED IRON" });
            items.Add(new NameCodePair() { Code = "39", Name = "Hardened Steel Gr 4.4" });
            items.Add(new NameCodePair() { Code = "40", Name = "Hardened Steel Gr 6.6" });
            items.Add(new NameCodePair() { Code = "41", Name = "Hardened Steel Gr 8.8" });
            items.Add(new NameCodePair() { Code = "42", Name = "Hardened Steel Gr 10.9" });
            items.Add(new NameCodePair() { Code = "43", Name = "Hardened Steel Gr 12.9" });
            items.Add(new NameCodePair() { Code = "44", Name = "Aluminium" });
            items.Add(new NameCodePair() { Code = "45", Name = "SU 304L" });
            items.Add(new NameCodePair() { Code = "46", Name = "ASTM A516 GR 70" });
            items.Add(new NameCodePair() { Code = "47", Name = "AA 5083 H116" });
            items.Add(new NameCodePair() { Code = "48", Name = "AA 6082" });
            items.Add(new NameCodePair() { Code = "49", Name = "MTL10" });
            items.Add(new NameCodePair() { Code = "50", Name = "MTL07" });
            items.Add(new NameCodePair() { Code = "51", Name = "MILD STEEL GALVANIZED" });

            return items;
        }
        public static ChannelMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelMaterials LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelMaterials>(HullOutfitItems.DataPath + @"\Channel\ChannelMaterials.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelMaterials>(this, HullOutfitItems.DataPath + @"\Channel\ChannelMaterials.xml");
        }
    }
}
