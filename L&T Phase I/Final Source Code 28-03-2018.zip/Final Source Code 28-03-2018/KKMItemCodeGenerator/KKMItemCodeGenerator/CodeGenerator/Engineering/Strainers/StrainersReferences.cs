﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersReferences : ObservableCollection<NameCodePair>
    {
        public static StrainersReferences LoadList()
        {
            StrainersReferences items = new StrainersReferences();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "1", Name = "81005-705102-01-R1" });
            return items;
        }
        public static StrainersReferences LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersReferences LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersReferences>(EngineeringItems.DataPath + @"\Strainers\StrainersReferences.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersReferences>(this, EngineeringItems.DataPath + @"\Strainers\StrainersReferences.xml");
        }

    }
}
