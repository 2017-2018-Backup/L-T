﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PlateThicknessCollection : ObservableCollection<NameCodePair>
    {
        public static PlateThicknessCollection LoadList()
        {
            PlateThicknessCollection items = new PlateThicknessCollection();
            items.Add(new NameCodePair() { Code = "0010", Name = "1" });
            items.Add(new NameCodePair() { Code = "0025", Name = "2.5" });
            items.Add(new NameCodePair() { Code = "0030", Name = "3" });
            items.Add(new NameCodePair() { Code = "0040", Name = "4" });
            items.Add(new NameCodePair() { Code = "0050", Name = "5" });
            items.Add(new NameCodePair() { Code = "0060", Name = "6" });
            items.Add(new NameCodePair() { Code = "0070", Name = "7" });
            items.Add(new NameCodePair() { Code = "0075", Name = "7.5" });
            items.Add(new NameCodePair() { Code = "0080", Name = "8" });
            items.Add(new NameCodePair() { Code = "0085", Name = "8.5" });
            items.Add(new NameCodePair() { Code = "0090", Name = "9" });
            items.Add(new NameCodePair() { Code = "0095", Name = "9.5" });
            items.Add(new NameCodePair() { Code = "0100", Name = "10" });
            items.Add(new NameCodePair() { Code = "0105", Name = "10.5" });
            items.Add(new NameCodePair() { Code = "0110", Name = "11" });
            items.Add(new NameCodePair() { Code = "0115", Name = "11.5" });
            items.Add(new NameCodePair() { Code = "0120", Name = "12" });
            items.Add(new NameCodePair() { Code = "0125", Name = "12.5" });
            items.Add(new NameCodePair() { Code = "0130", Name = "13" });
            items.Add(new NameCodePair() { Code = "0135", Name = "13.5" });
            items.Add(new NameCodePair() { Code = "0140", Name = "14" });
            items.Add(new NameCodePair() { Code = "0150", Name = "15" });
            items.Add(new NameCodePair() { Code = "0155", Name = "15.5" });
            items.Add(new NameCodePair() { Code = "0160", Name = "16" });
            items.Add(new NameCodePair() { Code = "0170", Name = "17" });
            items.Add(new NameCodePair() { Code = "0180", Name = "18" });
            items.Add(new NameCodePair() { Code = "0185", Name = "18.5" });
            items.Add(new NameCodePair() { Code = "0190", Name = "19" });
            items.Add(new NameCodePair() { Code = "0200", Name = "20" });
            items.Add(new NameCodePair() { Code = "0210", Name = "21" });
            items.Add(new NameCodePair() { Code = "0220", Name = "22" });
            items.Add(new NameCodePair() { Code = "0240", Name = "24" });
            items.Add(new NameCodePair() { Code = "0250", Name = "25" });
            items.Add(new NameCodePair() { Code = "0270", Name = "27" });
            items.Add(new NameCodePair() { Code = "0260", Name = "26" });
            items.Add(new NameCodePair() { Code = "0280", Name = "28" });
            items.Add(new NameCodePair() { Code = "0300", Name = "30" });
            items.Add(new NameCodePair() { Code = "0320", Name = "32" });
            items.Add(new NameCodePair() { Code = "0350", Name = "35" });
            items.Add(new NameCodePair() { Code = "0360", Name = "36" });
            items.Add(new NameCodePair() { Code = "0400", Name = "40" });
            items.Add(new NameCodePair() { Code = "0450", Name = "45" });
            items.Add(new NameCodePair() { Code = "0500", Name = "50" });
            items.Add(new NameCodePair() { Code = "0600", Name = "60" });
            items.Add(new NameCodePair() { Code = "0700", Name = "70" });
            items.Add(new NameCodePair() { Code = "0750", Name = "75" });
            items.Add(new NameCodePair() { Code = "0800", Name = "80" });
            items.Add(new NameCodePair() { Code = "0900", Name = "90" });
            items.Add(new NameCodePair() { Code = "1000", Name = "100" });
            items.Add(new NameCodePair() { Code = "1250", Name = "125" });
            items.Add(new NameCodePair() { Code = "0035", Name = "3.15" });

            return items;
        }

        public static PlateThicknessCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static PlateThicknessCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PlateThicknessCollection>(HullItems.HullDataPath + @"\Plate\PlateThicknessCollection.xml");
        }
        
        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PlateThicknessCollection>(this, HullItems.HullDataPath + @"\Plate\PlateThicknessCollection.xml");
        }
    }
}
