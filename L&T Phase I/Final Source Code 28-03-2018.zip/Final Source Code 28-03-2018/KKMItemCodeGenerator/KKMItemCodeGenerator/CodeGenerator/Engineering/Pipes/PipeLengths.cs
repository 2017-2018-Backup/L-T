﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeLengths : ObservableCollection<NameCodePair>
    {
        public static PipeLengths LoadList()
        {
            PipeLengths items = new PipeLengths();
            items.Add(new NameCodePair() { Code = "", Name = "NOT-APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "150 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "250 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "500 mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "750 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "1000 mm" });
            items.Add(new NameCodePair() { Code = "06", Name = "1500 mm" });
            items.Add(new NameCodePair() { Code = "07", Name = "2000 mm" });
            items.Add(new NameCodePair() { Code = "08", Name = "3000 mm" });
            return items;
        }
        public static PipeLengths LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeLengths LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeLengths>(EngineeringItems.DataPath + @"\Pipes\PipeLengths.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeLengths>(this, EngineeringItems.DataPath + @"\Pipes\PipeLengths.xml");
        }

    }
}
