﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareBoltSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareBoltSubTypes LoadList()
        {
            HardwareBoltSubTypes items = new HardwareBoltSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Hex.Hd. Bolt" });
            items.Add(new NameCodePair() { Code = "02", Name = "Hex.Hd. Bolt-Half Threaded" });
            items.Add(new NameCodePair() { Code = "03", Name = "Hex.Soc.Cap.Bolt" });
            items.Add(new NameCodePair() { Code = "04", Name = "Round Bolt" });
            items.Add(new NameCodePair() { Code = "05", Name = "Eye Bolt" });
            items.Add(new NameCodePair() { Code = "06", Name = "Cup Square Bolt" });
            items.Add(new NameCodePair() { Code = "07", Name = "Hex. Hd. Bolt (with Hole)" });

            return items;
        }
        public static HardwareBoltSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareBoltSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareBoltSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareBoltSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareBoltSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareBoltSubTypes.xml");
        }
    }
}
