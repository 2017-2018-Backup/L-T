﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsCCLampCertificates : ObservableCollection<NameCodePair>
    {
        public static SupportsCCLampCertificates LoadList()
        {
            SupportsCCLampCertificates items = new SupportsCCLampCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "3.2" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            return items;
        }
        public static SupportsCCLampCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsCCLampCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsCCLampCertificates>(EngineeringItems.DataPath + @"\Supports\SupportsCCLampCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsCCLampCertificates>(this, EngineeringItems.DataPath + @"\Supports\SupportsCCLampCertificates.xml");
        }

    }
}
