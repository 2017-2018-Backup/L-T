﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeSubTypes LoadList()
        {
            PipeSubTypes items = new PipeSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Seamless" });
            items.Add(new NameCodePair() { Code = "02", Name = "ERW" });
            items.Add(new NameCodePair() { Code = "03", Name = "Precision" });
            items.Add(new NameCodePair() { Code = "04", Name = "Composite" });
            items.Add(new NameCodePair() { Code = "05", Name = "PVC" });
            items.Add(new NameCodePair() { Code = "06", Name = "Copper" });
            items.Add(new NameCodePair() { Code = "07", Name = "Pushfit pipe" });
            return items;
        }
        public static PipeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeSubTypes>(EngineeringItems.DataPath + @"\Pipes\PipeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeSubTypes>(this, EngineeringItems.DataPath + @"\Pipes\PipeSubTypes.xml");
        }

    }
}
