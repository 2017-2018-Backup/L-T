﻿using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;
using VDF = Autodesk.DataManagement.Client.Framework;
using System.IO.Packaging;
using System.Reflection;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties;

namespace KKMItemCodeGenerator
{
    class clsStaticGlobal
    {
        public static string _ItemsProjectCode = "";     
        public static string _ItemCode = "";          
        public static string _BudgetSFI = "";
        public static string _Unit = "";
        public static string _ItemGroup = "";
        public static string _Desc = "";
        public static string _Title = "";
        public static string _ItemexcelPath = @"C:\Item Code Data";
        
        public static ObservableCollection<ProjectCodes> ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();

        public static string BuildFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        public static void ErrHandlerLog(Exception ex)
        {
            try
            {
                string errorFilePath = BuildFilePath + "/ItemCodeGeneratorErrorLog.txt";
                if (!System.IO.File.Exists(errorFilePath))
                {
                    dynamic fs = System.IO.File.Create(errorFilePath);
                    fs.Close();
                    fs.Dispose();
                }
                zipFile(BuildFilePath, "error.txt");

                using (StreamWriter sw = new StreamWriter(errorFilePath, true))
                {

                    try
                    {
                        sw.WriteLine("Log Date & time: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                        sw.WriteLine("Message:" + ex.Message);

                        sw.WriteLine("Type:" + ex.GetType().ToString());
                        if ((ex.StackTrace != null))
                        {
                            sw.WriteLine("Trace: " + ex.StackTrace);
                        }

                        if ((ex.Source != null))
                        {
                            sw.WriteLine("Source: " + ex.Source);
                        }

                        if ((ex.TargetSite != null))
                        {
                            sw.WriteLine("Target: " + ex.TargetSite.ToString());
                        }

                        if ((ex.InnerException != null))
                        {
                            sw.WriteLine("Inner Message:" + ex.InnerException.Message);

                            if ((ex.InnerException.StackTrace != null))
                            {
                                sw.WriteLine("Trace: " + ex.InnerException.StackTrace);
                            }

                            if ((ex.InnerException.Source != null))
                            {
                                sw.WriteLine("Source: " + ex.InnerException.Source);
                            }

                            if ((ex.InnerException.TargetSite != null))
                            {
                                sw.WriteLine("Target: " + ex.InnerException.TargetSite.ToString());
                            }

                        }
                        sw.WriteLine("");
                        sw.WriteLine("");
                    }
                    catch (Exception)
                    {
                        sw.WriteLine("");
                        sw.WriteLine("");
                    }

                    sw.Close();
                }
            }
            catch (Exception)
            {

            }
        }

        public static void zipFile(string errorFolderPath, string errorFileName)
        {
            try
            {
                dynamic mFileName = errorFolderPath + "\\" + errorFileName;
                System.IO.FileInfo info = new System.IO.FileInfo(mFileName);
                string ZipFileName = "Error_" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss").Replace("-", "_").Replace(" ", "_").Replace(":", "_") + ".zip";
                if (info.Length >= 1048576)
                {

                    Package zip = ZipPackage.Open(errorFolderPath + "\\" + ZipFileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

                    //Replace spaces with an underscore (_)
                    string uriFileName = mFileName.Replace(" ", "_");

                    //A Uri always starts with a forward slash "/"
                    string zipUri = string.Concat("/", System.IO.Path.GetFileName(uriFileName));

                    Uri partUri = new Uri(zipUri, UriKind.Relative);
                    string contentType = System.Net.Mime.MediaTypeNames.Application.Zip;

                    //The PackagePart contains the information:
                    //Where to extract the file when it's extracted (partUri)
                    //The type of content stream (MIME type) - (contentType)
                    //The type of compression to use (CompressionOption.Normal)
                    PackagePart pkgPart = zip.CreatePart(partUri, contentType, CompressionOption.Normal);

                    //Read all of the bytes from the file to add to the zip file
                    byte[] bites = System.IO.File.ReadAllBytes(mFileName);

                    //Compress and write the bytes to the zip file
                    pkgPart.GetStream().Write(bites, 0, bites.Length);

                    zip.Close();
                    //Close the zip file

                    System.IO.File.Delete(mFileName);

                    dynamic fs = System.IO.File.Create(mFileName);
                    fs.Close();
                    fs.Dispose();
                }
            }
            catch (Exception)
            {

            }

        }

        public static void GetProjectCodes(Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections.Connection vCon)
        {
            try
            {
                VDF.Vault.Currency.Entities.Folder _rootfolder = vCon.FolderManager.RootFolder;
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = vCon.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.Category.Name.ToUpper() == "PROJECT")
                        {
                            clsStaticGlobal.ProjectCodeItemCollection.Add(new ProjectCodes() { ProjectCodeName = folder.EntityName });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }        

        public static void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception)
            {

                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }        

        public static void DisposeAllObjects()
        {
            try
            {
               
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }
    }
}
