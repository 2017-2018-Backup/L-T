﻿using KKMBuildSpecification;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Connectivity.WebServices;

namespace KKMBuildSpecifications
{
    public partial class frmBuildSpecificationLifecycle : Form
    {
        public SingleBuildSpecificationSummary _objSingleBuildSpecificationSummary;
        public bool IsEditMode = false;

        public frmBuildSpecificationLifecycle()
        {
            InitializeComponent();
        }

        public frmBuildSpecificationLifecycle(ref SingleBuildSpecificationSummary objSingleBuildSpecificationSummary, bool _IsEditMode)
        {
            InitializeComponent();
            _objSingleBuildSpecificationSummary = objSingleBuildSpecificationSummary;
            IsEditMode = _IsEditMode;
        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdProceed_Click(object sender, EventArgs e)
        {
            _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = ((LifecycleStateListItem)cmdPostDeliveryLifecycle.SelectedItem).LifecycleState.DispName;
            _objSingleBuildSpecificationSummary.BuildSpecificationRemark = txtLifeCycleComment.Text;
            try
            {
                File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath });
                if (SingleFile.Length != 0)
                {
                    newFile = SingleFile[0];
                    LfCycDef lcDef = null;
                    LifecycleDefinitionListItem lcDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
                    if (lcDefItem != null)
                        lcDef = lcDefItem.LifecycleDefinition;

                    LifecycleStateListItem lcStateItem = cmdPostDeliveryLifecycle.SelectedItem as LifecycleStateListItem;

                    if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId != lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null && lcStateItem.LifecycleState.Id > 0)
                    {
                        // here we are setting both the lifecycle definition and the state
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleDefinitions(
                            new long[] { newFile.MasterId },
                            new long[] { lcDef.Id }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleBuildSpecificationSummary.BuildSpecificationRemark);

                        newFile = files[0];
                    }
                    else if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId == lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null &&
                        lcStateItem.LifecycleState.Id > 0 &&
                        newFile.FileLfCyc.LfCycStateId != lcStateItem.LifecycleState.Id)
                    {
                        // here the definition is correct but we need to change the lifecycle
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                            new long[] { newFile.MasterId }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleBuildSpecificationSummary.BuildSpecificationRemark);

                        newFile = files[0];
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            this.Close();
        }

        private void GetLifecycles()
        {
            try
            {
                LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
                int index = 1;

                LfCycDef noneDef = new LfCycDef()
                {
                    Id = -1,
                    DispName = "<None>",
                    StateArray = new LfCycState[0]
                };

                m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(noneDef));

                foreach (LfCycDef lcDef in lcDefs)
                {
                    index = m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(lcDef));
                    if ((lcDef.DispName.ToUpper() == "Build Specification") || (lcDef.Name.ToUpper() == "Build Specification") || (lcDef.Name.ToUpper() == "CRAR") || (lcDef.DispName.ToUpper() == "CRAR"))
                    {
                        m_lifecycleDefComboBox.SelectedIndex = index;
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void GetCategories()
        {
            try
            {
                Cat[] categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FILE", true);
                // create a dummy category
                Cat baseCategory = new Cat()
                {
                    Id = -1,
                    Name = "<Base>"
                };

                int index = m_categoryComboBox.Items.Add(new CategoryListItem(baseCategory));
                m_categoryComboBox.SelectedIndex = index;

                if (categories == null)
                    return;

                foreach (Cat category in categories)
                {
                    index = m_categoryComboBox.Items.Add(new CategoryListItem(category));
                    if (category.Name.ToUpper() == "Build Specification")
                    {
                        m_categoryComboBox.SelectedIndex = index;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmBuildSpecificationLifecycle_Load(object sender, EventArgs e)
        {
            try
            {
                GetCategories();
                GetLifecycles();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            try
            {
                if (IsEditMode == true)
                {
                    txtBuildSpecificationCustomerNumber.Text = _objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber;
                    txtLifeCycleComment.Text = _objSingleBuildSpecificationSummary.BuildSpecificationRemark;
                }
                else
                {
                    _objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber = txtBuildSpecificationCustomerNumber.Text;
                    _objSingleBuildSpecificationSummary.BuildSpecificationRemark = txtLifeCycleComment.Text;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmdPostDeliveryLifecycle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void m_lifecycleDefComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LifecycleDefinitionListItem lifecycleDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
            if (lifecycleDefItem == null || lifecycleDefItem.LifecycleDefinition == null)
                return;

            LfCycDef lifecycleDef = lifecycleDefItem.LifecycleDefinition;
            LfCycState[] states = lifecycleDef.StateArray;
            if (states == null)
                return;

            cmdPostDeliveryLifecycle.Items.Clear();
            cmdPostDeliveryLifecycle.Text = String.Empty;

            int index;
            foreach (LfCycState state in states)
            {
                index = cmdPostDeliveryLifecycle.Items.Add(new LifecycleStateListItem(state));
                if ((state.DispName.ToUpper() == _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper()) || (state.Name.ToUpper() == _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper()))
                {
                    cmdPostDeliveryLifecycle.SelectedIndex = index;
                }
            }
        }

        private void cmdPostDeliveryLifecycle_SelectedValueChanged(object sender, EventArgs e)
        {
            //System.Diagnostics.Debugger.Launch();

            LifecycleStateListItem lifecyclStateItem = cmdPostDeliveryLifecycle.SelectedItem as LifecycleStateListItem;

            if (lifecyclStateItem.LifecycleState.DispName.ToUpper() == "RELEASE")
            {
                Dictionary<string, List<string>> unrelesedDocs = clsStaticGlobal.CheckBuildSpecificationAllNotlReleaseModeDoc(_objSingleBuildSpecificationSummary);
                if ((unrelesedDocs.Count > 0) || (_objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity.Trim() == "Work in Progress"))
                {
                    string message = "";
                    foreach (var itemkey in unrelesedDocs)
                    {
                        foreach (var itemvalue in itemkey.Value)
                        {
                            if (message == "")
                            {
                                message = itemkey.Key + " : " + itemvalue;
                            }
                            else
                            {
                                message = message + Environment.NewLine + itemkey.Key + " : " + itemvalue;
                            }
                        }
                    }

                    if (message == "")
                    {
                        System.Windows.Forms.MessageBox.Show("Unable to change state. Ship technical specifcation not in complete state..!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Unable to change state. Listed Document are not in the Release state" + Environment.NewLine + message, "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }                    

                    foreach (LifecycleStateListItem state in cmdPostDeliveryLifecycle.Items)
                    {
                        if ((state.LifecycleState.Descr.ToUpper() == _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper()) || (state.LifecycleState.DispName.ToUpper() == _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper()))
                        {
                            cmdPostDeliveryLifecycle.SelectedItem = state;
                        }
                    }
                }
            }

        }
    }

    public class CategoryListItem
    {
        public Cat Category;

        public CategoryListItem(Cat category)
        {
            this.Category = category;
        }

        public override string ToString()
        {
            return Category.Name;
        }
    }

    public class LifecycleStateListItem
    {
        public LfCycState LifecycleState;

        public LifecycleStateListItem(LfCycState lifecycleState)
        {
            this.LifecycleState = lifecycleState;
        }

        public override string ToString()
        {
            return LifecycleState.DispName;
        }
    }

    public class LifecycleDefinitionListItem
    {
        public LfCycDef LifecycleDefinition;

        public LifecycleDefinitionListItem(LfCycDef lifecycleDefinition)
        {
            this.LifecycleDefinition = lifecycleDefinition;
        }

        public override string ToString()
        {
            return LifecycleDefinition.DispName;
        }
    }

}
