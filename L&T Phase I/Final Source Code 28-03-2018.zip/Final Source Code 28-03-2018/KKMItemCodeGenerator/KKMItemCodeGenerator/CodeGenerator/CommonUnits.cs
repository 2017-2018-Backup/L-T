﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKMItemCodeGenerator.CodeGenerator
{
     [Serializable()]
    public class CommonUnits : ObservableCollection<NameCodePair>
    {

         public static CommonUnits LoadFromXml(string Path)
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CommonUnits>(Path + @"\AllItemUnits.xml");
        }
    }
}
