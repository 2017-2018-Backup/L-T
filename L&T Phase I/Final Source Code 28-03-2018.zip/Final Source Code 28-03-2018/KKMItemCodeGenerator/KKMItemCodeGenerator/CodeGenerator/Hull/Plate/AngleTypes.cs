﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleTypes : ObservableCollection<NameCodePair>
    {
        public static AngleTypes LoadList()
        {
            AngleTypes items = new AngleTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "EQUAL ANGLE" });
            items.Add(new NameCodePair() { Code = "02", Name = "UNEQUAL ANGLE" });
            return items;
        }
        public static AngleTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleTypes>(HullItems.HullDataPath + @"\Angle\AngleTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleTypes>(this, HullItems.HullDataPath + @"\Angle\AngleTypes.xml");
        }
    }
}
