﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsThicknessCollection : ObservableCollection<NameCodePair>
    {
        public static BarsThicknessCollection LoadList()
        {
            BarsThicknessCollection items = new BarsThicknessCollection();
            items.Add(new NameCodePair() { Code = "050", Name = "5" });
            items.Add(new NameCodePair() { Code = "060", Name = "6" });
            items.Add(new NameCodePair() { Code = "070", Name = "7" });
            items.Add(new NameCodePair() { Code = "080", Name = "8" });
            items.Add(new NameCodePair() { Code = "090", Name = "9" });
            items.Add(new NameCodePair() { Code = "100", Name = "10" });
            items.Add(new NameCodePair() { Code = "110", Name = "11" });
            items.Add(new NameCodePair() { Code = "115", Name = "11.5" });
            items.Add(new NameCodePair() { Code = "120", Name = "12" });
            items.Add(new NameCodePair() { Code = "130", Name = "13" });
            items.Add(new NameCodePair() { Code = "140", Name = "14" });
            items.Add(new NameCodePair() { Code = "150", Name = "15" });
            items.Add(new NameCodePair() { Code = "160", Name = "16" });
            items.Add(new NameCodePair() { Code = "170", Name = "17" });
            items.Add(new NameCodePair() { Code = "180", Name = "18" });
            items.Add(new NameCodePair() { Code = "190", Name = "19" });
            items.Add(new NameCodePair() { Code = "200", Name = "20" });
            items.Add(new NameCodePair() { Code = "210", Name = "21" });
            items.Add(new NameCodePair() { Code = "220", Name = "22" });
            items.Add(new NameCodePair() { Code = "230", Name = "23" });
            items.Add(new NameCodePair() { Code = "240", Name = "24" });
            items.Add(new NameCodePair() { Code = "250", Name = "25" });
            return items;
        }

        public static BarsThicknessCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsThicknessCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsThicknessCollection>(HullItems.HullDataPath + @"\Bars\BarsThicknessCollection.xml");
        }
        
        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsThicknessCollection>(this, HullItems.HullDataPath + @"\Bars\BarsThicknessCollection.xml");
        }
    }
}
