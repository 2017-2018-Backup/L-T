﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveCheckSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveCheckSubTypes LoadList()
        {
            ValveCheckSubTypes items = new ValveCheckSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "SWING TYPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "LIFT TYPE" });
            items.Add(new NameCodePair() { Code = "03", Name = "SCREW DOWN NON RETURN" });
            items.Add(new NameCodePair() { Code = "04", Name = "SCREW DOWN NON RETURN - ANGLE TYPE" });
            items.Add(new NameCodePair() { Code = "05", Name = "DUO-CHECK" });
            return items;
        }
        public static ValveCheckSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveCheckSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveCheckSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveCheckSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveCheckSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveCheckSubTypes.xml");
        }

    }
}
