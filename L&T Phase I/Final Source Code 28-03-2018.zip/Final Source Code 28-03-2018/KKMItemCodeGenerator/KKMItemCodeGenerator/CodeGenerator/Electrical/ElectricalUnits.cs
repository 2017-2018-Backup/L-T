﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ElectricalUnits : ObservableCollection<NameCodePair>
    {
        public static ElectricalUnits LoadList()
        {
            ElectricalUnits items = new ElectricalUnits();
            items.Add(new NameCodePair() { Code = "A", Name = "Amperes" });
            items.Add(new NameCodePair() { Code = "C", Name = "Degrees Celcius" });
            items.Add(new NameCodePair() { Code = "F", Name = "Degrees Fahrenheit" });
            items.Add(new NameCodePair() { Code = "K", Name = "Degrees Kelvin" });
            items.Add(new NameCodePair() { Code = "KV", Name = "Kilovolts" });
            items.Add(new NameCodePair() { Code = "KVA", Name = "Kilo volt amperes" });
            items.Add(new NameCodePair() { Code = "KW", Name = "Kilo watts" });
            items.Add(new NameCodePair() { Code = "KWH", Name = "Kilo watt hours" });
            items.Add(new NameCodePair() { Code = "MWH", Name = "Mega Watt Hours" });
            items.Add(new NameCodePair() { Code = "T", Name = "Metric Tonnes" });
            items.Add(new NameCodePair() { Code = "V", Name = "Volts" });
            items.Add(new NameCodePair() { Code = "W", Name = "Watts" });
            items.Add(new NameCodePair() { Code = "cms", Name = "Centimeters" });
            items.Add(new NameCodePair() { Code = "cub", Name = "Cubic Metres" });
            items.Add(new NameCodePair() { Code = "day", Name = "Days" });
            items.Add(new NameCodePair() { Code = "gms", Name = "Grams" });
            items.Add(new NameCodePair() { Code = "hec", Name = "Hectare" });
            items.Add(new NameCodePair() { Code = "hp", Name = "Horse power" });
            items.Add(new NameCodePair() { Code = "hrs", Name = "Hours" });
            items.Add(new NameCodePair() { Code = "kgs", Name = "Kilograms" });
            items.Add(new NameCodePair() { Code = "kms", Name = "Kilometers" });
            items.Add(new NameCodePair() { Code = "ltr", Name = "Liters" });
            items.Add(new NameCodePair() { Code = "mA", Name = "Milliamperes" });
            items.Add(new NameCodePair() { Code = "mW", Name = "Milli watts" });
            items.Add(new NameCodePair() { Code = "mg", Name = "Milligrams" });
            items.Add(new NameCodePair() { Code = "ml", Name = "Milliliters" });
            items.Add(new NameCodePair() { Code = "mm", Name = "Millimeter" });
            items.Add(new NameCodePair() { Code = "mtr", Name = "Meters" });
            items.Add(new NameCodePair() { Code = "mv", Name = "Millivolts" });
            items.Add(new NameCodePair() { Code = "nm", Name = "Nanometer" });
            items.Add(new NameCodePair() { Code = "nos", Name = "Numbers" });
            items.Add(new NameCodePair() { Code = "ohm", Name = "Ohms" });
            items.Add(new NameCodePair() { Code = "scm", Name = "Square Centimeters" });
            items.Add(new NameCodePair() { Code = "sec", Name = "Seconds" });
            items.Add(new NameCodePair() { Code = "set", Name = "Set" });
            items.Add(new NameCodePair() { Code = "skm", Name = "Sqaure Kilometers" });
            items.Add(new NameCodePair() { Code = "sqm", Name = "Square metres" });
            items.Add(new NameCodePair() { Code = "uA", Name = "Micro Amperes" });
            items.Add(new NameCodePair() { Code = "uW", Name = "Micro watts" });
            items.Add(new NameCodePair() { Code = "ug", Name = "Micrograms" });
            items.Add(new NameCodePair() { Code = "um", Name = "Micrometer" });
            items.Add(new NameCodePair() { Code = "uml", Name = "Microliters" });
            items.Add(new NameCodePair() { Code = "uv", Name = "Microvolts" });
            items.Add(new NameCodePair() { Code = "N", Name = "Newton" });
            items.Add(new NameCodePair() { Code = "kN", Name = "Kilo Newton" });
            items.Add(new NameCodePair() { Code = "J", Name = "Joule" });
            items.Add(new NameCodePair() { Code = "Cal", Name = "calorie" });
            items.Add(new NameCodePair() { Code = "kJ", Name = "Kilo Joule" });
            items.Add(new NameCodePair() { Code = "Lux", Name = "Lux" });
            items.Add(new NameCodePair() { Code = "P", Name = "Pounds" });
            items.Add(new NameCodePair() { Code = "kCal/hr", Name = "Kilo Calorie/Hr" });
            items.Add(new NameCodePair() { Code = "bar", Name = "Bar" });
            items.Add(new NameCodePair() { Code = "Mpa", Name = "Mega Pascal" });
            items.Add(new NameCodePair() { Code = "kPa", Name = "Kilo pascal" });
            items.Add(new NameCodePair() { Code = "mbar", Name = "Milli Bar" });
            items.Add(new NameCodePair() { Code = "Pascals", Name = "Pascal" });
            items.Add(new NameCodePair() { Code = "Psi", Name = "Pounds/Sq.Inch" });
            items.Add(new NameCodePair() { Code = "kn", Name = "Knots" });
            items.Add(new NameCodePair() { Code = "kmph", Name = "Kilometer/Hour" });
            items.Add(new NameCodePair() { Code = "mps", Name = "Meter/Sec" });
            items.Add(new NameCodePair() { Code = "Nau.miles", Name = "Nautical Miles" });
            items.Add(new NameCodePair() { Code = "deg", Name = "Degrees" });
            items.Add(new NameCodePair() { Code = "rad", Name = "Radians" });
            items.Add(new NameCodePair() { Code = "Miles", Name = "Miles" });
            items.Add(new NameCodePair() { Code = "inch", Name = "Inch" });
            items.Add(new NameCodePair() { Code = "feet", Name = "Feet" });
            items.Add(new NameCodePair() { Code = "kg/cu.m", Name = "Kilograms/Cubic Meter" });
            items.Add(new NameCodePair() { Code = "P/cu.in", Name = "Pounds/Cubic Inches" });
            items.Add(new NameCodePair() { Code = "Cu.m/Hr", Name = "Cubic Meters/Hour" });
            items.Add(new NameCodePair() { Code = "Cu.Ft/Hr", Name = "Cubic Feet/Hour" });
            items.Add(new NameCodePair() { Code = "Gal", Name = "Gallons" });
            items.Add(new NameCodePair() { Code = "Gal/s", Name = "Gallons/Second" });
            items.Add(new NameCodePair() { Code = "TR", Name = "Tons of Refrigeration" });
            items.Add(new NameCodePair() { Code = "Cd", Name = "Candela" });
            items.Add(new NameCodePair() { Code = "MW", Name = "Mega watts" });
            items.Add(new NameCodePair() { Code = "bhp", Name = "Brake Horse power" });
            return items;
        }
        public static ElectricalUnits LoadFromExcel(String path)
        {
            return null;
        }

        public static ElectricalUnits LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ElectricalUnits>(ElectricalItems.DataPath + @"\ElectricalUnits.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ElectricalUnits>(this, ElectricalItems.DataPath + @"\ElectricalUnits.xml");
        }
    }
}
