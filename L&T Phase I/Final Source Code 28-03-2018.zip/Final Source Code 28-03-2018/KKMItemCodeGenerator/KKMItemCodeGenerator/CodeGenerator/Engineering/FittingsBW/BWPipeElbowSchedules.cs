﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWPipeElbowSchedules : ObservableCollection<NameCodePair>
    {
        public static BWPipeElbowSchedules LoadList()
        {
            BWPipeElbowSchedules items = new BWPipeElbowSchedules();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "SCH 10" });
            items.Add(new NameCodePair() { Code = "02", Name = "SCH 20" });
            items.Add(new NameCodePair() { Code = "03", Name = "SCH 30" });
            items.Add(new NameCodePair() { Code = "04", Name = "SCH STD" });
            items.Add(new NameCodePair() { Code = "05", Name = "SCH 40" });
            items.Add(new NameCodePair() { Code = "06", Name = "SCH 60" });
            items.Add(new NameCodePair() { Code = "07", Name = "SCH XS" });
            items.Add(new NameCodePair() { Code = "08", Name = "SCH 80" });
            items.Add(new NameCodePair() { Code = "09", Name = "SCH 100" });
            items.Add(new NameCodePair() { Code = "10", Name = "SCH 120" });
            items.Add(new NameCodePair() { Code = "11", Name = "SCH 140" });
            items.Add(new NameCodePair() { Code = "12", Name = "SCH 160" });
            items.Add(new NameCodePair() { Code = "13", Name = "SCH XXS" });
            items.Add(new NameCodePair() { Code = "14", Name = "PN 6" });
            items.Add(new NameCodePair() { Code = "15", Name = "PN 10" });
            items.Add(new NameCodePair() { Code = "16", Name = "PN 16" });
            items.Add(new NameCodePair() { Code = "17", Name = "5.4 Thk" });
            return items;
        }
        public static BWPipeElbowSchedules LoadFromExcel(String path)
        {
            return null;
        }

        public static BWPipeElbowSchedules LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWPipeElbowSchedules>(EngineeringItems.DataPath + @"\FittingsBW\BWPipeElbowSchedules.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWPipeElbowSchedules>(this, EngineeringItems.DataPath + @"\FittingsBW\BWPipeElbowSchedules.xml");
        }

    }
}
