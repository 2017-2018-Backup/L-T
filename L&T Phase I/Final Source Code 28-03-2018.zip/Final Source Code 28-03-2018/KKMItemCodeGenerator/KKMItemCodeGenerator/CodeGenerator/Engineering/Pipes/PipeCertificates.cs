﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeCertificates : ObservableCollection<NameCodePair>
    {
        public static PipeCertificates LoadList()
        {
            PipeCertificates items = new PipeCertificates();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Class I" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            items.Add(new NameCodePair() { Code = "E", Name = "Class B" });
            return items;
        }
        public static PipeCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeCertificates>(EngineeringItems.DataPath + @"\Pipes\PipeCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeCertificates>(this, EngineeringItems.DataPath + @"\Pipes\PipeCertificates.xml");
        }

    }
}
