﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PlateTypes : ObservableCollection<NameCodePair>
    {
        public static PlateTypes LoadList()
        {
            PlateTypes items = new PlateTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "NORMAL" });
            items.Add(new NameCodePair() { Code = "02", Name = "CHEQUERED" });
            items.Add(new NameCodePair() { Code = "03", Name = "BLAST AND PRIME" });
            return items;
        }
        public static PlateTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PlateTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PlateTypes>(HullItems.HullDataPath + @"\Plate\PlateTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PlateTypes>(this, HullItems.HullDataPath + @"\Plate\PlateTypes.xml");
        }
    }
}
