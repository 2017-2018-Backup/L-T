﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeMainTypes : ObservableCollection<NameCodePair>
    {
        public static PipeMainTypes LoadList()
        {
            PipeMainTypes items = new PipeMainTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "PIPE (NB/SCH)" });
            items.Add(new NameCodePair() { Code = "02", Name = "TUBE (OD/THK)" });
            return items;
        }
        public static PipeMainTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeMainTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeMainTypes>(EngineeringItems.DataPath + @"\Pipes\PipeMainTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeMainTypes>(this, EngineeringItems.DataPath + @"\Pipes\PipeMainTypes.xml");
        }

    }
}
