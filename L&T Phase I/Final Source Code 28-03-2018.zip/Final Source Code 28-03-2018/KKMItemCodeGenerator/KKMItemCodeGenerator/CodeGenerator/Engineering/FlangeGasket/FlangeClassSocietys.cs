﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeClassSocietys : ObservableCollection<NameCodePair>
    {
        public static FlangeClassSocietys LoadList()
        {
            FlangeClassSocietys items = new FlangeClassSocietys();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Non IACS" });
            items.Add(new NameCodePair() { Code = "B", Name = "IACS" });
            return items;
        }
        public static FlangeClassSocietys LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeClassSocietys LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeClassSocietys>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeClassSocietys.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeClassSocietys>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeClassSocietys.xml");
        }

    }
}
