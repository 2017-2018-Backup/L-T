﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWElbowSubTypes : ObservableCollection<NameCodePair>
    {
        public static BWElbowSubTypes LoadList()
        {
            BWElbowSubTypes items = new BWElbowSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "……….." });
            items.Add(new NameCodePair() { Code = "01", Name = "1.5D 90˚" });
            items.Add(new NameCodePair() { Code = "02", Name = "1.5D 45˚" });
            items.Add(new NameCodePair() { Code = "03", Name = "1.5D 30˚" });
            items.Add(new NameCodePair() { Code = "04", Name = "1.5D 180˚" });
            items.Add(new NameCodePair() { Code = "05", Name = "1.5D 100˚" });
            items.Add(new NameCodePair() { Code = "06", Name = "1.5D 22.5˚" });
            items.Add(new NameCodePair() { Code = "07", Name = "1.5D 10˚" });
            items.Add(new NameCodePair() { Code = "08", Name = "1D 90˚" });
            items.Add(new NameCodePair() { Code = "09", Name = "1D 45˚" });
            items.Add(new NameCodePair() { Code = "10", Name = "1D 30˚" });
            items.Add(new NameCodePair() { Code = "11", Name = "1D 180˚" });
            items.Add(new NameCodePair() { Code = "12", Name = "1D 100˚" });
            items.Add(new NameCodePair() { Code = "13", Name = "1D 22.5˚" });
            items.Add(new NameCodePair() { Code = "14", Name = "1D 10˚" });
            items.Add(new NameCodePair() { Code = "15", Name = "2D 90˚" });
            items.Add(new NameCodePair() { Code = "16", Name = "3D 90˚" });
            items.Add(new NameCodePair() { Code = "17", Name = "5D 90˚" });
            items.Add(new NameCodePair() { Code = "18", Name = "2D 45˚" });
            items.Add(new NameCodePair() { Code = "19", Name = "3D 45˚" });
            items.Add(new NameCodePair() { Code = "20", Name = "5D 45˚" });
            return items;
        }
        public static BWElbowSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BWElbowSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWElbowSubTypes>(EngineeringItems.DataPath + @"\FittingsBW\BWElbowSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWElbowSubTypes>(this, EngineeringItems.DataPath + @"\FittingsBW\BWElbowSubTypes.xml");
        }

    }
}
