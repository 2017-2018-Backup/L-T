﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeStandards : ObservableCollection<NameCodePair>
    {
        public static PipeStandards LoadList()
        {
            PipeStandards items = new PipeStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ANSI B 36.10" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANSI B 36.19" });
            items.Add(new NameCodePair() { Code = "03", Name = "JIS G-3447" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 2458" });
            items.Add(new NameCodePair() { Code = "05", Name = "EN 10027-2" });
            items.Add(new NameCodePair() { Code = "06", Name = "DIN 2353" });
            items.Add(new NameCodePair() { Code = "07", Name = "DIN-2391" });
            items.Add(new NameCodePair() { Code = "08", Name = "IS-1239" });
            items.Add(new NameCodePair() { Code = "09", Name = "DIN 86019" });
            items.Add(new NameCodePair() { Code = "10", Name = "EN 10216" });
            items.Add(new NameCodePair() { Code = "11", Name = "BS 2871" });
            items.Add(new NameCodePair() { Code = "12", Name = "DIN 86018" });
            items.Add(new NameCodePair() { Code = "13", Name = "LR 3.2" });
            items.Add(new NameCodePair() { Code = "14", Name = "NES 780 Part III" });
            items.Add(new NameCodePair() { Code = "15", Name = "EN 10217-1" });
            items.Add(new NameCodePair() { Code = "16", Name = "EN 10305-4" });
            items.Add(new NameCodePair() { Code = "17", Name = "ASME B 429" });
            items.Add(new NameCodePair() { Code = "18", Name = "ASME B88" });
            return items;
        }
        public static PipeStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeStandards>(EngineeringItems.DataPath + @"\Pipes\PipeStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeStandards>(this, EngineeringItems.DataPath + @"\Pipes\PipeStandards.xml");
        }

    }
}
