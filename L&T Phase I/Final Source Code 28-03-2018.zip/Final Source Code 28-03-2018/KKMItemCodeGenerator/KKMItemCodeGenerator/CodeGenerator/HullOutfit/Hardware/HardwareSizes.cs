﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareSizes : ObservableCollection<NameCodePair>
    {
        public static HardwareSizes LoadList()
        {
            HardwareSizes items = new HardwareSizes();
            items.Add(new NameCodePair() { Code = "M003", Name = "M3" });
            items.Add(new NameCodePair() { Code = "M004", Name = "M4" });
            items.Add(new NameCodePair() { Code = "M005", Name = "M5" });
            items.Add(new NameCodePair() { Code = "M006", Name = "M6" });
            items.Add(new NameCodePair() { Code = "M008", Name = "M8" });
            items.Add(new NameCodePair() { Code = "M010", Name = "M10" });
            items.Add(new NameCodePair() { Code = "M012", Name = "M12" });
            items.Add(new NameCodePair() { Code = "M014", Name = "M14" });
            items.Add(new NameCodePair() { Code = "M016", Name = "M16" });
            items.Add(new NameCodePair() { Code = "M018", Name = "M18" });
            items.Add(new NameCodePair() { Code = "M020", Name = "M20" });
            items.Add(new NameCodePair() { Code = "M022", Name = "M22" });
            items.Add(new NameCodePair() { Code = "M024", Name = "M24" });
            items.Add(new NameCodePair() { Code = "M025", Name = "M25" });
            items.Add(new NameCodePair() { Code = "M027", Name = "M27" });
            items.Add(new NameCodePair() { Code = "M030", Name = "M30" });
            items.Add(new NameCodePair() { Code = "M045", Name = "M45" });
            items.Add(new NameCodePair() { Code = "M036", Name = "M36" });
            items.Add(new NameCodePair() { Code = "M048", Name = "M48" });
            items.Add(new NameCodePair() { Code = "M033", Name = "M33" });

            return items;
        }
        public static HardwareSizes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareSizes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareSizes>(HullOutfitItems.DataPath + @"\Hardware\HardwareSizes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareSizes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareSizes.xml");
        }
    }
}
