﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingSize2 : ObservableCollection<NameCodePair>
    {
        public static PipeFittingSize2 LoadList()
        {
            PipeFittingSize2 items = new PipeFittingSize2();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "1/8\" (6NB)" });
            items.Add(new NameCodePair() { Code = "02", Name = "1/4\" (8NB)" });
            items.Add(new NameCodePair() { Code = "03", Name = "3/8\" (10NB)" });
            items.Add(new NameCodePair() { Code = "04", Name = "1/2\" (15NB)" });
            items.Add(new NameCodePair() { Code = "05", Name = "3/4\" (20NB)" });
            items.Add(new NameCodePair() { Code = "06", Name = "1\" (25NB)" });
            items.Add(new NameCodePair() { Code = "07", Name = "1-1/4\" (32NB)" });
            items.Add(new NameCodePair() { Code = "08", Name = "1-1/2\" (40NB)" });
            items.Add(new NameCodePair() { Code = "09", Name = "2\" (50NB)" });
            items.Add(new NameCodePair() { Code = "10", Name = "2-1/2\" (65NB)" });
            items.Add(new NameCodePair() { Code = "11", Name = "3\" (80NB)" });
            items.Add(new NameCodePair() { Code = "12", Name = "4\" (100NB)" });
            items.Add(new NameCodePair() { Code = "13", Name = "5\" (125NB)" });
            items.Add(new NameCodePair() { Code = "14", Name = "6 OD" });
            items.Add(new NameCodePair() { Code = "15", Name = "15 OD" });
            items.Add(new NameCodePair() { Code = "16", Name = "22 OD" });
            items.Add(new NameCodePair() { Code = "17", Name = "8 OD" });
            items.Add(new NameCodePair() { Code = "18", Name = "10 OD" });
            items.Add(new NameCodePair() { Code = "19", Name = "12 OD" });
            items.Add(new NameCodePair() { Code = "20", Name = "16 OD" });
            items.Add(new NameCodePair() { Code = "21", Name = "18 OD" });
            items.Add(new NameCodePair() { Code = "22", Name = "20 OD" });
            items.Add(new NameCodePair() { Code = "23", Name = "25 OD" });
            items.Add(new NameCodePair() { Code = "24", Name = "28 OD" });
            items.Add(new NameCodePair() { Code = "25", Name = "30 OD" });
            items.Add(new NameCodePair() { Code = "26", Name = "35 OD" });
            items.Add(new NameCodePair() { Code = "27", Name = "38 OD" });
            items.Add(new NameCodePair() { Code = "28", Name = "42 OD" });
            items.Add(new NameCodePair() { Code = "29", Name = "55 OD" });
            items.Add(new NameCodePair() { Code = "30", Name = "50 OD" });
            items.Add(new NameCodePair() { Code = "31", Name = "6\" (150NB)" });
            items.Add(new NameCodePair() { Code = "32", Name = "60 OD" });
            items.Add(new NameCodePair() { Code = "33", Name = "80 OD" });
            items.Add(new NameCodePair() { Code = "34", Name = "65 OD" });
            items.Add(new NameCodePair() { Code = "35", Name = "14 OD" });
            items.Add(new NameCodePair() { Code = "36", Name = "75 OD" });
            items.Add(new NameCodePair() { Code = "37", Name = "40 OD" });
            items.Add(new NameCodePair() { Code = "38", Name = "200 NB" });
            items.Add(new NameCodePair() { Code = "39", Name = "250 NB" });
            items.Add(new NameCodePair() { Code = "40", Name = "300 NB" });
            items.Add(new NameCodePair() { Code = "41", Name = "350 NB" });
            items.Add(new NameCodePair() { Code = "42", Name = "400 NB" });
            items.Add(new NameCodePair() { Code = "43", Name = "450 NB" });
            items.Add(new NameCodePair() { Code = "44", Name = "500 NB" });
            items.Add(new NameCodePair() { Code = "45", Name = "550 NB" });
            items.Add(new NameCodePair() { Code = "46", Name = "600 NB" });
            items.Add(new NameCodePair() { Code = "47", Name = "650 NB" });
            items.Add(new NameCodePair() { Code = "48", Name = "700 NB" });
            items.Add(new NameCodePair() { Code = "49", Name = "750 NB" });
            items.Add(new NameCodePair() { Code = "50", Name = "800 NB" });
            items.Add(new NameCodePair() { Code = "51", Name = "850 NB" });
            items.Add(new NameCodePair() { Code = "52", Name = "900 NB" });
            items.Add(new NameCodePair() { Code = "53", Name = "950 NB" });
            items.Add(new NameCodePair() { Code = "54", Name = "1000 NB" });
            items.Add(new NameCodePair() { Code = "55", Name = "1050 NB" });
            items.Add(new NameCodePair() { Code = "56", Name = "1100 NB" });
            items.Add(new NameCodePair() { Code = "57", Name = "1150 NB" });
            items.Add(new NameCodePair() { Code = "58", Name = "1200 NB" });
            return items;
        }
        public static PipeFittingSize2 LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingSize2 LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingSize2>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSize2.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingSize2>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSize2.xml");
        }

    }
}
