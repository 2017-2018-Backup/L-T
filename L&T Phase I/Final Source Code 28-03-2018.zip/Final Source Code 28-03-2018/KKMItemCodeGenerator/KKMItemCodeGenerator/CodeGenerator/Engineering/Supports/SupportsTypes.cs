﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsTypes : ObservableCollection<NameCodePair>
    {
        public static SupportsTypes LoadList()
        {
            SupportsTypes items = new SupportsTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "C-CLAMP" });
            items.Add(new NameCodePair() { Code = "02", Name = "U BOLT" });
            items.Add(new NameCodePair() { Code = "03", Name = "HYD CLAMP" });
            items.Add(new NameCodePair() { Code = "04", Name = "Vibration Mounts - BASIC SILENT" });
            items.Add(new NameCodePair() { Code = "05", Name = "Pipe Clamp (O-Type)" });
            return items;
        }
        public static SupportsTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsTypes>(EngineeringItems.DataPath + @"\Supports\SupportsTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsTypes>(this, EngineeringItems.DataPath + @"\Supports\SupportsTypes.xml");
        }

    }
}
