﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Diagnostics;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;

namespace KKMEnquiryProjectStructure
{
    public partial class frmKKMCreateNewEnquiryProject : Form
    {
        VDF.Vault.Currency.Entities.Folder rootfolder;
        ProjectProperties objProjectProperties;

        Cat _ProjectCategory = null;

        Cat _FolderCategory = null;

        public frmKKMCreateNewEnquiryProject()
        {
            InitializeComponent();

            rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdCreateProject_Click(object sender, EventArgs e)
        {
            if ((cmbProjectNumber.SelectedItem != null) && (txtProjectNumber.Text.Trim() != ""))
            {
                string _ProjectNumber = cmbProjectNumber.SelectedItem.ToString() + txtProjectNumber.Text;
                if (IsProjectNumberExist(_ProjectNumber) == true)
                {
                    MessageBox.Show("Project Number : " + _ProjectNumber + " already exist.", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            objProjectProperties = new ProjectProperties();

            if (IsValidateField() == true)
            {
                try
                {
                    objProjectProperties = AssignToObject(objProjectProperties);

                    if (CreateProjectStructure())
                    {
                        clsStaticGlobal.vaultConnectionContext.Context.ForceRefresh = true;
                        MessageBox.Show("New Enquiry created sucessfully..!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Please provide sufficient access rights for user to create enquiry project structure..!", "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                   
                    this.Close();
                }
                catch (Exception)
                {

                }

            }
        }

        private bool SetPermissionToFolder(Folder folder)
        {
            try
            {
                VDF.Vault.Currency.Entities.Folder _folder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, folder);

                ACE[] aces;

                Group[] groups = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllGroups();

                List<Group> BDGgroups = new List<Group> { };

                foreach (Group item in groups)
                {
                    if (item.Name.ToUpper().StartsWith("BDG"))
                    {
                        BDGgroups.Add(item);
                    }
                }

                if (BDGgroups.Count > 0)
                {
                    aces = new ACE[BDGgroups.Count];
                    int index = 0;

                    foreach (Group group in BDGgroups)
                    {
                        // Could use this to get existing
                        // permissions on the file
                        // ACL[] acls = m_serviceManager.
                        //   SecurityService.GetACLsByEntityIds
                        //(new long[] { myFiles[0].MasterId });
                        // ACE[] aces = acls[0].ACEArray;

                        ACE ace = new ACE();


                        ace.UserGrpId = group.Id;

                        AccessPermis readAccessPermis = new AccessPermis();
                        readAccessPermis.Id = 1;
                        readAccessPermis.Val = true;

                        AccessPermis writeAccessPermis = new AccessPermis();
                        writeAccessPermis.Id = 2;
                        writeAccessPermis.Val = true;

                        //AccessPermis deleteAccessPermis = new AccessPermis();
                        //deleteAccessPermis.Id = 3;
                        //deleteAccessPermis.Val = true;

                        ace.PermisArray = new AccessPermis[]
                            {
                                readAccessPermis,
                                writeAccessPermis
                                //deleteAccessPermis
                            };
                        aces[index] = ace;
                        index += 1;
                    }

                    ACL myAcl = clsStaticGlobal.connection.WebServiceManager.SecurityService.AddSystemACL(aces);
                    clsStaticGlobal.connection.WebServiceManager.SecurityService.SetSystemACLs(new long[] { _folder.EntityMasterId }, myAcl.Id, SysAclBeh.Override);

                    return true;
                }
            }
            catch (Exception)
            {

                return false;
            }

            return false;

        }

        private bool CreateProjectStructure()
        {
            bool isSucess = false;
            try
            {
                Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);

                foreach (Cat _cat in _Categories)
                {
                    if (_cat.Name.Trim().ToUpper() == "ENQUIRY")
                    {
                        _ProjectCategory = _cat;
                    }
                    if (_cat.Name.Trim().ToUpper() == "FOLDER")
                    {
                        _FolderCategory = _cat;
                    }
                }

                Folder _ProjectFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(objProjectProperties.ProjectNumber, rootfolder.Id, false, _ProjectCategory.Id);
                UpdateMainFolderProjectProperties(_ProjectFolder);

                Folder firstlevelCustomerSpecification = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Customer Specification", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelCustomerSpecification);

                Folder firstlevelDesignInputs = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Design Inputs", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelDesignInputs);

                Folder secondlevelDesignInputs_Hull = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Hull", firstlevelDesignInputs.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelDesignInputs_Hull);
                Folder secondlevelDesignInputs_HullOutfit = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Hull Outfit", firstlevelDesignInputs.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelDesignInputs_HullOutfit);
                Folder secondlevelDesignInputs_Engineering = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Engineering", firstlevelDesignInputs.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelDesignInputs_Engineering);
                Folder secondlevelDesignInputs_Electrical = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Electrical", firstlevelDesignInputs.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelDesignInputs_Electrical);
                Folder secondlevelDesignInputs_TechnicalBID = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Technical BID", firstlevelDesignInputs.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelDesignInputs_TechnicalBID);

                Folder firstlevelPMGInputs = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("PMG Inputs", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelPMGInputs);
                Folder firstlevelBDGInputs = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("BDG Inputs", _ProjectFolder.Id, false, _FolderCategory.Id);
                SetPermissionToFolder(firstlevelBDGInputs);
                UpdateSubFolderProperties(firstlevelBDGInputs);
                Folder firstlevelMinutesofMeetings = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Minutes of Meetings", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelMinutesofMeetings);
                Folder firstlevelGeneralDocuments = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("General Documents", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelGeneralDocuments);
                Folder firstlevelTEC = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("TEC", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelTEC);
                Folder firstlevelOthers = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Others", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelOthers);
                Folder firstlevelPresentationReviews = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Presentation or Reviews", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelPresentationReviews);

                isSucess = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: creating folder structure " + Environment.NewLine + ex.Message, "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return isSucess;

        }

        private bool UpdateMainFolderProjectProperties(Folder _ProjectFolder)
        {
            bool _Sucess = true;

            try
            {
                List<PropInstParam> propInstParams = new List<PropInstParam>();
                PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

                if (_ProjectFolder.Cat.CatName.ToUpper() == "ENQUIRY")
                {
                    PropInst[] source = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FLDR", new long[] { _ProjectFolder.Id });

                    foreach (PropDef def in clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FLDR"))
                    {
                        if (def.IsSys == false & def.IsAct == true)
                        {
                            if (def.DispName == "Policy")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Policy;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Template")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Template;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Enquiry Receipt Date")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.EnquiryReceiptDate.Date;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Customer")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Customer;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Customer Representative")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CustomerRepresentative;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Customer Enquiry No")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CustomerEnquireyNumber;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Category of Enquiry")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CategoryOfEnquiry;
                                propInstParams.Add(propInst);
                            }
                        }
                    }
                }

                PropInstParamArray propInstParamsArray = new PropInstParamArray();
                propInstParamsArray.Items = propInstParams.ToArray();
                propInstParamsArrays[0] = propInstParamsArray;
                clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFolderProperties(new long[] { _ProjectFolder.Id }, propInstParamsArrays);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: updating folder properties " + Environment.NewLine + ex.Message, "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return _Sucess;
        }

        private bool UpdateSubFolderProperties(Folder _subFolder)
        {
            bool _Sucess = true;

            try
            {
                List<PropInstParam> propInstParams = new List<PropInstParam>();
                PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

                if (_subFolder.Cat.CatName.ToUpper() == "FOLDER")
                {
                    PropInst[] source = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FLDR", new long[] { _subFolder.Id });

                    foreach (PropDef def in clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FLDR"))
                    {
                        if (def.IsSys == false & def.IsAct == true)
                        {
                            if (def.DispName == "Project Title")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ProjectNumber;
                                propInstParams.Add(propInst);
                            }
                        }
                    }
                }

                PropInstParamArray propInstParamsArray = new PropInstParamArray();
                propInstParamsArray.Items = propInstParams.ToArray();
                propInstParamsArrays[0] = propInstParamsArray;
                clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFolderProperties(new long[] { _subFolder.Id }, propInstParamsArrays);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: updating folder properties " + Environment.NewLine + ex.Message, "Create New Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return _Sucess;
        }

        private bool IsProjectNumberExist(string _ProjectNumber)
        {
            bool _IsExist = false;
            try
            {
                // check for any sub Folders.
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.EntityName.Trim() == _ProjectNumber)
                        {
                            _IsExist = true;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            return _IsExist;
        }

        private bool IsValidateField()
        {
            bool isvalid = true;

            if (cmbProjectNumber.SelectedItem == null)
            {
                errorProvider1.SetError(cmbProjectNumber, "Select Enquiry Project Code");
                isvalid = false;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (txtProjectNumber.Text.Trim() == "")
            {
                errorProvider2.SetError(txtProjectNumber, "Enter Enquiry Project Number");
                isvalid = false;
            }
            else
            {
                errorProvider2.Clear();
            }

            if (txtPolicy.Text.Trim() == "")
            {
                errorProvider3.SetError(txtPolicy, "Enter Value For Policy");
                isvalid = false;
            }
            else
            {
                errorProvider3.Clear();
            }

            if (txtTemplate.Text.Trim() == "")
            {
                errorProvider4.SetError(txtTemplate, "Enter Value For Template");
                isvalid = false;
            }
            else
            {
                errorProvider4.Clear();
            }

            if (dtpEnquiryReceiptDate.Text.Trim() == "")
            {
                errorProvider5.SetError(dtpEnquiryReceiptDate, "Select Enquiry Receipt Date");
                isvalid = false;
            }
            else
            {
                errorProvider5.Clear();
            }

            if (cmbCustomer.SelectedItem == null)
            {
                errorProvider6.SetError(cmbCustomer, "Select Customer");
                isvalid = false;
            }
            else
            {
                errorProvider6.Clear();
            }

            if (txtCustomerRepresentative.Text.Trim() == "")
            {
                errorProvider7.SetError(txtCustomerRepresentative, "Enter Value For Customer Representative");
                isvalid = false;
            }
            else
            {
                errorProvider7.Clear();
            }

            if (cmbCategoryofEnquiry.SelectedItem == null)
            {
                errorProvider8.SetError(cmbCategoryofEnquiry, "Select Category of Enquiry");
                isvalid = false;
            }
            else
            {
                errorProvider8.Clear();
            }

            return isvalid;
        }

        private ProjectProperties AssignToObject(ProjectProperties _objProjectProperties)
        {
            _objProjectProperties.ProjectNumber = cmbProjectNumber.SelectedItem.ToString() + txtProjectNumber.Text;
            _objProjectProperties.Policy = txtPolicy.Text;
            _objProjectProperties.Template = txtTemplate.Text;
            _objProjectProperties.EnquiryReceiptDate = dtpEnquiryReceiptDate.Value;
            _objProjectProperties.Customer = cmbCustomer.SelectedItem.ToString();
            _objProjectProperties.CustomerRepresentative = txtCustomerRepresentative.Text;
            _objProjectProperties.CustomerEnquireyNumber = txtCustomerEnquiryNumber.Text;
            _objProjectProperties.CategoryOfEnquiry = cmbCategoryofEnquiry.SelectedItem.ToString();

            return _objProjectProperties;
        }

        private void txtProjectNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void frmKKMCreateNewEnquiryProject_Load(object sender, EventArgs e)
        {
            if (clsStaticGlobal.connection.UserName.ToUpper().Contains("ADMINISTRATOR"))
            {
                btnNewCustomer.Enabled = true;
            }           

            //if ((clsStaticGlobal.connection.UserName.ToUpper().Contains("ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "SECURITY ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "PROJECT ADMINISTRATOR")))
            //{
            //    btnNewCustomer.Enabled = true;
            //}
            //else
            //{
            //    //System.Diagnostics.Debugger.Launch();
            //    bool isValidRole = false;
            //    UserInfo userInfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
            //    //Role[] rolesbyUser= clsStaticGlobal.connection.WebServiceManager.AdminService.GetRolesByUserId(clsStaticGlobal.connection.UserID);
            //    foreach (Role role in userInfo.Roles)
            //    {
            //        if ((role.Name.ToUpper().Trim() == "ADMINISTRATOR") || (role.Name.ToUpper().Trim() == "PROJECT ADMINISTRATOR") || (role.Name.ToUpper().Trim() == "SECURITY ADMINISTRATOR"))
            //        {
            //            isValidRole = true;
            //        }
            //    }

            //    bool isValidGroup = false;
            //    Group[] groups = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllGroups();
            //    List<Group> groupsBDG = new List<Group>();
            //    foreach (Group item in groups)
            //    {
            //        if (item.Name.StartsWith("BDG"))
            //        {
            //            groupsBDG.Add(item);
            //        }
            //    }

            //    foreach (Group item in groupsBDG)
            //    {
            //        User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetMemberUsersByGroupId(item.Id);
            //        foreach (User user in users)
            //        {
            //            if (user.Id == clsStaticGlobal.connection.UserID)
            //            {
            //                isValidGroup = true;
            //                break;
            //            }
            //        }
            //    }

            //    if ((isValidRole == true) && (isValidGroup == true))
            //    {
            //        btnNewCustomer.Enabled = true;
            //    }
            //}

            //if ((clsStaticGlobal.connection.UserName.ToUpper().Contains("ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "SECURITY ADMINISTRATOR") || (clsStaticGlobal.connection.UserName.ToUpper() == "PROJECT ADMINISTRATOR")))
            //{
            //    btnNewCustomer.Enabled = true;
            //}

            clsStaticGlobal.GetOrCreateFolder();

            try
            {
                VDF.Vault.Currency.Entities.FileIteration fileiteration = null;
                Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions;
                try
                {
                    _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { clsStaticGlobal.VaultCustomerFilePath });

                    if (_LatestFileswithVersions.Length != 0)
                    {
                        if (_LatestFileswithVersions[0].Id != -1)
                        {
                            fileiteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, _LatestFileswithVersions[0]);
                        }
                    }

                    if (fileiteration != null)
                    {
                        if (clsStaticGlobal.DownlodCustomerFile(fileiteration) == true)
                        {
                            Customer objcust = clsStaticGlobal.ReadCustomerData(clsStaticGlobal.LocalXMLCustomerFolderPath + "\\" + clsStaticGlobal.CustomerFilename);

                            try
                            {
                                cmbCustomer.Items.Clear();
                            }
                            catch (Exception)
                            {

                            }

                            foreach (string item in objcust.CustomerName)
                            {
                                cmbCustomer.Items.Add(item);
                            }
                        }
                    }

                }
                catch (Exception)
                {

                }

            }
            catch (Exception)
            {

            }
        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {

            frmCustomer frmCust = new frmCustomer();

            frmCust.ShowDialog();

            if (frmCust.dialogres == DialogResult.OK)
            {
                try
                {
                    cmbCustomer.Items.Clear();
                }
                catch (Exception)
                {

                }

                foreach (string item in frmCust.objcust.CustomerName)
                {
                    cmbCustomer.Items.Add(item);
                }
            }

        }
    }
}
