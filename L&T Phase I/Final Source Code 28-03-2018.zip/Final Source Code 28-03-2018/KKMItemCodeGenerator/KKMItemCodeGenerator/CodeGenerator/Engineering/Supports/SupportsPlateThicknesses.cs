﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsPlateThicknesses : ObservableCollection<NameCodePair>
    {
        public static SupportsPlateThicknesses LoadList()
        {
            SupportsPlateThicknesses items = new SupportsPlateThicknesses();
            items.Add(new NameCodePair() { Code = "01", Name = "2mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "2.5mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "3mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "3.5mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "4mm" });
            return items;
        }
        public static SupportsPlateThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsPlateThicknesses LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsPlateThicknesses>(EngineeringItems.DataPath + @"\Supports\SupportsPlateThicknesses.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsPlateThicknesses>(this, EngineeringItems.DataPath + @"\Supports\SupportsPlateThicknesses.xml");
        }

    }
}
