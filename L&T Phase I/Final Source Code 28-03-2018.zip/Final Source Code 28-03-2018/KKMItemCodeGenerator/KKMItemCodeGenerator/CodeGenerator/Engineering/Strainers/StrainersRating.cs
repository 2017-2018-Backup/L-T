﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersRating : ObservableCollection<NameCodePair>
    {
        public static StrainersRating LoadList()
        {
            StrainersRating items = new StrainersRating();
            items.Add(new NameCodePair() { Code = "00", Name = "PN4" });
            items.Add(new NameCodePair() { Code = "01", Name = "PN6" });
            items.Add(new NameCodePair() { Code = "02", Name = "PN 10" });
            items.Add(new NameCodePair() { Code = "03", Name = "PN 16" });
            items.Add(new NameCodePair() { Code = "04", Name = "PN 25" });
            items.Add(new NameCodePair() { Code = "05", Name = "PN 40" });
            items.Add(new NameCodePair() { Code = "06", Name = "PN 64" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASME 150#" });
            items.Add(new NameCodePair() { Code = "08", Name = "ASME 300#" });
            items.Add(new NameCodePair() { Code = "09", Name = "ASME 600#" });
            items.Add(new NameCodePair() { Code = "10", Name = "ASME 900#" });
            return items;
        }
        public static StrainersRating LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersRating LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersRating>(EngineeringItems.DataPath + @"\Strainers\StrainersRating.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersRating>(this, EngineeringItems.DataPath + @"\Strainers\StrainersRating.xml");
        }

    }
}
