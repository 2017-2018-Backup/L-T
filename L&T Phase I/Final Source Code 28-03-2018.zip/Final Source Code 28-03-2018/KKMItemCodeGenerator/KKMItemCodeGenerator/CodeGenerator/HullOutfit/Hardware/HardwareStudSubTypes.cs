﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareStudSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareStudSubTypes LoadList()
        {
            HardwareStudSubTypes items = new HardwareStudSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Half Threaded" });
            items.Add(new NameCodePair() { Code = "02", Name = "Full Threaded" });
            return items;
        }
        public static HardwareStudSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareStudSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareStudSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareStudSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareStudSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareStudSubTypes.xml");
        }
    }
}
