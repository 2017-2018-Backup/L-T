﻿namespace KKMSurveyorComment
{
    partial class frmCreateNewSurveyorComment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("ABS");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("BV");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("CCS");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("CRS");
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("DNV");
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("GL");
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("IRS");
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("KR");
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("LR");
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("NKK");
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("PRS");
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("RINA");
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem("RS");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCreateNewSurveyorComment));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstClassificationSociety = new System.Windows.Forms.ListView();
            this.cmbLRremark = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtEditCommentRemark = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLifeCycle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSurveyorCommentNumber = new System.Windows.Forms.TextBox();
            this.cmdCreateComment = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.cmbFunctionalGroup = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtClassApprovedDoc = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSubParaRef = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIssueNumber = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1060, 500);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1060, 500);
            this.panel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(840, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 18);
            this.label2.TabIndex = 72;
            this.label2.Text = "*";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SansSerif", 8.999999F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.Location = new System.Drawing.Point(858, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 14);
            this.label1.TabIndex = 71;
            this.label1.Text = "Marked properties are mandatory";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.lstClassificationSociety);
            this.groupBox1.Controls.Add(this.cmbLRremark);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtEditCommentRemark);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtLifeCycle);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtSurveyorCommentNumber);
            this.groupBox1.Controls.Add(this.cmdCreateComment);
            this.groupBox1.Controls.Add(this.cmdCancel);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtProjectCode);
            this.groupBox1.Controls.Add(this.cmbFunctionalGroup);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtClassApprovedDoc);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtComment);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtSubParaRef);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtIssueNumber);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.groupBox1.Location = new System.Drawing.Point(13, 29);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox1.Size = new System.Drawing.Size(1033, 457);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Surveyor Comment";
            // 
            // lstClassificationSociety
            // 
            this.lstClassificationSociety.CheckBoxes = true;
            listViewItem1.StateImageIndex = 0;
            listViewItem1.Tag = "ABS";
            listViewItem2.StateImageIndex = 0;
            listViewItem2.Tag = "BV";
            listViewItem3.StateImageIndex = 0;
            listViewItem3.Tag = "CCS";
            listViewItem4.StateImageIndex = 0;
            listViewItem4.Tag = "CRS";
            listViewItem5.StateImageIndex = 0;
            listViewItem5.Tag = "DNV";
            listViewItem6.StateImageIndex = 0;
            listViewItem6.Tag = "GL";
            listViewItem7.StateImageIndex = 0;
            listViewItem7.Tag = "IRS";
            listViewItem8.StateImageIndex = 0;
            listViewItem8.Tag = "KR";
            listViewItem9.StateImageIndex = 0;
            listViewItem9.Tag = "LR";
            listViewItem10.StateImageIndex = 0;
            listViewItem10.Tag = "NKK";
            listViewItem11.StateImageIndex = 0;
            listViewItem11.Tag = "PRS";
            listViewItem12.StateImageIndex = 0;
            listViewItem12.Tag = "RINA";
            listViewItem13.StateImageIndex = 0;
            listViewItem13.Tag = "RS";
            this.lstClassificationSociety.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13});
            this.lstClassificationSociety.Location = new System.Drawing.Point(184, 170);
            this.lstClassificationSociety.Name = "lstClassificationSociety";
            this.lstClassificationSociety.Size = new System.Drawing.Size(326, 115);
            this.lstClassificationSociety.TabIndex = 4;
            this.lstClassificationSociety.UseCompatibleStateImageBehavior = false;
            this.lstClassificationSociety.View = System.Windows.Forms.View.SmallIcon;
            // 
            // cmbLRremark
            // 
            this.cmbLRremark.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLRremark.FormattingEnabled = true;
            this.cmbLRremark.Items.AddRange(new object[] {
            "AQP",
            "AQS"});
            this.cmbLRremark.Location = new System.Drawing.Point(699, 185);
            this.cmbLRremark.Name = "cmbLRremark";
            this.cmbLRremark.Size = new System.Drawing.Size(326, 25);
            this.cmbLRremark.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(592, 216);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 17);
            this.label13.TabIndex = 77;
            this.label13.Text = "Design Remark :";
            // 
            // txtEditCommentRemark
            // 
            this.txtEditCommentRemark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEditCommentRemark.Location = new System.Drawing.Point(699, 216);
            this.txtEditCommentRemark.Multiline = true;
            this.txtEditCommentRemark.Name = "txtEditCommentRemark";
            this.txtEditCommentRemark.Size = new System.Drawing.Size(326, 129);
            this.txtEditCommentRemark.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(570, 186);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 17);
            this.label14.TabIndex = 76;
            this.label14.Text = "Class Remark Type :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 17);
            this.label4.TabIndex = 72;
            this.label4.Text = "Current Status :";
            // 
            // txtLifeCycle
            // 
            this.txtLifeCycle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLifeCycle.Location = new System.Drawing.Point(184, 106);
            this.txtLifeCycle.Name = "txtLifeCycle";
            this.txtLifeCycle.ReadOnly = true;
            this.txtLifeCycle.Size = new System.Drawing.Size(326, 25);
            this.txtLifeCycle.TabIndex = 2;
            this.txtLifeCycle.Text = "Pending";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 17);
            this.label3.TabIndex = 70;
            this.label3.Text = "Surveyor Comment Number :";
            // 
            // txtSurveyorCommentNumber
            // 
            this.txtSurveyorCommentNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurveyorCommentNumber.Enabled = false;
            this.txtSurveyorCommentNumber.Location = new System.Drawing.Point(184, 42);
            this.txtSurveyorCommentNumber.Name = "txtSurveyorCommentNumber";
            this.txtSurveyorCommentNumber.Size = new System.Drawing.Size(326, 25);
            this.txtSurveyorCommentNumber.TabIndex = 0;
            this.txtSurveyorCommentNumber.Text = "Automatically generated..!!";
            // 
            // cmdCreateComment
            // 
            this.cmdCreateComment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCreateComment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdCreateComment.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.cmdCreateComment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdCreateComment.ForeColor = System.Drawing.Color.White;
            this.cmdCreateComment.Location = new System.Drawing.Point(831, 414);
            this.cmdCreateComment.Margin = new System.Windows.Forms.Padding(5);
            this.cmdCreateComment.Name = "cmdCreateComment";
            this.cmdCreateComment.Size = new System.Drawing.Size(93, 29);
            this.cmdCreateComment.TabIndex = 12;
            this.cmdCreateComment.Text = "Save";
            this.cmdCreateComment.UseVisualStyleBackColor = false;
            this.cmdCreateComment.Click += new System.EventHandler(this.cmdCreateComment_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdCancel.ForeColor = System.Drawing.Color.White;
            this.cmdCancel.Location = new System.Drawing.Point(930, 414);
            this.cmdCancel.Margin = new System.Windows.Forms.Padding(5);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(93, 29);
            this.cmdCancel.TabIndex = 13;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = false;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(992, 382);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(33, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(971, 384);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 18);
            this.label10.TabIndex = 64;
            this.label10.Text = "*";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(515, 295);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(19, 18);
            this.label23.TabIndex = 62;
            this.label23.Text = "*";
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.BackColor = System.Drawing.Color.White;
            this.txtProjectCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProjectCode.Location = new System.Drawing.Point(699, 351);
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.ReadOnly = true;
            this.txtProjectCode.Size = new System.Drawing.Size(326, 25);
            this.txtProjectCode.TabIndex = 9;
            // 
            // cmbFunctionalGroup
            // 
            this.cmbFunctionalGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFunctionalGroup.FormattingEnabled = true;
            this.cmbFunctionalGroup.Items.AddRange(new object[] {
            "Accommodation",
            "Electrical",
            "Engineering",
            "Hull",
            "Hull Outfit",
            "HVAC"});
            this.cmbFunctionalGroup.Location = new System.Drawing.Point(184, 139);
            this.cmbFunctionalGroup.Name = "cmbFunctionalGroup";
            this.cmbFunctionalGroup.Size = new System.Drawing.Size(326, 25);
            this.cmbFunctionalGroup.TabIndex = 3;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(532, 385);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(163, 17);
            this.label28.TabIndex = 58;
            this.label28.Text = "Link Class Approved Doc. :";
            // 
            // txtClassApprovedDoc
            // 
            this.txtClassApprovedDoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClassApprovedDoc.Enabled = false;
            this.txtClassApprovedDoc.Location = new System.Drawing.Point(699, 381);
            this.txtClassApprovedDoc.Name = "txtClassApprovedDoc";
            this.txtClassApprovedDoc.Size = new System.Drawing.Size(270, 25);
            this.txtClassApprovedDoc.TabIndex = 10;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(640, 355);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 17);
            this.label24.TabIndex = 52;
            this.label24.Text = "Project :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(602, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Class Remark :";
            // 
            // txtComment
            // 
            this.txtComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtComment.Location = new System.Drawing.Point(699, 44);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(326, 135);
            this.txtComment.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(87, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 17);
            this.label12.TabIndex = 16;
            this.label12.Text = "Sub Para Ref. :";
            // 
            // txtSubParaRef
            // 
            this.txtSubParaRef.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSubParaRef.Location = new System.Drawing.Point(184, 291);
            this.txtSubParaRef.Name = "txtSubParaRef";
            this.txtSubParaRef.Size = new System.Drawing.Size(326, 25);
            this.txtSubParaRef.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Classification society :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Functional Group :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Issue Number :";
            // 
            // txtIssueNumber
            // 
            this.txtIssueNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIssueNumber.Location = new System.Drawing.Point(184, 74);
            this.txtIssueNumber.Name = "txtIssueNumber";
            this.txtIssueNumber.Size = new System.Drawing.Size(326, 25);
            this.txtIssueNumber.TabIndex = 1;
            this.txtIssueNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIssueNumber_KeyPress);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // frmCreateNewSurveyorComment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 500);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmCreateNewSurveyorComment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Surveyor Comment";
            this.Load += new System.EventHandler(this.frmCreateNewSurveyorComment_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtClassApprovedDoc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSubParaRef;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIssueNumber;
        private System.Windows.Forms.ComboBox cmbFunctionalGroup;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button cmdCreateComment;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSurveyorCommentNumber;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtLifeCycle;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ComboBox cmbLRremark;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtEditCommentRemark;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ListView lstClassificationSociety;
    }
}