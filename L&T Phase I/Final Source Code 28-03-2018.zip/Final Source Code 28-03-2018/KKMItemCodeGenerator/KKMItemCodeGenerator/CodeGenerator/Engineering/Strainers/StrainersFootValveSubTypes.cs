﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersFootValveSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersFootValveSubTypes LoadList()
        {
            StrainersFootValveSubTypes items = new StrainersFootValveSubTypes();
            return items;
        }
        public static StrainersFootValveSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersFootValveSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersFootValveSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersFootValveSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersFootValveSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersFootValveSubTypes.xml");
        }

    }
}
