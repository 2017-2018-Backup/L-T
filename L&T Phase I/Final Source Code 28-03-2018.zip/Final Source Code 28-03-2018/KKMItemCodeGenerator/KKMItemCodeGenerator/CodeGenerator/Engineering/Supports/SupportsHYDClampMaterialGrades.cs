﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsHYDClampMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static SupportsHYDClampMaterialGrades LoadList()
        {
            SupportsHYDClampMaterialGrades items = new SupportsHYDClampMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "RUBBER" });
            items.Add(new NameCodePair() { Code = "02", Name = "PVC" });
            return items;
        }
        public static SupportsHYDClampMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsHYDClampMaterialGrades LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsHYDClampMaterialGrades>(EngineeringItems.DataPath + @"\Supports\SupportsHYDClampMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsHYDClampMaterialGrades>(this, EngineeringItems.DataPath + @"\Supports\SupportsHYDClampMaterialGrades.xml");
        }

    }
}
