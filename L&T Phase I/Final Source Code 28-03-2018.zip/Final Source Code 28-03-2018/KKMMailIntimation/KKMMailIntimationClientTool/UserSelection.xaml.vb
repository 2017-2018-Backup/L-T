﻿Imports Autodesk.Connectivity.WebServices
Imports Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections
Imports System.ComponentModel

Public Class UI_UserSelection
    Dim tempUsers() As User
    Dim tempGroup() As Group
    'Dim vCon As Connection
    Dim vGroupInfo As Dictionary(Of Long, User())
    Public dg As Boolean = False

    Public Sub New(ByVal vUsers() As User, ByVal vGroups() As Group, ByVal vGrpInfo As Dictionary(Of Long, User()))
        InitializeComponent()
        tempUsers = vUsers
        tempGroup = vGroups
        lstUsers.DataContext = Me
        vGroupInfo = vGrpInfo
        LoadVaultUser()
        For Each gp As Group In vGroups
            cmbGroup.Items.Add(gp.Name)
        Next
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As RoutedEventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnOk_Click(sender As Object, e As RoutedEventArgs) Handles btnOk.Click
        dg = True
        Me.Close()
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As RoutedEventArgs) Handles btnSelect.Click
        ''Debugger.Launch()
        For Each item As Object In lstUsers.SelectedItems
            Dim objUserTobeAdded As UserTobeAdded = DirectCast(item, UserTobeAdded)
            If Not lstSelectedUsers.Items.Contains(objUserTobeAdded.username) Then
                lstSelectedUsers.Items.Add(objUserTobeAdded.username)
            End If
        Next
    End Sub

    Private Sub LoadVaultUser()
        lstUsers.Items.Clear()
        Dim listofUsers As List(Of UserTobeAdded) = New List(Of UserTobeAdded)()
        Dim int As Integer = 1
        For Each _user As Object In tempUsers
            Dim objUserTobeAdded As UserTobeAdded = New UserTobeAdded()
            objUserTobeAdded.Isuserchecked = False
            objUserTobeAdded.usercount = int
            objUserTobeAdded.username = _user.Name
            listofUsers.Add(objUserTobeAdded)
            int += 1
        Next

        lstUsers.ItemsSource = listofUsers
        Dim viewSearch As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
        viewSearch.Filter = New Predicate(Of Object)(AddressOf UserFilter)

        If lstUsers.IsGrouping = False Then
            Dim viewSearched As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
            Dim groupDescriptionSearched As PropertyGroupDescription = New PropertyGroupDescription("username")
            viewSearched.GroupDescriptions.Add(groupDescriptionSearched)
        End If

    End Sub

    Private Sub searchedtxt_TextChanged(sender As Object, e As TextChangedEventArgs)
        CollectionViewSource.GetDefaultView(lstUsers.ItemsSource).Refresh()
    End Sub

    Private Function UserFilter(item As Object) As Boolean
        If searchedtxt.Text.Trim() = "" Then
            Return True
        Else
            Dim itemitem As UserTobeAdded = DirectCast(item, UserTobeAdded)
            If itemitem.username.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0 Then
                Return True
            Else
                Return False
            End If
        End If
    End Function

    Private Sub cmbGroup_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles cmbGroup.SelectionChanged
        If cmbGroup.IsEnabled.Equals(True) Then
            lstUsers.ItemsSource = Nothing
            lstUsers.UpdateLayout()
            Dim groupId As Long = tempGroup.Where(Function(t) t.Name.Equals(cmbGroup.SelectedItem)).FirstOrDefault().Id
            ''lstUsers.Items.Clear()
            Dim listofUsers As List(Of UserTobeAdded) = New List(Of UserTobeAdded)()
            Dim int As Integer = 1
            For Each _user As Object In vGroupInfo(groupId)
                Dim objUserTobeAdded As UserTobeAdded = New UserTobeAdded()
                objUserTobeAdded.Isuserchecked = False
                objUserTobeAdded.usercount = int
                objUserTobeAdded.username = _user.Name
                listofUsers.Add(objUserTobeAdded)
                ''lstUsers.Items.Add(_user.Name)
                int += 1
            Next
            lstUsers.ItemsSource = listofUsers
            Dim viewSearch As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
            viewSearch.Filter = New Predicate(Of Object)(AddressOf UserFilter)

            If lstUsers.IsGrouping = False Then
                Dim viewSearched As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
                Dim groupDescriptionSearched As PropertyGroupDescription = New PropertyGroupDescription("username")
                viewSearched.GroupDescriptions.Add(groupDescriptionSearched)
            End If
            lstUsers.UpdateLayout()
        End If
    End Sub

    Private Sub rdUsers_Checked(sender As Object, e As RoutedEventArgs) Handles rdUsers.Checked
        Try
            If lstUsers IsNot Nothing Then
                lstUsers.ItemsSource = Nothing
                lstUsers.UpdateLayout()
                Dim listofUsers As List(Of UserTobeAdded) = New List(Of UserTobeAdded)()
                Dim int As Integer = 1
                For Each _usr As User In tempUsers
                    Dim objUserTobeAdded As UserTobeAdded = New UserTobeAdded()
                    objUserTobeAdded.Isuserchecked = False
                    objUserTobeAdded.usercount = int
                    objUserTobeAdded.username = _usr.Name
                    listofUsers.Add(objUserTobeAdded)
                    ''lstUsers.Items.Add(_usr.Name)
                    int += 1
                Next
                lstUsers.ItemsSource = listofUsers
                Dim viewSearch As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
                viewSearch.Filter = New Predicate(Of Object)(AddressOf UserFilter)

                If lstUsers.IsGrouping = False Then
                    Dim viewSearched As CollectionView = DirectCast(CollectionViewSource.GetDefaultView(lstUsers.ItemsSource), CollectionView)
                    Dim groupDescriptionSearched As PropertyGroupDescription = New PropertyGroupDescription("username")
                    viewSearched.GroupDescriptions.Add(groupDescriptionSearched)
                End If
                lstUsers.UpdateLayout()
                cmbGroup.IsEnabled = False
            End If
            ''rdGroup.IsChecked = False
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub rdGroup_Checked(sender As Object, e As RoutedEventArgs) Handles rdGroup.Checked
        Try
            cmbGroup.IsEnabled = True
            'If lstUsers.Items IsNot Nothing Then
            '    lstUsers.Items.Clear()
            'End If
            lstUsers.ItemsSource = Nothing
            lstUsers.UpdateLayout()
            cmbGroup.SelectedIndex = 0
            cmbGroup_SelectionChanged(Nothing, Nothing)
            ''rdUsers.IsChecked = False
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As RoutedEventArgs)
        Dim selList = lstSelectedUsers.SelectedItems
        For i As Integer = 0 To selList.Count - 1
            lstSelectedUsers.Items.Remove(selList(0))
        Next
    End Sub

End Class

Public Class UserTobeAdded
    Implements INotifyPropertyChanged

    Public Event PropertyChanged As PropertyChangedEventHandler _
        Implements INotifyPropertyChanged.PropertyChanged

    ' This method is called by the Set accessor of each property.
    ' The CallerMemberName attribute that is applied to the optional propertyName
    ' parameter causes the property name of the caller to be substituted as an argument.
    Private Sub NotifyPropertyChanged(Optional ByVal propertyName As String = Nothing)
        RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
    End Sub

    Private musercount As Integer
    Public Property usercount() As Integer
        Get
            Return musercount
        End Get
        Set(ByVal value As Integer)
            musercount = value
        End Set
    End Property

    Private musername As String
    Public Property username() As String
        Get
            Return musername
        End Get
        Set(ByVal value As String)
            musername = value
        End Set
    End Property

    Private mIsuserchecked As Boolean
    Public Property Isuserchecked() As Boolean
        Get
            Return mIsuserchecked
        End Get
        Set(ByVal value As Boolean)
            mIsuserchecked = value
            NotifyPropertyChanged()
        End Set
    End Property

End Class