﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static FlangeMaterialGrades LoadList()
        {
            FlangeMaterialGrades items = new FlangeMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "IS2062 GrA" });
            items.Add(new NameCodePair() { Code = "02", Name = "Gr A" });
            items.Add(new NameCodePair() { Code = "03", Name = "S 235" });
            items.Add(new NameCodePair() { Code = "04", Name = "SS-316L" });
            items.Add(new NameCodePair() { Code = "05", Name = "ASTM A 285 GR C" });
            items.Add(new NameCodePair() { Code = "06", Name = "SS-316" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASTM A-105" });
            items.Add(new NameCodePair() { Code = "08", Name = "Cu-Ni/IS2062" });
            items.Add(new NameCodePair() { Code = "09", Name = "NAB - NES 747 Part II" });
            items.Add(new NameCodePair() { Code = "10", Name = "GM - BS 1400 LG4C" });
            items.Add(new NameCodePair() { Code = "11", Name = "ASTM A 106 Gr B" });
            items.Add(new NameCodePair() { Code = "12", Name = "W5/NBR" });
            items.Add(new NameCodePair() { Code = "13", Name = "Carbon Steel S 275 JR" });
            items.Add(new NameCodePair() { Code = "14", Name = "ASTM A-182 F316" });
            items.Add(new NameCodePair() { Code = "15", Name = "SS 304" });
            items.Add(new NameCodePair() { Code = "16", Name = "AA 6082 T5" });
            return items;
        }
        public static FlangeMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeMaterialGrades LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeMaterialGrades>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeMaterialGrades>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeMaterialGrades.xml");
        }

    }
}
