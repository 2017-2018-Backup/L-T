﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CTLElecClassApprovals : ObservableCollection<NameCodePair>
    {
        public static CTLElecClassApprovals LoadList()
        {
            CTLElecClassApprovals items = new CTLElecClassApprovals();
            items.Add(new NameCodePair() { Code = "01", Name = "LR" });
            items.Add(new NameCodePair() { Code = "02", Name = "GL" });
            items.Add(new NameCodePair() { Code = "03", Name = "NIL" });
            items.Add(new NameCodePair() { Code = "04", Name = "DNV" });
            items.Add(new NameCodePair() { Code = "05", Name = "ABS" });
            items.Add(new NameCodePair() { Code = "06", Name = "IRS" });
            return items;
        }
        public static CTLElecClassApprovals LoadFromExcel(String path)
        {
            return null;
        }

        public static CTLElecClassApprovals LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CTLElecClassApprovals>(ElectricalItems.DataPath + @"\CableTerminalLugs\CTLElecClassApprovals.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CTLElecClassApprovals>(this, ElectricalItems.DataPath + @"\CableTerminalLugs\CTLElecClassApprovals.xml");
        }

    }
}
