﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersYTypeSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersYTypeSubTypes LoadList()
        {
            StrainersYTypeSubTypes items = new StrainersYTypeSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "MANUAL DRAIN" });
            items.Add(new NameCodePair() { Code = "02", Name = "AUTO BACK FLUSH" });
            items.Add(new NameCodePair() { Code = "03", Name = "PRESSURE DIFFERENTIAL SWITCH" });
            items.Add(new NameCodePair() { Code = "04", Name = "MAGNETIC TYPE" });
            return items;
        }
        public static StrainersYTypeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersYTypeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersYTypeSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersYTypeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersYTypeSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersYTypeSubTypes.xml");
        }

    }
}
