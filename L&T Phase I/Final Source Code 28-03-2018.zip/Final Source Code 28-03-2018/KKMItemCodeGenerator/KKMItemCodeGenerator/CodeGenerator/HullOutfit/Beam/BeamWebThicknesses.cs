﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamWebThicknesses : ObservableCollection<NameCodePair>
    {
        public static BeamWebThicknesses LoadList()
        {
            BeamWebThicknesses items = new BeamWebThicknesses();
            items.Add(new NameCodePair() { Code = "003", Name = "3.0 mm" });
            items.Add(new NameCodePair() { Code = "03B", Name = "3.2 mm" });
            items.Add(new NameCodePair() { Code = "03D", Name = "3.4 mm" });
            items.Add(new NameCodePair() { Code = "03G", Name = "3.7 mm" });
            items.Add(new NameCodePair() { Code = "004", Name = "4.0 mm" });
            items.Add(new NameCodePair() { Code = "04C", Name = "4.3 mm" });
            items.Add(new NameCodePair() { Code = "04D", Name = "4.4 mm" });
            items.Add(new NameCodePair() { Code = "04G", Name = "4.7 mm" });
            items.Add(new NameCodePair() { Code = "04H", Name = "4.8 mm" });
            items.Add(new NameCodePair() { Code = "005", Name = "5.0 mm" });
            items.Add(new NameCodePair() { Code = "05A", Name = "5.1 mm" });
            items.Add(new NameCodePair() { Code = "05B", Name = "5.2 mm" });
            items.Add(new NameCodePair() { Code = "05D", Name = "5.4 mm" });
            items.Add(new NameCodePair() { Code = "05F", Name = "5.6 mm" });
            items.Add(new NameCodePair() { Code = "05G", Name = "5.7 mm" });
            items.Add(new NameCodePair() { Code = "05H", Name = "5.8 mm" });
            items.Add(new NameCodePair() { Code = "006", Name = "6.0 mm" });
            items.Add(new NameCodePair() { Code = "06A", Name = "6.1 mm" });
            items.Add(new NameCodePair() { Code = "06D", Name = "6.4 mm" });
            items.Add(new NameCodePair() { Code = "06E", Name = "6.5 mm" });
            items.Add(new NameCodePair() { Code = "06G", Name = "6.7 mm" });
            items.Add(new NameCodePair() { Code = "06I", Name = "6.9 mm" });
            items.Add(new NameCodePair() { Code = "007", Name = "7.0 mm" });
            items.Add(new NameCodePair() { Code = "07D", Name = "7.4 mm" });
            items.Add(new NameCodePair() { Code = "07F", Name = "7.6 mm" });
            items.Add(new NameCodePair() { Code = "07G", Name = "7.7 mm" });
            items.Add(new NameCodePair() { Code = "07H", Name = "7.8 mm" });
            items.Add(new NameCodePair() { Code = "07I", Name = "7.9 mm" });
            items.Add(new NameCodePair() { Code = "008", Name = "8.0 mm" });
            items.Add(new NameCodePair() { Code = "08A", Name = "8.1 mm" });
            items.Add(new NameCodePair() { Code = "08C", Name = "8.3 mm" });
            items.Add(new NameCodePair() { Code = "08E", Name = "8.5 mm" });
            items.Add(new NameCodePair() { Code = "08F", Name = "8.6 mm" });
            items.Add(new NameCodePair() { Code = "08H", Name = "8.8 mm" });
            items.Add(new NameCodePair() { Code = "08I", Name = "8.9 mm" });
            items.Add(new NameCodePair() { Code = "009", Name = "9.0 mm" });
            items.Add(new NameCodePair() { Code = "09A", Name = "9.1 mm" });
            items.Add(new NameCodePair() { Code = "09B", Name = "9.2 mm" });
            items.Add(new NameCodePair() { Code = "09D", Name = "9.4 mm" });
            items.Add(new NameCodePair() { Code = "09E", Name = "9.5 mm" });
            items.Add(new NameCodePair() { Code = "09H", Name = "9.8 mm" });
            items.Add(new NameCodePair() { Code = "09I", Name = "9.9 mm" });
            items.Add(new NameCodePair() { Code = "010", Name = "10.0 mm" });
            items.Add(new NameCodePair() { Code = "10A", Name = "10.1 mm" });
            items.Add(new NameCodePair() { Code = "10B", Name = "10.2 mm" });
            items.Add(new NameCodePair() { Code = "10E", Name = "10.5 mm" });
            items.Add(new NameCodePair() { Code = "10F", Name = "10.6 mm" });
            items.Add(new NameCodePair() { Code = "11B", Name = "11.2 mm" });
            items.Add(new NameCodePair() { Code = "11C", Name = "11.3 mm" });
            items.Add(new NameCodePair() { Code = "11H", Name = "11.8 mm" });
            items.Add(new NameCodePair() { Code = "012", Name = "12.0 mm" });

            return items;
        }
        public static BeamWebThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamWebThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamWebThicknesses>(HullOutfitItems.DataPath + @"\Beam\BeamWebThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamWebThicknesses>(this, HullOutfitItems.DataPath + @"\Beam\BeamWebThicknesses.xml");
        }
    }
}
