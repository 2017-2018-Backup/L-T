﻿using KKMCustomerComment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace KKMCustomerComments
{
    public partial class frmCreateCustomerComments : Form
    {

        int CustomerCommentNo = 1;
        bool IsVersionUpdate = false;
        string selectedVer = "";
        bool IsEditMode = false;
        bool IsCheckedOut = false;        
        string checkedOutUsername = "";

        public frmCreateCustomerComments()
        {
            InitializeComponent();
        }

        public frmCreateCustomerComments(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;
        }

        private void AddProjectFolderItem(AutoCompleteStringCollection ProjectFolderCOllection)
        {
            try
            {
                // check for any sub Folders.
                VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.Category.Name.ToUpper() == "PROJECT")
                        {
                            ProjectFolderCOllection.Add(folder.EntityName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmCreateNewCustomerComment_Load(object sender, EventArgs e)
        {
            lstviewCustomerRelatedDocuments.View = View.List;
            lstviewLandTRelatedDocuments.View = View.List;
            txtCustomerCustomerCommentNumber.ReadOnly = true;

            foreach (string item in clsStaticGlobal.GetAllUserList())
            {
                cmbCustomerCommentResponsiblePerson.Items.Add(item);
            }

            try
            {               
                if (IsEditMode == true)
                {
                    AssignToControl(clsStaticGlobal.objSingleCustomerCommentsummary);
                    selectedVer = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion;
                    IsVersionUpdate = false;
                }
                else
                {    
                    CustomerCommentNo = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber + 1;
                    txtCustomerCommentProjectCode.Text = clsStaticGlobal._ProjectCode;
                    txtCustomerCustomerCommentNumber.Text = txtCustomerCommentProjectCode.Text + "_" + CustomerCommentNo.ToString();

                    txtLifecycleState.Text = "Create";

                    if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentHistoryVersions.Count > 0)
                    {
                        if (cmbHistoryVersion.Items.Count > 0)
                        {
                            cmbHistoryVersion.Items.Clear();
                        }
                        foreach (int item in clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentHistoryVersions)
                        {
                            cmbHistoryVersion.Items.Add(item.ToString());
                        }

                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion != "")
                        {
                            cmbHistoryVersion.SelectedItem = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion;
                            cmbHistoryVersion.SelectedText = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            if (IsCheckedOut == true)
            {
                MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdCreateComment_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {

                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (IsValidateField() == true)
                        {
                            if (IsEditMode == true)
                            {
                                if ((IsVersionUpdate == true) && (selectedVer != clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion))
                                {
                                    AssignToObject();
                                }
                                else if ((IsVersionUpdate == false) && (selectedVer == clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion))
                                {
                                    AssignToObject();
                                }
                                MessageBox.Show("Customer Comment updated successfully..!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                            }
                            else
                            {
                                string _TempCommentName = txtCustomerCustomerCommentNumber.Text.Trim();
                                string _TempFileName = "PDC_" + _TempCommentName + ".xml";

                                if (IsCustomerCommentNameExist(_TempFileName, _TempCommentName))
                                {
                                    MessageBox.Show("Customer Comment already exist", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    try
                                    {
                                        AssignToObject();
                                        String _xmlFilePath = clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;
                                        clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;
                                        clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleCustomerCommentsummary, _xmlFilePath, false);
                                        clsStaticGlobal.UpdateFileRemark(clsStaticGlobal.objSingleCustomerCommentsummary);
                                        MessageBox.Show("Customer Comment updated successfully..!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        this.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        clsStaticGlobal.ErrHandlerLog(ex);
                                        MessageBox.Show("Error in creating Customer Comment!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        MessageBox.Show("Error in creating Customer Comment!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IsCustomerCommentNameExist(string _filename, string _CommentName)
        {
            bool IsExist = false;
            try
            {
                foreach (SingleCustomerCommentsummary item in clsStaticGlobal.objSingleCustomerCommentCollection.collectionCustomerComment)
                {
                    if ((item.CustomerCommentFileName == _filename) || (item.CustomerCustomerCommentNumber == _CommentName))
                    {
                        IsExist = true;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return IsExist;
        }

        private void AssignToObject()
        {
            try
            {
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCustomerCommentNumber = txtCustomerCustomerCommentNumber.Text.Trim();

                if (IsEditMode == false)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName = "PDC_" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCustomerCommentNumber + ".xml";
                    clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";
                    clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLatestVersion = "1";
                }

                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber = CustomerCommentNo;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentProjectCode = txtCustomerCommentProjectCode.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCustomerCommentNumber = txtCustomerCustomerCommentNumber.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentsystem = txtCustomerCommentsystem.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCustomerComment = txtCustomerCustomerComment.Text;

                if (cmbCustomerCommentResponsiblePerson.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentResponsiblePerson = cmbCustomerCommentResponsiblePerson.SelectedItem.ToString();
                }

                if (cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer = cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem.ToString();
                }

                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentCloserDate = dtpCustomerCommentCloserDate.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLandTComment = txtCustomerCommentLandTComment.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentTimeImplications = txtCustomerCommentTimeImplications.Text;
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentCostImplications = txtCustomerCommentCostImplications.Text;

                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark = txtCustomerCommentRemark.Text;

                string _CustomerRelatedDocuments = "";
                if (clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        if (_CustomerRelatedDocuments.Trim() == "")
                        {
                            _CustomerRelatedDocuments = item.FileName;
                        }
                        else
                        {
                            _CustomerRelatedDocuments = _CustomerRelatedDocuments + "," + Environment.NewLine + item.FileName;
                        }
                    }
                }
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentCustomerRelatedDocuments = _CustomerRelatedDocuments;

                string _LandTRelatedDocuments = "";

                if (clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        if (_LandTRelatedDocuments.Trim() == "")
                        {
                            _LandTRelatedDocuments = item.FileName;
                        }
                        else
                        {
                            _LandTRelatedDocuments = _LandTRelatedDocuments + "," + Environment.NewLine + item.FileName;
                        }
                    }
                }
                clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLandTRelatedDocuments = _LandTRelatedDocuments;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void AssignToControl(SingleCustomerCommentsummary _SingleCustomerCommentsummary)
        {
            try
            {
                txtCustomerCommentProjectCode.Text = _SingleCustomerCommentsummary.CustomerCommentProjectCode;
                txtCustomerCustomerCommentNumber.Text = _SingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                txtCustomerCustomerComment.Text = _SingleCustomerCommentsummary.CustomerCustomerComment;               

                if (_SingleCustomerCommentsummary.CustomerCommentHistoryVersions.Count > 0)
                {
                    if (cmbHistoryVersion.Items.Count > 0)
                    {
                        cmbHistoryVersion.Items.Clear();
                    }
                    foreach (int item in _SingleCustomerCommentsummary.CustomerCommentHistoryVersions)
                    {
                        cmbHistoryVersion.Items.Add(item.ToString());
                        cmbHistoryVersion.Refresh();
                    }

                    if (_SingleCustomerCommentsummary.CustomerCommentLatestVersion != "")
                    {
                        cmbHistoryVersion.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentLatestVersion;
                        cmbHistoryVersion.SelectedText = _SingleCustomerCommentsummary.CustomerCommentLatestVersion;
                    }
                }

                if (_SingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in _SingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewCustomerRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentsystem.Text = _SingleCustomerCommentsummary.CustomerCommentsystem;

                if ((_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != "") || (_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != null))
                {
                    cmbCustomerCommentResponsiblePerson.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                    cmbCustomerCommentResponsiblePerson.Text = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                }

                dtpCustomerCommentCloserDate.Text = _SingleCustomerCommentsummary.CustomerCommentCloserDate;
                txtCustomerCommentLandTComment.Text = _SingleCustomerCommentsummary.CustomerCommentLandTComment;

                txtLifecycleState.Text = _SingleCustomerCommentsummary.CustomerCommentLifeCycle;

                if (_SingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in _SingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewLandTRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentTimeImplications.Text = _SingleCustomerCommentsummary.CustomerCommentTimeImplications;
                txtCustomerCommentCostImplications.Text = _SingleCustomerCommentsummary.CustomerCommentCostImplications;

                if ((_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != "") || (_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != null))
                {
                    cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                    cmbCustomerCommentFindAcceptanceFromCustomer.Text = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                }


                txtCustomerCommentRemark.Text = _SingleCustomerCommentsummary.CustomerCommentRemark;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidateField()
        {
            bool isvalid = true;

            if (txtCustomerCommentProjectCode.Text.Trim() == "")
            {
                errorProvider1.SetError(txtCustomerCommentProjectCode, "Enter project number");
                isvalid = false;
            }
            else
            {
                errorProvider1.Clear();
            }

            return isvalid;
        }

        private void txtIssueNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void btnLandTRelatedDocuments_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        clsStaticGlobal.RelatedDocByLandTFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                        Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.VaultCustomerLandTFolder.FolderPath);
                        clsStaticGlobal.PrintLandTRelatedDocumentFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                        UserControlRelatedDocByLandT objfrmLandTRelevantDocument = new UserControlRelatedDocByLandT(true);
                        objfrmLandTRelevantDocument.ShowDialog();

                        if (clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                        {
                            if (lstviewLandTRelatedDocuments.Items.Count > 0)
                            {
                                try
                                {
                                    lstviewLandTRelatedDocuments.Items.Clear();
                                }
                                catch (Exception)
                                {

                                }

                            }
                            foreach (LandTRelatedDocument item in clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                            {
                                ListViewItem _lstitem = new ListViewItem();
                                _lstitem.Text = item.FileName;
                                _lstitem.Tag = item.FilePath;
                                lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                            }
                        }
                        else
                        {
                            lstviewLandTRelatedDocuments.Items.Clear();
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            lstviewLandTRelatedDocuments.Update();
        }

        private void btnCustomerRelatedDocuments_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        clsStaticGlobal.RelevantDocByCustomerFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                        Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.VaultCustomerCustomerFolder.FolderPath);
                        clsStaticGlobal.PrintCustomerRelevantDocumentsFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                        UserControlRelevantDocByCustomer objfrmRelevantDocByCustomer = new UserControlRelevantDocByCustomer(true);
                        objfrmRelevantDocByCustomer.ShowDialog();


                        if (clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                        {
                            if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                            {
                                try
                                {
                                    lstviewCustomerRelatedDocuments.Items.Clear();
                                }
                                catch (Exception)
                                {

                                }

                            }
                            foreach (CustomerRelatedDocument item in clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                            {
                                ListViewItem _lstitem = new ListViewItem();
                                _lstitem.Text = item.FileName;
                                _lstitem.Tag = item.FilePath;
                                lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                            }
                        }
                        else
                        {
                            lstviewCustomerRelatedDocuments.Items.Clear();
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            lstviewCustomerRelatedDocuments.Update();
        }

        private void btnApplyHistoryVersion_Click(object sender, EventArgs e)
        {
            if (cmbHistoryVersion.SelectedItem != null)
            {
                try
                {
                    int selectedVersion = int.Parse(cmbHistoryVersion.SelectedItem.ToString());
                    IsVersionUpdate = false;
                    selectedVer = selectedVersion.ToString();
                    Autodesk.Connectivity.WebServices.File[] SingleFile;
                    Autodesk.Connectivity.WebServices.File _LatestFileswithVersions = null;

                    SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath });
                    if (SingleFile.Length != 0)
                    {
                        _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFileByVersion(SingleFile[0].MasterId, selectedVersion);
                    }

                    try
                    {
                        if (_LatestFileswithVersions != null)
                        {
                            clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");

                            if (!Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions"))
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            }
                            else
                            {
                                clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            }

                            VDF.Vault.Currency.Entities.FileIteration fileIter = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, _LatestFileswithVersions);
                            VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                            settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                            VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                            try
                            {
                                XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                                SingleCustomerCommentsummary objVersionSingleCustomerCommentsummary = new SingleCustomerCommentsummary();
                                string[] filePaths = Directory.GetFiles(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions", "*.xml", SearchOption.TopDirectoryOnly);
                                foreach (string _filepath in filePaths)
                                {
                                    using (var sr = new StreamReader(_filepath))
                                    {
                                        objVersionSingleCustomerCommentsummary = (SingleCustomerCommentsummary)xs.Deserialize(sr);
                                    }
                                    if (objVersionSingleCustomerCommentsummary != null)
                                    {
                                        string _Poststatus = "";
                                        string _Postremark = "";
                                        string _Postrevision = "";
                                        clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(objVersionSingleCustomerCommentsummary.CustomerCommentFileFullPath, out _Poststatus, out _Postremark, out _Postrevision);
                                        objVersionSingleCustomerCommentsummary.CustomerCommentLifeCycle = _Poststatus;
                                        objVersionSingleCustomerCommentsummary.CustomerCommentRemark = _Postremark;

                                        if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                                        {
                                            foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                                            {
                                                string _status = "";
                                                string _remark = "";
                                                string _revision = "";
                                                clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                                item.FileStatus = _status;
                                                item.FileRemark = _remark;
                                                item.FileRevision = _revision;
                                            }
                                        }

                                        if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                                        {
                                            foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                                            {
                                                string _status = "";
                                                string _remark = "";
                                                string _revision = "";
                                                clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                                item.FileStatus = _status;
                                                item.FileRemark = _remark;
                                                item.FileRevision = _revision;
                                            }
                                        }
                                    }
                                }

                                VersionsAssignToControl(objVersionSingleCustomerCommentsummary);

                                System.Windows.Forms.MessageBox.Show("Selected version data uploaded successfully..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                clsStaticGlobal.ErrHandlerLog(ex);
                                System.Windows.Forms.MessageBox.Show("Unable to read Customer Comment file version..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Unable to get selected Customer Comment file version..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }

        }

        private void btnSetLatestHistoryVersion_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    DialogResult _dialogRes = MessageBox.Show("Are you sure to set current details as latest details for Customer Comment..?", "Customer Comment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (_dialogRes == System.Windows.Forms.DialogResult.Yes)
                    {
                        try
                        {
                            if (IsValidateField() == true)
                            {
                                if (IsEditMode == true)
                                {
                                    IsVersionUpdate = true;
                                    selectedVer = cmbHistoryVersion.SelectedItem.ToString();
                                    AssignToObject();
                                    MessageBox.Show("Customer Comment updated successfully..!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    this.Close();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                            MessageBox.Show("Error in creating Customer Comment!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void VersionsAssignToControl(SingleCustomerCommentsummary _SingleCustomerCommentsummary)
        {
            try
            {
                txtCustomerCommentProjectCode.Text = _SingleCustomerCommentsummary.CustomerCommentProjectCode;
                txtCustomerCustomerCommentNumber.Text = _SingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                txtCustomerCustomerComment.Text = _SingleCustomerCommentsummary.CustomerCustomerComment;

                if (_SingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in _SingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewCustomerRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentsystem.Text = _SingleCustomerCommentsummary.CustomerCommentsystem;

                if ((_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != "") || (_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != null))
                {
                    cmbCustomerCommentResponsiblePerson.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                    cmbCustomerCommentResponsiblePerson.Text = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                }

                dtpCustomerCommentCloserDate.Text = _SingleCustomerCommentsummary.CustomerCommentCloserDate;
                txtCustomerCommentLandTComment.Text = _SingleCustomerCommentsummary.CustomerCommentLandTComment;

                txtLifecycleState.Text = _SingleCustomerCommentsummary.CustomerCommentLifeCycle;

                if (_SingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in _SingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewLandTRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentTimeImplications.Text = _SingleCustomerCommentsummary.CustomerCommentTimeImplications;
                txtCustomerCommentCostImplications.Text = _SingleCustomerCommentsummary.CustomerCommentCostImplications;

                if ((_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != "") || (_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != null))
                {
                    cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                    cmbCustomerCommentFindAcceptanceFromCustomer.Text = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                }

                txtCustomerCommentRemark.Text = _SingleCustomerCommentsummary.CustomerCommentRemark;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbHistoryVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            IsVersionUpdate = false;
        }
    }
}
