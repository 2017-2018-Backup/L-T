﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingSeals : ObservableCollection<NameCodePair>
    {
        public static PipeFittingSeals LoadList()
        {
            PipeFittingSeals items = new PipeFittingSeals();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "O-RING" });
            return items;
        }
        public static PipeFittingSeals LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingSeals LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingSeals>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSeals.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingSeals>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSeals.xml");
        }

    }
}
