﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersEndTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersEndTypes LoadList()
        {
            StrainersEndTypes items = new StrainersEndTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "BSPP FEMALE" });
            items.Add(new NameCodePair() { Code = "02", Name = "BSPP MALE" });
            items.Add(new NameCodePair() { Code = "03", Name = "NPT F" });
            items.Add(new NameCodePair() { Code = "04", Name = "NPT M" });
            items.Add(new NameCodePair() { Code = "05", Name = "BW" });
            items.Add(new NameCodePair() { Code = "06", Name = "SW" });
            items.Add(new NameCodePair() { Code = "07", Name = "RF FLANGE" });
            items.Add(new NameCodePair() { Code = "08", Name = "FF FLANGE" });
            items.Add(new NameCodePair() { Code = "09", Name = "WAFER TYPE" });
            items.Add(new NameCodePair() { Code = "10", Name = "BUTT WELDING" });
            items.Add(new NameCodePair() { Code = "11", Name = "RF-SmF" });
            items.Add(new NameCodePair() { Code = "12", Name = "SOFT SEALING" });
            items.Add(new NameCodePair() { Code = "13", Name = "SOCKET WELDING" });
            items.Add(new NameCodePair() { Code = "14", Name = "BITE TYPE" });
            return items;
        }
        public static StrainersEndTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersEndTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersEndTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersEndTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersEndTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersEndTypes.xml");
        }

    }
}
