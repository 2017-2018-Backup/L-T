﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingBushingSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingBushingSubTypes LoadList()
        {
            PipeFittingBushingSubTypes items = new PipeFittingBushingSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "BUSHING" });
            items.Add(new NameCodePair() { Code = "02", Name = "FLUSH BUSHING" });
            items.Add(new NameCodePair() { Code = "03", Name = "BUSHING HEX. HEAD" });
            return items;
        }
        public static PipeFittingBushingSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingBushingSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingBushingSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingBushingSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingBushingSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingBushingSubTypes.xml");
        }

    }
}
