﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWTeeSubTypes : ObservableCollection<NameCodePair>
    {
        public static BWTeeSubTypes LoadList()
        {
            BWTeeSubTypes items = new BWTeeSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "90˚ Equal" });
            items.Add(new NameCodePair() { Code = "02", Name = "Y Branch, 45˚ Equal" });
            items.Add(new NameCodePair() { Code = "03", Name = "90˚ Unequal" });
            items.Add(new NameCodePair() { Code = "04", Name = "Y Branch, 45˚ Unequal" });
            return items;
        }
        public static BWTeeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BWTeeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWTeeSubTypes>(EngineeringItems.DataPath + @"\FittingsBW\BWTeeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWTeeSubTypes>(this, EngineeringItems.DataPath + @"\FittingsBW\BWTeeSubTypes.xml");
        }

    }
}
