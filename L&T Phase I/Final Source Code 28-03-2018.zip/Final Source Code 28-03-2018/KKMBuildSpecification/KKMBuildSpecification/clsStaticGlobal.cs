﻿using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Xml.Serialization;
using KKMBuildSpecification;
using VDF = Autodesk.DataManagement.Client.Framework;
using System.IO.Packaging;
using System.Reflection;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties;
using excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

public static class clsStaticGlobal
{
    public static bool IsReadOnly = false;
    public static bool IsFilter = false;
    public static VDF.Vault.Currency.Connections.Connection connection;
    public static string _ProjectCode = "";
    public static string BuildSpecificationFolderName = "Build Specification";
    public static string BuildSpecificationFileCategory = "Build Specification";
    public static string BuildSpecificationSOTRNumberFolderName = "SORT for NAVY";
    public static string BuildSpecificationClassDrawingFolderName = "Class Approved Drawings";
    public static string BuildSpecificationDADDrawingFolderName = "DAD";
    public static string BuildSpecificationProductionDrawingFolderName = "Production Drawings";
    public static string BuildSpecificationMasterDrawingListFolderName = "MASTER DRAWING LIST";

    public static Dictionary<string, List<MasterDrawingFile>> MasterDrawingList = new Dictionary<string, List<MasterDrawingFile>>() { };
    public static SFIcodes sficodes = new SFIcodes();
    public static string LocalXMLBuildSpecificationFolderPath = Path.GetTempPath() + BuildSpecificationFolderName;

    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder ProjectFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultBuildSpecificationFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultSOTRNumberFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultClassDrawingFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultDADDrawingFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultProductionDrawingFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultMasterDrawingListFolder = null;

    public static List<Autodesk.Connectivity.WebServices.File> SOTRNumberFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> ClassDrawingFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> DADDrawingFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> ProductionDrawingFiles = null;

    public static List<int> ListBuildSpecificationNumbers = null;

    public static ObservableCollection<ProjectCodes> ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();
    public static ObservableCollection<CommentStates> CommentStatesCollection = new ObservableCollection<CommentStates>();
    public static ObservableCollection<CompletionActivities> CompletionActivitiesCollection = new ObservableCollection<CompletionActivities>();
    public static SingleBuildSpecificationSummary objSingleBuildSpecificationSummary;
    public static clsBuildSpecificationSummary objSingleBuildSpecificationCollection;
    public static ObservableCollection<SingleBuildSpecificationSummary> SingleBuildSpecificationSummaryItemCollection = new ObservableCollection<SingleBuildSpecificationSummary>();

    public static ObservableCollection<SOTRNumber> SOTRNumberSearchedItemCollection = new ObservableCollection<SOTRNumber>();
    public static ObservableCollection<ClassDrawing> ClassDrawingSearchedItemCollection = new ObservableCollection<ClassDrawing>();
    public static ObservableCollection<DADDrawing> DADDrawingSearchedItemCollection = new ObservableCollection<DADDrawing>();
    public static ObservableCollection<ProductionDrawing> ProductionDrawingSearchedItemCollection = new ObservableCollection<ProductionDrawing>();

    public static string ErrorFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

    public static void ErrHandlerLog(Exception ex)
    {
        try
        {
            string errorFilePath = ErrorFilePath + "/BuildSpecificationErrorLog.txt";
            if (!System.IO.File.Exists(errorFilePath))
            {
                dynamic fs = System.IO.File.Create(errorFilePath);
                fs.Close();
                fs.Dispose();
            }
            zipFile(ErrorFilePath, "error.txt");

            using (StreamWriter sw = new StreamWriter(errorFilePath, true))
            {
                try
                {
                    sw.WriteLine("Log Date & time: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                    sw.WriteLine("Message:" + ex.Message);

                    sw.WriteLine("Type:" + ex.GetType().ToString());
                    if ((ex.StackTrace != null))
                    {
                        sw.WriteLine("Trace: " + ex.StackTrace);
                    }

                    if ((ex.Source != null))
                    {
                        sw.WriteLine("Source: " + ex.Source);
                    }

                    if ((ex.TargetSite != null))
                    {
                        sw.WriteLine("Target: " + ex.TargetSite.ToString());
                    }

                    if ((ex.InnerException != null))
                    {
                        sw.WriteLine("Inner Message:" + ex.InnerException.Message);

                        if ((ex.InnerException.StackTrace != null))
                        {
                            sw.WriteLine("Trace: " + ex.InnerException.StackTrace);
                        }

                        if ((ex.InnerException.Source != null))
                        {
                            sw.WriteLine("Source: " + ex.InnerException.Source);
                        }

                        if ((ex.InnerException.TargetSite != null))
                        {
                            sw.WriteLine("Target: " + ex.InnerException.TargetSite.ToString());
                        }

                    }
                    sw.WriteLine("");
                    sw.WriteLine("");
                }
                catch (Exception)
                {
                    sw.WriteLine("");
                    sw.WriteLine("");
                }

                sw.Close();
            }
        }
        catch (Exception)
        {

        }
    }

    public static void zipFile(string errorFolderPath, string errorFileName)
    {
        try
        {
            dynamic mFileName = errorFolderPath + "\\" + errorFileName;
            System.IO.FileInfo info = new System.IO.FileInfo(mFileName);
            string ZipFileName = "Error_" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss").Replace("-", "_").Replace(" ", "_").Replace(":", "_") + ".zip";
            if (info.Length >= 1048576)
            {

                Package zip = ZipPackage.Open(errorFolderPath + "\\" + ZipFileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

                //Replace spaces with an underscore (_)
                string uriFileName = mFileName.Replace(" ", "_");

                //A Uri always starts with a forward slash "/"
                string zipUri = string.Concat("/", System.IO.Path.GetFileName(uriFileName));

                Uri partUri = new Uri(zipUri, UriKind.Relative);
                string contentType = System.Net.Mime.MediaTypeNames.Application.Zip;

                //The PackagePart contains the information:
                //Where to extract the file when it's extracted (partUri)
                //The type of content stream (MIME type) - (contentType)
                //The type of compression to use (CompressionOption.Normal)
                PackagePart pkgPart = zip.CreatePart(partUri, contentType, CompressionOption.Normal);

                //Read all of the bytes from the file to add to the zip file
                byte[] bites = System.IO.File.ReadAllBytes(mFileName);

                //Compress and write the bytes to the zip file
                pkgPart.GetStream().Write(bites, 0, bites.Length);

                zip.Close();
                //Close the zip file

                System.IO.File.Delete(mFileName);

                dynamic fs = System.IO.File.Create(mFileName);
                fs.Close();
                fs.Dispose();
            }
        }
        catch (Exception)
        {

        }

    }

    public static void ReadExcelFile(string _ExcelfilePath, ref List<MasterDrawingFile> _SOTRDrawinglist, ref List<MasterDrawingFile> _ClassApprovedDrawinglist, ref List<MasterDrawingFile> _ProductionDrawinglist)
    {

        try
        {
            excel.Application xlApp = null;
            try
            {
                xlApp = new excel.Application();

                if (System.IO.File.Exists(_ExcelfilePath))
                {
                    try
                    {
                        excel.Workbook xlWorkbook = xlApp.Workbooks.Open(_ExcelfilePath);
                        excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
                        excel.Range xlRange = xlWorksheet.UsedRange;

                        try
                        {
                            int rowCount = xlRange.Rows.Count;

                            for (int i = 2; i <= rowCount; i++)
                            {
                                if (xlRange.Cells[i, 1].Value2.ToString() != "")
                                {
                                    string DrawingDocumentType = xlRange.Cells[i, 1].Value2.ToString();
                                    string DocumentNumber = xlRange.Cells[i, 2].Value2.ToString();
                                    string DocumentDescription = xlRange.Cells[i, 3].Value2.ToString();
                                    string RevisionNumber = xlRange.Cells[i, 4].Value2.ToString();

                                    if (DrawingDocumentType.ToUpper().Trim() == "PRODUCTION DOCUMENT")
                                    {
                                        MasterDrawingFile masterDrawingFile = new MasterDrawingFile();
                                        if ((DrawingDocumentType.Trim() != "") && (DocumentNumber.Trim() != ""))
                                        {
                                            masterDrawingFile.DocumentType = DrawingDocumentType;
                                            masterDrawingFile.DocumentNumber = DocumentNumber;
                                            masterDrawingFile.DocumentDescription = DocumentDescription;
                                            masterDrawingFile.RevisionNumber = RevisionNumber;
                                            var _searchedProductionDrawinglist = from itemMasterDrawingFile in _ProductionDrawinglist
                                                                                 where itemMasterDrawingFile.DocumentNumber == DocumentNumber.Trim()
                                                                                 select itemMasterDrawingFile;
                                            if ((_searchedProductionDrawinglist != null) && (_searchedProductionDrawinglist.Count() == 0))
                                            {
                                                _ProductionDrawinglist.Add(masterDrawingFile);
                                            }

                                        }
                                    }
                                    else if (DrawingDocumentType.Trim().ToUpper() == "CLASS APPROVED DOCUMENT")
                                    {
                                        MasterDrawingFile masterDrawingFile = new MasterDrawingFile();
                                        if ((DrawingDocumentType.Trim() != "") && (DocumentNumber.Trim() != ""))
                                        {
                                            masterDrawingFile.DocumentType = DrawingDocumentType;
                                            masterDrawingFile.DocumentNumber = DocumentNumber;
                                            masterDrawingFile.DocumentDescription = DocumentDescription;
                                            masterDrawingFile.RevisionNumber = RevisionNumber;

                                            var _searchedClassApprovedDrawinglist = from itemMasterDrawingFile in _ClassApprovedDrawinglist
                                                                                    where itemMasterDrawingFile.DocumentNumber == DocumentNumber.Trim()
                                                                                    select itemMasterDrawingFile;
                                            if ((_searchedClassApprovedDrawinglist != null) && (_searchedClassApprovedDrawinglist.Count() == 0))
                                            {
                                                _ClassApprovedDrawinglist.Add(masterDrawingFile);
                                            }

                                        }
                                    }
                                    else if (DrawingDocumentType.Trim().ToUpper() == "SOTR")
                                    {
                                        MasterDrawingFile masterDrawingFile = new MasterDrawingFile();
                                        if ((DrawingDocumentType.Trim() != "") && (DocumentNumber.Trim() != ""))
                                        {
                                            masterDrawingFile.DocumentType = DrawingDocumentType;
                                            masterDrawingFile.DocumentNumber = DocumentNumber;
                                            masterDrawingFile.DocumentDescription = DocumentDescription;
                                            masterDrawingFile.RevisionNumber = RevisionNumber;
                                            var _searchedSOTRDrawinglist = from itemMasterDrawingFile in _SOTRDrawinglist
                                                                           where itemMasterDrawingFile.DocumentNumber == DocumentNumber.Trim()
                                                                           select itemMasterDrawingFile;
                                            if ((_searchedSOTRDrawinglist != null) && (_searchedSOTRDrawinglist.Count() == 0))
                                            {
                                                _SOTRDrawinglist.Add(masterDrawingFile);
                                            }

                                        }
                                    }
                                    else
                                    {

                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                            //cleanup
                            GC.Collect();
                            GC.WaitForPendingFinalizers();

                        }
                        catch (Exception)
                        {

                        }
                        finally
                        {
                            try
                            {
                                Marshal.ReleaseComObject(xlRange);
                                Marshal.ReleaseComObject(xlWorksheet);

                                //close and release
                                xlWorkbook.Close();
                                Marshal.ReleaseComObject(xlWorkbook);

                            }
                            catch (Exception)
                            {

                            }

                        }

                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Excel application not installed.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            finally
            {
                if (xlApp != null)
                {
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlApp);
                }
            }
        }
        catch (Exception ex1)
        {
            clsStaticGlobal.ErrHandlerLog(ex1);
        }
    }

    public static string VaultExplorerFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

    public static Dictionary<string, List<MasterDrawingFile>> BindingMasterDrawingsData(string _XMLFolderPath)
    {
        Dictionary<string, List<MasterDrawingFile>> _masterDrawingList = new Dictionary<string, List<MasterDrawingFile>>() { };
        List<MasterDrawingFile> SOTRDrawinglist = new List<MasterDrawingFile>() { };
        List<MasterDrawingFile> ClassApprovedDrawinglist = new List<MasterDrawingFile>() { };
        List<MasterDrawingFile> ProductionDrawinglist = new List<MasterDrawingFile>() { };
        try
        {
            string[] filePaths = Directory.GetFiles(_XMLFolderPath, "*.*");

            foreach (string _filepath in filePaths)
            {
                clsStaticGlobal.ReadExcelFile(_filepath, ref SOTRDrawinglist, ref ClassApprovedDrawinglist, ref ProductionDrawinglist);
            }

            _masterDrawingList.Add("PRODUCTION DOCUMENT", ProductionDrawinglist);
            _masterDrawingList.Add("CLASS APPROVED DOCUMENT", ClassApprovedDrawinglist);
            _masterDrawingList.Add("SOTR", SOTRDrawinglist);

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _masterDrawingList;
    }

    public static List<string> GetAllUserList()
    {
        List<string> userList = new List<string> { };

        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;

            User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllUsers();

            foreach (User item in users)
            {
                userList.Add(clsStaticGlobal.GetUserName(item));
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return userList;
    }

    public static string GetUserNameWithFirstandLast(string _name)
    {
        string UsernamewithFirstandLast = "";
        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllUsers();
            foreach (User item in users)
            {

                if (_name.ToUpper().Trim() == item.Name.ToUpper().Trim())
                {
                    UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                    break;
                }
                else
                {

                    string[] CustomerDocs = item.Name.Split(new char[] { '\\' });
                    if (CustomerDocs.Count() > 1)
                    {
                        if (CustomerDocs[1].Trim() == _name.Trim())
                        {
                            UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                            break;
                        }
                    }
                }

                if (item.LastName.Trim() == "")
                {
                    if ((_name.ToUpper().Trim() == item.Name.ToUpper().Trim()) || (item.FirstName.ToUpper().Trim() == _name.ToUpper().Trim()))
                    {
                        UsernamewithFirstandLast = item.FirstName.Trim();
                        break;
                    }
                    else
                    {
                        string[] CustomerDocs = item.Name.Split(new char[] { '\\' });

                        if (CustomerDocs.Count() > 1)
                        {
                            if (CustomerDocs[1].Trim() == _name.Trim())
                            {
                                UsernamewithFirstandLast = item.FirstName.Trim();
                                break;
                            }
                        }
                    }
                }
                else
                {
                    if ((_name.ToUpper().Trim() == item.Name.ToUpper().Trim()) || (item.FirstName.ToUpper().Trim() + " " + item.LastName.ToUpper().Trim() == _name.ToUpper().Trim()))
                    {
                        UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                        break;
                    }
                    else
                    {

                        string[] CustomerDocs = item.Name.Split(new char[] { '\\' });
                        if (CustomerDocs.Count() > 1)
                        {
                            if (CustomerDocs[1].Trim() == _name.Trim())
                            {
                                UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                                break;
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return UsernamewithFirstandLast.Trim();
    }

    public static long GetBuildSpecificationLifeCycleStateID()
    {
        long _stateID = -1;

        LfCycDef _ProjectLifeCycleDef = null;
        LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
        foreach (LfCycDef lcDef in lcDefs)
        {
            if (lcDef.DispName.ToUpper() == "PROJECT")
            {
                _ProjectLifeCycleDef = lcDef;
                break;
            }
        }

        if (_ProjectLifeCycleDef != null)
        {
            LfCycDef lifecycleDef = _ProjectLifeCycleDef;
            LfCycState[] states = lifecycleDef.StateArray;

            foreach (LfCycState state in states)
            {
                if ((state.DispName.ToUpper() == "BUILD SPECIFICATION") || (state.Name.ToUpper() == "BUILD SPECIFICATION"))
                {
                    _stateID = state.Id;
                    return _stateID;
                }
            }
        }

        return _stateID;
    }

    public static string GetUserName(User item)
    {
        string UserName = "";
        try
        {
            if (item.FirstName != null)
            {
                UserName = item.FirstName.Trim();
            }
            if (item.LastName != null)
            {
                if (UserName.Trim() == "")
                {
                    UserName = item.LastName.Trim();
                }
                else
                {
                    UserName = UserName.Trim() + " " + item.LastName.Trim();
                }

                UserName.Trim();
            }

            if (UserName.Trim() == "")
            {
                UserName = item.Name.Trim();
            }
        }
        catch (Exception)
        {

        }

        return UserName;
    }

    public static string Combine(string path1, string path2)
    {
        path1 = path1.Trim();
        path2 = path2.Trim();

        if (path1.EndsWith("/"))
        {
            path1 = path1.Remove(path1.Length - 1);
        }
        if (path2.StartsWith("/"))
        {
            path2 = path2.Substring(1);
        }
        return path1 + "/" + path2;
    }

    public static string EscapeHTML(string value)
    {
        string retVal = value;
        retVal = retVal.Replace("$", "%24");
        retVal = retVal.Replace("/", "%2f");
        retVal = retVal.Replace(" ", "+");
        return retVal;
    }

    public static string GeHyperLink(string vaultfilePath)
    {
        string hyperlink = "";
        try
        {
            Autodesk.Connectivity.WebServices.File file = null;
            Autodesk.Connectivity.WebServices.File[] files;
            files = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { vaultfilePath });
            if (files.Length != 0)
            {
                file = files[0];
            }

            UriBuilder newUri1 = new UriBuilder(clsStaticGlobal.connection.WebServiceManager.DocumentService.Url);
            newUri1.Path = "AutodeskDM/Services/EntityDataCommandRequest.aspx";
            newUri1.Query = string.Format("Vault={0}&ObjectId={1}&ObjectType={2}&Command=Select", clsStaticGlobal.connection.Vault, EscapeHTML(Combine(clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(file.FolderId).FullName, file.Name)), "File");
            hyperlink = newUri1.ToString();
        }
        catch (Exception)
        {

        }

        return hyperlink;
    }

    public static void GetProjectCodes()
    {
        try
        {
            clsStaticGlobal.ProjectCodeItemCollection = new ObservableCollection<ProjectCodes> { };
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.Category.Name.ToUpper() == "PROJECT")
                    {
                        clsStaticGlobal.ProjectCodeItemCollection.Add(new ProjectCodes() { ProjectCodeName = folder.EntityName });
                    }
                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static String GetFilePropertyValue(string PropName, long fileID, bool isSystemProp)
    {
        String value = null;

        PropInst[] fileProperties = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { fileID });
        try
        {
            foreach (PropInst prop in fileProperties)
            {
                PropertyDefinition propdef = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitionById(prop.PropDefId);

                if (propdef.IsSystem == isSystemProp)
                {
                    if ((propdef.DisplayName.ToUpper().Trim() == PropName.ToUpper().Trim()) || (propdef.SystemName.ToUpper().Trim() == PropName.ToUpper().Trim()))
                    {
                        if ((prop.Val != null) && (prop.Val.ToString().Trim() != ""))
                        {
                            try
                            {
                                return prop.Val.ToString();
                            }
                            catch (Exception)
                            {

                            }
                        }

                    }
                }

            }
        }
        catch (Exception)
        {

        }

        return value;
    }

    public static void AllFileStates()
    {
        try
        {
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            LfCycDef lfcycledefShipTech = null;
            foreach (LfCycDef lfcycledef in lcDefs)
            {
                if ((lfcycledef.DispName.ToUpper() == "BUILD SPECIFICATION") || (lfcycledef.Name.ToUpper() == "BUILD SPECIFICATION") || (lfcycledef.Name.ToUpper() == "CRAR") || (lfcycledef.DispName.ToUpper() == "CRAR"))
                {
                    lfcycledefShipTech = lfcycledef;
                    break;
                }
            }

            if (lfcycledefShipTech != null)
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                foreach (LfCycState LfCycStateitem in lfcycledefShipTech.StateArray)
                {
                    clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = LfCycStateitem.DispName });
                }
            }
            else
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Create" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Review" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Approve" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Release" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Obsolete" });
            }



        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void AllCompletionActivities()
    {
        try
        {
            clsStaticGlobal.CompletionActivitiesCollection.Add(new CompletionActivities() { CompletionActivity = "All" });
            clsStaticGlobal.CompletionActivitiesCollection.Add(new CompletionActivities() { CompletionActivity = "Completed" });
            clsStaticGlobal.CompletionActivitiesCollection.Add(new CompletionActivities() { CompletionActivity = "Work in Progress" });

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void ReleaseObject(object obj)
    {
        try
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
        }
        catch (Exception)
        {

            obj = null;
        }
        finally
        {
            GC.Collect();
        }
    }

    public static string GetPropertyValue(string _VaultfilePath)
    {
        string _RelatedDAD = "";
        try
        {
            PropertyDefinitionDictionary props = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitions(VDF.Vault.Currency.Entities.EntityClassIds.Files, null, PropertyDefinitionFilter.IncludeAll);
            PropertyDefinition myRelatedDAD = null;
            PropertyDefinition propDef;
            foreach (KeyValuePair<string, Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties.PropertyDefinition> myKeyValPair in props)
            {
                propDef = myKeyValPair.Value;

                if (propDef.DisplayName.ToUpper().Trim() == "RELATED DAD")
                {
                    myRelatedDAD = propDef;
                    break;
                }
            }

            if (myRelatedDAD != null)
            {
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
                if (SingleFile.Length != 0)
                {

                    VDF.Vault.Currency.Entities.FileIteration myFile = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, SingleFile[0]);

                    _RelatedDAD = clsStaticGlobal.connection.PropertyManager.GetPropertyValue(myFile, myRelatedDAD, null).ToString();
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _RelatedDAD;
    }

    public static VDF.Vault.Currency.Entities.Folder GetorCreateBuildSpecificationFolder(string SelectedProjectCode)
    {
        try
        {
            Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);
            Cat _BuildSpecificationFolderCategory = null;
            foreach (Cat _cat in _Categories)
            {
                if (_cat.Name.Trim().ToUpper() == "FOLDER")
                {
                    _BuildSpecificationFolderCategory = _cat;
                    break;
                }
            }

            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            VDF.Vault.Currency.Entities.Folder _ProjectFolder = null;
            VDF.Vault.Currency.Entities.Folder _BuildSpecificationFolder = null;
            VDF.Vault.Currency.Entities.Folder _VaultSOTRNumberFolder = null;
            VDF.Vault.Currency.Entities.Folder _VaultClassDrawingFolder = null;
            VDF.Vault.Currency.Entities.Folder _VaultDADDrawingFolder = null;
            VDF.Vault.Currency.Entities.Folder _VaultProductionDrawingFolder = null;
            VDF.Vault.Currency.Entities.Folder _VaultMasterDrawingListFolder = null;

            IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.EntityName == SelectedProjectCode)
                    {
                        _ProjectFolder = folder;
                        clsStaticGlobal.ProjectFolder = folder;
                        break;
                    }
                }
            }

            if (_ProjectFolder != null)
            {
                IEnumerable<VDF.Vault.Currency.Entities.Folder> SubFolders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_ProjectFolder, false, false);
                if (SubFolders != null && SubFolders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in SubFolders)
                    {
                        if (folder.EntityName == BuildSpecificationFolderName)
                        {
                            _BuildSpecificationFolder = folder;
                            break;
                        }
                    }
                }
            }

            if (_BuildSpecificationFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(BuildSpecificationFolderName, _ProjectFolder.Id, false, _BuildSpecificationFolderCategory.Id);
                _BuildSpecificationFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                clsStaticGlobal.VaultBuildSpecificationFolder = _BuildSpecificationFolder;
            }
            else
            {
                clsStaticGlobal.VaultBuildSpecificationFolder = _BuildSpecificationFolder;
            }

            try
            {
                if (_VaultSOTRNumberFolder == null)
                {
                    string _SOTRNumberPath = _ProjectFolder.FullName + "/Design and Engineering/" + BuildSpecificationSOTRNumberFolderName;
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(_SOTRNumberPath);
                    _VaultSOTRNumberFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                    clsStaticGlobal.VaultSOTRNumberFolder = _VaultSOTRNumberFolder;
                }
            }
            catch (Exception)
            {

            }

            try
            {
                if (_VaultClassDrawingFolder == null)
                {
                    string _ClassDrawingPath = _ProjectFolder.FullName + "/Design and Engineering/" + BuildSpecificationClassDrawingFolderName;
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(_ClassDrawingPath);
                    _VaultClassDrawingFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                    clsStaticGlobal.VaultClassDrawingFolder = _VaultClassDrawingFolder;
                }
            }
            catch (Exception)
            {

            }

            try
            {
                if (_VaultDADDrawingFolder == null)
                {
                    string _DADDrawingPath = _ProjectFolder.FullName + "/Design and Engineering/" + BuildSpecificationClassDrawingFolderName + "/" + BuildSpecificationDADDrawingFolderName;
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(_DADDrawingPath);
                    _VaultDADDrawingFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                    clsStaticGlobal.VaultDADDrawingFolder = _VaultDADDrawingFolder;
                }
            }
            catch (Exception)
            {

            }

            try
            {
                if (_VaultProductionDrawingFolder == null)
                {
                    string _ProductionDrawingPath = _ProjectFolder.FullName + "/Design and Engineering/" + BuildSpecificationProductionDrawingFolderName;
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(_ProductionDrawingPath);
                    _VaultProductionDrawingFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                    clsStaticGlobal.VaultProductionDrawingFolder = _VaultProductionDrawingFolder;
                }
            }
            catch (Exception)
            {

            }

            try
            {

                if (_VaultMasterDrawingListFolder == null)
                {
                    string _tMatserDrawingListPath = _ProjectFolder.FullName + "/Design and Engineering/" + BuildSpecificationProductionDrawingFolderName + "/" + BuildSpecificationMasterDrawingListFolderName;
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(_tMatserDrawingListPath);
                    _VaultMasterDrawingListFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                    clsStaticGlobal.VaultMasterDrawingListFolder = _VaultMasterDrawingListFolder;
                }
            }
            catch (Exception)
            {

            }


            return _BuildSpecificationFolder;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return null;
        }
    }

    public static string GetFileNameWithoutExtension(string _filename)
    {
        int fileExtPos = _filename.LastIndexOf(".");
        if (fileExtPos >= 0)
            _filename = _filename.Substring(0, fileExtPos);
        return _filename;
    }

    public static void DeleteFileFromDirectory(string _DirectoryPath)
    {
        try
        {
            if (Directory.Exists(_DirectoryPath))
            {
                foreach (string file in Directory.GetFiles(_DirectoryPath))
                {
                    System.IO.File.SetAttributes(file, FileAttributes.Normal);
                    System.IO.File.Delete(file);
                }
            }
        }
        catch (Exception ex)
        {
            System.Windows.Forms.MessageBox.Show("Error in deleting files.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static string GetFileExtension(string fileName)
    {
        string ext = string.Empty;
        try
        {
            int fileExtPos = fileName.LastIndexOf(".", StringComparison.Ordinal);
            if (fileExtPos >= 0)
            {
                ext = fileName.Substring(fileExtPos, fileName.Length - fileExtPos);
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return ext;
    }

    public static void BindingDataSingleWrite(SingleBuildSpecificationSummary _objSingleBuildSpecificationSummary, string XMLFilePath, bool _IsEdit)
    {
        try
        {
            if (Directory.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode))
            {
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
            }
            else
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode);
            }

            if (_IsEdit == true)
            {
                CheckoutFile(_objSingleBuildSpecificationSummary.BuildSpecificationFileName, LocalXMLBuildSpecificationFolderPath);
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
                XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, _objSingleBuildSpecificationSummary);
                tw.Close();

                CheckinFile(_objSingleBuildSpecificationSummary.BuildSpecificationFileName, LocalXMLBuildSpecificationFolderPath, _objSingleBuildSpecificationSummary.BuildSpecificationRemark);
            }
            else
            {
                XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, _objSingleBuildSpecificationSummary);
                tw.Close();
                AddFileintoVault(clsStaticGlobal.VaultBuildSpecificationFolder, XMLFilePath, _objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber, _objSingleBuildSpecificationSummary.BuildSpecificationRemark);
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void AddFileintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _BuildSpecificationFolder, string _XMLfilePath, string _BuildSpecificationName, string _remark)
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _BuildSpecificationFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_XMLfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_XMLfilePath), _remark, DateTime.Now, null, null, FileClassification.None, false, fileStream);
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool UpdateFileProperties(Autodesk.Connectivity.WebServices.File _File, string _FileCategory, string _DisplayName, string _Value)
    {
        bool _Sucess = true;
        try
        {
            List<PropInstParam> propInstParams = new List<PropInstParam>();
            PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

            if (_File.Cat.CatName == _FileCategory)
            {
                PropInst[] source = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { _File.MasterId });

                foreach (PropDef def in clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE"))
                {
                    if (def.IsSys == false & def.IsAct == true)
                    {
                        if (def.DispName == _DisplayName)
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = _DisplayName;
                            propInstParams.Add(propInst);
                            break;
                        }
                    }
                }
            }

            PropInstParamArray propInstParamsArray = new PropInstParamArray();
            propInstParamsArray.Items = propInstParams.ToArray();
            propInstParamsArrays[0] = propInstParamsArray;
            clsStaticGlobal.connection.WebServiceManager.DocumentService.UpdateFileProperties(new long[] { _File.MasterId }, propInstParamsArrays);

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _Sucess;
    }

    public static bool DownloadFile(string _XMLfileName, string _DownloadedPath)
    {
        string _VaultFilePath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + _XMLfileName;
        _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

        bool isSucess = false;
        try
        {
            if (!Directory.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode))
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
            }
            else
            {
                if (System.IO.File.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName))
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName);
                }
            }

            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                VDF.Vault.Currency.Entities.FileIteration fileIter = new FileIteration(clsStaticGlobal.connection, newFile);

                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
                settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in results.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }
                isSucess = true;
            }
            else
            {
                isSucess = false;
            }


        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            System.Windows.Forms.MessageBox.Show("Error in file download.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return isSucess;

    }

    public static void CheckoutFile(string _XMLfileName, string _DownloadedPath)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                //clsStaticGlobal.connection.WorkingFoldersManager.SetWorkingFolder()
                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);
                //
                settings.DefaultAcquisitionOption = VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download;

                settings.AddEntityToAcquire(oFileIteration);

                VDF.Vault.Settings.FileRelationshipGatheringSettings fileRelSetting = settings.OptionsRelationshipGathering.FileRelationshipSettings;
                fileRelSetting.IncludeChildren = true;
                fileRelSetting.IncludeParents = false;
                fileRelSetting.IncludeLibraryContents = true;
                settings.AddEntityToAcquire(oFileIteration);
                settings.OptionsResolution.SyncWithRemoteSiteSetting = VDF.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;
                settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

                var m_res = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in m_res.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void DownlodFile_Fource(VDF.Vault.Currency.Entities.FileIteration file, VDF.Vault.Currency.Connections.Connection connection, string _DownloadedPath)
    {
        try
        {
            //' download individual files to a temp location
            VDF.Vault.Settings.AcquireFilesSettings settings = new Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings(connection);

            settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);

            settings.AddFileToAcquire(file, Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);

            settings.OptionsResolution.SyncWithRemoteSiteSetting = Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;

            settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

            Autodesk.DataManagement.Client.Framework.Vault.Results.AcquireFilesResults results = connection.FileManager.AcquireFiles(settings);

            foreach (var _res in results.FileResults)
            {
                if (_res.Status == Autodesk.DataManagement.Client.Framework.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                {
                    System.Windows.MessageBox.Show("Unable to Download File : " + Environment.NewLine + _res.File.EntityName + Environment.NewLine + "Download manualy and Resolve Link after Complete.", "Download Vault File", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void CheckinFile(string _XMLfileName, string _DownloadedPath, string _remark)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;
            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                VDF.Currency.FolderPathAbsolute fldrPath = new VDF.Currency.FolderPathAbsolute(_DownloadedPath);
                string filePath = Path.Combine(fldrPath.ToString(), oFileIteration.EntityName);
                VDF.Currency.FilePathAbsolute filePathAbs = new VDF.Currency.FilePathAbsolute(filePath);

                if (System.IO.File.Exists(filePath))
                {
                    if (oFileIteration.IsCheckedOut == true)
                    {
                        try
                        {
                            clsStaticGlobal.connection.FileManager.CheckinFile(oFileIteration, _remark, false, new Autodesk.Connectivity.WebServices.FileAssocParam[] { }, null, false, null,
                                                           Autodesk.Connectivity.WebServices.FileClassification.None, false, filePathAbs);
                        }
                        catch (Exception ex1)
                        {
                            System.Windows.Forms.MessageBox.Show(ex1.ToString() + ex1.StackTrace);
                        }

                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static bool CheckIsBuildSpecificationAllReleaseMode(SingleBuildSpecificationSummary objSingleBuildSpecificationSummary, out string warning)
    {
        bool IsBuildSpecificationAllReleaseMode = true;
        warning = "";
        try
        {
            if ((objSingleBuildSpecificationSummary.BuildSpecificationSECTION == null) || (objSingleBuildSpecificationSummary.BuildSpecificationSECTION.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationParaNumber == null) || (objSingleBuildSpecificationSummary.BuildSpecificationParaNumber.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationSubParaNumber == null) || (objSingleBuildSpecificationSummary.BuildSpecificationSubParaNumber.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationSFI == null) || (objSingleBuildSpecificationSummary.BuildSpecificationSFI.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine == null) || (objSingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationFunction == null) || (objSingleBuildSpecificationSummary.BuildSpecificationFunction.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson == null) || (objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson == null) || (objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator == null) || (objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if ((objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator == null) || (objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator.Trim() == ""))
            {
                IsBuildSpecificationAllReleaseMode = false;
            }

            if (objSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired.Trim().ToUpper() == "YES")
            {
                if (objSingleBuildSpecificationSummary.ListSOTRNumber.Count == 0)
                {
                    IsBuildSpecificationAllReleaseMode = false;
                }
                foreach (SOTRNumber item in objSingleBuildSpecificationSummary.ListSOTRNumber)
                {
                    if (item.FileStatus.ToUpper() != "RELEASE")
                    {
                        IsBuildSpecificationAllReleaseMode = false;
                    }
                }
            }

            if (objSingleBuildSpecificationSummary.ListClassDrawing.Count == 0)
            {
                IsBuildSpecificationAllReleaseMode = false;
            }
            else
            {
                foreach (ClassDrawing item in objSingleBuildSpecificationSummary.ListClassDrawing)
                {
                    if (item.FileType == "CLASS APPROVED")
                    {
                        if (item.FileStatus.ToUpper() != "RELEASE")
                        {
                            IsBuildSpecificationAllReleaseMode = false;
                        }
                    }

                }
            }


            if (objSingleBuildSpecificationSummary.ListProductionDrawing.Count == 0)
            {
                IsBuildSpecificationAllReleaseMode = false;
            }
            else
            {
                foreach (ProductionDrawing item in objSingleBuildSpecificationSummary.ListProductionDrawing)
                {
                    if (item.FileStatus.ToUpper() != "RELEASE")
                    {
                        IsBuildSpecificationAllReleaseMode = false;
                    }
                }
            }

        }

        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            IsBuildSpecificationAllReleaseMode = false;
        }

        if (IsBuildSpecificationAllReleaseMode == true)
        {
            objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = true;
            objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = "Completed";
        }
        else
        {
            objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = false;
            objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = "Work in Progress";
        }

        return IsBuildSpecificationAllReleaseMode;
    }

    public static Dictionary<string, List<string>> CheckBuildSpecificationAllNotlReleaseModeDoc(SingleBuildSpecificationSummary objSingleBuildSpecificationSummary)
    {
        Dictionary<string, List<string>> incompleteStateDocuments = new Dictionary<string, List<string>>();

        try
        {
            List<string> _sotrDOcs = new List<string>();
            if (objSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired.Trim().ToUpper() == "YES")
            {
                foreach (SOTRNumber item in objSingleBuildSpecificationSummary.ListSOTRNumber)
                {
                    if (item.FileStatus.ToUpper() != "RELEASE")
                    {
                        _sotrDOcs.Add(item.FileNumber);
                    }
                }

                if (_sotrDOcs.Count > 0)
                {
                    incompleteStateDocuments.Add("SOTR Document", _sotrDOcs);
                }
            }

            List<string> _classDOcs = new List<string>();
            foreach (ClassDrawing item in objSingleBuildSpecificationSummary.ListClassDrawing)
            {
                if (item.FileType == "CLASS APPROVED")
                {
                    if (item.FileStatus.ToUpper() != "RELEASE")
                    {
                        _classDOcs.Add(item.FileNumber);
                    }
                }

            }

            if (_classDOcs.Count > 0)
            {
                incompleteStateDocuments.Add("Class Approved Document", _classDOcs);
            }

            List<string> _productionDOcs = new List<string>();
            foreach (ProductionDrawing item in objSingleBuildSpecificationSummary.ListProductionDrawing)
            {
                if (item.FileStatus.ToUpper() != "RELEASE")
                {
                    _productionDOcs.Add(item.FileNumber);
                }
            }

            if (_productionDOcs.Count > 0)
            {
                incompleteStateDocuments.Add("Production Document", _productionDOcs);
            }

        }

        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);

        }

        return incompleteStateDocuments;
    }

    public static Autodesk.Connectivity.WebServices.File getVaultFileByPath(string vaultfilepath)
    {
        Autodesk.Connectivity.WebServices.File outputfile = null;

        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFiles;

            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { vaultfilepath });

            if (SingleFiles.Length != 0)
            {
                if (SingleFiles[0].Id != -1)
                {
                    outputfile = SingleFiles[0];
                    return outputfile;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        catch (Exception)
        {

        }

        return null;

    }

    public static Autodesk.Connectivity.WebServices.Folder getVaultFolderByPath(string vaultfolderpath)
    {
        Autodesk.Connectivity.WebServices.Folder outputfolder = null;
        try
        {
            outputfolder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(vaultfolderpath);

            if (outputfolder.Id != -1)
            {
                return outputfolder;
            }
            else
            {
                return null;
            }
        }
        catch (Exception)
        {

        }

        return null;

    }

    public static void BindingDataMultipleRead(ref clsBuildSpecificationSummary objBuildSpecificationCollection, SingleBuildSpecificationSummary objSingleBuildSpecificationSummary, string _XMLFolderPath, string _ProjectCode)
    {
        try
        {
            List<SingleBuildSpecificationSummary> listSingleBuildSpecificationSummary = new List<SingleBuildSpecificationSummary>();
            _XMLFolderPath = _XMLFolderPath + "\\" + _ProjectCode;
            objBuildSpecificationCollection = new clsBuildSpecificationSummary();
            XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));
            objSingleBuildSpecificationSummary = new SingleBuildSpecificationSummary();
            string[] filePaths = Directory.GetFiles(_XMLFolderPath, "*.xml");

            foreach (string _filepath in filePaths)
            {
                using (var sr = new StreamReader(_filepath))
                {
                    objSingleBuildSpecificationSummary = (SingleBuildSpecificationSummary)xs.Deserialize(sr);
                }
                if (objSingleBuildSpecificationSummary != null)
                {
                    string _Shipstatus = "";
                    string _Shipremark = "";
                    string _Shiprevision = "";

                    clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath, out _Shipstatus, out _Shipremark, out _Shiprevision);
                    objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = _Shipstatus;
                    objSingleBuildSpecificationSummary.BuildSpecificationRemark = _Shipremark;

                    // Debugger.Launch();
                    if (objSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                    {
                        foreach (SOTRNumber item in objSingleBuildSpecificationSummary.ListSOTRNumber)
                        {
                            try
                            {
                                if (item.FilePath != "")
                                {
                                    string _status = "";
                                    string _remark = "";
                                    string _revision = "";

                                    if (item.FilePath != "")
                                    {
                                        clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                        item.FileStatus = _status;
                                        item.FileRemark = _remark;
                                        item.FileRevision = _revision;
                                    }
                                }
                                else
                                {
                                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item.FileName, "SOTR", clsStaticGlobal.ProjectFolder);

                                    if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                    {
                                        Autodesk.Connectivity.WebServices.Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                        string _Searchedfilepath = _folder.FullName + "/" + _SearchedFile.Name;

                                        string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                        if (fileDec == null)
                                        {
                                            fileDec = "";
                                        }
                                        string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                                        if (fileSection == null)
                                        {
                                            fileSection = "";
                                        }
                                        string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _SearchedFile.Id, false); //Class Approved Drawing Number
                                        if (fileRelatedDAD == null)
                                        {
                                            fileRelatedDAD = "";
                                        }

                                        string revision = _SearchedFile.FileRev.Label;
                                        if (revision == null)
                                        {
                                            revision = "";
                                        }

                                        try
                                        {
                                            item.IsCheckedSOTRNumber = false;
                                            item.FileType = "SOTR";
                                            item.FileName = item.FileName;
                                            item.FileNumber = item.FileNumber;
                                            item.FileDesc = fileDec;
                                            item.FileSection = fileSection;
                                            item.FilePath = _Searchedfilepath;
                                            item.FileRemark = _SearchedFile.Comm;
                                            item.FileRevision = revision;
                                            item.FileStatus = _SearchedFile.FileLfCyc.LfCycStateName;
                                        }
                                        catch (Exception)
                                        {

                                        }

                                    }
                                }
                            }
                            catch (Exception)
                            {

                            }

                        }
                    }

                    if (objSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                    {
                        ObservableCollection<ClassDrawing> newDADClassDrawingList = new ObservableCollection<ClassDrawing>();

                        foreach (ClassDrawing item in objSingleBuildSpecificationSummary.ListClassDrawing)
                        {
                            if (item.FileType.ToUpper() == "CLASS APPROVED")
                            {
                                string _status = "";
                                string _remark = "";
                                string _revision = "";
                                if (item.FilePath != "")
                                {
                                    clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                    item.IsCheckedClassDrawing = false;
                                    item.FileStatus = _status;
                                    item.FileRemark = _remark;
                                    item.FileRevision = _revision;
                                }
                                else
                                {
                                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item.FileName, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);

                                    if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                    {
                                        Autodesk.Connectivity.WebServices.Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                        string _Searchedfilepath = _folder.FullName + "/" + _SearchedFile.Name;

                                        string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                        if (fileDec == null)
                                        {
                                            fileDec = "";
                                        }
                                        string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                                        if (fileSection == null)
                                        {
                                            fileSection = "";
                                        }
                                        string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _SearchedFile.Id, false); //Class Approved Drawing Number
                                        if (fileRelatedDAD == null)
                                        {
                                            fileRelatedDAD = "";
                                        }

                                        try
                                        {
                                            item.IsCheckedClassDrawing = false;
                                            item.FileType = "CLASS APPROVED";
                                            item.FileName = item.FileName;
                                            item.FileNumber = item.FileNumber;
                                            item.FileDesc = fileDec;
                                            item.FileSection = fileSection;
                                            item.FileRelatedDAD = fileRelatedDAD;
                                            item.FilePath = _Searchedfilepath;
                                            item.FileRemark = _SearchedFile.Comm;
                                            item.FileRevision = _SearchedFile.FileRev.Label;
                                            item.FileStatus = _SearchedFile.FileLfCyc.LfCycStateName;
                                            item.FileUsedIn = "";
                                        }
                                        catch (Exception)
                                        {

                                        }


                                        FileAssocArray[] attachmentsFileList = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFileAssociationsByMasterIds(new long[] { _SearchedFile.MasterId }, FileAssociationTypeEnum.Attachment, true, FileAssociationTypeEnum.Attachment, true, true, true, false);

                                        foreach (FileAssocArray itemFileAssocArray in attachmentsFileList)
                                        {
                                            try
                                            {
                                                foreach (FileAssoc itemFileAssoc in itemFileAssocArray.FileAssocs)
                                                {
                                                    try
                                                    {
                                                        if (itemFileAssoc.ParFile != null)
                                                        {
                                                            Autodesk.Connectivity.WebServices.Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(itemFileAssoc.ParFile.FolderId);
                                                            string filePath = folder.FullName + "/" + itemFileAssoc.ParFile.Name;
                                                            string fileName = itemFileAssoc.ParFile.Name;
                                                            string fileRemark = itemFileAssoc.ParFile.Comm;
                                                            string fileStatus = itemFileAssoc.ParFile.FileLfCyc.LfCycStateName;
                                                            string fileRevision = itemFileAssoc.ParFile.FileRev.Label.ToString();
                                                            string fileDec1 = clsStaticGlobal.GetFilePropertyValue("Description", itemFileAssoc.Id, false);
                                                            if (fileDec1 == null)
                                                            {
                                                                fileDec1 = "";
                                                            }
                                                            newDADClassDrawingList.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FileNumber = "", FileDesc = fileDec1, FileSection = "", FilePath = filePath, FileRemark = fileRemark, FileRevision = fileRevision, FileStatus = fileStatus, FileRelatedDAD = "", FileUsedIn = _SearchedFile.Name });
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        clsStaticGlobal.ErrHandlerLog(ex);
                                                    }

                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                clsStaticGlobal.ErrHandlerLog(ex);
                                            }

                                        }
                                    }
                                }
                            }
                            else
                            {
                                string _status = "";
                                string _remark = "";
                                string _revision = "";

                                if (item.FilePath != "")
                                {
                                    clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                    item.IsCheckedClassDrawing = false;
                                    item.FileStatus = "Exist";
                                    item.FileRemark = _remark;
                                    item.FileRevision = "";
                                }

                            }

                        }
                        foreach (ClassDrawing item in newDADClassDrawingList)
                        {
                            objSingleBuildSpecificationSummary.ListClassDrawing.Add(item);
                        }

                        string _ClassDrawing = "";
                        string _ClassDrawingDAD = "";

                        foreach (ClassDrawing _item in objSingleBuildSpecificationSummary.ListClassDrawing)
                        {
                            if (_item.FileType == "CLASS APPROVED")
                            {
                                if (_ClassDrawing.Trim() == "")
                                {
                                    _ClassDrawing = "CLASS APPROVED : " + _item.FileName;
                                }
                                else
                                {
                                    _ClassDrawing = _ClassDrawing + "," + Environment.NewLine + "CLASS APPROVED : " + _item.FileName;
                                }
                            }
                            else
                            {
                                if (_ClassDrawingDAD.Trim() == "")
                                {
                                    _ClassDrawingDAD = "DAD : " + _item.FileName;
                                }
                                else
                                {
                                    _ClassDrawingDAD = _ClassDrawingDAD + "," + Environment.NewLine + "DAD : " + _item.FileName;
                                }
                            }

                        }
                        objSingleBuildSpecificationSummary.BuildSpecificationClassDrawing = _ClassDrawing + Environment.NewLine + _ClassDrawingDAD;
                    }

                    if (objSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                    {
                        foreach (ProductionDrawing item in objSingleBuildSpecificationSummary.ListProductionDrawing)
                        {
                            string _status = "";
                            string _remark = "";
                            string _revision = "";
                            if (item.FilePath != "")
                            {
                                clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                item.IsCheckedProductionDrawing = false;
                                item.FileStatus = _status;
                                item.FileRemark = _remark;
                                item.FileRevision = _revision;
                            }
                            else
                            {
                                Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item.FileName, "PRODUCTION DOCUMENT", clsStaticGlobal.ProjectFolder);

                                if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                {
                                    Autodesk.Connectivity.WebServices.Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                    string _Searchedfilepath = _folder.FullName + "/" + _SearchedFile.Name;

                                    string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                    if (fileDec == null)
                                    {
                                        fileDec = "";
                                    }
                                    string fileElement = clsStaticGlobal.GetFilePropertyValue("Element", _SearchedFile.Id, false);
                                    if (fileElement == null)
                                    {
                                        fileElement = "";
                                    }
                                    string filesfi = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                                    if (filesfi == null)
                                    {
                                        filesfi = "";
                                    }
                                    string fileRelevantClassApproved = clsStaticGlobal.GetFilePropertyValue("Class Approved Drawing Number", _SearchedFile.Id, false); //Class Approved Drawing Number
                                    if (fileRelevantClassApproved == null)
                                    {
                                        fileRelevantClassApproved = "";
                                    }

                                    try
                                    {
                                        item.IsCheckedProductionDrawing = false;
                                        item.FileType = "PRODUCTION";
                                        item.FileName = item.FileName;
                                        item.FileNumber = item.FileNumber;
                                        item.FileDesc = fileDec;
                                        item.FileElement = fileElement;
                                        item.FileSFI = filesfi;
                                        item.FileRelevantClassApproved = fileRelevantClassApproved;
                                        item.FilePath = _Searchedfilepath;
                                        item.FileRemark = _SearchedFile.Comm;
                                        item.FileRevision = _SearchedFile.FileRev.Label;
                                        item.FileStatus = _SearchedFile.FileLfCyc.LfCycStateName;
                                        item.FileUsedIn = "";
                                    }
                                    catch (Exception)
                                    {

                                    }


                                }
                            }

                        }

                    }

                    string warning = "";
                    clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(objSingleBuildSpecificationSummary, out warning);

                    clsStaticGlobal.ListBuildSpecificationNumbers.Add(objSingleBuildSpecificationSummary.BuildSpecificationNumber);
                    listSingleBuildSpecificationSummary.Add(objSingleBuildSpecificationSummary);

                    clsStaticGlobal.ListBuildSpecificationNumbers.Sort();
                }
            }
            objBuildSpecificationCollection.collectionBuildSpecification = listSingleBuildSpecificationSummary.OrderBy(o => o.BuildSpecificationNumber).ToList();
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static SingleBuildSpecificationSummary BindingDataSingleRead(SingleBuildSpecificationSummary objSingleBuildSpecificationSummary, string _XMLFilePath)
    {
        objSingleBuildSpecificationSummary = new SingleBuildSpecificationSummary();

        try
        {
            if (System.IO.File.Exists(_XMLFilePath) == true)
            {
                XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));

                using (var sr = new StreamReader(_XMLFilePath))
                {
                    objSingleBuildSpecificationSummary = (SingleBuildSpecificationSummary)xs.Deserialize(sr);
                    return objSingleBuildSpecificationSummary;
                }
            }
            else
            {
                return objSingleBuildSpecificationSummary;
            }

        }
        catch (Exception)
        {
            return objSingleBuildSpecificationSummary;
        }

    }

    public static List<Autodesk.Connectivity.WebServices.File> FilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound, string _FolderName, string _Category, List<Autodesk.Connectivity.WebServices.File> SearchedFiles)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper() == _FolderName.ToUpper())
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if (file.Cat.CatName.ToUpper() == _Category.ToUpper())
                            {
                                SearchedFiles.Add(file);
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursiveFilesInFolder(folder, serviceManager, IsFolderFound, _FolderName, _Category, SearchedFiles);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        FilesInFolder(folder, serviceManager, IsFolderFound, _FolderName, _Category, SearchedFiles);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return SearchedFiles;
    }

    public static void RecursiveFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound, string _FolderName, string _Category, List<Autodesk.Connectivity.WebServices.File> SearchedFiles)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Cat.CatName.ToUpper() == _Category.ToUpper())
                    {
                        SearchedFiles.Add(file);
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursiveFilesInFolder(folder, serviceManager, IsFolderFound, _FolderName, _Category, SearchedFiles);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void PrintSOTRNumberFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper().Contains(BuildSpecificationSOTRNumberFolderName.ToUpper()))
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if (file.Cat.CatName.ToUpper() == "SORT")
                            {
                                clsStaticGlobal.SOTRNumberFiles.Add(file);
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintSOTRNumberFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintSOTRNumberFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintSOTRNumberFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Cat.CatName.ToUpper() == "SORT")
                    {
                        clsStaticGlobal.SOTRNumberFiles.Add(file);
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintSOTRNumberFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void PrintClassDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper().Contains(BuildSpecificationClassDrawingFolderName.ToUpper()))
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if (file.Cat.CatName.ToUpper() == "CLASS APPROVED DRAWINGS")
                            {
                                clsStaticGlobal.ClassDrawingFiles.Add(file);
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintClassDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintClassDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintClassDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Cat.CatName.ToUpper() == "CLASS APPROVED DRAWINGS")
                    {
                        clsStaticGlobal.ClassDrawingFiles.Add(file);
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintClassDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void PrintDADDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper().Contains(BuildSpecificationDADDrawingFolderName.ToUpper()))
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            clsStaticGlobal.DADDrawingFiles.Add(file);
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintDADDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintDADDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintDADDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    clsStaticGlobal.DADDrawingFiles.Add(file);
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintDADDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void PrintProductionDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper().Contains(BuildSpecificationProductionDrawingFolderName.ToUpper()))
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if (file.Cat.CatName.ToUpper() == "PRODUCTION DRAWINGS")
                            {
                                clsStaticGlobal.ProductionDrawingFiles.Add(file);
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintProductionDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintProductionDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintProductionDrawingFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Cat.CatName.ToUpper() == "PRODUCTION DRAWINGS")
                    {
                        clsStaticGlobal.ProductionDrawingFiles.Add(file);
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintProductionDrawingFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool AddReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _BuildSpecificationReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _BuildSpecificationReferenceDocFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_LocalfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_LocalfilePath), Path.GetFileName(_LocalfilePath), DateTime.Now, null, null, FileClassification.None, false, fileStream);
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static bool DeleteReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _BuildSpecificationReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(_BuildSpecificationReferenceDocFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (_BuildSpecificationReferenceDocFolder.FullName + "/" + file.Name == _LocalfilePath)
                    {
                        clsStaticGlobal.connection.WebServiceManager.DocumentService.DeleteFileFromFolder(file.MasterId, _BuildSpecificationReferenceDocFolder.Id);
                        return true;
                    }
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static string GetClassApprovedDrawingStatus(string _VaultfilePath)
    {
        string _DrawingStatus = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _DrawingStatus = SingleFile[0].FileLfCyc.LfCycStateName;
            }
            return _DrawingStatus;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _DrawingStatus;
        }
    }

    public static void GetFileStateAndRemark(string _VaultfilePath, out string state, out string remark)
    {
        state = "";
        remark = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                state = SingleFile[0].FileLfCyc.LfCycStateName;
                remark = SingleFile[0].Comm;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static string GetClassApprovedDrawingRevision(string _VaultfilePath)
    {
        string _DrawingRevison = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _DrawingRevison = SingleFile[0].FileRev.Label.ToString();
            }
            return _DrawingRevison;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _DrawingRevison;
        }
    }

    public static List<string> GetFileVersions(string _VaultfilePath)
    {
        List<string> _FileVersionList = new List<string> { };
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFilesByMasterId(SingleFile[0].MasterId);
            }

            foreach (Autodesk.Connectivity.WebServices.File item in _LatestFileswithVersions)
            {
                _FileVersionList.Add(item.VerNum.ToString());
            }
            return _FileVersionList;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _FileVersionList;
        }
    }

    public static Autodesk.Connectivity.WebServices.File SearchFileByName(string _filename, string _DocumentCategory, Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _VaultProjectFolder)
    {
        Autodesk.Connectivity.WebServices.File myFile = null;

        try
        {
            PropDef[] filePropDefs = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE");
            PropDef FileNamePropDef = filePropDefs.Single(n => n.SysName == "Name");

            SrchCond FileSearchCond = new SrchCond()
            {
                PropDefId = FileNamePropDef.Id,
                PropTyp = PropertySearchType.SingleProperty,
                SrchOper = 1,
                SrchRule = SearchRuleType.Must,
                SrchTxt = _filename,
            };

            SrchCond FileSearchCondwithfileExtension = new SrchCond()
            {
                PropDefId = FileNamePropDef.Id,
                PropTyp = PropertySearchType.SingleProperty,
                SrchOper = 1,
                SrchRule = SearchRuleType.Must,
                SrchTxt = _filename + ".doc.zip",
            };

            string bookmark = string.Empty;
            SrchStatus status = null;
            List<Autodesk.Connectivity.WebServices.File> totalResults = new List<Autodesk.Connectivity.WebServices.File>();
            while (status == null || totalResults.Count < status.TotalHits)
            {
                Autodesk.Connectivity.WebServices.File[] results = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindFilesBySearchConditions(
                    new SrchCond[] { FileSearchCond, FileSearchCondwithfileExtension },
                    null, new long[] { _VaultProjectFolder.Id }, true, true, ref bookmark, out status);

                if (results != null)
                    totalResults.AddRange(results);
                else
                    break;
            }

            if (totalResults.Count > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File itemFile in totalResults)
                {
                    if (itemFile.Cat.CatName.Trim().ToUpper() == _DocumentCategory)
                    {
                        return itemFile;
                    }
                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);

        }
        return myFile;
    }

    public static Autodesk.Connectivity.WebServices.File IsFileExistintoVault(Autodesk.Connectivity.WebServices.Folder parentFolder, string _Vaultfilename)
    {
        Autodesk.Connectivity.WebServices.File _file = null;
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Name == _Vaultfilename)
                    {
                        _file = file;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _file;
    }

    public static bool UpdateFileRemark(SingleBuildSpecificationSummary _objSingleBuildSpecificationSummary)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _objSingleBuildSpecificationSummary.BuildSpecificationRemark);
                newFile = files[0];
                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _IsSuccess;
    }

    public static VDF.Vault.Forms.Results.SelectEntityResults BrowseFiles(VDF.Vault.Currency.Entities.Folder myInventorFileFolder)
    {

        VDF.Vault.Forms.Results.SelectEntityResults selEntsResults = null;

        VDF.Vault.Forms.Settings.SelectEntitySettings.EntityRegularExpressionFilter[] filters = new[]
        {
            new VDF.Vault.Forms.Settings.SelectEntitySettings.EntityRegularExpressionFilter("All Files (*.*)", ".*", VDF.Vault.Currency.Entities.EntityClassIds.Files)
        };

        VDF.Vault.Forms.Settings.SelectEntitySettings.EntityRegularExpressionFilter initialFilter =
            new VDF.Vault.Forms.Settings.SelectEntitySettings.EntityRegularExpressionFilter("All Files (*.*)", ".*", VDF.Vault.Currency.Entities.EntityClassIds.Files);

        VDF.Vault.Forms.Settings.SelectEntitySettings EntSettings = new VDF.Vault.Forms.Settings.SelectEntitySettings();
        EntSettings.ActionableEntityClassIds.Add("FILE");
        EntSettings.DialogCaption = "Select files";
        EntSettings.MultipleSelect = true;
        EntSettings.ConfigureActionButtons("Select Files", null, null, false);
        EntSettings.InitialBrowseLocation = myInventorFileFolder;
        EntSettings.ConfigureFilters("Select Files (*.*)", filters, initialFilter);

        selEntsResults = VDF.Vault.Forms.Library.SelectEntity(clsStaticGlobal.connection, EntSettings);

        return selEntsResults;
    }

    public static void DisposeAllObjects()
    {
        try
        {
            IsReadOnly = false;
            IsFilter = false;
            clsStaticGlobal.CommentStatesCollection = new ObservableCollection<CommentStates>();
            clsStaticGlobal.CompletionActivitiesCollection = new ObservableCollection<CompletionActivities>();
            clsStaticGlobal.VaultBuildSpecificationFolder = null;
            clsStaticGlobal.VaultSOTRNumberFolder = null;
            clsStaticGlobal.VaultClassDrawingFolder = null;
            clsStaticGlobal.VaultDADDrawingFolder = null;
            clsStaticGlobal.VaultProductionDrawingFolder = null;
            clsStaticGlobal.ProjectFolder = null;
            clsStaticGlobal.SOTRNumberFiles = null;
            clsStaticGlobal.ClassDrawingFiles = null;
            clsStaticGlobal.DADDrawingFiles = null;
            clsStaticGlobal.ProductionDrawingFiles = null;
            clsStaticGlobal.ListBuildSpecificationNumbers = new List<int> { };
            clsStaticGlobal.sficodes = new SFIcodes();
            clsStaticGlobal.ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();

            clsStaticGlobal.objSingleBuildSpecificationSummary = null;
            clsStaticGlobal.objSingleBuildSpecificationCollection = null;
            clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection = new ObservableCollection<SingleBuildSpecificationSummary>();

            clsStaticGlobal.SOTRNumberSearchedItemCollection = new ObservableCollection<SOTRNumber>();
            clsStaticGlobal.ClassDrawingSearchedItemCollection = new ObservableCollection<ClassDrawing>();
            clsStaticGlobal.DADDrawingSearchedItemCollection = new ObservableCollection<DADDrawing>();
            clsStaticGlobal.ProductionDrawingSearchedItemCollection = new ObservableCollection<ProductionDrawing>();

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool IsFileCheckedOut(string _VaultfilePath, out string username)
    {
        username = "";

        List<int> _FileVersionList = new List<int> { };
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };

            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                try
                {
                    if (SingleFile[0].CheckedOut == true)
                    {
                        long userid = SingleFile[0].CkOutUserId;

                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(userid);
                        username = clsStaticGlobal.GetUserName(userinfo.User);
                    }
                }
                catch (Exception)
                {

                }

                return SingleFile[0].CheckedOut;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    #region Global Function

    public static bool VaultFileCommentUpdate(string _VaultFilePath, string _NewComment)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _NewComment);
                newFile = files[0];
                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static bool VaultFileChangeStateAndComment(string _VaultFilePath, string _StateName, string _Comment)
    {
        bool _IsSuccess = false;
        try
        {

            long _stateID = -1;

            LfCycDef _BuildSpecificationLifeCycleDef = null;
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            foreach (LfCycDef lcDef in lcDefs)
            {
                if ((lcDef.DispName.ToUpper() == "BUILD SPECIFICATION") || (lcDef.Name.ToUpper() == "BUILD SPECIFICATION"))
                {
                    _BuildSpecificationLifeCycleDef = lcDef;
                    break;
                }
            }

            if (_BuildSpecificationLifeCycleDef != null)
            {
                LfCycDef lifecycleDef = _BuildSpecificationLifeCycleDef;
                LfCycState[] states = lifecycleDef.StateArray;

                foreach (LfCycState state in states)
                {
                    if ((state.DispName.ToUpper() == _StateName.ToUpper()) || (state.Name.ToUpper() == _StateName.ToUpper()))
                    {
                        _stateID = state.Id;
                        break;
                    }
                }
            }
            if (_stateID != -1)
            {
                Autodesk.Connectivity.WebServices.File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFiles;
                SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
                if (SingleFiles.Length != 0)
                {
                    newFile = SingleFiles[0];
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                    new long[] { newFile.MasterId }, new long[] { _stateID }, _Comment);
                    newFile = files[0];
                    _IsSuccess = true;


                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static void VaultFileGetStateAndComment(string _VaultFilePath, out string _StateName, out string _Comment)
    {
        _StateName = "";
        _Comment = "";
        try
        {
            //
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                _StateName = newFile.FileLfCyc.LfCycStateName;
                _Comment = newFile.Comm;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void GetValutFileStatusAndRemarkAndRevision(string _VaultfilePath, out string _Status, out string _Remark, out string _Revision)
    {
        _Status = "";
        _Remark = "";
        _Revision = "";

        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                if (SingleFile[0].Id != -1)
                {
                    _Status = SingleFile[0].FileLfCyc.LfCycStateName;
                    _Remark = SingleFile[0].Comm;
                    _Revision = SingleFile[0].FileRev.Label.ToString(); ;
                }
                else
                {
                    _Status = "File not exist";
                    _Remark = "File not available in Vault.";
                }
            }
            else
            {
                _Status = "File not exist";
                _Remark = "File not available in Vault.";
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            _Remark = "File not available in Vault.";
        }
    }

    public static void GetValutFileStatus(string _VaultfilePath, out string status)
    {
        status = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                status = SingleFile[0].FileLfCyc.LfCycStateName;

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    #endregion



}
