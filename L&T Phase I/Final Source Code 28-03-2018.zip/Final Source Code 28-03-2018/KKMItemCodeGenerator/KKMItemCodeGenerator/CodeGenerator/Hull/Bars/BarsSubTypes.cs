﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsSubTypes : ObservableCollection<NameCodePair>
    {
        public static BarsSubTypes LoadList()
        {
            BarsSubTypes items = new BarsSubTypes();
            items.Add(new NameCodePair() { Code = "HP", Name = "HOLLAND PROFILE" });
            items.Add(new NameCodePair() { Code = "FB", Name = "FLAT BAR" });
           
            return items;
        }
        public static BarsSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsSubTypes>(HullItems.HullDataPath + @"\Bars\BarsSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsSubTypes>(this, HullItems.HullDataPath + @"\Bars\BarsSubTypes.xml");
        }
    }
}
