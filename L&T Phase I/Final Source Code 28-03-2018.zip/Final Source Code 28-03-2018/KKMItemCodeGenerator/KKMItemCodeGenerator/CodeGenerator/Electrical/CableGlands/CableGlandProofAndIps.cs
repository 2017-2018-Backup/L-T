﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandProofAndIps : ObservableCollection<NameCodePair>
    {
        public static CableGlandProofAndIps LoadList()
        {
            CableGlandProofAndIps items = new CableGlandProofAndIps();
            items.Add(new NameCodePair() { Code = "01", Name = "EX PROOF IP66" });
            items.Add(new NameCodePair() { Code = "02", Name = "EX PROOF IP67" });
            items.Add(new NameCodePair() { Code = "03", Name = "EX PROOF IP68" });
            items.Add(new NameCodePair() { Code = "04", Name = "EX PROOF IP55" });
            items.Add(new NameCodePair() { Code = "05", Name = "EX PROOF IP56" });
            items.Add(new NameCodePair() { Code = "06", Name = "WATER PROOF IP66" });
            items.Add(new NameCodePair() { Code = "07", Name = "WATER PROOF IP67" });
            items.Add(new NameCodePair() { Code = "08", Name = "WATER PROOF IP68" });
            items.Add(new NameCodePair() { Code = "09", Name = "WATER PROOF IP55" });
            items.Add(new NameCodePair() { Code = "10", Name = "WATER PROOF IP56" });
            items.Add(new NameCodePair() { Code = "11", Name = "WEATHER PROOF IP66" });
            items.Add(new NameCodePair() { Code = "12", Name = "WEATHER PROOF IP67" });
            items.Add(new NameCodePair() { Code = "13", Name = "WEATHER PROOF IP68" });
            items.Add(new NameCodePair() { Code = "14", Name = "WEATHER PROOF IP55" });
            items.Add(new NameCodePair() { Code = "15", Name = "WEATHER PROOF IP56" });

            return items;
        }
        public static CableGlandProofAndIps LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandProofAndIps LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandProofAndIps>(ElectricalItems.DataPath + @"\CableGland\CableGlandProofAndIps.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandProofAndIps>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandProofAndIps.xml");
        }

    }
}
