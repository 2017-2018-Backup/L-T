﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTrayMaterials : ObservableCollection<NameCodePair>
    {
        public static CableTrayMaterials LoadList()
        {
            CableTrayMaterials items = new CableTrayMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "GI PRIMED" });
            items.Add(new NameCodePair() { Code = "02", Name = "GI PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "03", Name = "GI HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "04", Name = "GI POWDER COATED" });
            items.Add(new NameCodePair() { Code = "05", Name = "GI FRP COATED" });
            items.Add(new NameCodePair() { Code = "06", Name = "GI SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "07", Name = "GI ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "08", Name = "GI ANODIZED" });
            items.Add(new NameCodePair() { Code = "09", Name = "ALUMINIUM PRIMED" });
            items.Add(new NameCodePair() { Code = "10", Name = "ALUMINIUM PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "11", Name = "ALUMINIUM HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "12", Name = "ALUMINIUM POWDER COATED" });
            items.Add(new NameCodePair() { Code = "13", Name = "ALUMINIUM FRP COATED" });
            items.Add(new NameCodePair() { Code = "14", Name = "ALUMINIUM SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "15", Name = "ALUMINIUM ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "16", Name = "ALUMINIUM ANODIZED" });
            items.Add(new NameCodePair() { Code = "17", Name = "ZINC COATED PRIMED" });
            items.Add(new NameCodePair() { Code = "18", Name = "ZINC COATED PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "19", Name = "ZINC COATED HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "20", Name = "ZINC COATED POWDER COATED" });
            items.Add(new NameCodePair() { Code = "21", Name = "ZINC COATED FRP COATED" });
            items.Add(new NameCodePair() { Code = "22", Name = "ZINC COATED SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "23", Name = "ZINC COATED ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "24", Name = "ZINC COATED ANODIZED" });
            items.Add(new NameCodePair() { Code = "25", Name = "FRP COATED PRIMED" });
            items.Add(new NameCodePair() { Code = "26", Name = "FRP COATED PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "27", Name = "FRP COATED HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "28", Name = "FRP COATED POWDER COATED" });
            items.Add(new NameCodePair() { Code = "29", Name = "FRP COATED FRP COATED" });
            items.Add(new NameCodePair() { Code = "30", Name = "FRP COATED SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "31", Name = "FRP COATED ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "32", Name = "FRP COATED ANODIZED" });
            items.Add(new NameCodePair() { Code = "33", Name = "S.S PRIMED" });
            items.Add(new NameCodePair() { Code = "34", Name = "S.S PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "35", Name = "S.S HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "36", Name = "S.S POWDER COATED" });
            items.Add(new NameCodePair() { Code = "37", Name = "S.S FRP COATED" });
            items.Add(new NameCodePair() { Code = "38", Name = "S.S SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "39", Name = "S.S ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "40", Name = "S.S ANODIZED" });
            items.Add(new NameCodePair() { Code = "41", Name = "MILD STEEL PRIMED" });
            items.Add(new NameCodePair() { Code = "42", Name = "MILD STEEL PRE GALVANIZED" });
            items.Add(new NameCodePair() { Code = "43", Name = "MILD STEEL HOT DIP GALVANIZED" });
            items.Add(new NameCodePair() { Code = "44", Name = "MILD STEEL POWDER COATED" });
            items.Add(new NameCodePair() { Code = "45", Name = "MILD STEEL FRP COATED" });
            items.Add(new NameCodePair() { Code = "46", Name = "MILD STEEL SELF COLOUR" });
            items.Add(new NameCodePair() { Code = "47", Name = "MILD STEEL ZINC PLATED" });
            items.Add(new NameCodePair() { Code = "48", Name = "MILD STEEL ANODIZED" });
            return items;
        }
        public static CableTrayMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTrayMaterials LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTrayMaterials>(ElectricalItems.DataPath + @"\CableTray\CableTrayMaterials.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTrayMaterials>(this, ElectricalItems.DataPath + @"\CableTray\CableTrayMaterials.xml");
        }

    }
}
