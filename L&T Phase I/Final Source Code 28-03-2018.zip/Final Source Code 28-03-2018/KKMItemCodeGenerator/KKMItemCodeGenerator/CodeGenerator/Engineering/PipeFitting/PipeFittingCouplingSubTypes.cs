﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingCouplingSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingCouplingSubTypes LoadList()
        {
            PipeFittingCouplingSubTypes items = new PipeFittingCouplingSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "SOCKET COUPLING" });
            items.Add(new NameCodePair() { Code = "02", Name = "BRANCH COUPLING" });
            items.Add(new NameCodePair() { Code = "03", Name = "HALF COUPLING" });
            items.Add(new NameCodePair() { Code = "04", Name = "REDUCING COUPLING" });
            items.Add(new NameCodePair() { Code = "05", Name = "VICTAULIC COUPLING ST107" });
            items.Add(new NameCodePair() { Code = "06", Name = "VICTAULIC COUPLING ST177" });
            items.Add(new NameCodePair() { Code = "07", Name = "STRAIGHT COUPLING" });
            items.Add(new NameCodePair() { Code = "08", Name = "CAMLOCK COUPLING" });
            items.Add(new NameCodePair() { Code = "09", Name = "QUICK RELEASE COUPLING" });
            return items;
        }
        public static PipeFittingCouplingSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingCouplingSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingCouplingSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCouplingSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingCouplingSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCouplingSubTypes.xml");
        }

    }
}
