﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KKMShipTechnicalSpecification;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;

namespace KKMShipTechnicalSpecification
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlDADDrawings : Window
    {
        public UserControlDADDrawings()
        {
            InitializeComponent();

            try
            {
                clsStaticGlobal.DADDrawingsSearchedItemCollection.Clear();
                int SearchedCount = 1;
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.DADDrawingFiles)
                {
                    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                    string filePath = folder.FullName + "/" + _item.Name;
                    string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                    string fileName = _item.Name;
                    int fileExtPos = fileName.LastIndexOf(".");
                    if (fileExtPos >= 0)
                        fileName = fileName.Substring(0, fileExtPos);

                    clsStaticGlobal.DADDrawingsSearchedItemCollection.Add(new DADDrawings { Count = SearchedCount, IsCheckedDADDrawings = false, FileType = "DAD Drawings", FileName = fileName, FilePath = filePath, FileRemark = "", FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                    SearchedCount += 1;
                }

                //clsStaticGlobal.DADDrawingsSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(DADDrawingsSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListDADDrawings_CollectionChanged);

                DADDrawingsSearchGridViewBox.ItemsSource = clsStaticGlobal.DADDrawingsSearchedItemCollection;
                DADDrawingsSearchGridViewBox.UpdateLayout();

                if (clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings.Count > 0)
                {
                    DADDrawingsGridViewBox.ItemsSource = clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings;
                    DADDrawingsGridViewBox.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void DADDrawingsSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.DADDrawingsSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListDADDrawings_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            // System.Diagnostics.Debugger.Launch();
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings)
                {
                    item.Count = k;
                    k++;

                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                    //item.FileRemark = _remark;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    DADDrawingsSearchGridViewBox.UpdateLayout();
                    DADDrawingsGridViewBox.Items.Refresh();
                    foreach (DADDrawings _item in clsStaticGlobal.DADDrawingsSearchedItemCollection)
                    {
                        if (_item.IsCheckedDADDrawings == true)
                        {
                            bool IsFileExist = false;
                            foreach (DADDrawings _itemExist in clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings)
                            {
                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                            }

                            if (IsFileExist == false)
                            {
                                clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings.Add(new DADDrawings { IsCheckedDADDrawings = true, FileType = "DAD Drawings", FileName = _item.FileName, FilePath = _item.FilePath, FileRemark = "", FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString() });
                            }
                        }
                    }
                    DADDrawingsGridViewBox.ItemsSource = clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings;
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Ship Technical Specification in Release state. User can not edit..!!", "Ship Technical Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            DADDrawingsGridViewBox.UpdateLayout();
        }

        private void cmdRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    if (clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings.Count > 0)
                    {
                        try
                        {
                            if (DADDrawingsGridViewBox.SelectedCells.Count > 0)
                            {
                                DADDrawings objDADDrawings = (DADDrawings)DADDrawingsGridViewBox.SelectedCells[0].Item;
                                clsStaticGlobal.objSingleShipTechnicalSpecificationSummary.ListDADDrawings.Remove(objDADDrawings);
                                DADDrawingsGridViewBox.UpdateLayout();
                            }
                            else
                            {
                                MessageBox.Show("Select single file first.", "Ship Technical Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }

            }
            else
            {
                MessageBox.Show("Ship Technical Specification in Release state. User can not edit..!!", "Ship Technical Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DADDrawingsSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                DADDrawingsSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }        
    }

}
