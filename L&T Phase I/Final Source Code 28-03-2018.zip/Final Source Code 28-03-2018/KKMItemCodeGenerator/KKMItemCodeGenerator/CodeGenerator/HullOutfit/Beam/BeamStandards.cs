﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamStandards : ObservableCollection<NameCodePair>
    {
        public static BeamStandards LoadList()
        {
            BeamStandards items = new BeamStandards();
            items.Add(new NameCodePair() { Code = "01", Name = "Non - Std" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISMB" });
            items.Add(new NameCodePair() { Code = "03", Name = "ISJB" });
            items.Add(new NameCodePair() { Code = "04", Name = "ISLB" });
            items.Add(new NameCodePair() { Code = "05", Name = "ISWB" });
            items.Add(new NameCodePair() { Code = "06", Name = "ISHB" });
            items.Add(new NameCodePair() { Code = "07", Name = "IPN" });
            items.Add(new NameCodePair() { Code = "08", Name = "HEA" });
            items.Add(new NameCodePair() { Code = "09", Name = "HEB" });
            items.Add(new NameCodePair() { Code = "10", Name = "ISSC" });

            return items;
        }
        public static BeamStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamStandards LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamStandards>(HullOutfitItems.DataPath + @"\Beam\BeamStandards.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamStandards>(this, HullOutfitItems.DataPath + @"\Beam\BeamStandards.xml");
        }
    }
}
