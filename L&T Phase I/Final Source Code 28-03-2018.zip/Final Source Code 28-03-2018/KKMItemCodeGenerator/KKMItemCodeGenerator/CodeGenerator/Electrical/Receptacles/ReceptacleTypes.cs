﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ReceptacleTypes : ObservableCollection<NameCodePair>
    {
        public static ReceptacleTypes LoadList()
        {
            ReceptacleTypes items = new ReceptacleTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "RECEPTACLES STRAIGHT" });
            items.Add(new NameCodePair() { Code = "02", Name = "RECEPTACLES LOCKING" });
            items.Add(new NameCodePair() { Code = "03", Name = "RECEPTACLES PIN AND SLEEVE" });
            items.Add(new NameCodePair() { Code = "04", Name = "RECEPTACLES SOCKET" });
            items.Add(new NameCodePair() { Code = "05", Name = "RECEPTACLES SWITCH" });
            items.Add(new NameCodePair() { Code = "06", Name = "RECEPTACLES SWITCHED SOCKETS" });          
            return items;
        }
        public static ReceptacleTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ReceptacleTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ReceptacleTypes>(ElectricalItems.DataPath + @"\Receptacles\ReceptacleTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath + @"\Receptacles"))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath + @"\Receptacles");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ReceptacleTypes>(this, ElectricalItems.DataPath + @"\Receptacles\ReceptacleTypes.xml");
        }

    }
}
