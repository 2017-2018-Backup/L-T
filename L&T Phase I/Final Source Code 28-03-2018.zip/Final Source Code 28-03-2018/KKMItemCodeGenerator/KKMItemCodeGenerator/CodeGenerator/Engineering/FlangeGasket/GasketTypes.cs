﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class GasketTypes : ObservableCollection<NameCodePair>
    {
        public static GasketTypes LoadList()
        {
            GasketTypes items = new GasketTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "RING" });
            items.Add(new NameCodePair() { Code = "02", Name = "FULLFACE" });
            items.Add(new NameCodePair() { Code = "03", Name = "RAISED" });
            items.Add(new NameCodePair() { Code = "04", Name = "VICTAULIC ST 107" });
            items.Add(new NameCodePair() { Code = "05", Name = "VICTAULIC ST 177" });
            return items;
        }
        public static GasketTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static GasketTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<GasketTypes>(EngineeringItems.DataPath + @"\FlangeGasket\GasketTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<GasketTypes>(this, EngineeringItems.DataPath + @"\FlangeGasket\GasketTypes.xml");
        }

    }
}
