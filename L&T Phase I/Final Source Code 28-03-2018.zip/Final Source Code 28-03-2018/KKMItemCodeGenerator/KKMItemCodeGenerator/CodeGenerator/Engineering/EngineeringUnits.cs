﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class EngineeringUnits : ObservableCollection<NameCodePair>
    {
        public static EngineeringUnits LoadList()
        {
            EngineeringUnits items = new EngineeringUnits();
            items.Add(new NameCodePair() { Code = "mtr", Name = "Meters" });
            items.Add(new NameCodePair() { Code = "nos", Name = "Numbers" });
            items.Add(new NameCodePair() { Code = "kgs", Name = "Kilograms" });
            items.Add(new NameCodePair() { Code = "ltr", Name = "Liters" });
            items.Add(new NameCodePair() { Code = "mm", Name = "Millimeter" });
            items.Add(new NameCodePair() { Code = "nm", Name = "Nanometer" });
            items.Add(new NameCodePair() { Code = "scm", Name = "Square Centimeters" });
            items.Add(new NameCodePair() { Code = "N", Name = "Newton" });
            items.Add(new NameCodePair() { Code = "kN", Name = "Kilo Newton" });
            items.Add(new NameCodePair() { Code = "kn", Name = "Knots" });
            items.Add(new NameCodePair() { Code = "kmph", Name = "Kilometer/Hour" });
            items.Add(new NameCodePair() { Code = "inch", Name = "Inch" });
            items.Add(new NameCodePair() { Code = "feet", Name = "Feet" });
            items.Add(new NameCodePair() { Code = "kg/cu.m", Name = "Kilograms/Cubic Meter" });
            items.Add(new NameCodePair() { Code = "TR", Name = "Tons of Refrigeration" });
            items.Add(new NameCodePair() { Code = "skm", Name = "Sqaure Kilometers" });
            items.Add(new NameCodePair() { Code = "sqm", Name = "Square metres" });
            items.Add(new NameCodePair() { Code = "ug", Name = "Micrograms" });
            items.Add(new NameCodePair() { Code = "um", Name = "Micrometer" });
            items.Add(new NameCodePair() { Code = "scm", Name = "Square Centimeters" });
            items.Add(new NameCodePair() { Code = "set", Name = "Set" });
            items.Add(new NameCodePair() { Code = "C", Name = "Degrees Celcius" });
            items.Add(new NameCodePair() { Code = "F", Name = "Degrees Fahrenheit" });
            items.Add(new NameCodePair() { Code = "K", Name = "Degrees Kelvin" });
            items.Add(new NameCodePair() { Code = "KW", Name = "Kilo watts" });
            items.Add(new NameCodePair() { Code = "KWH", Name = "Kilo watt hours" });
            items.Add(new NameCodePair() { Code = "MWH", Name = "Mega Watt Hours" });
            items.Add(new NameCodePair() { Code = "T", Name = "Metric Tonnes" });
            items.Add(new NameCodePair() { Code = "V", Name = "Volts" });
            items.Add(new NameCodePair() { Code = "W", Name = "Watts" });
            items.Add(new NameCodePair() { Code = "hp", Name = "Horse power" });
            items.Add(new NameCodePair() { Code = "kms", Name = "Kilometers" });
            items.Add(new NameCodePair() { Code = "cms", Name = "Centimeters" });
            items.Add(new NameCodePair() { Code = "cub", Name = "Cubic Metres" });

            return items;
        }
        public static EngineeringUnits LoadFromExcel(String path)
        {
            return null;
        }

        public static EngineeringUnits LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<EngineeringUnits>(EngineeringItems.DataPath + @"\EngineeringUnits.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<EngineeringUnits>(this, EngineeringItems.DataPath + @"\EngineeringUnits.xml");
        }
    }
}
