﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeTubeStandards : ObservableCollection<NameCodePair>
    {
        public static PipeTubeStandards LoadList()
        {
            PipeTubeStandards items = new PipeTubeStandards();
            items.Add(new NameCodePair() { Code = "01", Name = "PIPE (NB/SCH)" });
            items.Add(new NameCodePair() { Code = "02", Name = "TUBE (OD/THK)" });
            items.Add(new NameCodePair() { Code = "03", Name = "DATA & SIGNAL CABLE" });

            return items;
        }
        public static PipeTubeStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeTubeStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeTubeStandards>(EngineeringItems.DataPath + @"\Pipes\PipeTubeStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeTubeStandards>(this, EngineeringItems.DataPath + @"\Pipes\PipeTubeStandards.xml");
        }

    }
}
