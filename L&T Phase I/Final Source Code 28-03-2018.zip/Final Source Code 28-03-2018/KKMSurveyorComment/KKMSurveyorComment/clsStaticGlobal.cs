﻿using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using KKMSurveyorComment;
using VDF = Autodesk.DataManagement.Client.Framework;
using System.IO.Packaging;
using System.Reflection;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties;
using System.Xml.Serialization;

public static class clsStaticGlobal
{
    public static bool IsReadOnly = false;
    public static bool IsFilter = false;
    public static VDF.Vault.Currency.Connections.Connection connection;
    public static string _ProjectCode = "";
    public static string SurveyorCommentFolderName = "Surveyor Comments";
    public static string SurveyorCommentFileCategory = "Surveyor Comments";
    public static string LocalXMLSurveyorCommentFolderPath = Path.GetTempPath() + SurveyorCommentFolderName;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultSurvayerReferenceDocFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultSurvayerFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder ProjectFolder = null;
    public static List<Autodesk.Connectivity.WebServices.File> RelatedDocumentDADFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> ClassApprovedDrawingFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> ReferenceDocumentFiles = null;
    public static List<int> ListSurveyorCommentNumbers = null;
    public static ObservableCollection<ProjectCodes> ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();
    public static ObservableCollection<CommentStates> CommentStatesCollection = new ObservableCollection<CommentStates>();
    public static SingleSurveyorCommentSummary objSingleSurveyorCommentSummary;
    public static SurveyorCommentsCollection objSurveyorCommentsCollection;
    public static ObservableCollection<SingleSurveyorCommentSummary> SingleSurveyorCommentSummaryItemCollection = new ObservableCollection<SingleSurveyorCommentSummary>();

    public static ObservableCollection<RelatedDocumentDAD> RelatedDocumentDADSearchedItemCollection = new ObservableCollection<RelatedDocumentDAD>();
    public static ObservableCollection<ClassApprovedDrawing> ClassApprovedDrawingSearchedItemCollection = new ObservableCollection<ClassApprovedDrawing>();
    public static ObservableCollection<ReferenceDocument> ReferenceDocumentSearchedItemCollection = new ObservableCollection<ReferenceDocument>();

    public static string ErrorFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

    public static void ErrHandlerLog(Exception ex)
    {
        try
        {
            string errorFilePath = ErrorFilePath + "/SurveyorCommentErrorLog.txt";
            if (!System.IO.File.Exists(errorFilePath))
            {
                dynamic fs = System.IO.File.Create(errorFilePath);
                fs.Close();
                fs.Dispose();
            }
            zipFile(ErrorFilePath, "error.txt");

            using (StreamWriter sw = new StreamWriter(errorFilePath, true))
            {

                try
                {
                    sw.WriteLine("Log Date & time: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                    sw.WriteLine("Message:" + ex.Message);

                    sw.WriteLine("Type:" + ex.GetType().ToString());
                    if ((ex.StackTrace != null))
                    {
                        sw.WriteLine("Trace: " + ex.StackTrace);
                    }

                    if ((ex.Source != null))
                    {
                        sw.WriteLine("Source: " + ex.Source);
                    }

                    if ((ex.TargetSite != null))
                    {
                        sw.WriteLine("Target: " + ex.TargetSite.ToString());
                    }

                    if ((ex.InnerException != null))
                    {
                        sw.WriteLine("Inner Message:" + ex.InnerException.Message);

                        if ((ex.InnerException.StackTrace != null))
                        {
                            sw.WriteLine("Trace: " + ex.InnerException.StackTrace);
                        }

                        if ((ex.InnerException.Source != null))
                        {
                            sw.WriteLine("Source: " + ex.InnerException.Source);
                        }

                        if ((ex.InnerException.TargetSite != null))
                        {
                            sw.WriteLine("Target: " + ex.InnerException.TargetSite.ToString());
                        }

                    }
                    sw.WriteLine("");
                    sw.WriteLine("");
                }
                catch (Exception)
                {
                    sw.WriteLine("");
                    sw.WriteLine("");
                }

                sw.Close();
            }
        }
        catch (Exception)
        {

        }
    }

    public static void zipFile(string errorFolderPath, string errorFileName)
    {
        try
        {
            dynamic mFileName = errorFolderPath + "\\" + errorFileName;
            System.IO.FileInfo info = new System.IO.FileInfo(mFileName);
            string ZipFileName = "Error_" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss").Replace("-", "_").Replace(" ", "_").Replace(":", "_") + ".zip";
            if (info.Length >= 1048576)
            {

                Package zip = ZipPackage.Open(errorFolderPath + "\\" + ZipFileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

                //Replace spaces with an underscore (_)
                string uriFileName = mFileName.Replace(" ", "_");

                //A Uri always starts with a forward slash "/"
                string zipUri = string.Concat("/", System.IO.Path.GetFileName(uriFileName));

                Uri partUri = new Uri(zipUri, UriKind.Relative);
                string contentType = System.Net.Mime.MediaTypeNames.Application.Zip;

                //The PackagePart contains the information:
                //Where to extract the file when it's extracted (partUri)
                //The type of content stream (MIME type) - (contentType)
                //The type of compression to use (CompressionOption.Normal)
                PackagePart pkgPart = zip.CreatePart(partUri, contentType, CompressionOption.Normal);

                //Read all of the bytes from the file to add to the zip file
                byte[] bites = System.IO.File.ReadAllBytes(mFileName);

                //Compress and write the bytes to the zip file
                pkgPart.GetStream().Write(bites, 0, bites.Length);

                zip.Close();
                //Close the zip file

                System.IO.File.Delete(mFileName);

                dynamic fs = System.IO.File.Create(mFileName);
                fs.Close();
                fs.Dispose();
            }
        }
        catch (Exception)
        {

        }

    }

    public static string GetUserName(User item)
    {
        string UserName = "";
        try
        {
            if (item.FirstName != null)
            {
                UserName = item.FirstName.Trim();
            }
            if (item.LastName != null)
            {
                if (UserName.Trim() == "")
                {
                    UserName = item.LastName.Trim();
                }
                else
                {
                    UserName = UserName.Trim() + " " + item.LastName.Trim();
                }

                UserName.Trim();
            }

            if (UserName.Trim() == "")
            {
                UserName = item.Name.Trim();
            }
        }
        catch (Exception)
        {

        }

        return UserName;
    }

    public static void GetProjectCodes()
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.Category.Name.ToUpper() == "PROJECT")
                    {
                        clsStaticGlobal.ProjectCodeItemCollection.Add(new ProjectCodes() { ProjectCodeName = folder.EntityName });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void GetCommentStates()
    {
        try
        {
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            LfCycDef lfcycledefSurveyorComment = null;
            foreach (LfCycDef lfcycledef in lcDefs)
            {
                if ((lfcycledef.DispName.ToUpper() == "SURVEYOR COMMENTS") || (lfcycledef.Name.ToUpper() == "SURVEYOR COMMENTS"))
                {
                    lfcycledefSurveyorComment = lfcycledef;
                    break;
                }
            }

            if (lfcycledefSurveyorComment != null)
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                foreach (LfCycState LfCycStateitem in lfcycledefSurveyorComment.StateArray)
                {
                    clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = LfCycStateitem.DispName });
                }
            }
            else
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Create" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Design Approval" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "QC-Class Approval" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Release" });
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static String GetFilePropertyValue(string PropName, long fileID, bool isSystemProp)
    {
        String value = null;

        PropInst[] fileProperties = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { fileID });

        try
        {
            foreach (PropInst prop in fileProperties)
            {
                PropertyDefinition propdef = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitionById(prop.PropDefId);

                if (propdef.IsSystem == isSystemProp)
                {
                    if ((propdef.DisplayName.ToUpper().Trim() == PropName.ToUpper().Trim()) || (propdef.SystemName.ToUpper().Trim() == PropName.ToUpper().Trim()))
                    {
                        if ((prop.Val != null) && (prop.Val.ToString().Trim() != ""))
                        {
                            try
                            {
                                return prop.Val.ToString();
                            }
                            catch (Exception)
                            {

                            }
                        }

                    }
                }

            }
        }
        catch (Exception)
        {

        }


        return value;
    }

    public static void ReleaseObject(object obj)
    {
        try
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
        }
        catch (Exception)
        {

            obj = null;
        }
        finally
        {
            GC.Collect();
        }
    }

    public static string GetPropertyValue(string _VaultfilePath)
    {
        string _RelatedDAD = "";
        try
        {
            PropertyDefinitionDictionary props = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitions(VDF.Vault.Currency.Entities.EntityClassIds.Files, null, PropertyDefinitionFilter.IncludeAll);
            PropertyDefinition myRelatedDAD = null;
            PropertyDefinition propDef;
            foreach (KeyValuePair<string, Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties.PropertyDefinition> myKeyValPair in props)
            {
                propDef = myKeyValPair.Value;

                if (propDef.DisplayName.ToUpper().Trim() == "RELATED DAD")
                {
                    //It is the PropertyDefinition
                    myRelatedDAD = propDef;
                    break; // TODO: might not be correct. Was : Exit For
                }
            }

            if (myRelatedDAD != null)
            {
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
                if (SingleFile.Length != 0)
                {
                    VDF.Vault.Currency.Entities.FileIteration myFile = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, SingleFile[0]);
                    _RelatedDAD = clsStaticGlobal.connection.PropertyManager.GetPropertyValue(myFile, myRelatedDAD, null).ToString();
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }


        return _RelatedDAD;
    }

    public static VDF.Vault.Currency.Entities.Folder GetorCreateSurveyorCommentFolder(string SelectedProjectCode)
    {
        try
        {
            Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);
            Cat _SurveyorFolderCategory = null;
            foreach (Cat _cat in _Categories)
            {
                if (_cat.Name.Trim().ToUpper() == "FOLDER")
                {
                    _SurveyorFolderCategory = _cat;
                    break;
                }
            }

            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            VDF.Vault.Currency.Entities.Folder _ProjectFolder = null;
            VDF.Vault.Currency.Entities.Folder _SurveyorFolder = null;

            IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.EntityName == SelectedProjectCode)
                    {
                        _ProjectFolder = folder;
                        clsStaticGlobal.ProjectFolder = folder;
                        break;
                    }
                }
            }

            if (_ProjectFolder != null)
            {
                IEnumerable<VDF.Vault.Currency.Entities.Folder> SubFolders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_ProjectFolder, false, false);
                if (SubFolders != null && SubFolders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in SubFolders)
                    {
                        if (folder.EntityName == SurveyorCommentFolderName)
                        {
                            _SurveyorFolder = folder;
                            break;
                        }
                    }
                }
            }

            if (_SurveyorFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(SurveyorCommentFolderName, _ProjectFolder.Id, false, _SurveyorFolderCategory.Id);
                _SurveyorFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
            }

            return _SurveyorFolder;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return null;
        }

    }

    public static VDF.Vault.Currency.Entities.Folder GetorCreateSurveyorReferenceDocFolder(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultSurvayerFolder, String _SurveyorCommentFileName)
    {
        VDF.Vault.Currency.Entities.Folder _SurveyorReferenceDocFolder = null;
        try
        {
            Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);
            Cat _SurveyorFolderCategory = null;
            foreach (Cat _cat in _Categories)
            {
                if (_cat.Name.Trim().ToUpper() == "FOLDER")
                {
                    _SurveyorFolderCategory = _cat;
                    break;
                }
            }

            if (VaultSurvayerFolder != null)
            {
                IEnumerable<VDF.Vault.Currency.Entities.Folder> SubFolders = clsStaticGlobal.connection.FolderManager.GetChildFolders(VaultSurvayerFolder, false, false);
                if (SubFolders != null && SubFolders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in SubFolders)
                    {
                        if (folder.EntityName == _SurveyorCommentFileName)
                        {
                            _SurveyorReferenceDocFolder = folder;
                            break;
                        }
                    }
                }
            }

            if (_SurveyorReferenceDocFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(_SurveyorCommentFileName, VaultSurvayerFolder.Id, false, _SurveyorFolderCategory.Id);
                _SurveyorReferenceDocFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
            }

            return _SurveyorReferenceDocFolder;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return null;
        }

    }

    public static string GetFileNameWithoutExtension(string _filename)
    {
        int fileExtPos = _filename.LastIndexOf(".");
        if (fileExtPos >= 0)
            _filename = _filename.Substring(0, fileExtPos);
        return _filename;
    }

    public static string GetFileExtension(string fileName)
    {
        string ext = string.Empty;
        try
        {
            int fileExtPos = fileName.LastIndexOf(".", StringComparison.Ordinal);
            if (fileExtPos >= 0)
            {
                ext = fileName.Substring(fileExtPos, fileName.Length - fileExtPos);
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return ext;
    }

    public static void BindingDataSingleWrite(SingleSurveyorCommentSummary objSingleSurveyorCommentSummary, string XMLFilePath, bool _IsEdit)
    {
        // Debugger.Launch();
        try

        {
            if (Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
            {
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
            }
            else
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
            }

            if (_IsEdit == true)
            {
                CheckoutFile(objSingleSurveyorCommentSummary.SurveyorCommentFileName, LocalXMLSurveyorCommentFolderPath);
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, objSingleSurveyorCommentSummary);
                tw.Close();

                CheckinFile(objSingleSurveyorCommentSummary.SurveyorCommentFileName, LocalXMLSurveyorCommentFolderPath, objSingleSurveyorCommentSummary.LifeCycleComment);
            }
            else
            {
                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, objSingleSurveyorCommentSummary);
                tw.Close();
                AddFileintoVault(clsStaticGlobal.VaultSurvayerFolder, XMLFilePath, objSingleSurveyorCommentSummary.SurveyorCommentName, "");
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void AddFileintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _SurveyorCommentFolder, string _XMLfilePath, string _SurveyorCommentName, string _remark)
    {
        try
        {
            //Debugger.Launch();
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _SurveyorCommentFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_XMLfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_XMLfilePath), _remark, DateTime.Now, null, null, FileClassification.None, false, fileStream);
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool UpdateFileProperties(Autodesk.Connectivity.WebServices.File _File, string _FileCategory, string _DisplayName, string _Value)
    {
        bool _Sucess = true;
        try
        {
            List<PropInstParam> propInstParams = new List<PropInstParam>();
            PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

            if (_File.Cat.CatName == _FileCategory)
            {
                PropInst[] source = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { _File.MasterId });

                foreach (PropDef def in clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE"))
                {
                    if (def.IsSys == false & def.IsAct == true)
                    {
                        if (def.DispName == _DisplayName)
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = _DisplayName;
                            propInstParams.Add(propInst);
                            break;
                        }
                    }
                }
            }

            PropInstParamArray propInstParamsArray = new PropInstParamArray();
            propInstParamsArray.Items = propInstParams.ToArray();
            propInstParamsArrays[0] = propInstParamsArray;
            clsStaticGlobal.connection.WebServiceManager.DocumentService.UpdateFileProperties(new long[] { _File.MasterId }, propInstParamsArrays);

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _Sucess;
    }

    public static void CheckoutFile(string _XMLfileName, string _DownloadedPath)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                //clsStaticGlobal.connection.WorkingFoldersManager.SetWorkingFolder()
                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);
                //
                settings.DefaultAcquisitionOption = VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download;

                settings.AddEntityToAcquire(oFileIteration);

                VDF.Vault.Settings.FileRelationshipGatheringSettings fileRelSetting = settings.OptionsRelationshipGathering.FileRelationshipSettings;
                fileRelSetting.IncludeChildren = true;
                fileRelSetting.IncludeParents = false;
                fileRelSetting.IncludeLibraryContents = true;
                settings.AddEntityToAcquire(oFileIteration);
                settings.OptionsResolution.SyncWithRemoteSiteSetting = VDF.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;
                settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

                var m_res = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in m_res.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void DownlodFile_Fource(VDF.Vault.Currency.Entities.FileIteration file, VDF.Vault.Currency.Connections.Connection connection, string _DownloadedPath)
    {
        try
        {
            //' download individual files to a temp location
            VDF.Vault.Settings.AcquireFilesSettings settings = new Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings(connection);

            settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);

            settings.AddFileToAcquire(file, Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);

            settings.OptionsResolution.SyncWithRemoteSiteSetting = Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;

            settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

            Autodesk.DataManagement.Client.Framework.Vault.Results.AcquireFilesResults results = connection.FileManager.AcquireFiles(settings);

            foreach (var _res in results.FileResults)
            {
                if (_res.Status == Autodesk.DataManagement.Client.Framework.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                {
                    System.Windows.MessageBox.Show("Unable to Download File : " + Environment.NewLine + _res.File.EntityName + Environment.NewLine + "Download manualy and Resolve Link after Complete.", "Download Vault File", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void DeleteFileFromDirectory(string _DirectoryPath)
    {
        try
        {
            if (Directory.Exists(_DirectoryPath))
            {
                foreach (string file in Directory.GetFiles(_DirectoryPath))
                {
                    System.IO.File.SetAttributes(file, FileAttributes.Normal);
                    System.IO.File.Delete(file);
                }
            }
        }
        catch (Exception ex)
        {
            System.Windows.Forms.MessageBox.Show("Error in deleting files. Check file should not be opened..!!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool DownloadFile(string _XMLfileName, string _DownloadedPath)
    {
        //Debugger.Launch();
        string _VaultFilePath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + _XMLfileName;
        _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

        bool isSucess = false;
        try
        {
            if (!Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode))
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
            }
            else
            {
                if (System.IO.File.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName))
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName);
                }
            }

            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                VDF.Vault.Currency.Entities.FileIteration fileIter = new FileIteration(clsStaticGlobal.connection, newFile);

                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
                settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in results.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }

                isSucess = true;
            }
            else
            {
                isSucess = false;
            }


        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            //System.Windows.Forms.MessageBox.Show("Error in file download.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return isSucess;

    }

    public static bool DownloadFileByPath(string _VaultFileName, string _VaultFilePath, string _DownloadedFolderPath)
    {
        bool isSucess = false;
       // Debugger.Launch();
        try
        {
            if (!Directory.Exists(_DownloadedFolderPath))
            {
                Directory.CreateDirectory(_DownloadedFolderPath);
            }
            else
            {
                if (System.IO.File.Exists(_DownloadedFolderPath + "\\" + _VaultFileName))
                {
                    clsStaticGlobal.DeleteFileFromDirectory(_DownloadedFolderPath + "\\" + _VaultFileName);
                }
            }

            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                if (newFile.Id != -1)
                {
                    VDF.Vault.Currency.Entities.FileIteration fileIter = new FileIteration(clsStaticGlobal.connection, newFile);

                    VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                    settings.LocalPath = new VDF.Currency.FolderPathAbsolute(_DownloadedFolderPath);
                    settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                    VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                    foreach (var _res in results.FileResults)
                    {
                        if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                        {
                            DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedFolderPath);
                        }
                    }

                    isSucess = true;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("File not exist in vault " + Environment.NewLine + _VaultFilePath, "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                isSucess = false;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            //System.Windows.Forms.MessageBox.Show("Error in file download.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return isSucess;

    }

    public static bool IsFileCheckedOut(string _VaultfilePath, out string username)
    {
        username = "";

        List<int> _FileVersionList = new List<int> { };
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };

            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                try
                {
                    if (SingleFile[0].CheckedOut == true)
                    {
                        long userid = SingleFile[0].CkOutUserId;

                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(userid);
                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    username = userinfo.User.LastName.Trim();
                        //}
                        //else
                        //{
                        //    username = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}

                        username = clsStaticGlobal.GetUserName(userinfo.User);

                    }
                }
                catch (Exception)
                {

                }

                return SingleFile[0].CheckedOut;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static void CheckinFile(string _XMLfileName, string _DownloadedPath, string _remark)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;
            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                VDF.Currency.FolderPathAbsolute fldrPath = new VDF.Currency.FolderPathAbsolute(_DownloadedPath);
                string filePath = Path.Combine(fldrPath.ToString(), oFileIteration.EntityName);
                VDF.Currency.FilePathAbsolute filePathAbs = new VDF.Currency.FilePathAbsolute(filePath);

                if (System.IO.File.Exists(filePath))
                {
                    if (oFileIteration.IsCheckedOut == true)
                    {
                        try
                        {
                            clsStaticGlobal.connection.FileManager.CheckinFile(oFileIteration, _remark, false, new Autodesk.Connectivity.WebServices.FileAssocParam[] { }, null, false, null,
                                                           Autodesk.Connectivity.WebServices.FileClassification.None, false, filePathAbs);
                        }
                        catch (Exception ex1)
                        {
                            System.Windows.Forms.MessageBox.Show(ex1.ToString() + ex1.StackTrace);
                        }

                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void BindingDataMultipleRead(ref SurveyorCommentsCollection objSurveyorCommentsCollection, SingleSurveyorCommentSummary objSingleSurveyorCommentSummary, string _XMLFolderPath, string _ProjectCode)
    {
        try
        {
            List<SingleSurveyorCommentSummary> listSingleSurveyorCommentSummary = new List<SingleSurveyorCommentSummary>();
            _XMLFolderPath = _XMLFolderPath + "\\" + _ProjectCode;
            clsStaticGlobal.ListSurveyorCommentNumbers = new List<int>();
            objSurveyorCommentsCollection = new SurveyorCommentsCollection();
            XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
            objSingleSurveyorCommentSummary = new SingleSurveyorCommentSummary();
            string[] filePaths = Directory.GetFiles(_XMLFolderPath, "*.xml");
            foreach (string _filepath in filePaths)
            {
                using (var sr = new StreamReader(_filepath))
                {
                    objSingleSurveyorCommentSummary = (SingleSurveyorCommentSummary)xs.Deserialize(sr);
                }
                if (objSingleSurveyorCommentSummary != null)
                {
                    string _Survstatus = "";
                    string _Survremark = "";
                    string _Survrevision = "";
                    clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath, out _Survstatus, out _Survremark, out _Survrevision);
                    objSingleSurveyorCommentSummary.LifeCycle = _Survstatus;
                    objSingleSurveyorCommentSummary.LifeCycleComment = _Survremark;

                    if (objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                    {
                        foreach (ClassApprovedDrawing item in objSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                        {
                            string _status = "";
                            string _remark = "";
                            string _revision = "";
                            clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                            item.FileStatus = _status;
                            item.FileRemark = _remark;
                            item.FileRevision = _revision;
                            objSingleSurveyorCommentSummary.DrawingRemark = _remark;
                        }
                        //objSingleSurveyorCommentSummary.RelatedDocumentDAD = clsStaticGlobal.GetPropertyValue(objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FilePath);
                    }


                    if (objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                    {
                        foreach (RelatedDocumentDAD item in objSingleSurveyorCommentSummary.ListRelatedDocumentDAD)
                        {
                            string _status = "";
                            string _remark = "";
                            string _revision = "";
                            clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                            item.FileStatus = _status;
                            item.FileRemark = _remark;
                            item.FileRevision = _revision;
                        }                       
                    }

                    clsStaticGlobal.ListSurveyorCommentNumbers.Add(objSingleSurveyorCommentSummary.SurveyorCommentNumber);
                    listSingleSurveyorCommentSummary.Add(objSingleSurveyorCommentSummary);
                    clsStaticGlobal.ListSurveyorCommentNumbers.Sort();
                    clsStaticGlobal.ListSurveyorCommentNumbers.Distinct();  
                    objSurveyorCommentsCollection.collectionSurveyorCommentSummary = listSingleSurveyorCommentSummary.OrderBy(o => o.SurveyorCommentNumber).ToList();

                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void BindingDataSingleRead(SingleSurveyorCommentSummary objSingleSurveyorCommentSummary, string _XMLFolderPath)
    {
        try
        {
            objSingleSurveyorCommentSummary = new SingleSurveyorCommentSummary();
            XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
            using (var sr = new StreamReader(_XMLFolderPath + "*.xml"))
            {
                objSingleSurveyorCommentSummary = (SingleSurveyorCommentSummary)xs.Deserialize(sr);
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void PrintRelatedDocumentDADFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name == "DAD")
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            clsStaticGlobal.RelatedDocumentDADFiles.Add(file);

                            //if (file.Name.ToUpper().EndsWith(".PDF") == true)
                            //{
                            //    clsStaticGlobal.RelatedDocumentDADFiles.Add(file);
                            //}
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintRelatedDocumentDADFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }


    }

    public static void PrintClassApprovedDocumentFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name == "Class Approved Drawings")
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if ((file.Name.ToUpper().EndsWith(".ZIP") == true) && (file.Cat.CatName.ToUpper() == "CLASS APPROVED DOCUMENT"))
                            {
                                clsStaticGlobal.ClassApprovedDrawingFiles.Add(file);
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintClassApprovedDocumentFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintClassApprovedDocumentFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintClassApprovedDocumentFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if ((file.Name.ToUpper().EndsWith(".ZIP") == true) && (file.Cat.CatName.ToUpper() == "CLASS APPROVED DOCUMENT"))
                    {
                        clsStaticGlobal.ClassApprovedDrawingFiles.Add(file);
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintClassApprovedDocumentFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool AddReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _SurveyorCommentReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _SurveyorCommentReferenceDocFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_LocalfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_LocalfilePath), Path.GetFileName(_LocalfilePath), DateTime.Now, null, null, FileClassification.None, false, fileStream);
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static bool DeleteReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _SurveyorCommentReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(_SurveyorCommentReferenceDocFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (_SurveyorCommentReferenceDocFolder.FullName + "/" + file.Name == _LocalfilePath)
                    {
                        clsStaticGlobal.connection.WebServiceManager.DocumentService.DeleteFileFromFolder(file.MasterId, _SurveyorCommentReferenceDocFolder.Id);
                        return true;
                    }
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static void GetValutFileStatusAndRemarkAndRevision(string _VaultfilePath, out string _Status, out string _Remark, out string _Revision)
    {
        _Status = "";
        _Remark = "";
        _Revision = "";

        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                if (SingleFile[0].Id != -1)
                {
                    _Status = SingleFile[0].FileLfCyc.LfCycStateName;
                    _Remark = SingleFile[0].Comm;
                    _Revision = SingleFile[0].FileRev.Label.ToString(); ;
                }
                else
                {
                    _Remark = "File not available in Vault.";
                }
            }
            else
            {
                _Remark = "File not available in Vault.";
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            _Remark = "File not available in Vault.";
        }
    }

    public static void GetValutFileStatus(string _VaultfilePath, out string status)
    {
        status = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                status = SingleFile[0].FileLfCyc.LfCycStateName;

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static string GetClassApprovedDrawingRevision(string _VaultfilePath)
    {
        string _DrawingRevison = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _DrawingRevison = SingleFile[0].FileRev.Label.ToString();
            }
            return _DrawingRevison;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _DrawingRevison;
        }
    }

    public static Autodesk.Connectivity.WebServices.File SearchFileByName(string _filename, string _DocumentCategory, Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _VaultProjectFolder)
    {
        Autodesk.Connectivity.WebServices.File myFile = null;

        try
        {
            PropDef[] filePropDefs = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE");
            PropDef FileNamePropDef = filePropDefs.Single(n => n.SysName == "Name");

            SrchCond FileSearchCond = new SrchCond()
            {
                PropDefId = FileNamePropDef.Id,
                PropTyp = PropertySearchType.SingleProperty,
                SrchOper = 1,
                SrchRule = SearchRuleType.Must,
                SrchTxt = _filename,
            };

            SrchCond FileSearchCondwithfileExtension = new SrchCond()
            {
                PropDefId = FileNamePropDef.Id,
                PropTyp = PropertySearchType.SingleProperty,
                SrchOper = 1,
                SrchRule = SearchRuleType.Must,
                SrchTxt = _filename,
            };

            string bookmark = string.Empty;
            SrchStatus status = null;
            List<Autodesk.Connectivity.WebServices.File> totalResults = new List<Autodesk.Connectivity.WebServices.File>();
            while (status == null || totalResults.Count < status.TotalHits)
            {
                Autodesk.Connectivity.WebServices.File[] results = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindFilesBySearchConditions(
                    new SrchCond[] { FileSearchCond, FileSearchCondwithfileExtension },
                    null, new long[] { _VaultProjectFolder.Id }, true, true, ref bookmark, out status);

                if (results != null)
                    totalResults.AddRange(results);
                else
                    break;
            }

            if (totalResults.Count > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File itemFile in totalResults)
                {
                    if (itemFile.Cat.CatName.Trim().ToUpper() == _DocumentCategory)
                    {
                        return itemFile;
                    }
                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);

        }
        return myFile;
    }


    public static void DisposeAllObjects()
    {
        try
        {

            IsReadOnly = false;
            IsFilter = false;

            clsStaticGlobal.VaultSurvayerReferenceDocFolder = null;
            clsStaticGlobal.VaultSurvayerFolder = null;
            clsStaticGlobal.ProjectFolder = null;
            clsStaticGlobal.RelatedDocumentDADFiles = null;
            clsStaticGlobal.ClassApprovedDrawingFiles = null;
            clsStaticGlobal.ReferenceDocumentFiles = null;

            clsStaticGlobal.ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();
            clsStaticGlobal.CommentStatesCollection = new ObservableCollection<CommentStates>();
            clsStaticGlobal.objSingleSurveyorCommentSummary = null;
            clsStaticGlobal.objSurveyorCommentsCollection = null;
            clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection = new ObservableCollection<SingleSurveyorCommentSummary>();

            clsStaticGlobal.RelatedDocumentDADSearchedItemCollection = new ObservableCollection<RelatedDocumentDAD>();
            clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection = new ObservableCollection<ClassApprovedDrawing>();
            clsStaticGlobal.ReferenceDocumentSearchedItemCollection = new ObservableCollection<ReferenceDocument>();
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool VaultFileCommentUpdate(string _VaultFilePath, string _NewComment)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _NewComment);
                newFile = files[0];
                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static bool VaultFileChangeStateAndComment(string _VaultFilePath, string _StateName, string _Comment)
    {
        bool _IsSuccess = false;
        try
        {

            long _stateID = -1;

            LfCycDef _PostDeliveryCommentsLifeCycleDef = null;
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            foreach (LfCycDef lcDef in lcDefs)
            {
                if ((lcDef.DispName.ToUpper() == "POST DELIVERY COMMENTS") || (lcDef.Name.ToUpper() == "POST DELIVERY COMMENTS"))
                {
                    _PostDeliveryCommentsLifeCycleDef = lcDef;
                    break;
                }
            }

            if (_PostDeliveryCommentsLifeCycleDef != null)
            {
                LfCycDef lifecycleDef = _PostDeliveryCommentsLifeCycleDef;
                LfCycState[] states = lifecycleDef.StateArray;

                foreach (LfCycState state in states)
                {
                    if ((state.DispName.ToUpper() == _StateName.ToUpper()) || (state.Name.ToUpper() == _StateName.ToUpper()))
                    {
                        _stateID = state.Id;
                        break;
                    }
                }
            }
            if (_stateID != -1)
            {
                Autodesk.Connectivity.WebServices.File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFiles;
                SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
                if (SingleFiles.Length != 0)
                {
                    newFile = SingleFiles[0];
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                    new long[] { newFile.MasterId }, new long[] { _stateID }, _Comment);
                    newFile = files[0];
                    _IsSuccess = true;


                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static void VaultFileGetStateAndComment(string _VaultFilePath, out string _StateName, out string _Comment)
    {
        _StateName = "";
        _Comment = "";
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                _StateName = newFile.FileLfCyc.LfCycStateName;
                _Comment = newFile.Comm;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static Autodesk.Connectivity.WebServices.File IsFileExistintoVault(Autodesk.Connectivity.WebServices.Folder parentFolder, string _Vaultfilename)
    {
        Autodesk.Connectivity.WebServices.File _file = null;
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Name.ToUpper().Trim() == _Vaultfilename.ToUpper().Trim())
                    {
                        _file = file;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _file;
    }

    public static bool UpdateFileRemark(SingleSurveyorCommentSummary _objSingleSurveyorCommentSummary)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _objSingleSurveyorCommentSummary.Comment);
                newFile = files[0];
                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _IsSuccess;
    }

}
