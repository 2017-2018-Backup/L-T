﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsHOTypes : ObservableCollection<NameCodePair>
    {
        public static BarsHOTypes LoadList()
        {
            BarsHOTypes items = new BarsHOTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "ROUND" });
            items.Add(new NameCodePair() { Code = "02", Name = "SQUARE" });
            items.Add(new NameCodePair() { Code = "03", Name = "-" });
            items.Add(new NameCodePair() { Code = "04", Name = "HALF ROUND" });
            items.Add(new NameCodePair() { Code = "05", Name = "HOLLOW SQUARE BAR" });

            return items;
        }
        public static BarsHOTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsHOTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsHOTypes>(HullOutfitItems.DataPath + @"\Bars\BarsHOTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsHOTypes>(this, HullOutfitItems.DataPath + @"\Bars\BarsHOTypes.xml");
        }
    }
}
