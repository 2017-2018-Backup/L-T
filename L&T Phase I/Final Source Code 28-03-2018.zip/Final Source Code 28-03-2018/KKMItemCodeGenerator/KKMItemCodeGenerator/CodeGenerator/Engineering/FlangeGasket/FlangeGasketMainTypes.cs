﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeGasketMainTypes : ObservableCollection<NameCodePair>
    {
        public static FlangeGasketMainTypes LoadList()
        {
            FlangeGasketMainTypes items = new FlangeGasketMainTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "FLANGE" });
            items.Add(new NameCodePair() { Code = "02", Name = "GASKET" });
            return items;
        }
        public static FlangeGasketMainTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeGasketMainTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeGasketMainTypes>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeGasketMainTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeGasketMainTypes>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeGasketMainTypes.xml");
        }

    }
}
