﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingScupperSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingScupperSubTypes LoadList()
        {
            PipeFittingScupperSubTypes items = new PipeFittingScupperSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "DECK SCUPPER" });
            items.Add(new NameCodePair() { Code = "01", Name = "SANITARY SCUPPER" });
            items.Add(new NameCodePair() { Code = "02", Name = "SCUPPER PLUG" });
            return items;
        }
        public static PipeFittingScupperSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingScupperSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingScupperSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingScupperSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingScupperSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingScupperSubTypes.xml");
        }

    }
}
