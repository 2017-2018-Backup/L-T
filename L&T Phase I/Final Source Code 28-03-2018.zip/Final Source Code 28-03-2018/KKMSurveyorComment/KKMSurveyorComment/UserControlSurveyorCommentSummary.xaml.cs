﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using KKMSurveyorComment;
using System.Xml.Serialization;
using System.IO;
using System.Diagnostics;
using excel = Microsoft.Office.Interop.Excel;
using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace KKMSurveyorComment
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlSurveyorCommentSummary : Window
    {
        UserControlReferenceDocument objfrmReferenceDocument;
        UserControlRelatedDocumentDAD objfrmRelatedDocumentDAD;
        UserControlClassApprovedDocument objfrmClassApprovedDocument;
        frmCreateNewSurveyorComment objfrmCreateNewSurveyorComment;
        frmSurveyorCommentLifecycle objfrmSurveyorLifecycle;

        public ObservableCollection<SingleSurveyorCommentSummary> FileCollection { get { return clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection; } }

        public UserControlSurveyorCommentSummary()
        {
            InitializeComponent();
            try
            {
                //Debugger.Launch();
                clsStaticGlobal.DisposeAllObjects();
                clsStaticGlobal.GetProjectCodes();
                cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
                clsStaticGlobal.GetCommentStates();
                cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;
                //cmbCommentStatus.SelectedIndex = 0;
                chkIsFilter.IsChecked = false;
                IsFilterAllow(false);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            //if (this.CloseButtonClicked != null)
            //    CloseButtonClicked(sender, e);
            this.Close();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                //Debugger.Launch();
                clsStaticGlobal.DisposeAllObjects();
                clsStaticGlobal.GetProjectCodes();
                cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
                clsStaticGlobal.GetCommentStates();
                cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;
                //cmbCommentStatus.SelectedIndex = 0;
                chkIsFilter.IsChecked = false;
                IsFilterAllow(false);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void IsFilterAllow(bool _IsReadOnly)
        {
            if (_IsReadOnly == true)
            {

                txtSurvCommentName.Visibility = Visibility.Visible;
                lblCommentName.Visibility = Visibility.Visible;
                cmbCommentStatus.Visibility = Visibility.Visible;
                lblCommentStatus.Visibility = Visibility.Visible;
                txtSurvDrawingName.Visibility = Visibility.Visible;
                lblDrawingName.Visibility = Visibility.Visible;
                cmdFilter.Visibility = Visibility.Visible;
            }
            else
            {

                txtSurvCommentName.Visibility = Visibility.Hidden;
                lblCommentName.Visibility = Visibility.Hidden;
                cmbCommentStatus.Visibility = Visibility.Hidden;
                lblCommentStatus.Visibility = Visibility.Hidden;
                txtSurvDrawingName.Visibility = Visibility.Hidden;
                lblDrawingName.Visibility = Visibility.Hidden;
                cmdFilter.Visibility = Visibility.Hidden;
            }

        }

        private void cmbProjectCode_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (chkIsFilter.IsChecked == true)
            {
                chkIsFilter.IsChecked = false;
            }
            else
            {
                BindwithFilter();
            }
        }

        private void BindwithFilter()
        {
            try
            {
                clsStaticGlobal.objSurveyorCommentsCollection = new SurveyorCommentsCollection();
                FileCollection.Clear();

                if (((ProjectCodes)cmbProjectCode.SelectedItem) != null)
                {
                    clsStaticGlobal._ProjectCode = ((ProjectCodes)cmbProjectCode.SelectedItem).ProjectCodeName.ToString();
                    clsStaticGlobal.VaultSurvayerFolder = clsStaticGlobal.GetorCreateSurveyorCommentFolder(clsStaticGlobal._ProjectCode);

                    if (clsStaticGlobal.VaultSurvayerFolder != null)
                    {
                        if (GetAllFilesByProjectFolder(clsStaticGlobal._ProjectCode) == true)
                        {
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridSurveyorCommentSummary.DataContext = this;
                            clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("User does not have full permission for selected Project Folder.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void BindingDataGridView()
        {
            try
            {
                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.Clear();
                DataGridSurveyorCommentSummary.Items.Refresh();
                if (clsStaticGlobal.objSurveyorCommentsCollection.collectionSurveyorCommentSummary != null)
                {
                    foreach (SingleSurveyorCommentSummary objSingleSurveyorCommentSummary in clsStaticGlobal.objSurveyorCommentsCollection.collectionSurveyorCommentSummary)
                    {
                        if (chkIsFilter.IsChecked == true)
                        {
                            bool IsAdd = false;
                            string CommentName = txtSurvCommentName.Text.Trim().Replace("*", "");
                            string CommentState = ((CommentStates)cmbCommentStatus.SelectedItem).CommentState.ToString();
                            string DrawingName = txtSurvDrawingName.Text.Trim().Replace("*", "");

                            if (objSingleSurveyorCommentSummary.SurveyorCommentName.ToUpper().Contains(CommentName.Trim().ToUpper()) && objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileName.ToUpper().Contains(DrawingName.Trim().ToUpper()))
                            {
                                if (CommentState == "All")
                                {
                                    IsAdd = true;
                                }
                                else
                                {
                                    if (objSingleSurveyorCommentSummary.LifeCycle == CommentState)
                                    {
                                        IsAdd = true;
                                    }
                                }
                            }


                            if (IsAdd == true)
                            {
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.Add(objSingleSurveyorCommentSummary);
                            }
                        }
                        else
                        {
                            clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.Add(objSingleSurveyorCommentSummary);
                        }
                    }

                    DataGridSurveyorCommentSummary.UpdateLayout();
                }

                DataGridSurveyorCommentSummary.UpdateLayout();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        void AllSurveyorCommentSummary_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection)
                {
                    item.SurveyorCommentCount = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void ContextMenuLifeCycle_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        string _LifeCycle = clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle;
                        objfrmSurveyorLifecycle = new frmSurveyorCommentLifecycle(ref clsStaticGlobal.objSingleSurveyorCommentSummary, true);
                        objfrmSurveyorLifecycle.ShowDialog();
                        if (_LifeCycle != clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle)
                        {
                            String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                            clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridSurveyorCommentSummary.DataContext = this;
                            clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Please select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Please select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private SingleSurveyorCommentSummary GetSelectedDataGridRow(object sender)
        {
            try
            {
                if (DataGridSurveyorCommentSummary.SelectedItems.Count > 0)
                {
                    if (DataGridSurveyorCommentSummary.SelectedItems.Count == 1)
                    {
                        SingleSurveyorCommentSummary objSingleSurveyorCommentSummary = (SingleSurveyorCommentSummary)DataGridSurveyorCommentSummary.SelectedCells[0].Item;
                        return objSingleSurveyorCommentSummary;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return null;
            }
        }

        private void DeleteFileFromDirectory(string _DirectoryPath)
        {
            try
            {
                if (Directory.Exists(_DirectoryPath))
                {
                    foreach (string file in Directory.GetFiles(_DirectoryPath))
                    {
                        System.IO.File.SetAttributes(file, FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error in deleting files.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private bool GetAllFilesByProjectFolder(string _ProjectCode)
        {
            try
            {
                try
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
                }
                catch (Exception ex)
                {

                    clsStaticGlobal.ErrHandlerLog(ex);
                }
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultSurvayerFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.SurveyorCommentFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            FileIterations.Add(new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file));
                        }
                    }
                    ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters = (ICollection<VDF.Vault.Currency.Entities.FileIteration>)FileIterations;
                    DownlodAllProjectSpecificSurveyorCommentFiles(fileIters, _ProjectCode);
                    return true;

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("No Surveyor Comments available.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return false;
            }
        }

        public void DownlodAllProjectSpecificSurveyorCommentFiles(ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters, string _ProjectCode)
        {
            try
            {
                DeleteFileFromDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);

                if (!Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode))
                {
                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
                }
                else
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
                }


                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + _ProjectCode);
                foreach (VDF.Vault.Currency.Entities.FileIteration fileIter in fileIters)
                {
                    settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                }
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void AddSurveyorComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                clsStaticGlobal.IsReadOnly = false;
                //Debugger.Launch();
                clsStaticGlobal.objSingleSurveyorCommentSummary = new SingleSurveyorCommentSummary();
                List<int> lstCommentsNumbers = GetAllCommentsNumbers(clsStaticGlobal._ProjectCode);
                if (lstCommentsNumbers.Count > 0)
                {
                    clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentNumber = lstCommentsNumbers.Last() + 1;
                }
                else
                {
                    clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentNumber = 1;
                }
                objfrmCreateNewSurveyorComment = new frmCreateNewSurveyorComment(false, false, "");
                objfrmCreateNewSurveyorComment.ShowDialog();

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                        DataGridSurveyorCommentSummary.DataContext = this;
                        clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                        BindingDataGridView();
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void EditComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        clsStaticGlobal.IsReadOnly = false;

                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        string checkedOutUsername = "";

                        bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath, out checkedOutUsername);

                        string CurrentUser = "";
                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    CurrentUser = userinfo.User.LastName.Trim();
                        //}
                        //else
                        //{
                        //    CurrentUser = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}
                        CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);

                        if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                        {
                            if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath))
                            {
                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                            }
                            IsCheckedOut = false;
                        }

                        if (IsCheckedOut == false)
                        {
                            if (Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                            }
                            else
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                            }
                            clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath);
                        }


                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        {
                            clsStaticGlobal.IsReadOnly = true;
                        }

                        objfrmCreateNewSurveyorComment = new frmCreateNewSurveyorComment(true, IsCheckedOut, checkedOutUsername);

                        if (objfrmCreateNewSurveyorComment.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            if (clsStaticGlobal.IsReadOnly == false)
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                TextWriter tw = new StreamWriter(_xmlFilePath);
                                xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                tw.Close();

                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);

                                clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                DataGridSurveyorCommentSummary.DataContext = this;
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                BindingDataGridView();
                            }
                        }
                        else
                        {
                            if (IsCheckedOut == false)
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                                else
                                {
                                    XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                    TextWriter tw = new StreamWriter(_xmlFilePath);
                                    xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                    tw.Close();
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                            }
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void LifeCycle_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Debugger.Launch();

                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        clsStaticGlobal.IsReadOnly = false;
                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        //{
                        //    clsStaticGlobal.IsReadOnly = true;
                        //}
                        string _LifeCycle = clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle;
                        string _LifeCycleComment = clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment;
                        objfrmSurveyorLifecycle = new frmSurveyorCommentLifecycle(ref clsStaticGlobal.objSingleSurveyorCommentSummary, true);
                        objfrmSurveyorLifecycle.ShowDialog();
                        if (clsStaticGlobal.IsReadOnly == false)
                        {
                            if ((_LifeCycle != clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle) || (_LifeCycleComment != clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment))
                            {
                                //String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                DataGridSurveyorCommentSummary.DataContext = this;
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                BindingDataGridView();
                            }
                        }

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Surveyor Comment First.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void RelatedDocumentDAD_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        clsStaticGlobal.IsReadOnly = false;

                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        string checkedOutUsername = "";

                        bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath, out checkedOutUsername);

                        string CurrentUser = "";
                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    CurrentUser = userinfo.User.LastName.Trim();
                        //}
                        //else
                        //{
                        //    CurrentUser = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}
                        CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);
                        if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                        {
                            if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath))
                            {
                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                            }
                            IsCheckedOut = false;
                        }

                        if (IsCheckedOut == false)
                        {
                            if (Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                            }
                            else
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                            }
                            clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath);
                        }


                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        {
                            clsStaticGlobal.IsReadOnly = true;
                        }

                        //clsStaticGlobal.IsReadOnly = false;
                        //clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        //{
                        //    clsStaticGlobal.IsReadOnly = true;
                        //}

                        clsStaticGlobal.RelatedDocumentDADFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                        Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.ProjectFolder.FullName);
                        clsStaticGlobal.PrintRelatedDocumentDADFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                        objfrmRelatedDocumentDAD = new UserControlRelatedDocumentDAD(true, IsCheckedOut, checkedOutUsername);
                        objfrmRelatedDocumentDAD.ShowDialog();
                        if (objfrmRelatedDocumentDAD.DialogResUserControlRelatedDocumentDAD == System.Windows.Forms.DialogResult.OK)
                        {
                            if (clsStaticGlobal.IsReadOnly == false)
                            {
                                clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs = "";

                                foreach (RelatedDocumentDAD itemRelatedDocumentDAD in clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD)
                                {
                                    if ((clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs != null) && (clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs != ""))
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs = clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs + Environment.NewLine + itemRelatedDocumentDAD.FileName;
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs = itemRelatedDocumentDAD.FileName;
                                    }
                                }

                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                TextWriter tw = new StreamWriter(_xmlFilePath);
                                xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                tw.Close();

                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);

                                clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                DataGridSurveyorCommentSummary.DataContext = this;
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                BindingDataGridView();

                                //if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                                //{
                                //    //clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDAD = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD[0].FileName;
                                //    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //    DataGridSurveyorCommentSummary.DataContext = this;
                                //    clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //    BindingDataGridView();
                                //}
                                //else
                                //{
                                //    //clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDAD = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD[0].FileName;
                                //    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //    DataGridSurveyorCommentSummary.DataContext = this;
                                //    clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //    BindingDataGridView();
                                //}
                            }
                        }
                        else
                        {
                            if (IsCheckedOut == false)
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                                else
                                {
                                    XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                    TextWriter tw = new StreamWriter(_xmlFilePath);
                                    xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                    tw.Close();
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                            }
                        }


                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Surveyor Comment First.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void ClassApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ObservableCollection<ClassApprovedDrawing> TempListClassApprovedDrawing = new ObservableCollection<ClassApprovedDrawing> { };

                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                {
                    TempListClassApprovedDrawing.Add(clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0]);
                }

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        //clsStaticGlobal.IsReadOnly = false;
                        //clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        //{
                        //    clsStaticGlobal.IsReadOnly = true;
                        //}

                        clsStaticGlobal.IsReadOnly = false;

                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        string checkedOutUsername = "";

                        bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath, out checkedOutUsername);

                        string CurrentUser = "";
                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    CurrentUser = userinfo.User.LastName.Trim();
                        //}
                        //else
                        //{
                        //    CurrentUser = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}

                        CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);

                        if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                        {
                            if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath))
                            {
                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                            }
                            IsCheckedOut = false;
                        }

                        if (IsCheckedOut == false)
                        {
                            if (Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                            }
                            else
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                            }
                            clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath);
                        }


                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        {
                            clsStaticGlobal.IsReadOnly = true;
                        }

                        clsStaticGlobal.ClassApprovedDrawingFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                        Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.ProjectFolder.FullName);
                        clsStaticGlobal.PrintClassApprovedDocumentFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                        objfrmClassApprovedDocument = new UserControlClassApprovedDocument(true, IsCheckedOut, checkedOutUsername);
                        objfrmClassApprovedDocument.ShowDialog();

                        if (objfrmClassApprovedDocument.DialogResUserControlClassApprovedDocument == System.Windows.Forms.DialogResult.OK)
                        {
                            if (clsStaticGlobal.IsReadOnly == false)
                            {

                                clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = "";

                                foreach (ClassApprovedDrawing itemClassApprovedDrawing in clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                                {
                                    if ((clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments != null) && (clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments != ""))
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments + Environment.NewLine + itemClassApprovedDrawing.FileName;
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = itemClassApprovedDrawing.FileName;
                                    }
                                }

                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                TextWriter tw = new StreamWriter(_xmlFilePath);
                                xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                tw.Close();

                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);

                                clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                DataGridSurveyorCommentSummary.DataContext = this;
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                BindingDataGridView();

                                //if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                                //{
                                //    clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileName;
                                //    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRemark = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRemark;
                                //    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRevision;
                                //    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileStatus;
                                //    clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName = "SC_" + clsStaticGlobal._ProjectCode + "_" + clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument + "_" + clsStaticGlobal.objSingleSurveyorCommentSummary.SubParaRef;

                                //    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //    DataGridSurveyorCommentSummary.DataContext = this;
                                //    clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //    BindingDataGridView();
                                //}
                                //else
                                //{
                                //    if (TempListClassApprovedDrawing.Count > 0)
                                //    {
                                //        clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Add(TempListClassApprovedDrawing[0]);
                                //        clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileName;
                                //        clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRemark = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRemark;
                                //        clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRevision;
                                //        clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileStatus;
                                //        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //        clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //        clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //        DataGridSurveyorCommentSummary.DataContext = this;
                                //        clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //        BindingDataGridView();
                                //    }

                                //}
                            }
                        }
                        else
                        {
                            if (IsCheckedOut == false)
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                                else
                                {
                                    XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                    TextWriter tw = new StreamWriter(_xmlFilePath);
                                    xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                    tw.Close();
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                            }
                        }



                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void ReferenceDocument_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Debugger.Launch();

                clsStaticGlobal.objSingleSurveyorCommentSummary = GetSelectedDataGridRow(sender);

                if (clsStaticGlobal.objSingleSurveyorCommentSummary != null)
                {
                    if (clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName != null)
                    {
                        //clsStaticGlobal.IsReadOnly = false;
                        //clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        //{
                        //    clsStaticGlobal.IsReadOnly = true;
                        //}

                        clsStaticGlobal.IsReadOnly = false;

                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;

                        string checkedOutUsername = "";

                        bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath, out checkedOutUsername);

                        string CurrentUser = "";
                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);

                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    CurrentUser = userinfo.User.LastName.Trim();
                        //}
                        //else
                        //{
                        //    CurrentUser = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}

                        // Debugger.Launch();
                        CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);

                        if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                        {
                            if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath))
                            {
                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                            }
                            IsCheckedOut = false;
                        }

                        if (IsCheckedOut == false)
                        {
                            if (Directory.Exists(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    try
                                    {
                                        System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                        System.IO.File.Delete(_xmlFilePath);
                                    }
                                    catch (Exception)
                                    {

                                    }

                                }
                            }
                            else
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                            }
                            clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath);
                        }


                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                        {
                            clsStaticGlobal.IsReadOnly = true;
                        }

                        objfrmReferenceDocument = new UserControlReferenceDocument(true, IsCheckedOut, checkedOutUsername);
                        objfrmReferenceDocument.ShowDialog();
                        if (objfrmReferenceDocument.DialogResUserControlReferenceDocument == System.Windows.Forms.DialogResult.OK)
                        {
                            if (clsStaticGlobal.IsReadOnly == false)
                            {
                                clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments = "";

                                foreach (ReferenceDocument itemReferenceDocument in clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument)
                                {
                                    if ((clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments != null) && (clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments != ""))
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments = clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments + Environment.NewLine + itemReferenceDocument.FileName;
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.ReferenceDocuments = itemReferenceDocument.FileName;
                                    }
                                }


                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                    System.IO.File.Delete(_xmlFilePath);
                                }
                                XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                TextWriter tw = new StreamWriter(_xmlFilePath);
                                xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                tw.Close();

                                clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);

                                clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                DataGridSurveyorCommentSummary.DataContext = this;
                                clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                BindingDataGridView();

                                //if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.Count > 0)
                                //{
                                //    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //    DataGridSurveyorCommentSummary.DataContext = this;
                                //    clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //    BindingDataGridView();
                                //}
                                //else
                                //{
                                //    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                //    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, true);
                                //    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSurveyorCommentsCollection, clsStaticGlobal.objSingleSurveyorCommentSummary, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal._ProjectCode);
                                //    DataGridSurveyorCommentSummary.DataContext = this;
                                //    clsStaticGlobal.SingleSurveyorCommentSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllSurveyorCommentSummary_CollectionChanged);
                                //    BindingDataGridView();
                                //}
                            }
                        }
                        else
                        {
                            if (IsCheckedOut == false)
                            {
                                if (System.IO.File.Exists(_xmlFilePath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                                else
                                {
                                    XmlSerializer xs = new XmlSerializer(typeof(SingleSurveyorCommentSummary));
                                    TextWriter tw = new StreamWriter(_xmlFilePath);
                                    xs.Serialize(tw, clsStaticGlobal.objSingleSurveyorCommentSummary);
                                    tw.Close();
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName, clsStaticGlobal.LocalXMLSurveyorCommentFolderPath, clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment);
                                }
                            }
                        }

                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Surveyor Comment.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmdExport_Click(object sender, RoutedEventArgs e)
        {
            excel.Application xlApp;
            excel.Workbook xlWorkBook;
            excel.Worksheet xlWorkSheet;
            //bool IsExport = false;
            bool IsExport = true;
            try
            {
                List<SingleSurveyorCommentSummary> excelSingleSurveyorCommentSummaryList = new List<SingleSurveyorCommentSummary>();

                foreach (var item in DataGridSurveyorCommentSummary.SelectedItems)
                {
                    excelSingleSurveyorCommentSummaryList.Add((SingleSurveyorCommentSummary)item);
                }

                if (excelSingleSurveyorCommentSummaryList.Count > 0)
                {
                    //try
                    //{

                    //    foreach (SingleSurveyorCommentSummary _ObjSingleSurveyorCommentSummary in clsStaticGlobal.objSurveyorCommentsCollection.collectionSurveyorCommentSummary)
                    //    {
                    //        if (_ObjSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                    //        {
                    //            IsExport = true;
                    //        }
                    //    }

                    //    if (IsExport == false)
                    //    {
                    //        System.Windows.MessageBox.Show("There is no one Surveyor Comment in release state.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                    //    }
                    //}
                    //catch (Exception ex)
                    //{
                    //    System.Windows.MessageBox.Show("Error in report export.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                    //    clsStaticGlobal.ErrHandlerLog(ex);
                    //}

                    if (IsExport == true)
                    {
                        string _Filename = "Surveyor Comments";
                        System.Windows.Forms.Application.DoEvents();
                        System.Windows.Forms.SaveFileDialog saveFileDialog = new System.Windows.Forms.SaveFileDialog();
                        saveFileDialog.Title = "Save Excel Report";
                        saveFileDialog.RestoreDirectory = true;
                        saveFileDialog.FileName = "Surveyor Comments Summary_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        saveFileDialog.DefaultExt = "xlsx";

                        if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            _Filename = saveFileDialog.FileName;
                        }
                        else
                        {
                            return;
                        }

                        /////////////////////// Create Excel Application Object
                        object mMissingValue = System.Reflection.Missing.Value;
                        xlApp = new excel.Application();
                        xlApp.DisplayAlerts = false;
                        xlWorkBook = xlApp.Workbooks.Add(mMissingValue);
                        xlWorkSheet = null;

                        try
                        {
                            var prevSheet = xlWorkSheet;

                            if (prevSheet == null)
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(xlWorkBook.Sheets[1], mMissingValue, mMissingValue, mMissingValue);
                            }
                            else
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(mMissingValue, prevSheet, mMissingValue, mMissingValue);
                            }
                            xlWorkSheet.Name = "Surveyor Comments Summary";
                            int BorderStartindex = 0;
                            int RowNo = 2;
                            int ColNo = 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Surveyor Comments";
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Size = 16;
                            RowNo += 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Downloaded Date";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = "'" + DateTime.Now.ToLongDateString();
                            RowNo += 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "User ID";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = clsStaticGlobal.connection.UserName.ToString();
                            RowNo += 2;

                            int LoopRowNo = RowNo;
                            int LoopColNo = ColNo;

                            int StartRowNo = RowNo;
                            int StartColNo = ColNo;

                            xlWorkSheet.Cells[RowNo, ColNo - 1] = "Sr.No.";
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Surveyor Comment Name";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Comment Status";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Lifecycle Comment";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Originated Date";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Related Project";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Approved Document";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Approved Document File Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Drawing Revision";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Remark";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Remark Type";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Classification Society";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Sub Para Ref";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Functional Group";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Issue Number";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Drawing Remark";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Drawing Status";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Related Document (DAD)";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Related Document (DAD) File Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Reference Documents";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Reference Documents File Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;

                            BorderStartindex = RowNo;
                            int SrNoCnt = 1;
                            int NextCol = LoopColNo;

                            foreach (SingleSurveyorCommentSummary _ObjSingleSurveyorCommentSummary in excelSingleSurveyorCommentSummaryList)
                            {
                                //if (_ObjSingleSurveyorCommentSummary.LifeCycle.ToUpper() == "RELEASE")
                                //{
                                LoopRowNo = LoopRowNo + 1;
                                NextCol = LoopColNo;

                                xlWorkSheet.Cells[LoopRowNo, NextCol - 1] = SrNoCnt.ToString();
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.SurveyorCommentName;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.LifeCycle;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.LifeCycleComment;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.OriginatedDate;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.RelatedProject;
                                //NextCol = NextCol + 1;
                                //xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.ClassApprovedDocument;

                                //if (_ObjSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                                //{
                                //    NextCol = NextCol + 1;
                                //    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FilePath;
                                //}
                                //else
                                //{
                                //    NextCol = NextCol + 1;
                                //    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                //}

                                if (_ObjSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                                {
                                    string _collfilepath = "";
                                    string _collfilename = "";
                                    foreach (ClassApprovedDrawing item in _ObjSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                                    {
                                        if (_collfilepath != "")
                                        {
                                            _collfilepath = _collfilepath + Environment.NewLine + item.FilePath;
                                            _collfilename = _collfilename + Environment.NewLine + item.FileName;
                                        }
                                        else
                                        {
                                            _collfilepath = item.FilePath;
                                            _collfilename = item.FileName;
                                        }
                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.DrawingRevision;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.Comment;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.LRremark;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.ClassificationSociety;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.SubParaRef;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.FunctionalGroup;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.IssueNumber;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.DrawingRemark;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.DrawingStatus;
                                ////NextCol = NextCol + 1;
                                ////xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.RelatedDocumentDADs;

                                //if (_ObjSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                                //{
                                //    NextCol = NextCol + 1;
                                //    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleSurveyorCommentSummary.ListRelatedDocumentDAD[0].FilePath;
                                //}
                                //else
                                //{
                                //    NextCol = NextCol + 1;
                                //    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                //}

                                if (_ObjSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                                {
                                    string _collfilepath = "";
                                    string _collfilename = "";
                                    foreach (RelatedDocumentDAD item in _ObjSingleSurveyorCommentSummary.ListRelatedDocumentDAD)
                                    {
                                        if (_collfilepath != "")
                                        {
                                            _collfilepath = _collfilepath + Environment.NewLine + item.FilePath;
                                            _collfilename = _collfilename + Environment.NewLine + item.FileName;
                                        }
                                        else
                                        {
                                            _collfilepath = item.FilePath;
                                            _collfilename = item.FileName;
                                        }
                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                if (_ObjSingleSurveyorCommentSummary.ListReferenceDocument.Count > 0)
                                {
                                    string _collfilepath = "";
                                    string _collfilename = "";
                                    foreach (ReferenceDocument item in _ObjSingleSurveyorCommentSummary.ListReferenceDocument)
                                    {
                                        if (_collfilepath != "")
                                        {
                                            _collfilepath = _collfilepath + Environment.NewLine + item.FilePath;
                                            _collfilename = _collfilename + Environment.NewLine + item.FileName;
                                        }
                                        else
                                        {
                                            _collfilepath = item.FilePath;
                                            _collfilename = item.FileName;
                                        }
                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }



                                SrNoCnt = SrNoCnt + 1;
                                //}

                            }

                            for (int m = 2; m <= NextCol; m++)
                            {
                                xlWorkSheet.Columns[m].AutoFit();
                            }

                            xlWorkSheet.Range[xlWorkSheet.Cells[StartRowNo, StartColNo - 1], xlWorkSheet.Cells[LoopRowNo, NextCol]].Cells.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;

                            xlWorkBook.SaveAs(_Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                            xlWorkBook.Close(true, mMissingValue, mMissingValue);
                            System.Windows.MessageBox.Show("Surveyor comment summary report exported successfully..!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Information);
                        }

                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            xlApp.Quit();

                            try
                            {
                                clsStaticGlobal.ReleaseObject(xlWorkBook);

                            }
                            catch (Exception)
                            {

                            }
                            clsStaticGlobal.ReleaseObject(xlApp);
                        }
                    }

                }
                else
                {
                    System.Windows.MessageBox.Show("There is no Surveyor comments seletced to export.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex1)
            {
                System.Windows.MessageBox.Show("Excel application not installed.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                clsStaticGlobal.ErrHandlerLog(ex1);
            }

        }

        private void cmdFilter_Click(object sender, RoutedEventArgs e)
        {
            BindwithFilter();
        }

        private void chkIsFilter_Checked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == true)
            {
                IsFilterAllow(true);
            }

        }

        private void chkIsFilter_Unchecked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == false)
            {
                IsFilterAllow(false);
                BindwithFilter();
            }
        }

        private List<int> GetAllCommentsNumbers(string _ProjectCode)
        {
            List<int> listCommentsNumbers = new List<int>();
            try
            {
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultSurvayerFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.SurveyorCommentFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            string[] CommentsNumberSplite = file.Name.Split(new char[] { '_' });
                            string CommentNumber = CommentsNumberSplite[2].ToUpper().Replace(".XML", "");
                            listCommentsNumbers.Add(int.Parse(CommentNumber));
                            listCommentsNumbers.Sort();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return listCommentsNumbers;
        }

        private void cmdcmdMassUploadFormat_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string MassUploadFileFormatPath = clsStaticGlobal.ErrorFilePath + "/Surveyor Comments Mass Upload.xlsx";
                FolderBrowserDialog openfolderdialog1 = new FolderBrowserDialog();
                openfolderdialog1.ShowNewFolderButton = true;
                if (openfolderdialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string MassUploadDestinationFilePath = openfolderdialog1.SelectedPath + "/Surveyor Comments Mass Upload_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";
                    if (System.IO.File.Exists(MassUploadFileFormatPath))
                    {
                        if (System.IO.File.Exists(MassUploadDestinationFilePath))
                            System.IO.File.Delete(MassUploadDestinationFilePath);
                        System.IO.File.Copy(MassUploadFileFormatPath, MassUploadDestinationFilePath);
                        System.Windows.MessageBox.Show("Surveyor Comments Mass Upload File Format Exported Successfully.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Surveyor Comments Mass Upload File Format Exported Failed.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmdcmdMassUpload_Click(object sender, RoutedEventArgs e)
        {

            if (cmbProjectCode.SelectedItem != null)
            {
                OpenFileDialog fdlg = new OpenFileDialog();
                fdlg.Title = "Open File Dialog For Excel File";
                fdlg.InitialDirectory = @"c:\";
                fdlg.Filter = "All files (*.xls)|*.xls|All files (*.xlsx)|*.xlsx";
                fdlg.FilterIndex = 2;
                fdlg.RestoreDirectory = true;
                if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        //Create COM Objects. Create a COM object for everything that is referenced
                        excel.Application xlApp = new excel.Application();
                        excel.Workbook xlWorkbook = xlApp.Workbooks.Open(fdlg.FileName);

                        excel._Worksheet xlWorksheet = xlWorkbook.Sheets["Surveyor Comments"];
                        excel.Range xlRange = xlWorksheet.UsedRange;

                        try
                        {
                            List<SingleSurveyorCommentSummary> _listSurveyorComments = new List<SingleSurveyorCommentSummary> { };

                            int rowCount = xlRange.Rows.Count;
                            int colCount = 16;
                            int actualRowCnt = 1;

                            for (int i = 1; i <= rowCount; i++)
                            {
                                if ((xlRange.Cells[i, 2].Value2 != null) && (xlRange.Cells[i, 2].Value2.ToString().Trim() != ""))
                                {
                                    actualRowCnt = i;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            rowCount = actualRowCnt;

                            bool isBreak = false;
                            int _SurveyorNumber = 0;
                            if (clsStaticGlobal.ListSurveyorCommentNumbers.Count > 0)
                            {
                                _SurveyorNumber = clsStaticGlobal.ListSurveyorCommentNumbers.Last();
                            }
                           // Debugger.Launch();
                            bool IsFormatCorrect = true;
                            for (int i = 1; i <= rowCount; i++)
                            {
                                if (i == 1)
                                {
                                    for (int j = 1; j <= colCount; j++)
                                    {
                                        switch (j)
                                        {
                                            case 1:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sr.No.") { IsFormatCorrect = false; }
                                                break;
                                            case 2:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Project Code") { IsFormatCorrect = false; }
                                                break;
                                            case 3:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Surveyor Comment Name") { IsFormatCorrect = false; }
                                                break;
                                            case 4:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Class Approved Document") { IsFormatCorrect = false; }
                                                break;
                                            case 5:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Comment") { IsFormatCorrect = false; }
                                                break;
                                            case 6:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Issue Number") { IsFormatCorrect = false; }
                                                break;
                                            case 7:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Functional Group") { IsFormatCorrect = false; }
                                                break;
                                            case 8:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Classification Society") { IsFormatCorrect = false; }
                                                break;
                                            case 9:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sub Para Reference") { IsFormatCorrect = false; }
                                                break;
                                            case 10:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Class Remark") { IsFormatCorrect = false; }
                                                break;
                                            case 11:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Class Remark Type") { IsFormatCorrect = false; }
                                                break;
                                            case 12:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Design Remark") { IsFormatCorrect = false; }
                                                break;
                                            case 13:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Related Document (DAD)") { IsFormatCorrect = false; }
                                                break;
                                            default:
                                                break;
                                        }

                                    }
                                }
                                else
                                {
                                    if (IsFormatCorrect)
                                    {
                                        _SurveyorNumber = _SurveyorNumber + 1;
                                        SingleSurveyorCommentSummary _objSingleSurveyorCommentSummary = new SingleSurveyorCommentSummary();
                                        _objSingleSurveyorCommentSummary.LifeCycle = "Create";

                                        for (int j = 1; j <= colCount; j++)
                                        {
                                            if (isBreak == false)
                                            {
                                                switch (j)
                                                {
                                                    case 1:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() == "")
                                                                {
                                                                    System.Windows.MessageBox.Show("Sr.No. column should not empty.!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                System.Windows.MessageBox.Show("Sr.No. column should not empty.!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 2:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    if (xlRange.Cells[i, j].Value2.ToString().Trim() == clsStaticGlobal._ProjectCode)
                                                                    {
                                                                        _objSingleSurveyorCommentSummary.RelatedProject = clsStaticGlobal._ProjectCode;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Selected project and project in mass upload excel is missmatch..!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        isBreak = true;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Project code column should not empty..!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                System.Windows.MessageBox.Show("Project code column should not empty..!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                isBreak = true;

                                                            }

                                                            break;
                                                        }
                                                    case 3:
                                                        {
                                                            try
                                                            {
                                                                _objSingleSurveyorCommentSummary.SurveyorCommentNumber = _SurveyorNumber;
                                                                _objSingleSurveyorCommentSummary.SurveyorCommentCommentNumber = clsStaticGlobal._ProjectCode + "_" + _SurveyorNumber.ToString();
                                                                _objSingleSurveyorCommentSummary.SurveyorCommentFileName = "SC_" + _objSingleSurveyorCommentSummary.SurveyorCommentCommentNumber + ".xml";

                                                            }
                                                            catch (Exception ex)
                                                            {

                                                            }

                                                            break;
                                                        }
                                                    case 4:
                                                        {
                                                            string _ClassApprovedDocuments = "";
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string ClassApprovedDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    ClassApprovedDoc = ClassApprovedDoc.Replace("\n", "");
                                                                    ClassApprovedDoc = ClassApprovedDoc.Replace("\r", "");
                                                                    string[] ClassApprovedDocs = ClassApprovedDoc.Split(new char[] { ';', ',' });
                                                                    int cnt = 1;
                                                                    foreach (var item in ClassApprovedDocs)
                                                                    {

                                                                        string _filepath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + item;
                                                                        Autodesk.Connectivity.WebServices.File _file = clsStaticGlobal.SearchFileByName(item, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);
                                                                        if (_file != null)
                                                                        {
                                                                            if ((_file.FileLfCyc.LfCycStateName != null) && (_file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase)))
                                                                            {
                                                                                Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_file.FolderId);
                                                                                string filePath = folder.FullName + "/" + _file.Name;
                                                                                string fileext = clsStaticGlobal.GetFileExtension(_file.Name);
                                                                                string fileName = _file.Name;
                                                                                string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _file.Id, false);
                                                                                if (fileDec == null)
                                                                                {
                                                                                    fileDec = "";
                                                                                }
                                                                                string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _file.Id, false);
                                                                                if (fileSection == null)
                                                                                {
                                                                                    fileSection = "";
                                                                                }
                                                                                string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _file.Id, false);
                                                                                if (fileRelatedDAD == null)
                                                                                {
                                                                                    fileRelatedDAD = "";
                                                                                }
                                                                                _objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Add(new ClassApprovedDrawing { Count = cnt, IsCheckedClassApprovedDrawing = false, FileType = "Class Approved Document", FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _file.Comm, FileRevision = _file.FileRev.Label.ToString(), FileStatus = _file.FileLfCyc.LfCycStateName.ToString(), FileSection = fileSection, FileRelatedDAD = fileRelatedDAD });
                                                                                cnt += 1;

                                                                                if (_ClassApprovedDocuments.Trim() == "")
                                                                                {
                                                                                    _ClassApprovedDocuments = item;
                                                                                }
                                                                                else
                                                                                {
                                                                                    _ClassApprovedDocuments = _ClassApprovedDocuments + Environment.NewLine + item;
                                                                                }

                                                                            }
                                                                            else
                                                                            {
                                                                                System.Windows.MessageBox.Show("Class approved document not in release state..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                                isBreak = true;

                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            System.Windows.MessageBox.Show("Class approved document does not exist..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                            isBreak = true;
                                                                        }
                                                                    }

                                                                    _objSingleSurveyorCommentSummary.ClassApprovedDocuments = _ClassApprovedDocuments;
                                                                    _objSingleSurveyorCommentSummary.ClassApprovedDocument = xlRange.Cells[i, j].Value2.ToString();

                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.ClassApprovedDocument = "";
                                                                    _objSingleSurveyorCommentSummary.ClassApprovedDocuments = _ClassApprovedDocuments;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.ClassApprovedDocument = "";
                                                                _objSingleSurveyorCommentSummary.ClassApprovedDocuments = _ClassApprovedDocuments;

                                                                isBreak = true;

                                                            }

                                                            break;
                                                        }
                                                    case 5:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.LifeCycleComment = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.LifeCycleComment = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.LifeCycleComment = "";
                                                            }

                                                            break;
                                                        }
                                                    case 6:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.IssueNumber = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.IssueNumber = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.IssueNumber = "";
                                                            }

                                                            break;
                                                        }
                                                    case 7:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.FunctionalGroup = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.FunctionalGroup = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.FunctionalGroup = "";
                                                            }

                                                            break;
                                                        }
                                                    case 8:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string function = xlRange.Cells[i, j].Value2.ToString();
                                                                    function = function.Replace("\n", "");
                                                                    function = function.Replace("\r", "");
                                                                    string[] functions = function.Split(new char[] { ';', ',' });
                                                                    string _function = "";
                                                                    List<string> _functions = new List<string>();

                                                                    foreach (var item in functions)
                                                                    {
                                                                        if (_function.Trim() == "")
                                                                        {
                                                                            _function = item;
                                                                        }
                                                                        else
                                                                        {
                                                                            _function = _function + Environment.NewLine + item;
                                                                        }
                                                                        _functions.Add(item);

                                                                    }
                                                                    _objSingleSurveyorCommentSummary.ClassificationSociety = function;
                                                                    _objSingleSurveyorCommentSummary.ClassificationSocieties = _functions;
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.ClassificationSociety = "";
                                                                    _objSingleSurveyorCommentSummary.ClassificationSocieties = new List<string>();
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.ClassificationSociety = "";
                                                                _objSingleSurveyorCommentSummary.ClassificationSocieties = new List<string>();
                                                            }

                                                            break;
                                                        }
                                                    case 9:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.SubParaRef = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.SubParaRef = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.SubParaRef = "";
                                                            }

                                                            break;
                                                        }
                                                    case 10:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.Comment = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.Comment = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.Comment = "";
                                                            }

                                                            break;
                                                        }
                                                    case 11:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.LRremark = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.LRremark = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.LRremark = "";
                                                            }

                                                            break;
                                                        }
                                                    case 12:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleSurveyorCommentSummary.EditCommentRemark = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.EditCommentRemark = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.EditCommentRemark = "";
                                                            }

                                                            break;
                                                        }
                                                    case 13:
                                                        {
                                                            string _RelatedDADDocuments = "";
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string RelatedDADDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    RelatedDADDoc = RelatedDADDoc.Replace("\n", "");
                                                                    RelatedDADDoc = RelatedDADDoc.Replace("\r", "");
                                                                    string[] RelatedDADDocs = RelatedDADDoc.Split(new char[] { ';', ',' });
                                                                    int cnt = 1;
                                                                    foreach (var item in RelatedDADDocs)
                                                                    {

                                                                        string _filepath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + item;
                                                                        Autodesk.Connectivity.WebServices.File _file = clsStaticGlobal.SearchFileByName(item, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);
                                                                        if (_file != null)
                                                                        {
                                                                            if ((_file.FileLfCyc.LfCycStateName != null) && (_file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase)))
                                                                            {
                                                                                Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_file.FolderId);
                                                                                string filePath = folder.FullName + "/" + _file.Name;
                                                                                string fileext = clsStaticGlobal.GetFileExtension(_file.Name);
                                                                                string fileName = _file.Name;
                                                                                string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _file.Id, false);
                                                                                if (fileDec == null)
                                                                                {
                                                                                    fileDec = "";
                                                                                }
                                                                                
                                                                                _objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Add(new RelatedDocumentDAD { Count = cnt, IsCheckedRelatedDocumentDAD = false, FileType = "Related Document (DAD)", FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _file.Comm, FileRevision = _file.FileRev.Label.ToString(), FileStatus = _file.FileLfCyc.LfCycStateName.ToString() });
                                                                                cnt += 1;

                                                                                if (_RelatedDADDocuments.Trim() == "")
                                                                                {
                                                                                    _RelatedDADDocuments = item;
                                                                                }
                                                                                else
                                                                                {
                                                                                    _RelatedDADDocuments = _RelatedDADDocuments + Environment.NewLine + item;
                                                                                }

                                                                            }
                                                                            else
                                                                            {
                                                                                System.Windows.MessageBox.Show("Class approved document not in release state..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                                isBreak = true;

                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            System.Windows.MessageBox.Show("Class approved document does not exist..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                            isBreak = true;
                                                                        }
                                                                    }

                                                                    _objSingleSurveyorCommentSummary.RelatedDocumentDADs = _RelatedDADDocuments;                                                                   

                                                                }
                                                                else
                                                                {
                                                                    _objSingleSurveyorCommentSummary.RelatedDocumentDADs = "";
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleSurveyorCommentSummary.RelatedDocumentDADs = "";                                                               
                                                                isBreak = true;

                                                            }
                                                            break;
                                                        }
                                                    default:
                                                        break;
                                                }

                                            }

                                        }

                                        _listSurveyorComments.Add(_objSingleSurveyorCommentSummary);

                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Invalid column header..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                        isBreak = true;
                                    }

                                }

                            }

                            //cleanup
                            GC.Collect();
                            GC.WaitForPendingFinalizers();

                            if (isBreak == false)
                            {
                                if (_listSurveyorComments.Count > 0)
                                {
                                    if (MassUpload(_listSurveyorComments))
                                    {
                                        System.Windows.MessageBox.Show("Mass upload done successfully.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Information);

                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                                    }

                                }
                                else
                                {
                                    System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                                }

                            }
                            else
                            {
                                System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                            }

                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            try
                            {
                                Marshal.ReleaseComObject(xlRange);
                                Marshal.ReleaseComObject(xlWorksheet);

                                //close and release
                                xlWorkbook.Close();
                                Marshal.ReleaseComObject(xlWorkbook);

                                //quit and release
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);

                            }
                            catch (Exception)
                            {
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);
                            }

                        }

                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Excel application not installed.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                System.Windows.MessageBox.Show("Select project first.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }
        
        private bool MassUpload(List<SingleSurveyorCommentSummary> _listSingleSurveyorComments)
        {
            bool _isSuccess = false;
            try
            {
                foreach (SingleSurveyorCommentSummary _objSingleSurveyorCommentSummary in _listSingleSurveyorComments)
                {
                    String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + _objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                    _objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + _objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                    clsStaticGlobal.BindingDataSingleWrite(_objSingleSurveyorCommentSummary, _xmlFilePath, false);
                    clsStaticGlobal.UpdateFileRemark(_objSingleSurveyorCommentSummary);

                }

                BindwithFilter();

                _isSuccess = true;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _isSuccess;
        }
        
    }

    public class ProjectCodes
    {
        private string mProjectCode;

        public string ProjectCodeName
        {
            get { return mProjectCode; }
            set { mProjectCode = value; }
        }
    }

    public class CommentStates
    {
        private string mCommentState;

        public string CommentState
        {
            get { return mCommentState; }
            set { mCommentState = value; }
        }

    }

}
