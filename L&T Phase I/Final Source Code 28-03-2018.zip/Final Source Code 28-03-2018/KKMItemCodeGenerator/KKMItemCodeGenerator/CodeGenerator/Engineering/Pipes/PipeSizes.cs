﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeSizes : ObservableCollection<NameCodePair>
    {
        public static PipeSizes LoadList()
        {
            PipeSizes items = new PipeSizes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "6 NB" });
            items.Add(new NameCodePair() { Code = "02", Name = "8 NB" });
            items.Add(new NameCodePair() { Code = "03", Name = "10 NB" });
            items.Add(new NameCodePair() { Code = "04", Name = "15 NB" });
            items.Add(new NameCodePair() { Code = "05", Name = "20 NB" });
            items.Add(new NameCodePair() { Code = "06", Name = "25 NB" });
            items.Add(new NameCodePair() { Code = "07", Name = "32 NB" });
            items.Add(new NameCodePair() { Code = "08", Name = "40 NB" });
            items.Add(new NameCodePair() { Code = "09", Name = "50 NB" });
            items.Add(new NameCodePair() { Code = "10", Name = "65 NB" });
            items.Add(new NameCodePair() { Code = "11", Name = "80 NB" });
            items.Add(new NameCodePair() { Code = "12", Name = "100 NB" });
            items.Add(new NameCodePair() { Code = "13", Name = "125 NB" });
            items.Add(new NameCodePair() { Code = "14", Name = "150 NB" });
            items.Add(new NameCodePair() { Code = "14A", Name = "175 NB" });
            items.Add(new NameCodePair() { Code = "15", Name = "200 NB" });
            items.Add(new NameCodePair() { Code = "16", Name = "250 NB" });
            items.Add(new NameCodePair() { Code = "17", Name = "300 NB" });
            items.Add(new NameCodePair() { Code = "18", Name = "350 NB" });
            items.Add(new NameCodePair() { Code = "19", Name = "400 NB" });
            items.Add(new NameCodePair() { Code = "20", Name = "450 NB" });
            items.Add(new NameCodePair() { Code = "21", Name = "500 NB" });
            items.Add(new NameCodePair() { Code = "22", Name = "550 NB" });
            items.Add(new NameCodePair() { Code = "23", Name = "600 NB" });
            items.Add(new NameCodePair() { Code = "24", Name = "650 NB" });
            items.Add(new NameCodePair() { Code = "25", Name = "700 NB" });
            items.Add(new NameCodePair() { Code = "26", Name = "750 NB" });
            items.Add(new NameCodePair() { Code = "27", Name = "800 NB" });
            items.Add(new NameCodePair() { Code = "28", Name = "850 NB" });
            items.Add(new NameCodePair() { Code = "29", Name = "900 NB" });
            items.Add(new NameCodePair() { Code = "30", Name = "1000 NB" });
            items.Add(new NameCodePair() { Code = "31", Name = "1100 NB" });
            items.Add(new NameCodePair() { Code = "32", Name = "1200 NB" });
            items.Add(new NameCodePair() { Code = "33", Name = "90 NB" });
            items.Add(new NameCodePair() { Code = "34", Name = "50 mm" });
            return items;
        }
        public static PipeSizes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeSizes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeSizes>(EngineeringItems.DataPath + @"\Pipes\PipeSizes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeSizes>(this, EngineeringItems.DataPath + @"\Pipes\PipeSizes.xml");
        }

    }
}
