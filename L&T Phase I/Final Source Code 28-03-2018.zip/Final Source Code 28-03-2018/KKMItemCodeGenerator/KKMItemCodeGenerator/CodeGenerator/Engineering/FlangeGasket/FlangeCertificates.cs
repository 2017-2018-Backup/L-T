﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeCertificates : ObservableCollection<NameCodePair>
    {
        public static FlangeCertificates LoadList()
        {
            FlangeCertificates items = new FlangeCertificates();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Class I" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            items.Add(new NameCodePair() { Code = "E", Name = "Class B" });
            return items;
        }
        public static FlangeCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeCertificates>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeCertificates>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeCertificates.xml");
        }

    }
}
