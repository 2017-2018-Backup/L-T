﻿using KKMBuildSpecification;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace KKMBuildSpecifications
{
    public partial class frmCreateBuildSpecification : Form
    {
        bool IsEditMode = false;
        bool IsCheckedOut = false;
        string checkedOutUsername = "";
        private Dictionary<string, string> SFIallList;
        private Dictionary<string, List<MasterDrawingFile>> MasterDrawingLists;
        private List<MasterDrawingFile> SOTRDrawingsXls;
        private List<MasterDrawingFile> ClassApprovedsDrawingsXls;
        private List<MasterDrawingFile> ProductionDrawingXls;

        int BuildSpecificationNo = 1;

        public frmCreateBuildSpecification()
        {
            InitializeComponent();
            rbtMasterFromVault.CheckedChanged += new EventHandler(rbtMasterCheckedChanged);
            rbtMasterFromLocal.CheckedChanged += new EventHandler(rbtMasterCheckedChanged);
        }

        public frmCreateBuildSpecification(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;
            rbtMasterFromVault.CheckedChanged += new EventHandler(rbtMasterCheckedChanged);
            rbtMasterFromLocal.CheckedChanged += new EventHandler(rbtMasterCheckedChanged);
        }

        private void AddProjectFolderItem(AutoCompleteStringCollection ProjectFolderCOllection)
        {
            try
            {
                // check for any sub Folders.
                VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.Category.Name.ToUpper() == "PROJECT")
                        {
                            ProjectFolderCOllection.Add(folder.EntityName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmCreateNewBuildSpecification_Load(object sender, EventArgs e)
        {
            cmbBuildSpecificationSOTRRequired.SelectedIndex = 1;
            string warning = "";
            bool IsRelesedMode = clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(clsStaticGlobal.objSingleBuildSpecificationSummary, out warning);

            if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease == true)
            {
                txtBuildSpecificationCompletionofActivity.BackColor = Color.Green;
            }
            else
            {
                txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
            }           

            listViewBuildSpecificationSOTRNumber.View = View.List;
            listViewBuildSpecificationClassDrawing.View = View.List;
            listViewBuildSpecificationProductionDrawing.View = View.List;
            txtBuildSpecificationUniqNumber.ReadOnly = true;

            foreach (string item in clsStaticGlobal.GetAllUserList())
            {
                cmbBuildSpecificationResponsiblePerson.Items.Add(item);
                cmbBuildSpecificationSubResponsiblePerson.Items.Add(item);
                cmbBuildSpecificationResponsibleCoordinator.Items.Add(item);
                cmbBuildSpecificationSubResponsibleCoordinator.Items.Add(item);
            }

            rbtMasterCheckedChanged(rbtMasterFromVault, null);

            try
            {
                if (IsEditMode == true)
                {
                    AssignToControl(clsStaticGlobal.objSingleBuildSpecificationSummary);
                }
                else
                {
                    BuildSpecificationNo = clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber + 1;
                    txtBuildSpecificationProjectCode.Text = clsStaticGlobal._ProjectCode;
                    txtBuildSpecificationUniqNumber.Text = txtBuildSpecificationProjectCode.Text + "_" + BuildSpecificationNo.ToString();
                    txtBuildSpecificationLifeCycle.Text = "Create";

                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber = txtBuildSpecificationUniqNumber.Text.Trim();

                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = "Create";
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber = BuildSpecificationNo;

                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationProjectCode = txtBuildSpecificationProjectCode.Text;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            if (IsCheckedOut == true)
            {
                MessageBox.Show("Selected Build Specification checked out by user : " + checkedOutUsername + Environment.NewLine + "So user can not edit at this time..", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdCreateComment_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {

                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (IsEditMode == true)
                        {
                            AssignToObject();
                            string warning = "";
                            bool IsRelesedMode = clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(clsStaticGlobal.objSingleBuildSpecificationSummary, out warning);
                            if (IsRelesedMode == true)
                            {
                                txtBuildSpecificationCompletionofActivity.BackColor = Color.Green;
                            }
                            else
                            {
                                txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
                            }
                            MessageBox.Show("Build Specification updated successfully..!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                        else
                        {
                            string _TempCommentName = txtBuildSpecificationUniqNumber.Text.Trim();
                            string _TempFileName = "STS_" + _TempCommentName + ".xml";

                            if (IsBuildSpecificationNameExist(_TempFileName, _TempCommentName))
                            {
                                MessageBox.Show("Build Specification already exist", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else
                            {
                                try
                                {
                                    AssignToObject();
                                    string warning = "";
                                    bool IsRelesedMode = clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(clsStaticGlobal.objSingleBuildSpecificationSummary, out warning);
                                    if (IsRelesedMode == true)
                                    {
                                        txtBuildSpecificationCompletionofActivity.BackColor = Color.Green;
                                    }
                                    else
                                    {
                                        txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
                                    }
                                    String _xmlFilePath = clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;
                                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;
                                    //warning = "";
                                    //clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(clsStaticGlobal.objSingleBuildSpecificationSummary, out warning);
                                    clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleBuildSpecificationSummary, _xmlFilePath, false);
                                    clsStaticGlobal.UpdateFileRemark(clsStaticGlobal.objSingleBuildSpecificationSummary);
                                    MessageBox.Show("Build Specification created successfully..!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    this.Close();
                                }
                                catch (Exception ex)
                                {
                                    clsStaticGlobal.ErrHandlerLog(ex);
                                    MessageBox.Show("Error in creating Build Specification!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        MessageBox.Show("Error in creating Build Specification!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Build Specification in Release state. So user can not edit..!!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Build Specification checked out by user : " + checkedOutUsername + Environment.NewLine + "So user can not save at this time..", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IsBuildSpecificationNameExist(string _filename, string _CommentName)
        {
            bool IsExist = false;
            try
            {
                foreach (SingleBuildSpecificationSummary item in clsStaticGlobal.objSingleBuildSpecificationCollection.collectionBuildSpecification)
                {
                    if ((item.BuildSpecificationFileName == _filename) || (item.BuildSpecificationUniqNumber == _CommentName))
                    {
                        IsExist = true;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return IsExist;
        }

        private void AssignToObject()
        {
            try
            {
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber = txtBuildSpecificationUniqNumber.Text.Trim();

                if (IsEditMode == false)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName = "STS_" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber + ".xml";
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = "Create";
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber = BuildSpecificationNo;
                }

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationProjectCode = txtBuildSpecificationProjectCode.Text;

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSECTION = txtBuildSpecificationSECTION.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationParaNumber = txtBuildSpecificationParaNumber.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSubParaNumber = txtBuildSpecificationSubParaNumber.Text;

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSFI = txtBuildSpecificationSFI.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSFIDesc = txtBuildSpecificationSFIDesc.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine = txtBuildSpecificationReferenceBuildSpecificationLine.Text;

                string function = "";
                try
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFunctions.Clear();
                }
                catch (Exception)
                {

                }

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFunction = "";

                foreach (ListViewItem item in lstBuildSpecificationFunction.Items)
                {
                    if (item.Checked == true)
                    {
                        clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFunctions.Add(item.Text);

                        if (function == "")
                        {
                            function = item.Text;
                        }
                        else
                        {
                            function = function + Environment.NewLine + item.Text;
                        }
                    }
                }

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFunction = function;

                if (cmbBuildSpecificationResponsiblePerson.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson = cmbBuildSpecificationResponsiblePerson.SelectedItem.ToString();
                }

                if (cmbBuildSpecificationSubResponsiblePerson.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson = cmbBuildSpecificationSubResponsiblePerson.SelectedItem.ToString();
                }

                if (cmbBuildSpecificationResponsibleCoordinator.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator = cmbBuildSpecificationResponsibleCoordinator.SelectedItem.ToString();
                }

                if (cmbBuildSpecificationSubResponsibleCoordinator.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator = cmbBuildSpecificationSubResponsibleCoordinator.SelectedItem.ToString();
                }

                if (cmbBuildSpecificationSOTRRequired.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired = cmbBuildSpecificationSOTRRequired.SelectedItem.ToString();
                }

                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark = txtBuildSpecificationRemark.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationExtension = txttxtBuildSpecificationExtension.Text;
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = txtBuildSpecificationCompletionofActivity.Text;

                string _SOTRNumber = "";
                string _SOTRNumberDAD = "";
                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                {
                    if (listViewBuildSpecificationSOTRNumber.Items.Count > 0)
                    {
                        listViewBuildSpecificationSOTRNumber.Items.Clear();
                    }
                    foreach (SOTRNumber item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
                    {
                        if (item.FileType == "SOTR")
                        {
                            if (_SOTRNumber.Trim() == "")
                            {
                                _SOTRNumber = "SOTR : " + item.FileName;
                            }
                            else
                            {
                                _SOTRNumber = _SOTRNumber + "," + Environment.NewLine + "SOTR : " + item.FileName;
                            }
                        }
                        else
                        {
                            if (_SOTRNumberDAD.Trim() == "")
                            {
                                _SOTRNumberDAD = "DAD : " + item.FileName;
                            }
                            else
                            {
                                _SOTRNumberDAD = _SOTRNumberDAD + "," + Environment.NewLine + "DAD : " + item.FileName;
                            }
                        }

                    }
                }
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationSOTRNumber = _SOTRNumber + Environment.NewLine + _SOTRNumberDAD;


                string _ClassDrawing = "";
                string _ClassDrawingDAD = "";
                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                {
                    if (listViewBuildSpecificationClassDrawing.Items.Count > 0)
                    {
                        listViewBuildSpecificationClassDrawing.Items.Clear();
                    }
                    foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                    {
                        if (item.FileType == "CLASS APPROVED")
                        {
                            if (_ClassDrawing.Trim() == "")
                            {
                                _ClassDrawing = "CLASS APPROVED : " + item.FileName;
                            }
                            else
                            {
                                _ClassDrawing = _ClassDrawing + "," + Environment.NewLine + "CLASS APPROVED : " + item.FileName;
                            }
                        }
                        else
                        {
                            if (_ClassDrawingDAD.Trim() == "")
                            {
                                _ClassDrawingDAD = "DAD : " + item.FileName;
                            }
                            else
                            {
                                _ClassDrawingDAD = _ClassDrawingDAD + "," + Environment.NewLine + "DAD : " + item.FileName;
                            }
                        }
                    }
                }
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationClassDrawing = _ClassDrawing + Environment.NewLine + _ClassDrawingDAD;


                //string _DADDrawing = "";
                //if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListDADDrawing.Count > 0)
                //{
                //    if (listViewBuildSpecificationDADDrawing.Items.Count > 0)
                //    {
                //        listViewBuildSpecificationDADDrawing.Items.Clear();
                //    }
                //    foreach (DADDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListDADDrawing)
                //    {
                //        if (_DADDrawing.Trim() == "")
                //        {
                //            _DADDrawing = item.FileName;
                //        }
                //        else
                //        {
                //            _DADDrawing = _DADDrawing + "," + Environment.NewLine + item.FileName;
                //        }
                //    }
                //}
                //clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationDADDrawing = _DADDrawing;


                string _ProductionDrawing = "";
                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                {
                    if (listViewBuildSpecificationProductionDrawing.Items.Count > 0)
                    {
                        listViewBuildSpecificationProductionDrawing.Items.Clear();
                    }
                    foreach (ProductionDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                    {
                        if (_ProductionDrawing.Trim() == "")
                        {
                            _ProductionDrawing = "PRODUCTION : " + item.FileName;
                        }
                        else
                        {
                            _ProductionDrawing = _ProductionDrawing + "," + Environment.NewLine + "PRODUCTION : " + item.FileName;
                        }
                    }
                }
                clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationProductionDrawing = _ProductionDrawing;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void AssignToControl(SingleBuildSpecificationSummary _SingleBuildSpecificationSummary)
        {
            try
            {
                txtBuildSpecificationProjectCode.Text = _SingleBuildSpecificationSummary.BuildSpecificationProjectCode;
                txtBuildSpecificationUniqNumber.Text = _SingleBuildSpecificationSummary.BuildSpecificationUniqNumber;
                txtBuildSpecificationSECTION.Text = _SingleBuildSpecificationSummary.BuildSpecificationSECTION;
                txtBuildSpecificationParaNumber.Text = _SingleBuildSpecificationSummary.BuildSpecificationParaNumber;
                txtBuildSpecificationSubParaNumber.Text = _SingleBuildSpecificationSummary.BuildSpecificationSubParaNumber;

                txtBuildSpecificationSFI.Text = _SingleBuildSpecificationSummary.BuildSpecificationSFI;
                txtBuildSpecificationSFIDesc.Text = _SingleBuildSpecificationSummary.BuildSpecificationSFIDesc;

                txtBuildSpecificationReferenceBuildSpecificationLine.Text = _SingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine;
                txtBuildSpecificationLifeCycle.Text = _SingleBuildSpecificationSummary.BuildSpecificationLifeCycle;
                txtBuildSpecificationCompletionofActivity.Text = _SingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity;
                txtBuildSpecificationRemark.Text = _SingleBuildSpecificationSummary.BuildSpecificationRemark;
                txttxtBuildSpecificationExtension.Text = _SingleBuildSpecificationSummary.BuildSpecificationExtension;


                if ((_SingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson != "") || (_SingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson != null))
                {
                    cmbBuildSpecificationResponsiblePerson.SelectedItem = _SingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson;
                    cmbBuildSpecificationResponsiblePerson.Text = _SingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson;
                }

                if ((_SingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson != "") || (_SingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson != null))
                {
                    cmbBuildSpecificationSubResponsiblePerson.SelectedItem = _SingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson;
                    cmbBuildSpecificationSubResponsiblePerson.Text = _SingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson;
                }

                if ((_SingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator != "") || (_SingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator != null))
                {
                    cmbBuildSpecificationResponsibleCoordinator.SelectedItem = _SingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator;
                    cmbBuildSpecificationResponsibleCoordinator.Text = _SingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator;
                }

                if ((_SingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator != "") || (_SingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator != null))
                {
                    cmbBuildSpecificationSubResponsibleCoordinator.SelectedItem = _SingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator;
                    cmbBuildSpecificationSubResponsibleCoordinator.Text = _SingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator;
                }

                if ((_SingleBuildSpecificationSummary.BuildSpecificationFunction != "") || (_SingleBuildSpecificationSummary.BuildSpecificationFunction != null))
                {
                    foreach (var item in _SingleBuildSpecificationSummary.BuildSpecificationFunctions)
                    {
                        foreach (ListViewItem _ListViewItem in lstBuildSpecificationFunction.Items)
                        {
                            if (_ListViewItem.Text == item)
                            {
                                _ListViewItem.Checked = true;
                            }
                        }
                    }
                }

                if ((_SingleBuildSpecificationSummary.BuildSpecificationSOTRRequired != "") || (_SingleBuildSpecificationSummary.BuildSpecificationSOTRRequired != null))
                {
                    cmbBuildSpecificationSOTRRequired.SelectedItem = _SingleBuildSpecificationSummary.BuildSpecificationSOTRRequired;
                    cmbBuildSpecificationSOTRRequired.Text = _SingleBuildSpecificationSummary.BuildSpecificationSOTRRequired;
                }

                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                {
                    if (listViewBuildSpecificationSOTRNumber.Items.Count > 0)
                    {
                        listViewBuildSpecificationSOTRNumber.Items.Clear();
                    }

                    ListViewGroup SOTRgrp = new ListViewGroup("SOTR");
                    listViewBuildSpecificationSOTRNumber.Groups.Add(SOTRgrp);
                    foreach (SOTRNumber item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
                    {
                        ListViewItem _lstitem;

                        _lstitem = new ListViewItem(new string[]
                                    {   item.FileName,
                                         item.FileStatus
                                    },
                                           SOTRgrp);

                        if (item.FileStatus == "Release")
                        {
                            _lstitem.BackColor = Color.Green;
                        }
                        else
                        {
                            _lstitem.BackColor = Color.Red;
                        }

                        listViewBuildSpecificationSOTRNumber.Items.Add(_lstitem);
                    }

                }
                else
                {
                    listViewBuildSpecificationSOTRNumber.Items.Clear();
                }

                listViewBuildSpecificationSOTRNumber.View = View.Details;

                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                {
                    if (listViewBuildSpecificationClassDrawing.Items.Count > 0)
                    {
                        listViewBuildSpecificationClassDrawing.Items.Clear();
                    }

                    ListViewGroup ClassApprovedgrp = new ListViewGroup("CLASS APPROVED");
                    ListViewGroup DADgrp = new ListViewGroup("DAD");

                    listViewBuildSpecificationClassDrawing.Groups.Add(ClassApprovedgrp);
                    listViewBuildSpecificationClassDrawing.Groups.Add(DADgrp);
                    foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                    {
                        ListViewItem _lstitem;
                        if (item.FileType == "CLASS APPROVED")
                        {
                            _lstitem = new ListViewItem(new string[]
                                     {   item.FileName,
                                     item.FileUsedIn,
                                             item.FileStatus
                                     },
                                            ClassApprovedgrp);

                            if (item.FileStatus == "Release")
                            {
                                _lstitem.BackColor = Color.Green;
                            }
                            else
                            {
                                _lstitem.BackColor = Color.Red;
                            }
                        }
                        else
                        {
                            _lstitem = new ListViewItem(new string[]
                                     {   item.FileName,
                                     item.FileUsedIn,
                                             item.FileStatus
                                     },
                                            DADgrp);
                        }



                        listViewBuildSpecificationClassDrawing.Items.Add(_lstitem);

                    }

                }
                else
                {
                    listViewBuildSpecificationClassDrawing.Items.Clear();
                }

                listViewBuildSpecificationClassDrawing.View = View.Details;

                if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                {
                    if (listViewBuildSpecificationProductionDrawing.Items.Count > 0)
                    {
                        listViewBuildSpecificationProductionDrawing.Items.Clear();
                    }
                    ListViewGroup Productiongrp = new ListViewGroup("PRODUCTION");
                    //ListViewGroup DADgrp = new ListViewGroup("DAD");

                    listViewBuildSpecificationProductionDrawing.Groups.Add(Productiongrp);
                    //listViewBuildSpecificationSOTRNumber.Groups.Add(DADgrp);
                    foreach (ProductionDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                    {
                        ListViewItem _lstitem;
                        _lstitem = new ListViewItem(new string[]
                                    {   item.FileName,
                                            item.FileStatus
                                    }, Productiongrp);

                        if (item.FileStatus == "Release")
                        {
                            _lstitem.BackColor = Color.Green;
                        }
                        else
                        {
                            _lstitem.BackColor = Color.Red;
                        }

                        listViewBuildSpecificationProductionDrawing.Items.Add(_lstitem);
                    }
                }
                else
                {
                    listViewBuildSpecificationProductionDrawing.Items.Clear();
                }
                listViewBuildSpecificationProductionDrawing.View = View.Details;


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void txtIssueNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void btnApplyHistoryVersion_Click(object sender, EventArgs e)
        {



        }

        private void btnSetLatestHistoryVersion_Click(object sender, EventArgs e)
        {
            DialogResult _dialogRes = MessageBox.Show("Are you sure to current details as latest details for Build Specification..?", "Build Specification", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (_dialogRes == System.Windows.Forms.DialogResult.Yes)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        //if (IsValidateField() == true)
                        //{
                        //    if (IsEditMode == true)
                        //    {
                        //        AssignToObject();
                        //        MessageBox.Show("Build Specification updated successfully..!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //        this.Close();
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        MessageBox.Show("Error in creating Build Specification!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnBuildSpecificationClassDrawing_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        string SFIcode = "";
                        if (txtBuildSpecificationSFI.Text.Trim() != "")
                        {
                            SFIcode = txtBuildSpecificationSFI.Text.Trim();
                        }
                        else
                        {
                            MessageBox.Show("Select SFI code first.!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        UserControlClassDrawing objfrmUserControlClassDrawing = new UserControlClassDrawing(ClassApprovedsDrawingsXls, SFIcode);
                        objfrmUserControlClassDrawing.ShowDialog();
                        objfrmUserControlClassDrawing.Close();

                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                        {
                            if (listViewBuildSpecificationClassDrawing.Items.Count > 0)
                            {
                                listViewBuildSpecificationClassDrawing.Items.Clear();
                            }

                            //Debugger.Launch();
                            ListViewGroup ClassApprovedgrp = new ListViewGroup("CLASS APPROVED");
                            ListViewGroup DADgrp = new ListViewGroup("DAD");

                            listViewBuildSpecificationClassDrawing.Groups.Add(ClassApprovedgrp);
                            listViewBuildSpecificationClassDrawing.Groups.Add(DADgrp);
                            foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                            {
                                ListViewItem _lstitem;
                                if (item.FileType == "CLASS APPROVED")
                                {
                                    _lstitem = new ListViewItem(new string[]
                                             {   item.FileName,
                                             item.FileUsedIn,
                                             item.FileStatus
                                             },
                                                    ClassApprovedgrp);

                                    if (item.FileStatus == "Release")
                                    {
                                        _lstitem.BackColor = Color.Green;
                                    }
                                    else
                                    {
                                        _lstitem.BackColor = Color.Red;
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = false;
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = "Incompleted";
                                        txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;

                                    }
                                }
                                else
                                {
                                    _lstitem = new ListViewItem(new string[]
                                             {   item.FileName,
                                         item.FileUsedIn,
                                             item.FileStatus
                                             },
                                                    DADgrp);
                                }

                                listViewBuildSpecificationClassDrawing.Items.Add(_lstitem);

                            }

                        }
                        else
                        {
                            listViewBuildSpecificationClassDrawing.Items.Clear();
                        }
                        listViewBuildSpecificationClassDrawing.View = View.Details;
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Build Specification checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            listViewBuildSpecificationSOTRNumber.Update();

        }

        private void btnBuildSpecificationSOTRNumber_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        string SFIcode = "";
                        if (txtBuildSpecificationSFI.Text.Trim() != "")
                        {
                            SFIcode = txtBuildSpecificationSFI.Text.Trim();
                        }
                        else
                        {
                            MessageBox.Show("Select SFI code first.!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        UserControlSOTRNumbers objfrmUserControlSOTRNumbers = new UserControlSOTRNumbers(SOTRDrawingsXls, SFIcode);
                        objfrmUserControlSOTRNumbers.ShowDialog();

                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                        {
                            if (listViewBuildSpecificationSOTRNumber.Items.Count > 0)
                            {
                                listViewBuildSpecificationSOTRNumber.Items.Clear();
                            }

                            ListViewGroup SOTRgrp = new ListViewGroup("SOTR");

                            listViewBuildSpecificationSOTRNumber.Groups.Add(SOTRgrp);

                            foreach (SOTRNumber item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
                            {
                                ListViewItem _lstitem;

                                _lstitem = new ListViewItem(new string[]
                                         {   item.FileName,
                                                 item.FileStatus
                                         },
                                                SOTRgrp);

                                if (item.FileStatus == "Release")
                                {
                                    _lstitem.BackColor = Color.Green;
                                }
                                else
                                {
                                    _lstitem.BackColor = Color.Red;
                                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = false;
                                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = "Incompleted";
                                    txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
                                }

                                listViewBuildSpecificationSOTRNumber.Items.Add(_lstitem);
                            }

                        }
                        else
                        {
                            listViewBuildSpecificationSOTRNumber.Items.Clear();
                        }

                        listViewBuildSpecificationSOTRNumber.View = View.Details;
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Build Specification checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            listViewBuildSpecificationSOTRNumber.Update();
        }

        private void btnBuildSpecificationProductionDrawing_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        string SFIcode = "";
                        if (txtBuildSpecificationSFI.Text.Trim() != "")
                        {
                            SFIcode = txtBuildSpecificationSFI.Text.Trim();
                        }
                        else
                        {
                            MessageBox.Show("Select SFI code first.!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        UserControlProductionDrawing objfrmUserControlProductionDrawing = new UserControlProductionDrawing(ProductionDrawingXls, SFIcode);
                        objfrmUserControlProductionDrawing.ShowDialog();

                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                        {
                            if (listViewBuildSpecificationProductionDrawing.Items.Count > 0)
                            {
                                listViewBuildSpecificationProductionDrawing.Items.Clear();
                            }
                            ListViewGroup Productiongrp = new ListViewGroup("PRODUCTION");

                            listViewBuildSpecificationProductionDrawing.Groups.Add(Productiongrp);

                            foreach (ProductionDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                            {
                                ListViewItem _lstitem;
                                _lstitem = new ListViewItem(new string[]
                                            {   item.FileName,
                                                item.FileStatus
                                            }, Productiongrp);

                                if (item.FileStatus == "Release")
                                {
                                    _lstitem.BackColor = Color.Green;
                                }
                                else
                                {
                                    _lstitem.BackColor = Color.Red;
                                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = false;
                                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity = "Incompleted";
                                    txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
                                }

                                listViewBuildSpecificationProductionDrawing.Items.Add(_lstitem);
                            }
                        }
                        else
                        {
                            listViewBuildSpecificationProductionDrawing.Items.Clear();
                        }
                        listViewBuildSpecificationProductionDrawing.View = View.Details;
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Build Specification checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            listViewBuildSpecificationProductionDrawing.Update();
        }

        private void txtBuildSpecificationSFI_Leave(object sender, EventArgs e)
        {

        }

        private void txtBuildSpecificationSFI_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            //{
            //    e.Handled = true;
            //}
        }

        private void cmbBuildSpecificationSOTRRequired_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((cmbBuildSpecificationSOTRRequired.SelectedItem.ToString() == "NA") || (cmbBuildSpecificationSOTRRequired.SelectedItem.ToString() == "No"))
            {
                listViewBuildSpecificationSOTRNumber.Enabled = false;
                btnBuildSpecificationSOTRNumber.Enabled = false;
            }
            else
            {
                listViewBuildSpecificationSOTRNumber.Enabled = true;
                btnBuildSpecificationSOTRNumber.Enabled = true;
            }
        }

        private void DeleteFileFromDirectory(string _DirectoryPath)
        {
            try
            {
                if (Directory.Exists(_DirectoryPath))
                {
                    foreach (string file in Directory.GetFiles(_DirectoryPath))
                    {
                        System.IO.File.SetAttributes(file, FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error in deleting files.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private bool GetAllMasterDrawingListFilesByProjectFolder(string _ProjectCode)
        {
            try
            {
                try
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles");
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }

                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultMasterDrawingListFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if ((file.Name.ToUpper().Trim().Contains("MASTER DRAWING")) && (file.Name.ToUpper().Trim().Contains(".XLSX")) && (file.Name.ToUpper().Trim().Contains(".XLS")))
                        {
                            FileIterations.Add(new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file));
                        }
                    }
                    ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters = (ICollection<VDF.Vault.Currency.Entities.FileIteration>)FileIterations;
                    DownlodAllMasterDrawingListFiles(fileIters, _ProjectCode);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return false;
            }
        }

        private void DownlodAllMasterDrawingListFiles(ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters, string _ProjectCode)
        {
            try
            {
                //Debugger.Launch();
                DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles");

                if (!Directory.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles"))
                {
                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles");
                }
                else
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles");
                }


                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode + "\\MasterDrawingFiles");
                foreach (VDF.Vault.Currency.Entities.FileIteration fileIter in fileIters)
                {
                    settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                }
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string warning = "";
            bool IsRelesedMode = clsStaticGlobal.CheckIsBuildSpecificationAllReleaseMode(clsStaticGlobal.objSingleBuildSpecificationSummary, out warning);
            if (IsRelesedMode == true)
            {
                txtBuildSpecificationCompletionofActivity.BackColor = Color.Green;
            }
            else
            {
                txtBuildSpecificationCompletionofActivity.BackColor = Color.Red;
            }
        }

        private void rbtMasterCheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = (RadioButton)sender;

            MasterDrawingLists = new Dictionary<string, List<MasterDrawingFile>>() { };
            SOTRDrawingsXls = new List<MasterDrawingFile>();
            ClassApprovedsDrawingsXls = new List<MasterDrawingFile>();
            ProductionDrawingXls = new List<MasterDrawingFile>();

            if (radioButton.Name == "rbtMasterFromVault")
            {
                if (rbtMasterFromVault.Checked == true)
                {
                    try
                    {
                        GetAllMasterDrawingListFilesByProjectFolder(clsStaticGlobal._ProjectCode);
                        MasterDrawingLists = clsStaticGlobal.BindingMasterDrawingsData(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\MasterDrawingFiles");

                        foreach (var item in MasterDrawingLists)
                        {
                            if (item.Key.ToUpper() == "SOTR")
                            {
                                SOTRDrawingsXls = item.Value;
                            }
                            else if (item.Key.ToUpper() == "CLASS APPROVED DOCUMENT")
                            {
                                ClassApprovedsDrawingsXls = item.Value;
                            }
                            else if (item.Key.ToUpper() == "PRODUCTION DOCUMENT")
                            {
                                ProductionDrawingXls = item.Value;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
            }
            else if (radioButton.Name == "rbtMasterFromLocal")
            {
                if (rbtMasterFromLocal.Checked == true)
                {
                    OpenFileDialog fdlg = new OpenFileDialog();
                    fdlg.Title = "Open File Dialog For Excel File";
                    fdlg.InitialDirectory = @"c:\";
                    fdlg.Filter = "All files (*.xls)|*.xls|All files (*.xlsx)|*.xlsx";
                    fdlg.Multiselect = false;
                    fdlg.FilterIndex = 2;
                    fdlg.RestoreDirectory = true;
                    if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        //Debugger.Launch();
                        string _filepath = fdlg.FileName;
                        try
                        {
                            clsStaticGlobal.ReadExcelFile(_filepath, ref SOTRDrawingsXls, ref ClassApprovedsDrawingsXls, ref ProductionDrawingXls);

                            MasterDrawingLists.Add("PRODUCTION DOCUMENT", ProductionDrawingXls);
                            MasterDrawingLists.Add("CLASS APPROVED DOCUMENT", ClassApprovedsDrawingsXls);
                            MasterDrawingLists.Add("SOTR", SOTRDrawingsXls);

                            foreach (var item in MasterDrawingLists)
                            {
                                if (item.Key.ToUpper() == "SOTR")
                                {
                                    SOTRDrawingsXls = item.Value;
                                }
                                else if (item.Key.ToUpper() == "CLASS APPROVED DOCUMENT")
                                {
                                    ClassApprovedsDrawingsXls = item.Value;
                                }
                                else if (item.Key.ToUpper() == "PRODUCTION DOCUMENT")
                                {
                                    ProductionDrawingXls = item.Value;
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                    }
                }
            }

        }

        private void btnSFI_Click(object sender, EventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtBuildSpecificationSFI.Text = sfi.SFIcodenumber;
                txtBuildSpecificationSFIDesc.Text = sfi.SFIcodeDesc;
            }
        }
    }
}
