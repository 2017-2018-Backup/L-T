﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValvePressureReducingSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValvePressureReducingSubTypes LoadList()
        {
            ValvePressureReducingSubTypes items = new ValvePressureReducingSubTypes();
            return items;
        }
        public static ValvePressureReducingSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValvePressureReducingSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValvePressureReducingSubTypes>(EngineeringItems.DataPath + @"\Valves\ValvePressureReducingSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValvePressureReducingSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValvePressureReducingSubTypes.xml");
        }

    }
}
