﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KKMCreateNewProjectStructure
{
   public class ProjectProperties
    {

        private string mProjectNumber;

        public string ProjectNumber
        {
            get { return mProjectNumber; }
            set { mProjectNumber = value; }
        }

        private string mProjectTitle;

        public string ProjectTitle
        {
            get { return mProjectTitle; }
            set { mProjectTitle = value; }
        }

        private string mDescription;

        public string Description
        {
            get { return mDescription; }
            set { mDescription = value; }
        }

        private DateTime mZeroDate;

        public DateTime ZeroDate
        {
            get { return mZeroDate; }
            set { mZeroDate = value; }
        }

        private string mConsultant;

        public string Consultant
        {
            get { return mConsultant; }
            set { mConsultant = value; }
        }

        private string mProductEndUser;

        public string ProductEndUser
        {
            get { return mProductEndUser; }
            set { mProductEndUser = value; }
        }

        private string mDOCEnclosed;

        public string DOCEnclosed
        {
            get { return mDOCEnclosed; }
            set { mDOCEnclosed = value; }
        }

        private string mTransportationScope;

        public string TransportationScope
        {
            get { return mTransportationScope; }
            set { mTransportationScope = value; }
        }

        private string mDeliveryCondition;

        public string DeliveryCondition
        {
            get { return mDeliveryCondition; }
            set { mDeliveryCondition = value; }
        }

        private string mTypeofGuaranteeRequired;

        public string TypeofGuaranteeRequired
        {
            get { return mTypeofGuaranteeRequired; }
            set { mTypeofGuaranteeRequired = value; }
        }

        private string  mIsSiteWorkRequired;

        public string  IsSiteWorkRequired
        {
            get { return mIsSiteWorkRequired; }
            set { mIsSiteWorkRequired = value; }
        }

        private string mTypeDesignRqdfromLT;

        public string TypeDesignRqdfromLT
        {
            get { return mTypeDesignRqdfromLT; }
            set { mTypeDesignRqdfromLT = value; }
        }
        private string mLicensor;

        public string Licensor
        {
            get { return mLicensor; }
            set { mLicensor = value; }
        }

        private string mClassificationSociety;

        public string ClassificationSociety
        {
            get { return mClassificationSociety; }
            set { mClassificationSociety = value; }
        }

        private string mLeadingClassificationSociety;

        public string LeadingClassificationSociety
        {
            get { return mLeadingClassificationSociety; }
            set { mLeadingClassificationSociety = value; }
        }        

        private string mCategoryofProject;

        public string CategoryofProject
        {
            get { return mCategoryofProject; }
            set { mCategoryofProject = value; }
        }

        private string mPIM;

        public string PIM
        {
            get { return mPIM; }
            set { mPIM = value; }
        }

        private DateTime mContractualDeliveryDate;

        public DateTime ContractualDeliveryDate
        {
            get { return mContractualDeliveryDate; }
            set { mContractualDeliveryDate = value; }
        }

        private DateTime mPORecieptDate;

        public DateTime PORecieptDate
        {
            get { return mPORecieptDate; }
            set { mPORecieptDate = value; }
        }

        private DateTime mLOIRecieptDate;

        public DateTime LOIRecieptDate
        {
            get { return mLOIRecieptDate; }
            set { mLOIRecieptDate = value; }
        }

        private string mCustomerPONumber;

        public string CustomerPONumber
        {
            get { return mCustomerPONumber; }
            set { mCustomerPONumber = value; }
        }

        private string mCustomerLOINumber;

        public string CustomerLOINumber
        {
            get { return mCustomerLOINumber; }
            set { mCustomerLOINumber = value; }
        }

        private string mOwner;

        public string Owner
        {
            get { return mOwner; }
            set { mOwner = value; }
        }

        private string mSBUDepartment;

        public string SBUDepartment
        {
            get { return mSBUDepartment; }
            set { mSBUDepartment = value; }
        }

        private string mResponsibleProjectOwner;

        public string ResponsibleProjectOwner
        {
            get { return mResponsibleProjectOwner; }
            set { mResponsibleProjectOwner = value; }
        }

        private string mProjectLocation;

        public string ProjectLocation
        {
            get { return mProjectLocation; }
            set { mProjectLocation = value; }
        }
        
        
        
    }
}
