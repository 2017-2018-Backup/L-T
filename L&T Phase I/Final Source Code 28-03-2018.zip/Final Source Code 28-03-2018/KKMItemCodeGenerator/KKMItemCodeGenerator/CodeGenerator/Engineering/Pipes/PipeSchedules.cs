﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeSchedules : ObservableCollection<NameCodePair>
    {
        public static PipeSchedules LoadList()
        {
            PipeSchedules items = new PipeSchedules();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "SCH 10" });
            items.Add(new NameCodePair() { Code = "02", Name = "SCH 20" });
            items.Add(new NameCodePair() { Code = "03", Name = "SCH 30" });
            items.Add(new NameCodePair() { Code = "04", Name = "SCH STD" });
            items.Add(new NameCodePair() { Code = "05", Name = "SCH 40" });
            items.Add(new NameCodePair() { Code = "06", Name = "SCH 60" });
            items.Add(new NameCodePair() { Code = "07", Name = "SCH XS" });
            items.Add(new NameCodePair() { Code = "08", Name = "SCH 80" });
            items.Add(new NameCodePair() { Code = "09", Name = "SCH 100" });
            items.Add(new NameCodePair() { Code = "10", Name = "SCH 120" });
            items.Add(new NameCodePair() { Code = "11", Name = "SCH 140" });
            items.Add(new NameCodePair() { Code = "12", Name = "SCH 160" });
            items.Add(new NameCodePair() { Code = "13", Name = "SCH XXS" });
            items.Add(new NameCodePair() { Code = "14", Name = "PN 10" });
            items.Add(new NameCodePair() { Code = "15", Name = "PN 14" });
            items.Add(new NameCodePair() { Code = "16", Name = "PN 16" });
            items.Add(new NameCodePair() { Code = "17", Name = "PN 20" });
            items.Add(new NameCodePair() { Code = "18", Name = "5.4 Thk" });
            items.Add(new NameCodePair() { Code = "19", Name = "5 Thk" });
            items.Add(new NameCodePair() { Code = "20", Name = "SCH 5" });
            items.Add(new NameCodePair() { Code = "21", Name = "1 THK" });
            return items;
        }
        public static PipeSchedules LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeSchedules LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeSchedules>(EngineeringItems.DataPath + @"\Pipes\PipeSchedules.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeSchedules>(this, EngineeringItems.DataPath + @"\Pipes\PipeSchedules.xml");
        }

    }
}
