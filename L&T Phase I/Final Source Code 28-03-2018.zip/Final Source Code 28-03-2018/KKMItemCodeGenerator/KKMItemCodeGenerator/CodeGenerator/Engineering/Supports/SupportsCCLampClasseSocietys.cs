﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsCCLampClasseSocietys : ObservableCollection<NameCodePair>
    {
        public static SupportsCCLampClasseSocietys LoadList()
        {
            SupportsCCLampClasseSocietys items = new SupportsCCLampClasseSocietys();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "GL" });
            items.Add(new NameCodePair() { Code = "B", Name = "LR" });
            return items;
        }
        public static SupportsCCLampClasseSocietys LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsCCLampClasseSocietys LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsCCLampClasseSocietys>(EngineeringItems.DataPath + @"\Supports\SupportsCCLampClasseSocietys.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsCCLampClasseSocietys>(this, EngineeringItems.DataPath + @"\Supports\SupportsCCLampClasseSocietys.xml");
        }

    }
}
