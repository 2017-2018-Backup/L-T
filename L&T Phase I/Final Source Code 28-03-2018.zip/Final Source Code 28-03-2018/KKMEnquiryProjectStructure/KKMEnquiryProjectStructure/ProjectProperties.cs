﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KKMEnquiryProjectStructure
{
   public class ProjectProperties
    {

        private string mProjectNumber;

        public string ProjectNumber
        {
            get { return mProjectNumber; }
            set { mProjectNumber = value; }
        }

        private string mPolicy;

        public string Policy
        {
            get { return mPolicy; }
            set { mPolicy = value; }
        }

        private string mTemplate;

        public string Template
        {
            get { return mTemplate; }
            set { mTemplate = value; }
        }

        private DateTime mEnquiryReceiptDate;

        public DateTime EnquiryReceiptDate
        {
            get { return mEnquiryReceiptDate; }
            set { mEnquiryReceiptDate = value; }
        }

        private string mCustomer;

        public string Customer
        {
            get { return mCustomer; }
            set { mCustomer = value; }
        }

        private string mCustomerRepresentative;

        public string CustomerRepresentative
        {
            get { return mCustomerRepresentative; }
            set { mCustomerRepresentative = value; }
        }

        private string mCustomerEnquireyNumber;

        public string CustomerEnquireyNumber
        {
            get { return mCustomerEnquireyNumber; }
            set { mCustomerEnquireyNumber = value; }
        }

        private string mCategoryOfEnquiry;

        public string CategoryOfEnquiry
        {
            get { return mCategoryOfEnquiry; }
            set { mCategoryOfEnquiry = value; }
        }

        
    }
}
