﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersMudBoxSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersMudBoxSubTypes LoadList()
        {
            StrainersMudBoxSubTypes items = new StrainersMudBoxSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "STRAIGHT TYPE" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANGLE TYPE" });
            return items;
        }
        public static StrainersMudBoxSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersMudBoxSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersMudBoxSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersMudBoxSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersMudBoxSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersMudBoxSubTypes.xml");
        }

    }
}
