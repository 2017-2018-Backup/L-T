﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingStandards : ObservableCollection<NameCodePair>
    {
        public static PipeFittingStandards LoadList()
        {
            PipeFittingStandards items = new PipeFittingStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "JIS" });
            items.Add(new NameCodePair() { Code = "02", Name = "DIN 2950" });
            items.Add(new NameCodePair() { Code = "06", Name = "ASME B16.3" });
            items.Add(new NameCodePair() { Code = "03", Name = "ASME B16.11" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 2391" });
            items.Add(new NameCodePair() { Code = "05", Name = "DIN 2828" });
            items.Add(new NameCodePair() { Code = "06", Name = "JIC" });
            items.Add(new NameCodePair() { Code = "07", Name = "DIN 86087" });
            items.Add(new NameCodePair() { Code = "08", Name = "DIN 86088" });
            items.Add(new NameCodePair() { Code = "09", Name = "ASME B16.9" });
            items.Add(new NameCodePair() { Code = "10", Name = "NES 780 Part-III" });
            items.Add(new NameCodePair() { Code = "11", Name = "DIN 2353" });
            items.Add(new NameCodePair() { Code = "12", Name = "EHN 9308/600/01" });
            return items;
        }
        public static PipeFittingStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingStandards>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingStandards>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingStandards.xml");
        }

    }
}
