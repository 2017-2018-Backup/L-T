﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;
using KKMBuildSpecification;
using System.Collections;
using System.Diagnostics;

namespace KKMBuildSpecification
{
    /// <summary>
    /// Interaction logic for UserControlSOTRNumber.xaml
    /// </summary>
    public partial class UserControlSOTRNumbers : Window
    {
        public List<MasterDrawingFile> ExcelSOTRNumberList { get; set; }
        String SFIcode = "";
        public UserControlSOTRNumbers(List<MasterDrawingFile> _ExcelSOTRNumberList, string _SFIcode)
        {
            InitializeComponent();
            ExcelSOTRNumberList = _ExcelSOTRNumberList;
            SFIcode = _SFIcode;
            try
            {
                clsStaticGlobal.SOTRNumberSearchedItemCollection.Clear();

                int SearchedCount = 1;
                foreach (MasterDrawingFile _item in ExcelSOTRNumberList)
                {
                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.DocumentNumber, "SOTR", clsStaticGlobal.ProjectFolder);

                    if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                    {
                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                        string fileDec = _item.DocumentDescription;

                        string fileSFI = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                        if (fileSFI == null)
                        {
                            fileSFI = "";
                        }

                        string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                        if (fileSection == null)
                        {
                            fileSection = "";
                        }
                        //string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _SearchedFile.Id, false); //Class Approved Drawing Number
                        //if (fileRelatedDAD == null)
                        //{
                        //    fileRelatedDAD = "";
                        //}

                        if (fileSFI.Trim().ToUpper() == SFIcode.Trim().ToUpper())
                        {
                            clsStaticGlobal.SOTRNumberSearchedItemCollection.Add(new SOTRNumber { Count = SearchedCount, IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = _SearchedFile.Name, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileSection = fileSection, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName, FileLink="Go To Location" });
                        }                        
                    }
                    else
                    {
                        string fileDec = _item.DocumentDescription;
                        clsStaticGlobal.SOTRNumberSearchedItemCollection.Add(new SOTRNumber { Count = SearchedCount, IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = _item.DocumentNumber, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileSection = "", FilePath = "", FileRemark = "Unable to check SFI code.!", FileRevision = "", FileStatus = "File not exist.!", FileLink = "" });
                    }

                    SearchedCount += 1;
                }

                //foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.DADDrawingFiles)
                //{
                //    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                //    string filePath = folder.FullName + "/" + _item.Name;
                //    string fileName = _item.Name;
                //    clsStaticGlobal.SOTRNumberSearchedItemCollection.Add(new SOTRNumber { Count = SearchedCount, IsCheckedSOTRNumber = false, FileType = "DAD", FileName = fileName, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                //    SearchedCount += 1;
                //}

                SOTRNumberSearchlistview.ItemsSource = clsStaticGlobal.SOTRNumberSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(SOTRNumberSearchlistview.ItemsSource);
                viewSearch.Filter = UserFilter;

                if (SOTRNumberSearchlistview.IsGrouping == false)
                {
                    CollectionView viewSearched = (CollectionView)CollectionViewSource.GetDefaultView(SOTRNumberSearchlistview.ItemsSource);
                    PropertyGroupDescription groupDescriptionSearched = new PropertyGroupDescription("FileType");
                    viewSearched.GroupDescriptions.Add(groupDescriptionSearched);
                }

                SOTRNumberlistview.ItemsSource = clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber;
                if (SOTRNumberlistview.IsGrouping == false)
                {
                    CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(SOTRNumberlistview.ItemsSource);
                    PropertyGroupDescription groupDescription = new PropertyGroupDescription("FileType");
                    view.GroupDescriptions.Add(groupDescription);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void SOTRNumberSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.SOTRNumberSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListSOTRNumber_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
                {
                    item.Count = k;
                    k++;
                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void BindSOTRNumberDocuments()
        {
            List<SOTRNumber> SOTRNumbersTemp = new List<SOTRNumber>();

            foreach (SOTRNumber item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
            {
                if (item.FileType.ToUpper() == "SOTR")
                {
                    SOTRNumbersTemp.Add(item);
                }
            }

            clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Clear();

            SOTRNumberlistview.Items.Refresh();

            foreach (SOTRNumber item in SOTRNumbersTemp)
            {
                clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Add(new SOTRNumber { IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = item.FileName, FileNumber = item.FileNumber, FileDesc = item.FileDesc, FileSection = item.FileSection, FilePath = item.FilePath, FileRemark = item.FileRemark, FileRevision = item.FileRevision, FileStatus = item.FileStatus, FileLink=item.FileLink });
            }


            SOTRNumberlistview.Items.Refresh();

            SOTRNumberlistview.UpdateLayout();

        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    SOTRNumberSearchlistview.UpdateLayout();

                    SOTRNumberSearchlistview.Items.Refresh();

                    foreach (SOTRNumber _item in clsStaticGlobal.SOTRNumberSearchedItemCollection)
                    {
                        if (_item.IsCheckedSOTRNumber == true)
                        {
                            bool IsFileExist = false;
                            foreach (SOTRNumber _itemExist in clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber)
                            {

                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                                else
                                {
                                    var _itemExistTemp = _itemExist.FileName.Split(new char[] { '.' });
                                    var _itemTemp = _item.FileName.Split(new char[] { '.' });
                                    if (_itemExistTemp[0].ToUpper() == _itemTemp[0].ToUpper())
                                    {
                                        IsFileExist = true;
                                    }
                                }

                            }
                            if (IsFileExist == false)
                            {
                                if (_item.FileType.ToUpper() == "SOTR")
                                {
                                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.FileName, "SOTR", clsStaticGlobal.ProjectFolder);
                                    if (_SearchedFile != null)
                                    {
                                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Add(new SOTRNumber { IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = _SearchedFile.Name, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSection = _item.FileSection, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label.ToString(), FileStatus = _SearchedFile.FileLfCyc.LfCycStateName.ToString(), FileLink = "Go To Location" });
                                        
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Add(new SOTRNumber { IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = _item.FileName, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSection = _item.FileSection, FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist", FileLink = "" });
                                    }
                                }
                            }
                        }
                    }
                    SOTRNumberlistview.Items.Refresh();
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            SOTRNumberlistview.UpdateLayout();
        }

        private void cmdSOTRNumberRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                    {
                        try
                        {
                            bool isChecked = false;
                            List<SOTRNumber> listOfSOTRNumber = new List<SOTRNumber>();

                            foreach (var itemSOTRNumber in SOTRNumberlistview.Items)
                            {
                                SOTRNumber objSOTRNumberNumber = (SOTRNumber)itemSOTRNumber;

                                if (objSOTRNumberNumber.IsCheckedSOTRNumber == true)
                                {
                                    isChecked = true;
                                    listOfSOTRNumber.Add(objSOTRNumberNumber);
                                }

                            }

                            foreach (SOTRNumber item in listOfSOTRNumber)
                            {
                                clsStaticGlobal.objSingleBuildSpecificationSummary.ListSOTRNumber.Remove(item);
                            }

                            SOTRNumberlistview.Items.Refresh();

                            BindSOTRNumberDocuments();

                            if (isChecked == false)
                            {
                                MessageBox.Show("Select single file first.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }
                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }


                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SOTRNumberSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                //SOTRNumberSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            { return true; }

            else
            {
                //SOTRNumber itemitem = (SOTRNumber)item;

                //if (itemitem.FileNumber.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
                return ((item as SOTRNumber).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as SOTRNumber).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            //return ((item as SOTRNumber).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            // return ((item as SOTRNumber).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as SOTRNumber).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(SOTRNumberSearchlistview.ItemsSource).Refresh();
        }

        private void Hyperlink_OnRequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            try
            {
                string hyperlink = "";
                string filepath = "";
                try
                {

                    filepath = ((SOTRNumber)((System.Windows.FrameworkElement)((System.Windows.FrameworkContentElement)sender).Parent).DataContext).FilePath;
                    hyperlink = clsStaticGlobal.GeHyperLink(filepath);

                    // var urlPart = ((Hyperlink)sender).NavigateUri;
                    if (hyperlink != "")
                    {
                        Process.Start(new ProcessStartInfo(hyperlink));
                    }
                    else
                    {
                        MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

            }
            catch (Exception)
            {

            }

            e.Handled = true;
        }
    }

    public class SOTRNumberFileType : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            SOTRNumber SOTRNumber = (SOTRNumber)value;

            if (SOTRNumber.FileType.ToUpper() == "SOTR")
            {
                if ((SOTRNumber.FileStatus != null) && (SOTRNumber.FileStatus.ToUpper() == "RELEASE"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return null;
            }

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
