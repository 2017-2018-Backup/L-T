﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleThicknessCollection : ObservableCollection<NameCodePair>
    {
        public static AngleThicknessCollection LoadList()
        {
            AngleThicknessCollection items = new AngleThicknessCollection();
            items.Add(new NameCodePair() { Code = "03", Name = "3" });
            items.Add(new NameCodePair() { Code = "04", Name = "4" });
            items.Add(new NameCodePair() { Code = "05", Name = "5" });
            items.Add(new NameCodePair() { Code = "06", Name = "6" });
            items.Add(new NameCodePair() { Code = "07", Name = "7" });
            items.Add(new NameCodePair() { Code = "08", Name = "8" });
            items.Add(new NameCodePair() { Code = "09", Name = "9" });
            items.Add(new NameCodePair() { Code = "10", Name = "10" });
            items.Add(new NameCodePair() { Code = "12", Name = "12" });
            items.Add(new NameCodePair() { Code = "15", Name = "15" });
            items.Add(new NameCodePair() { Code = "16", Name = "16" });
            items.Add(new NameCodePair() { Code = "18", Name = "18" });
            items.Add(new NameCodePair() { Code = "20", Name = "20" });
            items.Add(new NameCodePair() { Code = "24", Name = "24" });
            items.Add(new NameCodePair() { Code = "25", Name = "25" });
            return items;
        }

        public static AngleThicknessCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleThicknessCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleThicknessCollection>(HullItems.HullDataPath + @"\Angle\AngleThicknessCollection.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleThicknessCollection>(this, HullItems.HullDataPath + @"\Angle\AngleThicknessCollection.xml");
        }
    }
}
