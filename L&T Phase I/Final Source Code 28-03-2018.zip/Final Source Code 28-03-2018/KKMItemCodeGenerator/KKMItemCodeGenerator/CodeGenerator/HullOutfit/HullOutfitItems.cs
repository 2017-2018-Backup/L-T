﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HullOutfitItems : ObservableCollection<NameCodePair>
    {
        public static String DataPath = "";
        public static HullOutfitItems LoadList()
        {
            HullOutfitItems items = new HullOutfitItems();
            items.Add(new NameCodePair() { Code = "AN", Name = "ANGLE" });
            items.Add(new NameCodePair() { Code = "CH", Name = "CHANNEL" });
            items.Add(new NameCodePair() { Code = "BE", Name = "BEAMS" });
            items.Add(new NameCodePair() { Code = "BA", Name = "BARS" });
            items.Add(new NameCodePair() { Code = "HW", Name = "HARDWARE MATERIAL" });
            //items.Add(new NameCodePair() { Code = "GR", Name = "GRATING" });

            return items;
        }
        public static HullOutfitItems LoadFromExcel(String path)
        {
            return null;
        }

        public static HullOutfitItems LoadFromXml(string path)
        {
            HullOutfitItems.DataPath = path;
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HullOutfitItems>(HullOutfitItems.DataPath + @"\Items.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HullOutfitItems>(this, path + @"\Items.xml");
        }

    }
}
