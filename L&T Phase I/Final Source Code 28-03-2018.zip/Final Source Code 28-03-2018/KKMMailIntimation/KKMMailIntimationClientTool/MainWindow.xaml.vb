﻿
Imports System.Data
Imports VDF = Autodesk.DataManagement.Client.Framework
Imports Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections
Imports System.Xml
Imports Autodesk.Connectivity.WebServices
Imports System.Windows
Imports Autodesk.DataManagement.Client.Framework.Vault
Imports System.Net.Mail
Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports System.Globalization
Imports System.Reflection
Imports KKMMailIntimationClientTool

Public Class UI
    Inherits Window
    Implements ILifeCycleEvent

    Public Shared _settingFileName As String = "Settings.xml"
    Public Shared _dirSep As String = System.IO.Path.DirectorySeparatorChar.ToString()
    Public Shared _outputPath As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + _dirSep + "KKMiVault" + _dirSep
    Dim vConnection As Connection
    Dim _jobType As String = String.Empty
    Private vaultGroup As Dictionary(Of String, Long) = New Dictionary(Of String, Long)
    Public vaultFolderId As Long
    Dim selectedExportOption As String
    Dim vUsers() As User
    Dim vGroups() As Group
    Dim vGroupInfo As Dictionary(Of Long, User())
    Dim dtEmailNotification As New DataTable
    Dim listofCategory As List(Of String)

    Private Sub GetCategoryList()
        listofCategory = New List(Of String)
        listofCategory.Add("As-Built Document")
        listofCategory.Add("Basic Design document")
        listofCategory.Add("Class Approved document")
        listofCategory.Add("DIN")
        listofCategory.Add("Enquiry")
        listofCategory.Add("Post Delivery Comments")
        listofCategory.Add("Project")
        listofCategory.Add("Production Document - Without Checklist")
        listofCategory.Add("Production document")
        listofCategory.Add("Purchase Order")
        listofCategory.Add("Ship Technical Specification")
        listofCategory.Add("SOTR")
        listofCategory.Add("Surveyor Comments")
        listofCategory.Add("Technical Specifications - Engineering")
        listofCategory.Sort()
    End Sub

    Public Sub New(ByVal _con As Connection)
        ' This call is required by the designer.
        Try
            InitializeComponent()

            If Not System.IO.Directory.Exists(_outputPath) Then
                System.IO.Directory.CreateDirectory(_outputPath)
            End If
            ' Add any initialization after the InitializeComponent() call.
            vConnection = _con
            GetCategoryList()
            If CommandExtension.isAdministrator Then
                AddColumns()
                LoadSettings()
                PopulateUI()
                Me.DataContext = Me
                GetAllUsers()
                GetAllGroups()
                LoadEmailSettings()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AddColumns()
        dtEmailNotification.Columns.Add("TransistionId", GetType(Long))
        dtEmailNotification.Columns.Add("Users")
    End Sub

    Public Sub GetAllUsers()
        vUsers = vConnection.WebServiceManager.AdminService.GetAllUsers()
    End Sub

    Public Sub GetAllGroups()
        vGroups = vConnection.WebServiceManager.AdminService.GetAllGroups()
        vGroupInfo = New Dictionary(Of Long, User())
        For Each grp As Group In vGroups
            Dim usr = vConnection.WebServiceManager.AdminService.GetMemberUsersByGroupId(grp.Id)
            vGroupInfo.Add(grp.Id, usr)
        Next
    End Sub

#Region "Download File"

    Public Function DownloadFile(ByVal _filename As String, ByVal isCheckout As Boolean) As Boolean
        ' download individual files to a temp location
        Try

            If System.IO.File.Exists(_outputPath + _filename) Then
                Dim oFileInfo As New IO.FileInfo(_outputPath + _filename)
                If (oFileInfo.Attributes And IO.FileAttributes.ReadOnly) > 0 Then
                    oFileInfo.Attributes = oFileInfo.Attributes Xor IO.FileAttributes.ReadOnly
                    System.IO.File.Delete(_outputPath + _filename)
                Else
                    System.IO.File.Delete(_outputPath + _filename)
                End If
            End If

            Dim oFileIteration As VDF.Vault.Currency.Entities.FileIteration = getFileIteration(_filename, vConnection)
            Dim settings As New VDF.Vault.Settings.AcquireFilesSettings(vConnection)
            settings.LocalPath = New VDF.Currency.FolderPathAbsolute(_outputPath)

            ' For Each fileIter As VDF.Vault.Currency.Entities.FileIteration In fileIters
            If isCheckout Then
                settings.AddFileToAcquire(oFileIteration, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout Or VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download)
            Else
                settings.AddFileToAcquire(oFileIteration, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download)
            End If

            ' Next
            Dim results As VDF.Vault.Results.AcquireFilesResults = vConnection.FileManager.AcquireFiles(settings)

            If results.FileResults(0).Status.Equals(VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Success) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function getFileIterationWithFolderId(ByVal nameOfFile As String, ByVal folderId As Long) _
                                                                     As VDF.Vault.Currency.Entities.FileIteration
        Dim conditions As SrchCond()

        ReDim conditions(0)

        Dim lCode As Long = 3

        Dim Defs As PropDef() = vConnection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE")

        Dim Prop As PropDef = Nothing

        For Each def As PropDef In Defs
            If def.DispName = "File Name" Then
                Prop = def
                Exit For
            End If
        Next def

        Dim searchCondition As SrchCond = New SrchCond()
        searchCondition.PropDefId = Prop.Id

        searchCondition.PropTyp = PropertySearchType.SingleProperty
        searchCondition.SrchOper = lCode

        searchCondition.SrchTxt = nameOfFile

        conditions(0) = searchCondition

        ' search for files
        Dim FileList As List(Of Autodesk.Connectivity.WebServices.File) = New List(Of Autodesk.Connectivity.WebServices.File)()
        Dim sBookmark As String = String.Empty
        Dim Status As SrchStatus = Nothing

        While (Status Is Nothing OrElse FileList.Count < Status.TotalHits)

            Dim files As Autodesk.Connectivity.WebServices.File() = vConnection.WebServiceManager.
                                                      DocumentService.FindFilesBySearchConditions(conditions,
                                                             Nothing, Nothing, True, True, sBookmark, Status)

            If (Not files Is Nothing) Then
                FileList.AddRange(files)
            End If
        End While

        Dim oFileIteration As VDF.Vault.Currency.Entities.FileIteration = Nothing
        For i As Integer = 0 To FileList.Count - 1
            If FileList(i).Name = nameOfFile And FileList(i).FolderId = folderId Then
                oFileIteration = New VDF.Vault.Currency.Entities.FileIteration(vConnection, FileList(i))
            End If
        Next

        Return oFileIteration

    End Function

    Public Function getFileIteration(ByVal nameOfFile As String, ByVal connection As VDF.Vault.Currency.Connections.Connection) _
                                                                       As VDF.Vault.Currency.Entities.FileIteration
        Dim conditions As SrchCond()

        ReDim conditions(0)

        Dim lCode As Long = 3

        Dim Defs As PropDef() = connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE")

        Dim Prop As PropDef = Nothing

        For Each def As PropDef In Defs
            If def.DispName = "File Name" Then
                Prop = def
                Exit For
            End If
        Next def

        Dim searchCondition As SrchCond = New SrchCond()
        searchCondition.PropDefId = Prop.Id

        searchCondition.PropTyp = PropertySearchType.SingleProperty
        searchCondition.SrchOper = lCode

        searchCondition.SrchTxt = nameOfFile

        conditions(0) = searchCondition

        ' search for files
        Dim FileList As List(Of Autodesk.Connectivity.WebServices.File) = New List(Of Autodesk.Connectivity.WebServices.File)()
        Dim sBookmark As String = String.Empty
        Dim Status As SrchStatus = Nothing

        While (Status Is Nothing OrElse FileList.Count < Status.TotalHits)

            Dim files As Autodesk.Connectivity.WebServices.File() = connection.WebServiceManager.
                                                      DocumentService.FindFilesBySearchConditions(conditions,
                                                             Nothing, Nothing, True, True, sBookmark, Status)

            If (Not files Is Nothing) Then
                FileList.AddRange(files)
            End If
        End While

        Dim oFileIteration As VDF.Vault.Currency.Entities.FileIteration = Nothing
        For i As Integer = 0 To FileList.Count - 1
            If FileList(i).Name = nameOfFile Then
                oFileIteration = New VDF.Vault.Currency.Entities.FileIteration(connection, FileList(i))
            End If
        Next

        Return oFileIteration

    End Function

#End Region

    Public Function SaveSettingsInVault()
        Try
            Dim filePath As String = _outputPath + _settingFileName
            If System.IO.File.Exists(filePath) Then
                Dim vaultFolderId As Long = 0
                Try
                    Dim folderpath() As String = {"$/KKMiVault"}
                    Dim _folder() As Folder = vConnection.WebServiceManager.DocumentService.FindFoldersByPaths(folderpath)
                    If Not _folder.Count.Equals(0) AndAlso _folder(0).Id <> -1 Then
                        vaultFolderId = _folder(0).Id
                    Else
                        Dim rootFolderId As Long = vConnection.WebServiceManager.DocumentService.GetFolderRoot().Id
                        Dim settingsFolder = vConnection.WebServiceManager.DocumentService.AddFolder("KKMiVault", rootFolderId, False)
                        If (settingsFolder IsNot Nothing) Then
                            vaultFolderId = settingsFolder.Id
                        Else
                            Return False
                        End If
                    End If
                Catch ex As Exception

                End Try

                Dim str() As String = {"$/KKMiVault/Settings.xml"}
                Dim _settingsFile() As File = vConnection.WebServiceManager.DocumentService.FindLatestFilesByPaths(str)

                If Not _settingsFile.Count.Equals(0) AndAlso _settingsFile(0).Id <> -1 Then
                    ' vConnection.WebServiceManager.DocumentService.DeleteFileFromFolderUnconditional(_settingsFile(0).MasterId, vaultFolderId)

                    Dim oFileIteration As VDF.Vault.Currency.Entities.FileIteration = getFileIteration("Settings.xml", vConnection)
                    vConnection.FileManager.CheckinFile(oFileIteration, "Settings File.", False, Nothing, Nothing, True, String.Empty, oFileIteration.FileClassification, oFileIteration.IsHidden, New VDF.Currency.FilePathAbsolute(filePath))
                Else
                    Dim folderEntity As New Currency.Entities.Folder(vConnection, vConnection.WebServiceManager.DocumentService.GetFolderById(vaultFolderId))
                    Dim filePathAbs As VDF.Currency.FilePathAbsolute = New VDF.Currency.FilePathAbsolute(filePath)

                    vConnection.FileManager.AddFile(folderEntity, "Settings File.", Nothing, Nothing, FileClassification.None, False, filePathAbs)
                    'ElseIf _settingsFile(0).Id <> -1 Then
                    '    vConnection.WebServiceManager.DocumentService.DeleteFileFromFolderUnconditional(_settingsFile(0).MasterId, vaultFolderId)
                End If

            Else
                lblError.Content = "Settings file is not Configured! Kindly Try Again."
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Public Function GetFolderByPath(ByVal parFolderId As Long, ByVal folderPath As String, ByVal foldername As String) As Folder
        Dim _folder As Folder = Nothing
        Try
            _folder = vConnection.WebServiceManager.DocumentService.GetFolderByPath(folderPath + "/" + foldername)
        Catch ex As Exception

        End Try
        If _folder Is Nothing Then
            _folder = vConnection.WebServiceManager.DocumentService.AddFolder(foldername, parFolderId, False)
        End If
        Return _folder
    End Function

    Private Function GetFileFromFolderId(ByVal _folderId As Long) As Autodesk.Connectivity.WebServices.File
        Try
            Dim filename(0) As String
            Dim results As Autodesk.Connectivity.WebServices.File()

            results = vConnection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(_folderId, True) ' EdmSecurity.Instance.VaultConnection.WebServiceManager.DocumentService.GetLatestFilePathsByNames(filename)

            For Each _file As File In results
                If _file.Name.Equals("Settings.xml", StringComparison.InvariantCultureIgnoreCase) Then
                    Return _file
                End If
            Next
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    Private Sub tbControl_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs) Handles tbControl.SelectionChanged
        If TypeOf e.Source Is TabControl AndAlso (DirectCast(e.Source, TabControl)).Name.Equals("tbControl") Then
            Dim selectedTab As String = DirectCast(tbControl.SelectedItem, System.Windows.Controls.TabItem).Name
            If selectedTab.Equals("tbItemMailSettings") Then
                LoadEmailSettings()
            End If
            lblError.Content = String.Empty
        End If
    End Sub

    Public Sub LoadEmailSettings()
        vaultGroup.Clear()

        If DownloadFile(_settingFileName, False) Then
            Dim tempXml As New XmlDocument
            tempXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)
            ' tempXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)
            If tempXml IsNot Nothing Then
                Dim xnMailConfig As XmlNode = tempXml.SelectSingleNode("Settings").SelectSingleNode("EmailConfiguration")
                If xnMailConfig IsNot Nothing Then
                    txtSMTPServer.Text = xnMailConfig.SelectSingleNode("SMTPServer").InnerText
                    txtPort.Text = xnMailConfig.SelectSingleNode("SMTPPort").InnerText
                    txtDisplayName.Text = xnMailConfig.SelectSingleNode("DisplayName").InnerText
                    txtFromEmail.Text = xnMailConfig.SelectSingleNode("FromEmail").InnerText
                    Dim isDefaultCred, isEnableSSL As Boolean
                    Boolean.TryParse(xnMailConfig.SelectSingleNode("UseDefaultCred").InnerText, isDefaultCred)
                    Boolean.TryParse(xnMailConfig.SelectSingleNode("EnableSSL").InnerText, isEnableSSL)
                    ckbxSSL.IsChecked = isEnableSSL
                    If isDefaultCred Then
                        ckbxCredential.IsChecked = isDefaultCred
                    Else
                        ckbxCredential.IsChecked = isDefaultCred
                        txtUsername.Text = xnMailConfig.SelectSingleNode("Username").InnerText
                        txtPassword.Password = xnMailConfig.SelectSingleNode("Password").InnerText
                        Try
                            txtMailContent.Text = xnMailConfig.SelectSingleNode("MailContent").InnerText
                        Catch ex As Exception
                        End Try

                    End If
                Else
                    ClearEmailTab()
                End If
            End If
        End If
    End Sub

    Public Sub ClearEmailTab()
        txtSMTPServer.Clear()
        txtPort.Clear()
        txtDisplayName.Clear()
        txtFromEmail.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        ckbxCredential.IsChecked = False
        ckbxSSL.IsChecked = False
        txtMailContent.Text = "Business Object: LTSB Design Specification $filename$ $revision$" & vbNewLine & vbNewLine &
                             "Policy: $category$" & vbNewLine & vbNewLine &
                               "Document Name: $filename$" & vbNewLine & vbNewLine &
                                "Revision: $revision$" & vbNewLine & vbNewLine &
                                 "Description: $description$" & vbNewLine & vbNewLine &
                                  "State: promoted to $state$ state" & vbNewLine & vbNewLine &
                                  "$link$" & vbNewLine & vbNewLine &
                                 "This is an automated mail. Kindly do not reply to this mail."
    End Sub

    Private Sub ckbxCredential_Checked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles ckbxCredential.Checked
        txtUsername.IsEnabled = False
        txtPassword.IsEnabled = False
    End Sub

    Private Sub ckbxCredential_Unchecked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles ckbxCredential.Unchecked
        txtUsername.IsEnabled = True
        txtPassword.IsEnabled = True
    End Sub

    Private Sub btnEmailSave_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnEmailSave.Click
        Dim xmlPath = _outputPath + _settingFileName
        Dim settingsXml As New XmlDocument

        Dim rootNode, parentNode, childNode, xmlnode, newNode As XmlNode
        Dim temp = getFileIteration(_settingFileName, vConnection)

        If temp Is Nothing Then
            xmlnode = settingsXml.CreateXmlDeclaration("1.0", "UTF-8", Nothing)
            settingsXml.AppendChild(xmlnode)
            rootNode = settingsXml.CreateElement("Settings")
            parentNode = settingsXml.CreateElement("EmailConfiguration")
            rootNode.AppendChild(parentNode)
            settingsXml.AppendChild(rootNode)
        ElseIf temp.IsCheckedOut Then
            lblError.Content = "Settings file is checked out on " + temp.CheckedOutMachine + "! Kindly Try Again."
            lblError.Foreground = New SolidColorBrush(Colors.Red)
            Exit Sub
        Else

            If DownloadFile(_settingFileName, True) Then
                ' tempXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)
                settingsXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)
                rootNode = settingsXml.SelectSingleNode("Settings")
                parentNode = settingsXml.SelectSingleNode("Settings").SelectSingleNode("EmailConfiguration")
                If parentNode Is Nothing Then
                    parentNode = settingsXml.CreateElement("EmailConfiguration")
                    rootNode.AppendChild(parentNode)
                End If
            Else
                lblError.Content = "Unable to Update Settings File! Kindly Try Again"
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                Exit Sub
            End If
        End If
        'settingsXml.AppendChild(xmlNode)
        'rootNode = settingsXml.CreateElement("Settings")

        newNode = settingsXml.CreateElement("EmailConfiguration")

        childNode = settingsXml.CreateElement("SMTPServer")
        childNode.InnerText = txtSMTPServer.Text
        newNode.AppendChild(childNode)

        childNode = settingsXml.CreateElement("SMTPPort")
        childNode.InnerText = txtPort.Text
        newNode.AppendChild(childNode)

        childNode = settingsXml.CreateElement("EnableSSL")
        If ckbxSSL.IsChecked.Equals(True) Then
            childNode.InnerText = "True"
        Else
            childNode.InnerText = "False"
        End If
        newNode.AppendChild(childNode)

        If ckbxCredential.IsChecked.Equals(True) Then
            childNode = settingsXml.CreateElement("UseDefaultCred")
            childNode.InnerText = "True"
            newNode.AppendChild(childNode)
        Else
            childNode = settingsXml.CreateElement("UseDefaultCred")
            childNode.InnerText = "False"
            newNode.AppendChild(childNode)

            childNode = settingsXml.CreateElement("Username")
            childNode.InnerText = txtUsername.Text
            newNode.AppendChild(childNode)

            childNode = settingsXml.CreateElement("Password")
            childNode.InnerText = txtPassword.Password
            newNode.AppendChild(childNode)
        End If

        childNode = settingsXml.CreateElement("FromEmail")
        childNode.InnerText = txtFromEmail.Text.ToLower()
        newNode.AppendChild(childNode)

        childNode = settingsXml.CreateElement("DisplayName")
        childNode.InnerText = txtDisplayName.Text
        newNode.AppendChild(childNode)

        childNode = settingsXml.CreateElement("MailContent")
        childNode.InnerText = txtMailContent.Text
        newNode.AppendChild(childNode)

        rootNode.ReplaceChild(newNode, parentNode)
        '   settingsXml.AppendChild(rootNode)


        If System.IO.File.Exists(xmlPath) Then
            Dim oFileInfo As New IO.FileInfo(xmlPath)
            If (oFileInfo.Attributes And IO.FileAttributes.ReadOnly) > 0 Then
                oFileInfo.Attributes = oFileInfo.Attributes Xor IO.FileAttributes.ReadOnly
                System.IO.File.Delete(xmlPath)
            End If
        End If

        settingsXml = Encryption.ClsExtention.Encrypt(settingsXml)
        settingsXml.Save(xmlPath)
        If SaveSettingsInVault() Then
            lblError.Content = "Email Settings Saved Successfully!" '  Me.Close()
            lblError.Foreground = New SolidColorBrush(Colors.Green)
        Else
            lblError.Content = "Email Settings Not Saved! Kindly Try Again"
            lblError.Foreground = New SolidColorBrush(Colors.Red)
        End If

    End Sub

    Private Sub btnEmailClear_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnEmailClear.Click
        ClearEmailTab()
    End Sub

#Region "Publish PDF Settings"
    Private m_currentThreadId As Guid = Guid.Empty
    Private m_idsToStates As Dictionary(Of Long, LfCycState)
    Private m_transIdsToEvents As Dictionary(Of Long, StringArray)
    Private m_pendingChanges As Dictionary(Of Long, StringArray)
    Private m_committingChanges As Boolean = False

#Region "Private methods"

    Private Sub GetTransitionEvents(ByVal lcDef As LfCycDef)
        Dim transitions As LfCycTrans() = lcDef.TransArray
        If transitions Is Nothing OrElse transitions.Length = 0 Then
            Return
        End If

        ' check to see if we have the information in the cache already
        If m_transIdsToEvents.ContainsKey(transitions(0).Id) Then
            Return
        End If

        Dim transIds As New List(Of Long)()
        For Each transition As LfCycTrans In transitions
            transIds.Add(transition.Id)
        Next

        Dim jobArrayArray As StringArray() = Nothing

        jobArrayArray = vConnection.WebServiceManager.LifeCycleService.GetJobTypesByLifeCycleStateTransitionIds(transIds.ToArray())

        Dim i As Integer = 0
        For Each id As Long In transIds
            If jobArrayArray IsNot Nothing Then
                m_transIdsToEvents.Add(id, jobArrayArray(i))
            Else
                m_transIdsToEvents.Add(id, Nothing)
            End If

            i += 1
        Next
    End Sub

    Private Sub UpdatePendingChanges()
        Try
            Dim transitionItem As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
            If transitionItem Is Nothing Then
                Return
            End If

            Dim transition As LfCycTrans = transitionItem.LfCycTrans
            If m_pendingChanges.ContainsKey(transition.Id) Then
                m_pendingChanges.Remove(transition.Id)
            End If

            Dim jobTypes As New StringArray()

            'If lst_FileJobs.Items.Count = 0 Then
            '    jobTypes.Items = Nothing
            'Else
            '    jobTypes.Items = New String(lst_FileJobs.Items.Count - 1) {}
            '    Dim i As Integer = 0
            '    For Each job As String In lst_FileJobs.Items
            '        jobTypes.Items(i) = job
            '        i += 1
            '    Next
            'End If

            If txt_FileJobs.Text = "" Then
                jobTypes.Items = Nothing
            Else
                ''jobTypes.Items = New String(txt_FileJobs.Text) {}
                jobTypes.Items = New String(0) {}
                Dim i As Integer = 0
                jobTypes.Items(i) = txt_FileJobs.Text
            End If

            m_pendingChanges.Add(transition.Id, jobTypes)

            If m_transIdsToEvents.ContainsKey(transition.Id) Then
                m_transIdsToEvents(transition.Id) = jobTypes
            Else
                m_transIdsToEvents.Add(transition.Id, jobTypes)
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region "WORKER_THREADS"

    Public Sub PopulateUIWorker()
        Try
            '' cmbx_category

            Dim categoriesFile As Cat() = vConnection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FILE", True)
            ''Debugger.Launch()
            If categoriesFile IsNot Nothing Then
                For Each CatDef As Cat In categoriesFile
                    Dim res As Boolean = listofCategory.Contains(CatDef.Name)
                    ''MessageBox.Show(CatDef.Name & " : " & res)
                    If listofCategory.Contains(CatDef.Name) = True Then
                        cmbx_category.Items.Add(New FileCatListItem(CatDef))
                    End If
                Next
                'If cmbx_category.Items.Count > 0 Then
                '    cmbx_category.SelectedIndex = 0
                'End If
            End If

            Dim categoriesFldr As Cat() = vConnection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", True)
            ''Debugger.Launch()
            If categoriesFldr IsNot Nothing Then
                For Each CatDef As Cat In categoriesFldr
                    If CatDef.Name = "Project" Then
                        cmbx_category.Items.Add(New FileCatListItem(CatDef))
                    End If
                Next
                'If cmbx_category.Items.Count > 0 Then
                '    cmbx_category.SelectedIndex = 0
                'End If
            End If

            'Dim lcDefs As LfCycDef() = Nothing
            'Try
            '    ' get all the lifecycle information
            '    lcDefs = vConnection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions()
            'Catch ex As Exception
            '    ' Show the error on the UI Thread

            'End Try

            'If lcDefs IsNot Nothing Then
            '    For Each lcDef As LfCycDef In lcDefs
            '        cmbx_lifeCylceDef.Items.Add(New LfCycDefListItem(lcDef))
            '    Next
            '    If cmbx_lifeCylceDef.Items.Count > 0 Then
            '        cmbx_lifeCylceDef.SelectedIndex = 0
            '    End If
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UpdateStatesWorker(ByVal threadId As Guid, ByVal lcDef As LfCycDefListItem)
        Try
            Dim states As LfCycState() = Nothing
            If lcDef.LfCycDef IsNot Nothing Then
                states = lcDef.LfCycDef.StateArray
            End If
            Try
                If states IsNot Nothing Then
                    GetTransitionEvents(lcDef.LfCycDef)
                End If
            Catch ex As Exception

            End Try
            If threadId.Equals(m_currentThreadId) Then
                If states IsNot Nothing Then
                    For Each state As LfCycState In states
                        ''lst_FileState.Items.Add(New LfCycStateListItem(state))
                        cmbx_FileState.Items.Add(New LfCycStateListItem(state))
                        m_idsToStates.Add(state.Id, state)
                    Next
                End If
                m_currentThreadId = Guid.Empty
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region "Interface Implementation"

    Public Sub AddJobEvent() Implements KKMMailIntimationClientTool.ILifeCycleEvent.AddJobEvent
        If m_committingChanges Then
            Return
        End If

        Dim transition As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
        If transition Is Nothing Then
            Return
        End If
        ''lst_FileJobs.Items.Add(_jobType)
        txt_FileJobs.Text = _jobType
        UpdatePendingChanges()
    End Sub

    Public ReadOnly Property CanAddJobEvent As Boolean Implements KKMMailIntimationClientTool.ILifeCycleEvent.CanAddJobEvent
        Get
            Dim transition As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
            If transition Is Nothing Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    Public ReadOnly Property CanDeleteJobEvent As Boolean Implements ILifeCycleEvent.CanDeleteJobEvent
        Get
            Dim transition As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
            If transition Is Nothing Then 'OrElse m_jobTypesListBox.SelectedItem Is Nothing Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    Public Sub CommitChanges() Implements ILifeCycleEvent.CommitChanges

        If m_pendingChanges.Count = 0 OrElse m_committingChanges Then
            Return
        End If

        m_committingChanges = True

        Try
            Dim enumerator As Dictionary(Of Long, StringArray).Enumerator = m_pendingChanges.GetEnumerator()
            Dim i As Integer = 0
            While enumerator.MoveNext()
                vConnection.WebServiceManager.LifeCycleService.UpdateLifeCycleStateTransitionJobTypes(enumerator.Current.Key, enumerator.Current.Value.Items)
                i += 1
            End While

            m_pendingChanges.Clear()

        Catch ex As Exception

        End Try

        m_committingChanges = False

    End Sub

    Public Sub DeleteJobEvent() Implements ILifeCycleEvent.DeleteJobEvent
        Dim transition As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
        If transition Is Nothing OrElse txt_FileJobs.Text = "" Then
            Return
        End If
        If txt_FileJobs.Text.Equals("KKMMailIntimationJobProcessorTool.EmailNotification.OnStateChange") Then
            For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.LfCycTrans.Id & "'")
                dtEmailNotification.Rows.Remove(row)
            Next
            lstSelectedUsers.ItemsSource = Nothing
            lstSelectedUsers.UpdateLayout()
        End If
        ''lst_FileJobs.Items.RemoveAt(lst_FileJobs.SelectedIndex)
        txt_FileJobs.Text = ""
        UpdatePendingChanges()
    End Sub

    Public ReadOnly Property HasPendingChanges As Boolean Implements ILifeCycleEvent.HasPendingChanges
        Get
            Return (m_pendingChanges IsNot Nothing AndAlso m_pendingChanges.Count > 0)
        End Get
    End Property

    Public ReadOnly Property IsRunning As Boolean Implements ILifeCycleEvent.IsRunning
        Get
            Return Not m_currentThreadId.Equals(Guid.Empty)
        End Get
    End Property

    Public Sub PopulateUI() Implements ILifeCycleEvent.PopulateUI
        Try
            If m_idsToStates Is Nothing Then
                m_idsToStates = New Dictionary(Of Long, LfCycState)()
                m_transIdsToEvents = New Dictionary(Of Long, StringArray)()
                m_pendingChanges = New Dictionary(Of Long, StringArray)()
                PopulateUIWorker()
                'ThreadPool.QueueUserWorkItem(New WaitCallback(AddressOf PopulateUIWorker))
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region

#End Region

    'Private Sub lst_FileState_SelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles lst_FileState.SelectionChanged
    '    If lst_FileState.SelectedItem IsNot Nothing Then
    '        lst_FileTransition.Items.Clear()
    '        lst_FileJobs.Items.Clear()
    '        '  m_jobTypesListBox.Items.Clear()
    '        ClearLstUsers()
    '        Dim lcDefItem As LfCycDefListItem = TryCast(cmbx_lifeCylceDef.SelectedItem, LfCycDefListItem)
    '        Dim stateItem As LfCycStateListItem = TryCast(lst_FileState.SelectedItem, LfCycStateListItem)

    '        Dim lcDef As LfCycDef = lcDefItem.LfCycDef
    '        Dim state As LfCycState = stateItem.LfCycState
    '        If lcDef IsNot Nothing AndAlso state IsNot Nothing Then
    '            Dim transitions As LfCycTrans() = lcDef.TransArray
    '            If transitions Is Nothing OrElse transitions.Length = 0 Then
    '                Return
    '            End If

    '            ' pass 1: going from the selected state
    '            For Each transition As LfCycTrans In transitions
    '                If transition.FromId = state.Id Then
    '                    Dim transItem As New LfCycTransListItem(transition)
    '                    transItem.DispName = state.DispName + " -> " + m_idsToStates(transition.ToId).DispName
    '                    lst_FileTransition.Items.Add(transItem)
    '                End If
    '            Next

    '            ' pass 2: going to the selected state
    '            For Each transition As LfCycTrans In transitions
    '                If transition.ToId = state.Id Then
    '                    Dim transItem As New LfCycTransListItem(transition)
    '                    transItem.DispName = state.DispName + " <- " + m_idsToStates(transition.FromId).DispName
    '                    lst_FileTransition.Items.Add(transItem)
    '                End If
    '            Next
    '        End If
    '    End If
    'End Sub

    Private Sub ClearLstUsers()
        lstSelectedUsers.ItemsSource = Nothing
        lstSelectedUsers.UpdateLayout()
    End Sub

    'Private Sub lst_FileTransition_SelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles lst_FileTransition.SelectionChanged
    '    If lst_FileTransition.SelectedItem IsNot Nothing Then

    '        Dim transition As LfCycTransListItem = TryCast(lst_FileTransition.SelectedItem, LfCycTransListItem)
    '        lst_FileJobs.Items.Clear()
    '        ClearLstUsers()
    '        If transition Is Nothing OrElse transition.LfCycTrans Is Nothing Then
    '            Return
    '        End If
    '        lstUsers.Items.Clear()
    '        lstUsers.IsEnabled = False
    '        If m_transIdsToEvents.ContainsKey(transition.LfCycTrans.Id) Then
    '            Dim jobArray As StringArray = m_transIdsToEvents(transition.LfCycTrans.Id)

    '            If jobArray IsNot Nothing AndAlso jobArray.Items IsNot Nothing Then
    '                For Each job As String In jobArray.Items
    '                    lst_FileJobs.Items.Add(job)
    '                    If job.Equals("KKMMailIntimationJobProcessorTool.EmailNotification.OnStateChange") Then
    '                        lstUsers.IsEnabled = True
    '                        For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.LfCycTrans.Id & "'")
    '                            lstUsers.Items.Add(row(1).ToString())
    '                        Next
    '                    Else
    '                        lstUsers.IsEnabled = False
    '                    End If
    '                Next
    '            End If
    '        End If
    '    End If
    'End Sub

    'Private Sub AddJobClick(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles cmAdd.Click
    '    _jobType = String.Empty
    '    If DirectCast(sender, System.Windows.Controls.MenuItem).Name.Equals("cmAdd", StringComparison.InvariantCultureIgnoreCase) Then
    '        _jobType = "KKMSOFTiVaultJobProcessor.Publish.LifeCycleStateChange"
    '        txtRootFolder.IsEnabled = True
    '        txtRootFolderPDF.IsEnabled = True
    '    End If
    '    If _jobType IsNot String.Empty And Not lst_FileJobs.Items.Contains(_jobType) Then
    '        AddJobEvent()
    '        CommitChanges()
    '    End If
    'End Sub

    'Private Sub AddMailJobClick(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles cmAddMail.Click
    '    _jobType = String.Empty
    '    If DirectCast(sender, System.Windows.Controls.MenuItem).Name.Equals("cmAddMail", StringComparison.InvariantCultureIgnoreCase) Then
    '        Dim obj As UI_UserSelection = New UI_UserSelection(vUsers, vGroups, vGroupInfo)
    '        _jobType = "KKMMailIntimationJobProcessorTool.EmailNotification.OnStateChange"
    '        If _jobType IsNot String.Empty And Not lst_FileJobs.Items.Contains(_jobType) Then
    '            obj.Owner = Me
    '            obj.ShowDialog()
    '            If obj.dg.Equals(True) Then
    '                Dim transitionItem As LfCycTransListItem = TryCast(lst_FileTransition.SelectedItem, LfCycTransListItem)
    '                If transitionItem Is Nothing Then
    '                    Return
    '                End If

    '                Dim transition As LfCycTrans = transitionItem.LfCycTrans
    '                If obj.lstSelectedUsers.Items.Count > 0 Then
    '                    lstUsers.IsEnabled = True
    '                    txtRootFolder.IsEnabled = False
    '                    txtRootFolderPDF.IsEnabled = False
    '                    For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.Id & "'")
    '                        dtEmailNotification.Rows.Remove(row)
    '                    Next
    '                    lstUsers.Items.Clear()
    '                    For Each Str As String In obj.lstSelectedUsers.Items
    '                        lstUsers.Items.Add(Str)
    '                        dtEmailNotification.Rows.Add(New String() {transition.Id, Str})
    '                    Next
    '                    AddJobEvent()
    '                    CommitChanges()
    '                End If
    '            Else
    '                lblError.Foreground = New SolidColorBrush(Colors.Red)
    '                lblError.Content = "Email Notification job is not configured since users are not selected for Email Notification!"
    '            End If
    '        End If
    '    End If
    'End Sub

    'Private Sub lst_FileJobs_PreviewMouseRightButtonDown(ByVal sender As System.Object, ByVal e As System.Windows.Input.MouseButtonEventArgs) Handles lst_FileJobs.PreviewMouseRightButtonDown
    '    If lst_FileTransition.SelectedItem Is Nothing Then
    '        '' cmAdd.IsEnabled = False

    '        cmDelete.IsEnabled = False
    '        mnuItemDeleteIco.Opacity = 0.5
    '        ''mnuItemPublishIco.Opacity = 0.5


    '    Else
    '        If lst_FileJobs.SelectedItem Is Nothing Then
    '            cmDelete.IsEnabled = False
    '            mnuItemDeleteIco.Opacity = 0.5
    '        Else
    '            cmDelete.IsEnabled = True
    '            mnuItemDeleteIco.Opacity = 1
    '        End If
    '        'If lst_FileJobs.Items.Contains("KKMSOFTiVaultJobProcessor.Publish.LifeCycleStateChange") Then
    '        '    cmAdd.IsEnabled = False
    '        '    mnuItemPublishIco.Opacity = 0.5
    '        'Else
    '        '    cmAdd.IsEnabled = True
    '        '    mnuItemPublishIco.Opacity = 1
    '        'End If
    '    End If
    'End Sub

    'Private Sub DeleteJobClick(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles cmDelete.Click
    '    DeleteJobEvent()
    '    CommitChanges()
    'End Sub

    Public Function EmailValidations()

        If txtSMTPServer.Text.Equals(String.Empty) Then
            lblError.Content = "Kindly Enter SMTP Server Address!"
            lblError.Foreground = New SolidColorBrush(Colors.Red)
            txtSMTPServer.Focus()
            Return False
        End If

        If ckbxCredential.IsChecked.Equals(False) Then
            If txtUsername.Text.Equals(String.Empty) Then
                lblError.Content = "Kindly Enter Username!"
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                txtUsername.Focus()
                Return False
            End If
            If txtPassword.Password.Equals(String.Empty) Then
                lblError.Content = "Kindly Enter Password!"
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                txtPassword.Focus()
                Return False
            End If
        End If

        Try
            Dim testMail = New MailAddress(txtTestEmailTo.Text)
        Catch ex As Exception
            lblError.Content = "Invalid From Email Address!"
            lblError.Foreground = New SolidColorBrush(Colors.Red)
            txtTestEmailTo.Focus()
            Return False
        End Try


        Return True

    End Function

    Private Sub btnSendTestMail_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnSendTestMail.Click
        If EmailValidations() Then
            Try
                Me.Cursor = Cursors.Wait
                Dim SmtpServer As New SmtpClient()

                If ckbxCredential.IsChecked.Equals(True) Then
                    SmtpServer.UseDefaultCredentials = True
                Else
                    SmtpServer.Credentials = New Net.NetworkCredential(txtUsername.Text, txtPassword.Password)
                End If
                If Not txtPort.Text.Equals(String.Empty) Then
                    Integer.TryParse(txtPort.Text, SmtpServer.Port)
                End If
                SmtpServer.Host = txtSMTPServer.Text

                If ckbxSSL.IsChecked.Equals(True) Then
                    SmtpServer.EnableSsl = True
                Else
                    SmtpServer.EnableSsl = False
                End If
                Dim mail As New MailMessage()
                mail.To.Add(txtTestEmailTo.Text)
                mail.From = New MailAddress(txtFromEmail.Text, txtDisplayName.Text)
                mail.Subject = "Test mail from KKM SOFT iVault Tools"
                Dim htmlview As String
                htmlview = "This a  test mail sent from KKM SOFT iVault Tools to test Email Settings!" + vbNewLine + vbNewLine _
                                + "By" + vbNewLine + "Mail Intimation" + vbNewLine + vbNewLine _
                                + "This is an autogenerated Email. Kindly do not reply to this mail!" ' "<html><body><table border=2><tr width=100%><td><img src=cid:Logo alt=companyname /></td><td>MY COMPANY DESCRIPTION</td></tr></table><hr/></body></html>"
                mail.Body = htmlview

                mail.IsBodyHtml = False
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure
                mail.ReplyTo = New MailAddress(txtFromEmail.Text)
                SmtpServer.ServicePoint.MaxIdleTime = 1
                SmtpServer.Send(mail)
                mail.Dispose()
                Me.Cursor = Cursors.Arrow
                lblError.Content = "Test Mail Sent Successfully!"
                lblError.Foreground = New SolidColorBrush(Colors.Green)
            Catch ex As Exception
                Me.Cursor = Cursors.Arrow
                lblError.Content = "Test Mail Failed!"
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                MessageBox.Show("Failure Details:" + ex.ToString(), "Mail Intimation", Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Information)
            End Try
        End If


    End Sub

    Public Sub LoadSettings()
        Try
            If DownloadFile(_settingFileName, False) Then
                Dim tempXml As New XmlDocument
                tempXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)

                If tempXml IsNot Nothing Then

                    Dim xnNode As XmlNode

                    xnNode = tempXml.SelectSingleNode("Settings").SelectSingleNode("PublishSettings")
                    LoadPublishSettings(xnNode)

                    xnNode = tempXml.SelectSingleNode("Settings")
                    LoadEmailNotificationSettings(xnNode)
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub LoadEmailNotificationSettings(ByVal xnNode As XmlNode)
        Try
            If xnNode IsNot Nothing Then
                If xnNode.SelectSingleNode("EmailSettings") IsNot Nothing Then
                    dtEmailNotification.Rows.Clear()
                    For Each node As XmlNode In xnNode.SelectSingleNode("EmailSettings").ChildNodes()
                        dtEmailNotification.Rows.Add(node.Attributes("TransistionId").Value, node.InnerText)
                    Next
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub LoadPublishSettings(ByVal xnNode As XmlNode)
        Try
            If xnNode Is Nothing Then
                ' LoadInitialPublishOptions()
            Else
                If xnNode.SelectSingleNode("RootFolder") IsNot Nothing Then
                    txtRootFolder.Text = xnNode.SelectSingleNode("RootFolder").InnerText
                End If

                If xnNode.SelectSingleNode("RootFolderPDF") IsNot Nothing Then
                    txtRootFolderPDF.Text = xnNode.SelectSingleNode("RootFolderPDF").InnerText
                End If

            End If
        Catch ex As Exception

        End Try
        '  Me.DataContext = Me
    End Sub

    Private Sub btnSavePublishSettings_Click(sender As Object, e As RoutedEventArgs)
        Try
            ''Debugger.Launch()
            Dim xmlPath = _outputPath + _settingFileName
            Dim settingsXml As New XmlDocument

            Dim rootNode, parentNode, parentNodeEmail, childNodeUsers, childNode4, xmlnode As XmlNode

            Dim xa As XmlAttribute
            Dim temp = getFileIteration(_settingFileName, vConnection)

            If temp Is Nothing Then
                xmlnode = settingsXml.CreateXmlDeclaration("1.0", "UTF-8", Nothing)
                settingsXml.AppendChild(xmlnode)
                rootNode = settingsXml.CreateElement("Settings")
                parentNode = settingsXml.CreateElement("PublishSettings")
                rootNode.AppendChild(parentNode)
                parentNodeEmail = settingsXml.CreateElement("EmailSettings")
                rootNode.AppendChild(parentNodeEmail)
                settingsXml.AppendChild(rootNode)
            ElseIf temp.IsCheckedOut Then
                lblError.Content = "Settings file is checked out on " + temp.CheckedOutMachine + "! Kindly Try Again."
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                Exit Sub
            Else
                If DownloadFile(_settingFileName, True) Then
                    settingsXml = Encryption.ClsExtention.GetXmlData(_outputPath + _settingFileName)
                    rootNode = settingsXml.SelectSingleNode("Settings")

                    parentNode = settingsXml.SelectSingleNode("Settings").SelectSingleNode("PublishSettings")
                    If parentNode Is Nothing Then
                        parentNode = settingsXml.CreateElement("PublishSettings")
                        rootNode.AppendChild(parentNode)
                    End If

                    parentNodeEmail = settingsXml.SelectSingleNode("Settings").SelectSingleNode("EmailSettings")
                    If parentNodeEmail Is Nothing Then
                        parentNodeEmail = settingsXml.CreateElement("EmailSettings")
                        rootNode.AppendChild(parentNodeEmail)
                    Else
                        parentNodeEmail.RemoveAll()
                    End If
                Else
                    lblError.Content = "Unable to Update Settings File! Kindly Try Again"
                    lblError.Foreground = New SolidColorBrush(Colors.Red)
                    Exit Sub
                End If
            End If

            If (parentNode.SelectSingleNode("RootFolder") IsNot Nothing) Then
                parentNode.SelectSingleNode("RootFolder").InnerText = txtRootFolder.Text
            Else
                childNode4 = settingsXml.CreateElement("RootFolder")
                childNode4.InnerText = txtRootFolder.Text
                parentNode.AppendChild(childNode4)
            End If

            If (parentNode.SelectSingleNode("RootFolderPDF") IsNot Nothing) Then
                parentNode.SelectSingleNode("RootFolderPDF").InnerText = txtRootFolderPDF.Text
            Else
                childNode4 = settingsXml.CreateElement("RootFolderPDF")
                childNode4.InnerText = txtRootFolderPDF.Text
                parentNode.AppendChild(childNode4)
            End If
            For Each row As DataRow In dtEmailNotification.Rows
                childNodeUsers = settingsXml.CreateElement("Notification")
                xa = settingsXml.CreateAttribute("TransistionId")
                xa.Value = row("TransistionId")
                childNodeUsers.Attributes.Append(xa)
                childNodeUsers.InnerText = row("Users")
                parentNodeEmail.AppendChild(childNodeUsers)
            Next

            If System.IO.File.Exists(xmlPath) Then
                Dim oFileInfo As New IO.FileInfo(xmlPath)
                If (oFileInfo.Attributes And IO.FileAttributes.ReadOnly) > 0 Then
                    oFileInfo.Attributes = oFileInfo.Attributes Xor IO.FileAttributes.ReadOnly
                    System.IO.File.Delete(xmlPath)
                End If
            End If
            settingsXml = Encryption.ClsExtention.Encrypt(settingsXml)
            settingsXml.Save(xmlPath)
            If SaveSettingsInVault() Then
                LoadSettings()
                lblError.Content = "Publish Settings Saved Successfully!" '  Me.Close()
                lblError.Foreground = New SolidColorBrush(Colors.Green)
            Else
                lblError.Content = "Publish Settings Not Saved! Kindly Try Again"
                lblError.Foreground = New SolidColorBrush(Colors.Red)
            End If
        Catch ex As Exception
            lblError.Content = "Publish Settings Not Saved! Kindly Try Again"
            lblError.Foreground = New SolidColorBrush(Colors.Red)
        End Try
    End Sub

    Private Sub BtnExternalFolder_OnClick(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim folderDialog As New Forms.FolderBrowserDialog
        folderDialog.ShowDialog()
        If Not folderDialog.SelectedPath.Equals(String.Empty, StringComparison.InvariantCultureIgnoreCase) Then
            'txtExternalFolder.Text = folderDialog.SelectedPath.ToString()
        End If
    End Sub

    Private Sub cmbx_category_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
        Try

            Dim ListlifecyclesDefName As List(Of String) = New List(Of String)()

            If IsNothing(cmbx_category.SelectedItem) = False Then

                Dim selectedCategory As FileCatListItem = DirectCast(cmbx_category.SelectedItem, FileCatListItem)

                Dim catconf As CatCfg = vConnection.WebServiceManager.CategoryService.GetCategoryConfigurationById(selectedCategory.CatDef.Id, New String() {"LifeCycle"})

                If IsNothing(catconf.BhvCfgArray) = False Then

                    For Each itemBhvCfg As BhvCfg In catconf.BhvCfgArray

                        If IsNothing(itemBhvCfg.BhvArray) = False Then

                            For Each itemBhv As Bhv In itemBhvCfg.BhvArray

                                ListlifecyclesDefName.Add(itemBhv.DisplayName)

                            Next

                        End If
                    Next

                End If

            End If

            Dim lcDefs As LfCycDef() = Nothing
            Try
                ' get all the lifecycle information
                lcDefs = vConnection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions()

            Catch ex As Exception
                ' Show the error on the UI Thread
            End Try

            cmbx_lifeCylceDef.Items.Clear()

            If lcDefs IsNot Nothing Then
                For Each lcDef As LfCycDef In lcDefs
                    For Each lifecyclename As String In ListlifecyclesDefName
                        If lifecyclename = lcDef.DispName Then
                            cmbx_lifeCylceDef.Items.Add(New LfCycDefListItem(lcDef))
                        End If
                    Next
                Next
                If cmbx_lifeCylceDef.Items.Count > 0 Then
                    cmbx_lifeCylceDef.SelectedIndex = 0
                End If
            End If

            txt_FileJobs.Text = ""
            cmbx_FileTransition.Items.Clear()
            cmbx_FileState.Items.Clear()

            'lst_FileJobs.Items.Clear()
            'lst_FileTransition.Items.Clear()
            'lst_FileState.Items.Clear()
            ClearLstUsers()
            'm_jobTypesListBox.Items.Clear()
            If (m_idsToStates IsNot Nothing) Then
                m_idsToStates.Clear()
            End If

            m_currentThreadId = Guid.NewGuid()
            If IsNothing(cmbx_lifeCylceDef.SelectedItem) = False Then
                UpdateStatesWorker(m_currentThreadId, cmbx_lifeCylceDef.SelectedItem)
            End If
            If cmbx_FileState.Items.Count > 0 Then
                cmbx_FileState.SelectedIndex = 0
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmbx_lifeCylceDef_SelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles cmbx_lifeCylceDef.SelectionChanged
        Try
            ''Debugger.Launch()
            cmbx_FileState.Items.Clear()
            cmbx_FileTransition.Items.Clear()

            'lst_FileJobs.Items.Clear()
            'lst_FileTransition.Items.Clear()
            'lst_FileState.Items.Clear()

            ClearLstUsers()
            '  m_jobTypesListBox.Items.Clear()
            If (m_idsToStates IsNot Nothing) Then
                m_idsToStates.Clear()
            End If
            m_currentThreadId = Guid.NewGuid()
            UpdateStatesWorker(m_currentThreadId, cmbx_lifeCylceDef.SelectedItem)
            If cmbx_FileState.Items.Count > 0 Then
                cmbx_FileState.SelectedIndex = 0
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmbx_FileState_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
        If cmbx_FileState.SelectedItem IsNot Nothing Then
            cmbx_FileTransition.Items.Clear()
            txt_FileJobs.Text = ""
            'lst_FileTransition.Items.Clear()
            'lst_FileJobs.Items.Clear()
            '  m_jobTypesListBox.Items.Clear()
            ClearLstUsers()
            Dim lcDefItem As LfCycDefListItem = TryCast(cmbx_lifeCylceDef.SelectedItem, LfCycDefListItem)
            Dim stateItem As LfCycStateListItem = TryCast(cmbx_FileState.SelectedItem, LfCycStateListItem)

            Dim lcDef As LfCycDef = lcDefItem.LfCycDef
            Dim state As LfCycState = stateItem.LfCycState
            If lcDef IsNot Nothing AndAlso state IsNot Nothing Then
                Dim transitions As LfCycTrans() = lcDef.TransArray
                If transitions Is Nothing OrElse transitions.Length = 0 Then
                    Return
                End If

                ' pass 1: going from the selected state
                For Each transition As LfCycTrans In transitions
                    If transition.FromId = state.Id Then
                        Dim transItem As New LfCycTransListItem(transition)
                        transItem.DispName = state.DispName + " -> " + m_idsToStates(transition.ToId).DispName
                        cmbx_FileTransition.Items.Add(transItem)
                        'lst_FileTransition.Items.Add(transItem)
                    End If
                Next

                ' pass 2: going to the selected state
                For Each transition As LfCycTrans In transitions
                    If transition.ToId = state.Id Then
                        Dim transItem As New LfCycTransListItem(transition)
                        transItem.DispName = state.DispName + " <- " + m_idsToStates(transition.FromId).DispName
                        cmbx_FileTransition.Items.Add(transItem)
                        'lst_FileTransition.Items.Add(transItem)
                    End If
                Next

                If cmbx_FileTransition.Items.Count > 0 Then
                    cmbx_FileTransition.SelectedIndex = 0
                End If

            End If
        End If
    End Sub

    Private Sub cmbx_FileTransition_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
        ''Debugger.Launch()
        If cmbx_FileTransition.SelectedItem IsNot Nothing Then
            Dim transition As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
            'lst_FileJobs.Items.Clear()
            txt_FileJobs.Text = ""
            ClearLstUsers()
            If transition Is Nothing OrElse transition.LfCycTrans Is Nothing Then
                Return
            End If
            lstSelectedUsers.ItemsSource = Nothing
            lstSelectedUsers.UpdateLayout()
            If m_transIdsToEvents.ContainsKey(transition.LfCycTrans.Id) Then
                Dim jobArray As StringArray = m_transIdsToEvents(transition.LfCycTrans.Id)

                If jobArray IsNot Nothing AndAlso jobArray.Items IsNot Nothing Then
                    For Each job As String In jobArray.Items
                        'lst_FileJobs.Items.Add(job)
                        txt_FileJobs.Text = job
                        If job.Equals("KKMMailIntimationJobProcessorTool.EmailNotification.OnStateChange") Then
                            '' lstUsers.IsEnabled = True
                            Dim listofselectedusers As List(Of SelectedUsers) = New List(Of SelectedUsers)()
                            Dim int As Integer = 1
                            For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.LfCycTrans.Id & "'")
                                ''lstUsers.Items.Add(row(1).ToString())
                                Dim objSelectedUsers As SelectedUsers = New SelectedUsers()
                                objSelectedUsers.usercount = int
                                objSelectedUsers.username = row(1).ToString()
                                Try
                                    Dim _userinfo As User = Nothing
                                    _userinfo = (From _user As User In vUsers
                                                 Where _user.Name.Equals(row(1).ToString())
                                                 Select _user).FirstOrDefault()
                                    If Not IsNothing(_userinfo) Then
                                        objSelectedUsers.useremail = _userinfo.Email
                                        objSelectedUsers.userfirstname = _userinfo.FirstName + " " + _userinfo.LastName
                                    Else
                                        objSelectedUsers.useremail = ""
                                        objSelectedUsers.userfirstname = ""
                                    End If
                                Catch ex As Exception
                                    objSelectedUsers.useremail = ""
                                    objSelectedUsers.userfirstname = ""
                                End Try
                                listofselectedusers.Add(objSelectedUsers)
                                int += 1
                            Next
                            lstSelectedUsers.ItemsSource = listofselectedusers
                            lstSelectedUsers.UpdateLayout()
                        Else
                            ''lstUsers.IsEnabled = False
                        End If
                    Next
                End If
            End If
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As RoutedEventArgs)
        Me.Close()
    End Sub

    Private Sub btnAddJob_Click(sender As Object, e As RoutedEventArgs)

        If Not IsNothing(cmbx_FileTransition.SelectedItem) Then
            _jobType = String.Empty
            _jobType = "KKMMailIntimationJobProcessorTool.EmailNotification.OnStateChange"
            AddJobEvent()
            CommitChanges()
        End If

        'Dim obj As UI_UserSelection = New UI_UserSelection(vUsers, vGroups, vGroupInfo)

        'If _jobType IsNot String.Empty And Not txt_FileJobs.Text.Contains(_jobType) Then
        '    obj.Owner = Me
        '    obj.ShowDialog()
        '    If obj.dg.Equals(True) Then
        '        Dim transitionItem As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
        '        If transitionItem Is Nothing Then
        '            Return
        '        End If
        '        Dim transition As LfCycTrans = transitionItem.LfCycTrans
        '        If obj.lstSelectedUsers.Items.Count > 0 Then
        '            lstUsers.IsEnabled = True
        '            txtRootFolder.IsEnabled = False
        '            txtRootFolderPDF.IsEnabled = False
        '            For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.Id & "'")
        '                dtEmailNotification.Rows.Remove(row)
        '            Next
        '            lstUsers.Items.Clear()
        '            For Each Str As String In obj.lstSelectedUsers.Items
        '                lstUsers.Items.Add(Str)
        '                dtEmailNotification.Rows.Add(New String() {transition.Id, Str})
        '            Next
        '            AddJobEvent()
        '            CommitChanges()
        '        End If
        '    Else
        '        lblError.Foreground = New SolidColorBrush(Colors.Red)
        '        lblError.Content = "Email Notification job is not configured since users are not selected for Email Notification!"
        '    End If
        'End If

    End Sub

    Private Sub btnRemoveJob_Click(sender As Object, e As RoutedEventArgs)
        DeleteJobEvent()
        CommitChanges()
    End Sub

    Private Sub btnAddUsers_Click(sender As Object, e As RoutedEventArgs)
        ''Debugger.Launch()
        If txt_FileJobs.Text.Contains(_jobType) AndAlso txt_FileJobs.Text <> "" Then
            Dim obj As UI_UserSelection = New UI_UserSelection(vUsers, vGroups, vGroupInfo)
            obj.Owner = Me
            obj.ShowDialog()
            If obj.dg.Equals(True) Then
                Dim transitionItem As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
                If transitionItem Is Nothing Then
                    Return
                End If
                Dim transition As LfCycTrans = transitionItem.LfCycTrans
                If obj.lstSelectedUsers.Items.Count > 0 Then
                    ''lstUsers.IsEnabled = True
                    txtRootFolder.IsEnabled = False
                    txtRootFolderPDF.IsEnabled = False
                    Dim listofexistingusers As List(Of String) = New List(Of String)()
                    For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.Id & "'")
                        '' Debugger.Launch()
                        listofexistingusers.Add(row.ItemArray(1).ToString())
                        dtEmailNotification.Rows.Remove(row)
                    Next
                    lstSelectedUsers.ItemsSource = Nothing
                    lstSelectedUsers.UpdateLayout()

                    Dim vUsers() = vConnection.WebServiceManager.AdminService.GetAllUsers()

                    Dim listofselectedusers As List(Of SelectedUsers) = New List(Of SelectedUsers)()
                    Dim int As Integer = 1

                    For Each itemstr As String In listofexistingusers
                        Dim objSelectedUsers As SelectedUsers = New SelectedUsers()
                        objSelectedUsers.usercount = int
                        objSelectedUsers.username = itemstr
                        Try
                            Dim _userinfo As User = Nothing
                            _userinfo = (From _user As User In vUsers
                                         Where _user.Name.Equals(itemstr)
                                         Select _user).FirstOrDefault()
                            If Not IsNothing(_userinfo) Then
                                objSelectedUsers.useremail = _userinfo.Email
                                objSelectedUsers.userfirstname = _userinfo.FirstName + " " + _userinfo.LastName
                            Else
                                objSelectedUsers.useremail = ""
                                objSelectedUsers.userfirstname = ""
                            End If
                        Catch ex As Exception
                            objSelectedUsers.useremail = ""
                            objSelectedUsers.userfirstname = ""
                        End Try
                        listofselectedusers.Add(objSelectedUsers)
                        int += 1
                        dtEmailNotification.Rows.Add(New String() {transition.Id, itemstr})
                    Next

                    For Each Str As String In obj.lstSelectedUsers.Items
                        If Not listofexistingusers.Contains(Str) Then
                            Dim objSelectedUsers As SelectedUsers = New SelectedUsers()
                            objSelectedUsers.usercount = int
                            objSelectedUsers.username = Str
                            Try
                                Dim _userinfo As User = Nothing
                                _userinfo = (From _user As User In vUsers
                                             Where _user.Name.Equals(Str)
                                             Select _user).FirstOrDefault()
                                If Not IsNothing(_userinfo) Then
                                    objSelectedUsers.useremail = _userinfo.Email
                                    objSelectedUsers.userfirstname = _userinfo.FirstName + " " + _userinfo.LastName
                                Else
                                    objSelectedUsers.useremail = ""
                                    objSelectedUsers.userfirstname = ""
                                End If
                            Catch ex As Exception
                                objSelectedUsers.useremail = ""
                                objSelectedUsers.userfirstname = ""
                            End Try

                            listofselectedusers.Add(objSelectedUsers)
                            int += 1
                            dtEmailNotification.Rows.Add(New String() {transition.Id, Str})
                        End If
                    Next

                    lstSelectedUsers.ItemsSource = listofselectedusers
                    lstSelectedUsers.UpdateLayout()

                    AddJobEvent()
                    CommitChanges()
                End If
            Else
                lblError.Foreground = New SolidColorBrush(Colors.Red)
                lblError.Content = "Email Notification job is not configured since users are not selected for Email Notification!"
            End If
        End If
    End Sub

    Private Sub btnRemoveUsers_Click(sender As Object, e As RoutedEventArgs)
        ''Debugger.Launch()
        If lstSelectedUsers.SelectedItems.Count > 0 Then
            Try
                Dim transitionItem As LfCycTransListItem = TryCast(cmbx_FileTransition.SelectedItem, LfCycTransListItem)
                If transitionItem Is Nothing Then
                    Return
                End If

                Dim transition As LfCycTrans = transitionItem.LfCycTrans
                txtRootFolder.IsEnabled = False
                txtRootFolderPDF.IsEnabled = False

                Dim listofRemoveusers As List(Of SelectedUsers) = New List(Of SelectedUsers)()
                For Each itemstr As Object In lstSelectedUsers.SelectedItems
                    Dim objSelectedUsers As SelectedUsers = DirectCast(itemstr, SelectedUsers)
                    listofRemoveusers.Add(objSelectedUsers)
                Next

                Dim listofSelectedusers As List(Of SelectedUsers) = New List(Of SelectedUsers)()
                For Each itemstr As Object In lstSelectedUsers.Items
                    Dim objSelectedUsers As SelectedUsers = DirectCast(itemstr, SelectedUsers)
                    listofSelectedusers.Add(objSelectedUsers)
                Next

                For Each itemstr As SelectedUsers In listofRemoveusers
                    listofSelectedusers.Remove(itemstr)
                Next

                For Each row As DataRow In dtEmailNotification.Select("TransistionId = '" & transition.Id & "'")
                    dtEmailNotification.Rows.Remove(row)
                Next

                For Each item As SelectedUsers In listofSelectedusers
                    dtEmailNotification.Rows.Add(New String() {transition.Id, item.username})
                Next

                lstSelectedUsers.ItemsSource = listofSelectedusers
                lstSelectedUsers.UpdateLayout()

                AddJobEvent()
                CommitChanges()

            Catch ex As Exception

            End Try

        Else
            MessageBox.Show("Select users to remove..!", "Mail Intimation", Forms.MessageBoxButtons.OK, Forms.MessageBoxIcon.Information)
        End If

    End Sub

End Class

Public Class SelectedUsers
    Implements INotifyPropertyChanged

    Public Event PropertyChanged As PropertyChangedEventHandler _
        Implements INotifyPropertyChanged.PropertyChanged

    ' This method is called by the Set accessor of each property.
    ' The CallerMemberName attribute that is applied to the optional propertyName
    ' parameter causes the property name of the caller to be substituted as an argument.
    Private Sub NotifyPropertyChanged(Optional ByVal propertyName As String = Nothing)
        RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
    End Sub

    Private musercount As Integer
    Public Property usercount() As Integer
        Get
            Return musercount
        End Get
        Set(ByVal value As Integer)
            musercount = value
        End Set
    End Property

    Private musername As String
    Public Property username() As String
        Get
            Return musername
        End Get
        Set(ByVal value As String)
            musername = value
        End Set
    End Property

    Private muserfirstname As String
    Public Property userfirstname() As String
        Get
            Return muserfirstname
        End Get
        Set(ByVal value As String)
            muserfirstname = value
        End Set
    End Property

    Private museremail As String
    Public Property useremail() As String
        Get
            Return museremail
        End Get
        Set(ByVal value As String)
            museremail = value
        End Set
    End Property

End Class








