﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsHYDClampSubTypes : ObservableCollection<NameCodePair>
    {
        public static SupportsHYDClampSubTypes LoadList()
        {
            SupportsHYDClampSubTypes items = new SupportsHYDClampSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "WELD PLATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "MOUNTING RAIL KIT" });
            items.Add(new NameCodePair() { Code = "03", Name = "STACKED ASSEMBLY" });
            return items;
        }
        public static SupportsHYDClampSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsHYDClampSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsHYDClampSubTypes>(EngineeringItems.DataPath + @"\Supports\SupportsHYDClampSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsHYDClampSubTypes>(this, EngineeringItems.DataPath + @"\Supports\SupportsHYDClampSubTypes.xml");
        }

    }
}
