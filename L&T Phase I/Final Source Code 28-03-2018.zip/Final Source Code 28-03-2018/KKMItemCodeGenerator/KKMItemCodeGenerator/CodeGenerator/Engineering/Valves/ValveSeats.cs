﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveSeats : ObservableCollection<NameCodePair>
    {
        public static ValveSeats LoadList()
        {
            ValveSeats items = new ValveSeats();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "PTFE" });
            items.Add(new NameCodePair() { Code = "02", Name = "GRAPHITE" });
            items.Add(new NameCodePair() { Code = "03", Name = "VITON" });
            items.Add(new NameCodePair() { Code = "04", Name = "NBR" });
            items.Add(new NameCodePair() { Code = "05", Name = "EPDM" });
            items.Add(new NameCodePair() { Code = "06", Name = "RUBBER" });
            items.Add(new NameCodePair() { Code = "07", Name = "ZINC FREE" });
            items.Add(new NameCodePair() { Code = "08", Name = "STAINLESS STEEL" });
            items.Add(new NameCodePair() { Code = "09", Name = "BRONZE" });
            items.Add(new NameCodePair() { Code = "10", Name = "TEFLON" });
            items.Add(new NameCodePair() { Code = "11", Name = "FPM" });
            return items;
        }
        public static ValveSeats LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveSeats LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveSeats>(EngineeringItems.DataPath + @"\Valves\ValveSeats.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveSeats>(this, EngineeringItems.DataPath + @"\Valves\ValveSeats.xml");
        }

    }
}
