﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsHOThicknesses : ObservableCollection<NameCodePair>
    {
        public static BarsHOThicknesses LoadList()
        {
            BarsHOThicknesses items = new BarsHOThicknesses();
            items.Add(new NameCodePair() { Code = "00", Name = "FOR SQUARE BAR" });
            items.Add(new NameCodePair() { Code = "00", Name = "FOR HALF ROUND BAR" });
            items.Add(new NameCodePair() { Code = "00", Name = "FOR ROUND BAR" });
            items.Add(new NameCodePair() { Code = "04", Name = "4 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "5 mm" });

            return items;
        }
        public static BarsHOThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsHOThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsHOThicknesses>(HullOutfitItems.DataPath + @"\Bars\BarsHOThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsHOThicknesses>(this, HullOutfitItems.DataPath + @"\Bars\BarsHOThicknesses.xml");
        }
    }
}
