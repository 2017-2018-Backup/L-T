﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingClassSociety : ObservableCollection<NameCodePair>
    {
        public static PipeFittingClassSociety LoadList()
        {
            PipeFittingClassSociety items = new PipeFittingClassSociety();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Non IACS" });
            items.Add(new NameCodePair() { Code = "B", Name = "IACS" });
            return items;
        }
        public static PipeFittingClassSociety LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingClassSociety LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingClassSociety>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingClassSociety.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingClassSociety>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingClassSociety.xml");
        }

    }
}
