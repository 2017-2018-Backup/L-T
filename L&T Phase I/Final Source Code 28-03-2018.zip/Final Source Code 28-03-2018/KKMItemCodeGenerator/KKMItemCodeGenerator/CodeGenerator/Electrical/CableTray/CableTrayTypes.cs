﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTrayTypes : ObservableCollection<NameCodePair>
    {
        public static CableTrayTypes LoadList()
        {
            CableTrayTypes items = new CableTrayTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "LADDER" });
            items.Add(new NameCodePair() { Code = "02", Name = "PERFORATED" });
            items.Add(new NameCodePair() { Code = "03", Name = "Z TYPE" });

            return items;
        }
        public static CableTrayTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTrayTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTrayTypes>(ElectricalItems.DataPath + @"\CableTray\CableTrayTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath + @"\CableTray"))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath + @"\CableTray");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTrayTypes>(this, ElectricalItems.DataPath + @"\CableTray\CableTrayTypes.xml");
        }

    }
}
