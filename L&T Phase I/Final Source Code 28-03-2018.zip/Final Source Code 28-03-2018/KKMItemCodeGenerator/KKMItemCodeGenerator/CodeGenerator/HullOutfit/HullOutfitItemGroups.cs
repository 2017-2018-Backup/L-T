﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ItemGroups : ObservableCollection<NameCodePair>
    {
        public static ItemGroups LoadList()
        {
            ItemGroups items = new ItemGroups();
            items.Add(new NameCodePair() { Code = "STS", Name = "Steel & Structural Items" });
            items.Add(new NameCodePair() { Code = "FST", Name = "Fasteners" });
            items.Add(new NameCodePair() { Code = "ACI", Name = "Access Items-Doors,hatches,etc" });
            items.Add(new NameCodePair() { Code = "DOE", Name = "Deck M/C & Outfitting Eqpt." });
            items.Add(new NameCodePair() { Code = "LSA", Name = "Life saving appliances" });
            items.Add(new NameCodePair() { Code = "FFA", Name = "Fire Fighting appliances" });
            items.Add(new NameCodePair() { Code = "NCE", Name = "Navigaton & Communication Eqpt" });
            items.Add(new NameCodePair() { Code = "AUI", Name = "Automation & Instrumentation" });
            items.Add(new NameCodePair() { Code = "VAS", Name = "Valves, Armatures & Supports" });
            items.Add(new NameCodePair() { Code = "ELE", Name = "Electrical Items" });
            items.Add(new NameCodePair() { Code = "PIP", Name = "Pipes" });
            items.Add(new NameCodePair() { Code = "PIF", Name = "Pipe Fittings" });
            items.Add(new NameCodePair() { Code = "PCT", Name = "Paints, Chemicals,Varnishes & Thinners" });
            items.Add(new NameCodePair() { Code = "OIL", Name = "Oils, Lubricants & Coolants" });
            items.Add(new NameCodePair() { Code = "ECT", Name = "Electrical Cables & Trays" });
            items.Add(new NameCodePair() { Code = "SAC", Name = "Ship Accomodation items" });
            items.Add(new NameCodePair() { Code = "SPE", Name = "Special Equipments" });
            items.Add(new NameCodePair() { Code = "RIG", Name = "Rigging Items" });
            items.Add(new NameCodePair() { Code = "GEC", Name = "General Consumables" });
            items.Add(new NameCodePair() { Code = "SAF", Name = "Safety Items" });
            items.Add(new NameCodePair() { Code = "WCA", Name = "Welding Consumables & Accessories" });
            items.Add(new NameCodePair() { Code = "OST", Name = "Office Stationery Items" });
            items.Add(new NameCodePair() { Code = "FUR", Name = "Furniture" });
            items.Add(new NameCodePair() { Code = "TIM", Name = "Timber items" });
            items.Add(new NameCodePair() { Code = "PAC", Name = "Painting Consumables" });
            items.Add(new NameCodePair() { Code = "MAI", Name = "Maintenanace Items" });
            items.Add(new NameCodePair() { Code = "GAS", Name = "Gases" });
            items.Add(new NameCodePair() { Code = "TAB", Name = "Tools& Abrasives" });
            items.Add(new NameCodePair() { Code = "ADS", Name = "Adhesives & Sealants" });
            items.Add(new NameCodePair() { Code = "MEQ", Name = "Mechnaical Equipments" });
            items.Add(new NameCodePair() { Code = "ACV", Name = "AC & Ventilation items" });
            items.Add(new NameCodePair() { Code = "CAN", Name = "Canteen Items" });
            items.Add(new NameCodePair() { Code = "VEH", Name = "Motor Vehicles & Accessories" });
            items.Add(new NameCodePair() { Code = "MIS", Name = "Miscellaneous Items" });
            items.Add(new NameCodePair() { Code = "COM", Name = "Computer Items" });
            items.Add(new NameCodePair() { Code = "INP", Name = "Insulation & Protection" });
            items.Add(new NameCodePair() { Code = "PMM", Name = "" });
            items.Add(new NameCodePair() { Code = "WRE", Name = "Weapon related equipment" });
            items.Add(new NameCodePair() { Code = "STR", Name = "Steel Profiles" });

            return items;
        }
        public static ItemGroups LoadFromExcel(String path)
        {
            return null;
        }

        public static ItemGroups LoadFromXml(String dataPath)
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ItemGroups>(dataPath + @"\HulloutfitItemGroups.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ItemGroups>(this, path + @"\HulloutfitItemGroups.xml");
        }
    }
}
