﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveReferences : ObservableCollection<NameCodePair>
    {
        public static ValveReferences LoadList()
        {
            ValveReferences items = new ValveReferences();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });

            return items;
        }
        public static ValveReferences LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveReferences LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveReferences>(EngineeringItems.DataPath + @"\Valves\ValveReferences.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveReferences>(this, EngineeringItems.DataPath + @"\Valves\ValveReferences.xml");
        }

    }
}
