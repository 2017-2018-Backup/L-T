﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWFittingStandards : ObservableCollection<NameCodePair>
    {
        public static BWFittingStandards LoadList()
        {
            BWFittingStandards items = new BWFittingStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ANSI B16.28" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANSI B16.9" });
            items.Add(new NameCodePair() { Code = "03", Name = "IS 1239" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 86088" });
            items.Add(new NameCodePair() { Code = "05", Name = "EN10253" });
            items.Add(new NameCodePair() { Code = "06", Name = "DIN 86090" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASME B16.5" });
            items.Add(new NameCodePair() { Code = "08", Name = "DIN 86089" });
            items.Add(new NameCodePair() { Code = "09", Name = "DIN 2553" });
            return items;
        }
        public static BWFittingStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static BWFittingStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWFittingStandards>(EngineeringItems.DataPath + @"\FittingsBW\BWFittingStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWFittingStandards>(this, EngineeringItems.DataPath + @"\FittingsBW\BWFittingStandards.xml");
        }

    }
}
