﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersFilterGauges : ObservableCollection<NameCodePair>
    {
        public static StrainersFilterGauges LoadList()
        {
            StrainersFilterGauges items = new StrainersFilterGauges();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "STAINLESS STEEL SS316" });
            items.Add(new NameCodePair() { Code = "02", Name = "STAINLESS STEEL SS304" });
            items.Add(new NameCodePair() { Code = "03", Name = "GUN METAL" });
            items.Add(new NameCodePair() { Code = "04", Name = "STAINLESS STEEL SS316L" });
            items.Add(new NameCodePair() { Code = "05", Name = "HOT DIP GALVANIZED STEEL" });
            return items;
        }
        public static StrainersFilterGauges LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersFilterGauges LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersFilterGauges>(EngineeringItems.DataPath + @"\Strainers\StrainersFilterGauges.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersFilterGauges>(this, EngineeringItems.DataPath + @"\Strainers\StrainersFilterGauges.xml");
        }

    }
}
