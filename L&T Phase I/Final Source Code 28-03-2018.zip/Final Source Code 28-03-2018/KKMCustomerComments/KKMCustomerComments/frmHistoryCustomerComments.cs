﻿using KKMCustomerComment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using excel = Microsoft.Office.Interop.Excel;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace KKMCustomerComments
{
    public partial class frmHistoryCustomerComments : Form
    {
        int CustomerCommentNo = 1;
        bool IsVersionUpdate = false;
        string selectedVer = "";
        Dictionary<string, List<int>> CollectionRevandVerions = new Dictionary<string, List<int>> { };
        SingleCustomerCommentsummary objVersionSingleCustomerCommentsummary = null;

        public object MessageBoxImage { get; private set; }

        public frmHistoryCustomerComments()
        {
            InitializeComponent();
        }

        public frmHistoryCustomerComments(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
        }

        private void AddProjectFolderItem(AutoCompleteStringCollection ProjectFolderCollection)
        {
            try
            {
                // check for any sub Folders.
                VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.Category.Name.ToUpper() == "PROJECT")
                        {
                            ProjectFolderCollection.Add(folder.EntityName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void frmHistoryCustomerComment_Load(object sender, EventArgs e)
        {
            objVersionSingleCustomerCommentsummary = clsStaticGlobal.objSingleCustomerCommentsummary;

            lstviewCustomerRelatedDocuments.View = View.List;

            lstviewLandTRelatedDocuments.View = View.List;

            txtCustomerCustomerCommentNumber.ReadOnly = true;

            CollectionRevandVerions = clsStaticGlobal.GetFileRevisionwithVersions(objVersionSingleCustomerCommentsummary.CustomerCommentFileFullPath);

            string SelectedRev = "";

            foreach (var item in CollectionRevandVerions)
            {
                cmbRevisionVersion.Items.Add(item.Key);
                SelectedRev = item.Key;
            }
            if (SelectedRev != "")
            {
                cmbRevisionVersion.SelectedItem = SelectedRev;
            }

            foreach (string item in clsStaticGlobal.GetAllUserList())
            {
                cmbCustomerCommentResponsiblePerson.Items.Add(item);
            }

            try
            {
                VersionsAssignToControl(objVersionSingleCustomerCommentsummary);
                selectedVer = objVersionSingleCustomerCommentsummary.CustomerCommentLatestVersion;
                IsVersionUpdate = false;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool IsCustomerCommentNameExist(string _filename, string _CommentName)
        {
            bool IsExist = false;
            try
            {
                foreach (SingleCustomerCommentsummary item in clsStaticGlobal.objSingleCustomerCommentCollection.collectionCustomerComment)
                {
                    if ((item.CustomerCommentFileName == _filename) || (item.CustomerCustomerCommentNumber == _CommentName))
                    {
                        IsExist = true;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return IsExist;
        }

        private void AssignToObject()
        {
            try
            {
                objVersionSingleCustomerCommentsummary.CustomerCustomerCommentNumber = txtCustomerCustomerCommentNumber.Text.Trim();

                objVersionSingleCustomerCommentsummary.CustomerCommentFileName = "PDC_" + objVersionSingleCustomerCommentsummary.CustomerCustomerCommentNumber + ".xml";
                objVersionSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";
                objVersionSingleCustomerCommentsummary.CustomerCommentLatestVersion = "1";

                objVersionSingleCustomerCommentsummary.CustomerCommentNumber = CustomerCommentNo;
                objVersionSingleCustomerCommentsummary.CustomerCommentProjectCode = txtCustomerCommentProjectCode.Text;
                objVersionSingleCustomerCommentsummary.CustomerCustomerCommentNumber = txtCustomerCustomerCommentNumber.Text;
                objVersionSingleCustomerCommentsummary.CustomerCommentsystem = txtCustomerCommentsystem.Text;
                objVersionSingleCustomerCommentsummary.CustomerCustomerComment = txtCustomerCustomerComment.Text;

                if (cmbCustomerCommentResponsiblePerson.SelectedItem != null)
                {
                    objVersionSingleCustomerCommentsummary.CustomerCommentResponsiblePerson = cmbCustomerCommentResponsiblePerson.SelectedItem.ToString();
                }

                if (cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem != null)
                {
                    objVersionSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer = cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem.ToString();
                }

                objVersionSingleCustomerCommentsummary.CustomerCommentCloserDate = dtpCustomerCommentCloserDate.Text;
                objVersionSingleCustomerCommentsummary.CustomerCommentLandTComment = txtCustomerCommentLandTComment.Text;
                objVersionSingleCustomerCommentsummary.CustomerCommentTimeImplications = txtCustomerCommentTimeImplications.Text;
                objVersionSingleCustomerCommentsummary.CustomerCommentCostImplications = txtCustomerCommentCostImplications.Text;

                objVersionSingleCustomerCommentsummary.CustomerCommentRemark = txtCustomerCommentRemark.Text;

                string _CustomerRelatedDocuments = "";
                if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        if (_CustomerRelatedDocuments.Trim() == "")
                        {
                            _CustomerRelatedDocuments = item.FileName;
                        }
                        else
                        {
                            _CustomerRelatedDocuments = _CustomerRelatedDocuments + "," + Environment.NewLine + item.FileName;
                        }
                    }
                }
                objVersionSingleCustomerCommentsummary.CustomerCommentCustomerRelatedDocuments = _CustomerRelatedDocuments;

                string _LandTRelatedDocuments = "";

                if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        if (_LandTRelatedDocuments.Trim() == "")
                        {
                            _LandTRelatedDocuments = item.FileName;
                        }
                        else
                        {
                            _LandTRelatedDocuments = _LandTRelatedDocuments + "," + Environment.NewLine + item.FileName;
                        }
                    }
                }
                objVersionSingleCustomerCommentsummary.CustomerCommentLandTRelatedDocuments = _LandTRelatedDocuments;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void AssignToControl(SingleCustomerCommentsummary _SingleCustomerCommentsummary)
        {
            try
            {
                txtCustomerCommentProjectCode.Text = _SingleCustomerCommentsummary.CustomerCommentProjectCode;
                txtCustomerCustomerCommentNumber.Text = _SingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                txtCustomerCustomerComment.Text = _SingleCustomerCommentsummary.CustomerCustomerComment;

                if (_SingleCustomerCommentsummary.CustomerCommentHistoryVersions.Count > 0)
                {
                    if (cmbHistoryVersion.Items.Count > 0)
                    {
                        cmbHistoryVersion.Items.Clear();
                    }
                    foreach (int item in _SingleCustomerCommentsummary.CustomerCommentHistoryVersions)
                    {
                        cmbHistoryVersion.Items.Add(item.ToString());
                        cmbHistoryVersion.Refresh();
                    }

                    if (_SingleCustomerCommentsummary.CustomerCommentLatestVersion != "")
                    {
                        cmbHistoryVersion.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentLatestVersion;
                        cmbHistoryVersion.SelectedText = _SingleCustomerCommentsummary.CustomerCommentLatestVersion;
                    }
                }

                if (_SingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in _SingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewCustomerRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentsystem.Text = _SingleCustomerCommentsummary.CustomerCommentsystem;

                if ((_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != "") || (_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != null))
                {
                    cmbCustomerCommentResponsiblePerson.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                    cmbCustomerCommentResponsiblePerson.Text = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                }

                dtpCustomerCommentCloserDate.Text = _SingleCustomerCommentsummary.CustomerCommentCloserDate;
                txtCustomerCommentLandTComment.Text = _SingleCustomerCommentsummary.CustomerCommentLandTComment;

                txtLifecycleState.Text = _SingleCustomerCommentsummary.CustomerCommentLifeCycle;

                if (_SingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in _SingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewLandTRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentTimeImplications.Text = _SingleCustomerCommentsummary.CustomerCommentTimeImplications;
                txtCustomerCommentCostImplications.Text = _SingleCustomerCommentsummary.CustomerCommentCostImplications;

                if ((_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != "") || (_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != null))
                {
                    cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                    cmbCustomerCommentFindAcceptanceFromCustomer.Text = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                }


                txtCustomerCommentRemark.Text = _SingleCustomerCommentsummary.CustomerCommentRemark;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidateField()
        {
            bool isvalid = true;

            if (txtCustomerCommentProjectCode.Text.Trim() == "")
            {
                errorProvider1.SetError(txtCustomerCommentProjectCode, "Enter project number");
                isvalid = false;
            }
            else
            {
                errorProvider1.Clear();
            }

            return isvalid;
        }

        private void txtIssueNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void btnLandTRelatedDocuments_Click(object sender, EventArgs e)
        {
            try
            {
                clsStaticGlobal.RelatedDocByLandTFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.VaultCustomerLandTFolder.FolderPath);
                clsStaticGlobal.PrintLandTRelatedDocumentFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                UserControlRelatedDocByLandT objfrmLandTRelevantDocument = new UserControlRelatedDocByLandT(false);
                objfrmLandTRelevantDocument.ShowDialog();

                if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        try
                        {
                            lstviewLandTRelatedDocuments.Items.Clear();
                        }
                        catch (Exception)
                        {

                        }
                    }
                    foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewLandTRelatedDocuments.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void btnCustomerRelatedDocuments_Click(object sender, EventArgs e)
        {
            try
            {
                clsStaticGlobal.RelevantDocByCustomerFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.VaultCustomerCustomerFolder.FolderPath);
                clsStaticGlobal.PrintCustomerRelevantDocumentsFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                UserControlRelevantDocByCustomer objfrmRelevantDocByCustomer = new UserControlRelevantDocByCustomer(false);
                objfrmRelevantDocByCustomer.ShowDialog();


                if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        try
                        {
                            lstviewCustomerRelatedDocuments.Items.Clear();
                        }
                        catch (Exception)
                        {

                        }
                    }
                    foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewCustomerRelatedDocuments.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void btnApplyHistoryVersion_Click(object sender, EventArgs e)
        {
            if (cmbHistoryVersion.SelectedItem != null)
            {
                try
                {
                    int selectedVersion = int.Parse(cmbHistoryVersion.SelectedItem.ToString());
                    IsVersionUpdate = false;
                    selectedVer = selectedVersion.ToString();
                    Autodesk.Connectivity.WebServices.File[] SingleFile;
                    Autodesk.Connectivity.WebServices.File _LatestFileswithVersions = null;

                    SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { objVersionSingleCustomerCommentsummary.CustomerCommentFileFullPath });
                    if (SingleFile.Length != 0)
                    {
                        _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFileByVersion(SingleFile[0].MasterId, selectedVersion);
                    }

                    try
                    {
                        if (_LatestFileswithVersions != null)
                        {
                            clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");

                            if (!Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions"))
                            {
                                Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            }
                            else
                            {
                                clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            }

                            VDF.Vault.Currency.Entities.FileIteration fileIter = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, _LatestFileswithVersions);
                            VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                            settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions");
                            settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                            VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                            try
                            {
                                XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                                objVersionSingleCustomerCommentsummary = new SingleCustomerCommentsummary();
                                string[] filePaths = Directory.GetFiles(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\Versions", "*.xml", SearchOption.TopDirectoryOnly);
                                foreach (string _filepath in filePaths)
                                {
                                    using (var sr = new StreamReader(_filepath))
                                    {
                                        objVersionSingleCustomerCommentsummary = (SingleCustomerCommentsummary)xs.Deserialize(sr);
                                    }
                                    if (objVersionSingleCustomerCommentsummary != null)
                                    {
                                        //string _Poststatus = "";
                                        //string _Postremark = "";
                                        //string _Postrevision = "";
                                        //clsStaticGlobal.GetValutFileStatusAndRemarkAndRevisionByFileID(_LatestFileswithVersions.Id, out _Poststatus, out _Postremark, out _Postrevision);
                                        objVersionSingleCustomerCommentsummary.CustomerCommentLifeCycle = _LatestFileswithVersions.FileLfCyc.LfCycStateName;
                                        objVersionSingleCustomerCommentsummary.CustomerCommentRemark = _LatestFileswithVersions.Comm;

                                        if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                                        {
                                            foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                                            {
                                                string _status = "";
                                                string _remark = "";
                                                string _revision = "";
                                                clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                                item.FileStatus = _status;
                                                item.FileRemark = _remark;
                                                item.FileRevision = _revision;
                                            }
                                        }

                                        if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                                        {
                                            foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                                            {
                                                string _status = "";
                                                string _remark = "";
                                                string _revision = "";
                                                clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                                                item.FileStatus = _status;
                                                item.FileRemark = _remark;
                                                item.FileRevision = _revision;
                                            }
                                        }
                                    }
                                }

                                VersionsAssignToControl(objVersionSingleCustomerCommentsummary);

                                System.Windows.Forms.MessageBox.Show("Selected version data uploaded successfully..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                clsStaticGlobal.ErrHandlerLog(ex);
                                System.Windows.Forms.MessageBox.Show("Unable to read Customer Comment file version..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Unable to get selected Customer Comment file version..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }

        }

        private void btnSetLatestHistoryVersion_Click(object sender, EventArgs e)
        {
            //if (IsCheckedOut == false)
            //{
            //    if (clsStaticGlobal.IsReadOnly == false)
            //    {
            //        DialogResult _dialogRes = MessageBox.Show("Are you sure to set current details as latest details for Customer Comment..?", "Customer Comment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //        if (_dialogRes == System.Windows.Forms.DialogResult.Yes)
            //        {
            //            try
            //            {
            //                if (IsValidateField() == true)
            //                {
            //                    if (IsEditMode == true)
            //                    {
            //                        IsVersionUpdate = true;
            //                        selectedVer = cmbHistoryVersion.SelectedItem.ToString();
            //                        AssignToObject();
            //                        MessageBox.Show("Customer Comment updated successfully..!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //                        this.Close();
            //                    }
            //                }
            //            }
            //            catch (Exception ex)
            //            {
            //                clsStaticGlobal.ErrHandlerLog(ex);
            //                MessageBox.Show("Error in creating Customer Comment!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //            }
            //        }
            //    }
            //    else
            //    {
            //        MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Selected Customer Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        private void VersionsAssignToControl(SingleCustomerCommentsummary _SingleCustomerCommentsummary)
        {
            try
            {
                txtCustomerCommentProjectCode.Text = _SingleCustomerCommentsummary.CustomerCommentProjectCode;
                txtCustomerCustomerCommentNumber.Text = _SingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                txtCustomerCustomerComment.Text = _SingleCustomerCommentsummary.CustomerCustomerComment;

                if (_SingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    if (lstviewCustomerRelatedDocuments.Items.Count > 0)
                    {
                        lstviewCustomerRelatedDocuments.Items.Clear();
                    }
                    foreach (CustomerRelatedDocument item in _SingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewCustomerRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewCustomerRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentsystem.Text = _SingleCustomerCommentsummary.CustomerCommentsystem;

                if ((_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != "") || (_SingleCustomerCommentsummary.CustomerCommentResponsiblePerson != null))
                {
                    cmbCustomerCommentResponsiblePerson.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                    cmbCustomerCommentResponsiblePerson.Text = _SingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                }

                dtpCustomerCommentCloserDate.Text = _SingleCustomerCommentsummary.CustomerCommentCloserDate;
                txtCustomerCommentLandTComment.Text = _SingleCustomerCommentsummary.CustomerCommentLandTComment;

                txtLifecycleState.Text = _SingleCustomerCommentsummary.CustomerCommentLifeCycle;

                if (_SingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    if (lstviewLandTRelatedDocuments.Items.Count > 0)
                    {
                        lstviewLandTRelatedDocuments.Items.Clear();
                    }
                    foreach (LandTRelatedDocument item in _SingleCustomerCommentsummary.ListLandTRelatedDocuments)
                    {
                        ListViewItem _lstitem = new ListViewItem();
                        _lstitem.Text = item.FileName;
                        _lstitem.Tag = item.FilePath;
                        lstviewLandTRelatedDocuments.Items.Add(_lstitem);
                    }
                }
                else
                {
                    lstviewLandTRelatedDocuments.Items.Clear();
                }

                txtCustomerCommentTimeImplications.Text = _SingleCustomerCommentsummary.CustomerCommentTimeImplications;
                txtCustomerCommentCostImplications.Text = _SingleCustomerCommentsummary.CustomerCommentCostImplications;

                if ((_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != "") || (_SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer != null))
                {
                    cmbCustomerCommentFindAcceptanceFromCustomer.SelectedItem = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                    cmbCustomerCommentFindAcceptanceFromCustomer.Text = _SingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                }

                txtCustomerCommentRemark.Text = _SingleCustomerCommentsummary.CustomerCommentRemark;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbHistoryVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            IsVersionUpdate = false;
        }

        private void cmbRevisionVersion_SelectedValueChanged(object sender, EventArgs e)
        {
            string Rev = cmbRevisionVersion.SelectedItem.ToString();
            try
            {
                cmbHistoryVersion.Items.Clear();
            }
            catch (Exception)
            {

            }

            foreach (var Revitem in CollectionRevandVerions)
            {
                if (Revitem.Key == Rev)
                {
                    string selectedFileVer = "";
                    foreach (var Intitem in Revitem.Value)
                    {
                        cmbHistoryVersion.Items.Add(Intitem.ToString());
                        selectedFileVer = Intitem.ToString();
                    }
                    if (selectedFileVer != "")
                    {
                        cmbHistoryVersion.SelectedItem = selectedFileVer;
                    }
                }

            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            excel.Application xlApp;
            excel.Workbook xlWorkBook;
            excel.Worksheet xlWorkSheet;

            try
            {
                if (objVersionSingleCustomerCommentsummary != null)
                {
                    string _Filename = "Customer Comments";
                    System.Windows.Forms.Application.DoEvents();
                    System.Windows.Forms.SaveFileDialog saveFileDialog = new System.Windows.Forms.SaveFileDialog();
                    saveFileDialog.Title = "Save Excel Report";
                    saveFileDialog.RestoreDirectory = true;
                    saveFileDialog.FileName = "Customer Comments Summary_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                    saveFileDialog.DefaultExt = "xlsx";

                    if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        _Filename = saveFileDialog.FileName;
                    }
                    else
                    {
                        return;
                    }

                    /////////////////////// Create Excel Application Object
                    object mMissingValue = System.Reflection.Missing.Value;
                    xlApp = new excel.Application();
                    xlApp.DisplayAlerts = false;
                    xlWorkBook = xlApp.Workbooks.Add(mMissingValue);
                    xlWorkSheet = null;

                    try
                    {
                        var prevSheet = xlWorkSheet;

                        if (prevSheet == null)
                        {
                            xlWorkSheet = xlWorkBook.Sheets.Add(xlWorkBook.Sheets[1], mMissingValue, mMissingValue, mMissingValue);
                        }
                        else
                        {
                            xlWorkSheet = xlWorkBook.Sheets.Add(mMissingValue, prevSheet, mMissingValue, mMissingValue);
                        }
                        xlWorkSheet.Name = "Customer Comments Summary";
                        int BorderStartindex = 0;
                        int RowNo = 2;
                        int ColNo = 2;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comments";
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Size = 16;
                        RowNo += 2;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Downloaded Date";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo + 1] = "'" + DateTime.Now.ToLongDateString();
                        RowNo += 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "User ID";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo + 1] = clsStaticGlobal.connection.UserName.ToString();
                        RowNo += 2;

                        int LoopRowNo = RowNo;
                        int LoopColNo = ColNo;

                        int StartRowNo = RowNo;
                        int StartColNo = ColNo;

                        xlWorkSheet.Cells[RowNo, ColNo - 1] = "Sr.No.";
                        xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo - 1].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Project Code";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comment Number";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comment";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Lifecycle Status";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. by Customer";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. path by Customer";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "System";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Responsible Person";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Comment Closure Target Date";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "L&T Comment";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. by L&T";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. path by L&T";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Time Implications";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Cost Implications (currency rate)";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Final Acceptance by Customer";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        ColNo = ColNo + 1;

                        xlWorkSheet.Cells[RowNo, ColNo] = "Remark";
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                        xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                        xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;

                        BorderStartindex = RowNo;
                        int SrNoCnt = 1;
                        int NextCol = LoopColNo;
                        LoopRowNo = LoopRowNo + 1;
                        NextCol = LoopColNo;

                        xlWorkSheet.Cells[LoopRowNo, NextCol - 1] = SrNoCnt.ToString();
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentProjectCode;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCustomerComment;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentLifeCycle;

                        if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                        {
                            string _collfilename = "";
                            foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                            {
                                if (_collfilename != "")
                                {
                                    _collfilename = _collfilename + "; " + Environment.NewLine + item.FileName;
                                }
                                else
                                {
                                    _collfilename = item.FileName;
                                }
                            }
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                        }
                        else
                        {
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                        }


                        if (objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                        {
                            string _collfilepath = "";
                            foreach (CustomerRelatedDocument item in objVersionSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                            {
                                if (_collfilepath != "")
                                {
                                    _collfilepath = _collfilepath + "; " + Environment.NewLine + item.FilePath;
                                }
                                else
                                {
                                    _collfilepath = item.FilePath;
                                }
                            }
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                        }
                        else
                        {
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                        }

                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentsystem;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentCloserDate;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentLandTComment;

                        if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                        {
                            string _collfilename = "";
                            foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                            {
                                if (_collfilename != "")
                                {
                                    _collfilename = _collfilename + "; " + Environment.NewLine + item.FileName;
                                }
                                else
                                {
                                    _collfilename = item.FileName;
                                }
                            }
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                        }
                        else
                        {
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                        }

                        if (objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                        {
                            string _collfilepath = "";
                            foreach (LandTRelatedDocument item in objVersionSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                            {
                                if (_collfilepath != "")
                                {
                                    _collfilepath = _collfilepath + "; " + Environment.NewLine + item.FilePath;
                                }
                                else
                                {
                                    _collfilepath = item.FilePath;
                                }
                            }
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                        }
                        else
                        {
                            NextCol = NextCol + 1;
                            xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                        }

                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentTimeImplications;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentCostImplications;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                        NextCol = NextCol + 1;
                        xlWorkSheet.Cells[LoopRowNo, NextCol] = objVersionSingleCustomerCommentsummary.CustomerCommentRemark;

                        SrNoCnt = SrNoCnt + 1;

                        for (int m = 2; m <= NextCol; m++)
                        {
                            xlWorkSheet.Columns[m].AutoFit();
                        }

                        xlWorkSheet.Range[xlWorkSheet.Cells[StartRowNo, StartColNo - 1], xlWorkSheet.Cells[LoopRowNo, NextCol]].Cells.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;

                        xlWorkBook.SaveAs(_Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                        xlWorkBook.Close(true, mMissingValue, mMissingValue);
                        System.Windows.MessageBox.Show("Customer Comment summary report exported successfully..!!", "Customer Comments", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);

                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Error in report export.", "Customer Comments", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                    finally
                    {
                        try
                        {
                            clsStaticGlobal.ReleaseObject(xlWorkBook);

                        }
                        catch (Exception)
                        {

                        }
                        xlApp.Quit();
                        clsStaticGlobal.ReleaseObject(xlApp);
                    }
                }
            }
            catch (Exception ex1)
            {
                System.Windows.MessageBox.Show("Excel application not installed.", "Customer Comments", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
                clsStaticGlobal.ErrHandlerLog(ex1);
            }
        }
    }
}
