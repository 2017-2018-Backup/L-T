﻿namespace KKMCustomerComments
{
    partial class frmHistoryCustomerComments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHistoryCustomerComments));
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider7 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lstviewCustomerRelatedDocuments = new System.Windows.Forms.ListView();
            this.txtCustomerCommentRemark = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCustomerCommentCostImplications = new System.Windows.Forms.TextBox();
            this.btnLandTRelatedDocuments = new System.Windows.Forms.Button();
            this.dtpCustomerCommentCloserDate = new System.Windows.Forms.DateTimePicker();
            this.cmbCustomerCommentResponsiblePerson = new System.Windows.Forms.ComboBox();
            this.lstviewLandTRelatedDocuments = new System.Windows.Forms.ListView();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCustomerCommentLandTComment = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCustomerCommentsystem = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCustomerCommentProjectCode = new System.Windows.Forms.TextBox();
            this.btnCustomerRelatedDocuments = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbCustomerCommentFindAcceptanceFromCustomer = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCustomerCustomerComment = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCustomerCommentTimeImplications = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCustomerCustomerCommentNumber = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtLifecycleState = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.btnSetLatestHistoryVersion = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbHistoryVersion = new System.Windows.Forms.ComboBox();
            this.btnApplyHistoryVersion = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbRevisionVersion = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // errorProvider7
            // 
            this.errorProvider7.ContainerControl = this;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txtLifecycleState);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.txtCustomerCustomerCommentNumber);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.txtCustomerCommentTimeImplications);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.txtCustomerCustomerComment);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.cmbCustomerCommentFindAcceptanceFromCustomer);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.btnCustomerRelatedDocuments);
            this.panel3.Controls.Add(this.txtCustomerCommentProjectCode);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.txtCustomerCommentsystem);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.txtCustomerCommentLandTComment);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.lstviewLandTRelatedDocuments);
            this.panel3.Controls.Add(this.cmbCustomerCommentResponsiblePerson);
            this.panel3.Controls.Add(this.dtpCustomerCommentCloserDate);
            this.panel3.Controls.Add(this.btnLandTRelatedDocuments);
            this.panel3.Controls.Add(this.txtCustomerCommentCostImplications);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txtCustomerCommentRemark);
            this.panel3.Controls.Add(this.lstviewCustomerRelatedDocuments);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(0, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(984, 399);
            this.panel3.TabIndex = 73;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(631, 304);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 17);
            this.label7.TabIndex = 89;
            this.label7.Text = "Remark :";
            // 
            // lstviewCustomerRelatedDocuments
            // 
            this.lstviewCustomerRelatedDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstviewCustomerRelatedDocuments.Location = new System.Drawing.Point(196, 165);
            this.lstviewCustomerRelatedDocuments.Name = "lstviewCustomerRelatedDocuments";
            this.lstviewCustomerRelatedDocuments.Size = new System.Drawing.Size(233, 100);
            this.lstviewCustomerRelatedDocuments.TabIndex = 3;
            this.lstviewCustomerRelatedDocuments.UseCompatibleStateImageBehavior = false;
            this.lstviewCustomerRelatedDocuments.View = System.Windows.Forms.View.List;
            // 
            // txtCustomerCommentRemark
            // 
            this.txtCustomerCommentRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerCommentRemark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentRemark.Location = new System.Drawing.Point(691, 302);
            this.txtCustomerCommentRemark.Multiline = true;
            this.txtCustomerCommentRemark.Name = "txtCustomerCommentRemark";
            this.txtCustomerCommentRemark.Size = new System.Drawing.Size(279, 87);
            this.txtCustomerCommentRemark.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(488, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(202, 17);
            this.label10.TabIndex = 87;
            this.label10.Text = "Cost Implications (currency rate) :";
            // 
            // txtCustomerCommentCostImplications
            // 
            this.txtCustomerCommentCostImplications.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerCommentCostImplications.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentCostImplications.Location = new System.Drawing.Point(691, 240);
            this.txtCustomerCommentCostImplications.Name = "txtCustomerCommentCostImplications";
            this.txtCustomerCommentCostImplications.Size = new System.Drawing.Size(279, 25);
            this.txtCustomerCommentCostImplications.TabIndex = 12;
            // 
            // btnLandTRelatedDocuments
            // 
            this.btnLandTRelatedDocuments.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLandTRelatedDocuments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.btnLandTRelatedDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLandTRelatedDocuments.ForeColor = System.Drawing.Color.White;
            this.btnLandTRelatedDocuments.Location = new System.Drawing.Point(939, 103);
            this.btnLandTRelatedDocuments.Name = "btnLandTRelatedDocuments";
            this.btnLandTRelatedDocuments.Size = new System.Drawing.Size(31, 20);
            this.btnLandTRelatedDocuments.TabIndex = 10;
            this.btnLandTRelatedDocuments.Text = "...";
            this.btnLandTRelatedDocuments.UseVisualStyleBackColor = false;
            this.btnLandTRelatedDocuments.Click += new System.EventHandler(this.btnLandTRelatedDocuments_Click);
            // 
            // dtpCustomerCommentCloserDate
            // 
            this.dtpCustomerCommentCloserDate.CustomFormat = "dd-MMM-yyyy";
            this.dtpCustomerCommentCloserDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCustomerCommentCloserDate.Location = new System.Drawing.Point(196, 333);
            this.dtpCustomerCommentCloserDate.Name = "dtpCustomerCommentCloserDate";
            this.dtpCustomerCommentCloserDate.Size = new System.Drawing.Size(270, 25);
            this.dtpCustomerCommentCloserDate.TabIndex = 7;
            // 
            // cmbCustomerCommentResponsiblePerson
            // 
            this.cmbCustomerCommentResponsiblePerson.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomerCommentResponsiblePerson.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomerCommentResponsiblePerson.FormattingEnabled = true;
            this.cmbCustomerCommentResponsiblePerson.Items.AddRange(new object[] {
            "AQP",
            "AQS"});
            this.cmbCustomerCommentResponsiblePerson.Location = new System.Drawing.Point(196, 302);
            this.cmbCustomerCommentResponsiblePerson.Name = "cmbCustomerCommentResponsiblePerson";
            this.cmbCustomerCommentResponsiblePerson.Size = new System.Drawing.Size(270, 25);
            this.cmbCustomerCommentResponsiblePerson.Sorted = true;
            this.cmbCustomerCommentResponsiblePerson.TabIndex = 6;
            // 
            // lstviewLandTRelatedDocuments
            // 
            this.lstviewLandTRelatedDocuments.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lstviewLandTRelatedDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstviewLandTRelatedDocuments.Location = new System.Drawing.Point(691, 103);
            this.lstviewLandTRelatedDocuments.Name = "lstviewLandTRelatedDocuments";
            this.lstviewLandTRelatedDocuments.Size = new System.Drawing.Size(242, 100);
            this.lstviewLandTRelatedDocuments.TabIndex = 9;
            this.lstviewLandTRelatedDocuments.UseCompatibleStateImageBehavior = false;
            this.lstviewLandTRelatedDocuments.View = System.Windows.Forms.View.List;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(639, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 85;
            this.label4.Text = "By L&&T:";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(592, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 17);
            this.label9.TabIndex = 82;
            this.label9.Text = "L&&T Comment :";
            // 
            // txtCustomerCommentLandTComment
            // 
            this.txtCustomerCommentLandTComment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerCommentLandTComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentLandTComment.Location = new System.Drawing.Point(691, 16);
            this.txtCustomerCommentLandTComment.Multiline = true;
            this.txtCustomerCommentLandTComment.Name = "txtCustomerCommentLandTComment";
            this.txtCustomerCommentLandTComment.Size = new System.Drawing.Size(279, 81);
            this.txtCustomerCommentLandTComment.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 337);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(192, 17);
            this.label8.TabIndex = 79;
            this.label8.Text = "Comment Closure Target Date :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(139, 273);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 17);
            this.label13.TabIndex = 77;
            this.label13.Text = "System :";
            // 
            // txtCustomerCommentsystem
            // 
            this.txtCustomerCommentsystem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentsystem.Location = new System.Drawing.Point(196, 271);
            this.txtCustomerCommentsystem.Name = "txtCustomerCommentsystem";
            this.txtCustomerCommentsystem.Size = new System.Drawing.Size(270, 25);
            this.txtCustomerCommentsystem.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(65, 306);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(130, 17);
            this.label14.TabIndex = 76;
            this.label14.Text = "Repsonsible Person :";
            // 
            // txtCustomerCommentProjectCode
            // 
            this.txtCustomerCommentProjectCode.BackColor = System.Drawing.Color.White;
            this.txtCustomerCommentProjectCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentProjectCode.Location = new System.Drawing.Point(196, 16);
            this.txtCustomerCommentProjectCode.Name = "txtCustomerCommentProjectCode";
            this.txtCustomerCommentProjectCode.ReadOnly = true;
            this.txtCustomerCommentProjectCode.Size = new System.Drawing.Size(270, 25);
            this.txtCustomerCommentProjectCode.TabIndex = 0;
            // 
            // btnCustomerRelatedDocuments
            // 
            this.btnCustomerRelatedDocuments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.btnCustomerRelatedDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerRelatedDocuments.ForeColor = System.Drawing.Color.White;
            this.btnCustomerRelatedDocuments.Location = new System.Drawing.Point(435, 165);
            this.btnCustomerRelatedDocuments.Name = "btnCustomerRelatedDocuments";
            this.btnCustomerRelatedDocuments.Size = new System.Drawing.Size(31, 20);
            this.btnCustomerRelatedDocuments.TabIndex = 4;
            this.btnCustomerRelatedDocuments.Text = "...";
            this.btnCustomerRelatedDocuments.UseVisualStyleBackColor = false;
            this.btnCustomerRelatedDocuments.Click += new System.EventHandler(this.btnCustomerRelatedDocuments_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(107, 167);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 17);
            this.label28.TabIndex = 58;
            this.label28.Text = "By Customer :";
            // 
            // cmbCustomerCommentFindAcceptanceFromCustomer
            // 
            this.cmbCustomerCommentFindAcceptanceFromCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbCustomerCommentFindAcceptanceFromCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerCommentFindAcceptanceFromCustomer.FormattingEnabled = true;
            this.cmbCustomerCommentFindAcceptanceFromCustomer.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbCustomerCommentFindAcceptanceFromCustomer.Location = new System.Drawing.Point(691, 271);
            this.cmbCustomerCommentFindAcceptanceFromCustomer.Name = "cmbCustomerCommentFindAcceptanceFromCustomer";
            this.cmbCustomerCommentFindAcceptanceFromCustomer.Size = new System.Drawing.Size(279, 25);
            this.cmbCustomerCommentFindAcceptanceFromCustomer.TabIndex = 13;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(140, 19);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 17);
            this.label24.TabIndex = 52;
            this.label24.Text = "Project :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(64, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 17);
            this.label11.TabIndex = 19;
            this.label11.Text = "Customer Comment :";
            // 
            // txtCustomerCustomerComment
            // 
            this.txtCustomerCustomerComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCustomerComment.Location = new System.Drawing.Point(196, 78);
            this.txtCustomerCustomerComment.Multiline = true;
            this.txtCustomerCustomerComment.Name = "txtCustomerCustomerComment";
            this.txtCustomerCustomerComment.Size = new System.Drawing.Size(270, 81);
            this.txtCustomerCustomerComment.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(574, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 17);
            this.label12.TabIndex = 16;
            this.label12.Text = "Time Implications :";
            // 
            // txtCustomerCommentTimeImplications
            // 
            this.txtCustomerCommentTimeImplications.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerCommentTimeImplications.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCommentTimeImplications.Location = new System.Drawing.Point(691, 209);
            this.txtCustomerCommentTimeImplications.Name = "txtCustomerCommentTimeImplications";
            this.txtCustomerCommentTimeImplications.Size = new System.Drawing.Size(279, 25);
            this.txtCustomerCommentTimeImplications.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(502, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(188, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Final acceptance by Customer :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Customer Comment Number :";
            // 
            // txtCustomerCustomerCommentNumber
            // 
            this.txtCustomerCustomerCommentNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerCustomerCommentNumber.Location = new System.Drawing.Point(196, 47);
            this.txtCustomerCustomerCommentNumber.Name = "txtCustomerCustomerCommentNumber";
            this.txtCustomerCustomerCommentNumber.Size = new System.Drawing.Size(270, 25);
            this.txtCustomerCustomerCommentNumber.TabIndex = 1;
            this.txtCustomerCustomerCommentNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIssueNumber_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(99, 367);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 17);
            this.label15.TabIndex = 91;
            this.label15.Text = "Lifecycle State :";
            // 
            // txtLifecycleState
            // 
            this.txtLifecycleState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLifecycleState.Enabled = false;
            this.txtLifecycleState.Location = new System.Drawing.Point(196, 364);
            this.txtLifecycleState.Name = "txtLifecycleState";
            this.txtLifecycleState.ReadOnly = true;
            this.txtLifecycleState.Size = new System.Drawing.Size(270, 25);
            this.txtLifecycleState.TabIndex = 90;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.btnExport);
            this.panel4.Controls.Add(this.btnSetLatestHistoryVersion);
            this.panel4.Controls.Add(this.cmdCancel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 434);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(984, 40);
            this.panel4.TabIndex = 74;
            // 
            // cmdCancel
            // 
            this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdCancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCancel.ForeColor = System.Drawing.Color.White;
            this.cmdCancel.Location = new System.Drawing.Point(890, 4);
            this.cmdCancel.Margin = new System.Windows.Forms.Padding(4);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(80, 28);
            this.cmdCancel.TabIndex = 1;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = false;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // btnSetLatestHistoryVersion
            // 
            this.btnSetLatestHistoryVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetLatestHistoryVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.btnSetLatestHistoryVersion.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSetLatestHistoryVersion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetLatestHistoryVersion.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetLatestHistoryVersion.ForeColor = System.Drawing.Color.White;
            this.btnSetLatestHistoryVersion.Location = new System.Drawing.Point(156, 4);
            this.btnSetLatestHistoryVersion.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetLatestHistoryVersion.Name = "btnSetLatestHistoryVersion";
            this.btnSetLatestHistoryVersion.Size = new System.Drawing.Size(146, 28);
            this.btnSetLatestHistoryVersion.TabIndex = 4;
            this.btnSetLatestHistoryVersion.Text = "Set as Latest Version";
            this.btnSetLatestHistoryVersion.UseVisualStyleBackColor = false;
            this.btnSetLatestHistoryVersion.Visible = false;
            this.btnSetLatestHistoryVersion.Click += new System.EventHandler(this.btnSetLatestHistoryVersion_Click);
            // 
            // btnExport
            // 
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Location = new System.Drawing.Point(4, 4);
            this.btnExport.Margin = new System.Windows.Forms.Padding(4);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(146, 28);
            this.btnExport.TabIndex = 0;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cmbRevisionVersion);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.btnApplyHistoryVersion);
            this.panel2.Controls.Add(this.cmbHistoryVersion);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(984, 35);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.label3.Location = new System.Drawing.Point(155, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "History Version :";
            // 
            // cmbHistoryVersion
            // 
            this.cmbHistoryVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHistoryVersion.FormattingEnabled = true;
            this.cmbHistoryVersion.Location = new System.Drawing.Point(261, 6);
            this.cmbHistoryVersion.Name = "cmbHistoryVersion";
            this.cmbHistoryVersion.Size = new System.Drawing.Size(69, 21);
            this.cmbHistoryVersion.Sorted = true;
            this.cmbHistoryVersion.TabIndex = 1;
            this.cmbHistoryVersion.SelectedIndexChanged += new System.EventHandler(this.cmbHistoryVersion_SelectedIndexChanged);
            // 
            // btnApplyHistoryVersion
            // 
            this.btnApplyHistoryVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApplyHistoryVersion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.btnApplyHistoryVersion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApplyHistoryVersion.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApplyHistoryVersion.ForeColor = System.Drawing.Color.White;
            this.btnApplyHistoryVersion.Location = new System.Drawing.Point(335, 3);
            this.btnApplyHistoryVersion.Margin = new System.Windows.Forms.Padding(4);
            this.btnApplyHistoryVersion.Name = "btnApplyHistoryVersion";
            this.btnApplyHistoryVersion.Size = new System.Drawing.Size(92, 26);
            this.btnApplyHistoryVersion.TabIndex = 2;
            this.btnApplyHistoryVersion.Text = "Apply";
            this.btnApplyHistoryVersion.UseVisualStyleBackColor = false;
            this.btnApplyHistoryVersion.Click += new System.EventHandler(this.btnApplyHistoryVersion_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.label16.Location = new System.Drawing.Point(12, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(63, 17);
            this.label16.TabIndex = 74;
            this.label16.Text = "Revision :";
            // 
            // cmbRevisionVersion
            // 
            this.cmbRevisionVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRevisionVersion.FormattingEnabled = true;
            this.cmbRevisionVersion.Location = new System.Drawing.Point(76, 6);
            this.cmbRevisionVersion.Name = "cmbRevisionVersion";
            this.cmbRevisionVersion.Size = new System.Drawing.Size(69, 21);
            this.cmbRevisionVersion.Sorted = true;
            this.cmbRevisionVersion.TabIndex = 0;
            this.cmbRevisionVersion.SelectedValueChanged += new System.EventHandler(this.cmbRevisionVersion_SelectedValueChanged);
            // 
            // frmHistoryCustomerComments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 474);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmHistoryCustomerComments";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Comment History";
            this.Load += new System.EventHandler(this.frmHistoryCustomerComment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.ErrorProvider errorProvider7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnSetLatestHistoryVersion;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtLifecycleState;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCustomerCustomerCommentNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCustomerCommentTimeImplications;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCustomerCustomerComment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbCustomerCommentFindAcceptanceFromCustomer;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button btnCustomerRelatedDocuments;
        private System.Windows.Forms.TextBox txtCustomerCommentProjectCode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCustomerCommentsystem;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCustomerCommentLandTComment;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListView lstviewLandTRelatedDocuments;
        private System.Windows.Forms.ComboBox cmbCustomerCommentResponsiblePerson;
        private System.Windows.Forms.DateTimePicker dtpCustomerCommentCloserDate;
        private System.Windows.Forms.Button btnLandTRelatedDocuments;
        private System.Windows.Forms.TextBox txtCustomerCommentCostImplications;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCustomerCommentRemark;
        private System.Windows.Forms.ListView lstviewCustomerRelatedDocuments;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cmbRevisionVersion;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnApplyHistoryVersion;
        private System.Windows.Forms.ComboBox cmbHistoryVersion;
        private System.Windows.Forms.Label label3;
    }
}