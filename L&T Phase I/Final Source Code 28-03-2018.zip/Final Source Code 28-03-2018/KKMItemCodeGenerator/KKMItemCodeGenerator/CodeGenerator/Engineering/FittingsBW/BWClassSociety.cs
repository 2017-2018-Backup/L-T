﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWClassSociety : ObservableCollection<NameCodePair>
    {
        public static BWClassSociety LoadList()
        {
            BWClassSociety items = new BWClassSociety();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Non IACS" });
            items.Add(new NameCodePair() { Code = "B", Name = "IACS" });
            return items;
        }
        public static BWClassSociety LoadFromExcel(String path)
        {
            return null;
        }

        public static BWClassSociety LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWClassSociety>(EngineeringItems.DataPath + @"\FittingsBW\BWClassSociety.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWClassSociety>(this, EngineeringItems.DataPath + @"\FittingsBW\BWClassSociety.xml");
        }

    }
}
