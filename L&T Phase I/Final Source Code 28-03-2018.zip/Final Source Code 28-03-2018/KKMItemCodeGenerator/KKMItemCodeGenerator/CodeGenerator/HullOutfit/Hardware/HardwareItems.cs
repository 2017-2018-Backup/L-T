﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareItems : ObservableCollection<NameCodePair>
    {
        public static HardwareItems LoadList()
        {
            HardwareItems items = new HardwareItems();
            items.Add(new NameCodePair() { Code = "01", Name = "BOLT" });
            items.Add(new NameCodePair() { Code = "02", Name = "SCREW" });
            items.Add(new NameCodePair() { Code = "03", Name = "NUT" });
            items.Add(new NameCodePair() { Code = "04", Name = "WASHER" });
            items.Add(new NameCodePair() { Code = "05", Name = "GRUB SCREW" });
            items.Add(new NameCodePair() { Code = "06", Name = "STUD" });

            return items;
        }
        public static HardwareItems LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareItems LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareItems>(HullOutfitItems.DataPath + @"\Hardware\HardwareItems.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareItems>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareItems.xml");
        }
    }
}
