﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveStandards : ObservableCollection<NameCodePair>
    {
        public static ValveStandards LoadList()
        {
            ValveStandards items = new ValveStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "DIN 3202" });
            items.Add(new NameCodePair() { Code = "02", Name = "ASME B16.10" });
            items.Add(new NameCodePair() { Code = "03", Name = "DIN 86037" });
            items.Add(new NameCodePair() { Code = "04", Name = "ASME B16.34" });
            items.Add(new NameCodePair() { Code = "05", Name = "IS 5290" });
            items.Add(new NameCodePair() { Code = "06", Name = "NES 375" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASME B16.5" });
            return items;
        }
        public static ValveStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveStandards>(EngineeringItems.DataPath + @"\Valves\ValveStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveStandards>(this, EngineeringItems.DataPath + @"\Valves\ValveStandards.xml");
        }

    }
}
