﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTrayConnectionTypes : ObservableCollection<NameCodePair>
    {
        public static CableTrayConnectionTypes LoadList()
        {
            CableTrayConnectionTypes items = new CableTrayConnectionTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "BOLTED" });
            items.Add(new NameCodePair() { Code = "02", Name = "WELDED" });

            return items;
        }
        public static CableTrayConnectionTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTrayConnectionTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTrayConnectionTypes>(ElectricalItems.DataPath + @"\CableTray\CableTrayConnectionTypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTrayConnectionTypes>(this, ElectricalItems.DataPath + @"\CableTray\CableTrayConnectionTypes.xml");
        }

    }
}
