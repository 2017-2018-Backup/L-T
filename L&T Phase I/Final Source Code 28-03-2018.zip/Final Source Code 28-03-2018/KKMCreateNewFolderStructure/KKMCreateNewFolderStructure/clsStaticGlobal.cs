﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KKMCreateNewProjectStructure
{
    public static class clsStaticGlobal
    {
        public static Autodesk.Connectivity.Explorer.Extensibility.CommandItemEventArgs _ConnectionContext =null;
        public static Autodesk.Connectivity.WebServices.Folder GoLocationFolder = null;
    }
}
