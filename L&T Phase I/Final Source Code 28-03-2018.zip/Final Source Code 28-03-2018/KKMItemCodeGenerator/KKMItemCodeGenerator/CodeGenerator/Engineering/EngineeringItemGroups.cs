﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class EngineeringItemGroups : ObservableCollection<NameCodePair>
    {
        public static EngineeringItemGroups LoadList()
        {
            EngineeringItemGroups items = new EngineeringItemGroups();
            items.Add(new NameCodePair() { Code = "PIP", Name = "Pipes" });
            items.Add(new NameCodePair() { Code = "PIF", Name = "Pipe Fittings" });
            items.Add(new NameCodePair() { Code = "FFA", Name = "Fire Fighting appliances" });
            items.Add(new NameCodePair() { Code = "VAS", Name = "Valves, Armatures & Supports" });
            items.Add(new NameCodePair() { Code = "ACI", Name = "Access Items-Doors,hatches,etc" });
            items.Add(new NameCodePair() { Code = "DOE", Name = "Deck M/C & Outfitting Eqpt." });
            items.Add(new NameCodePair() { Code = "OIL", Name = "Oils, Lubricants & Coolants" });
            items.Add(new NameCodePair() { Code = "SPE", Name = "Special Equipments" });
            items.Add(new NameCodePair() { Code = "STS", Name = "Steel & Structural Items" });
            items.Add(new NameCodePair() { Code = "ACV", Name = "AC & Ventilation items" });
            items.Add(new NameCodePair() { Code = "AUI", Name = "Automation & Instrumentation" });
            items.Add(new NameCodePair() { Code = "TAB", Name = "Tools & Abrasives" });
            items.Add(new NameCodePair() { Code = "ADS", Name = "Adhesives & Sealants" });
            items.Add(new NameCodePair() { Code = "FST", Name = "Fasteners" });
            items.Add(new NameCodePair() { Code = "MEQ", Name = "Mechnaical Equipments" });

            return items;
        }
        public static EngineeringItemGroups LoadFromExcel(String path)
        {
            return null;
        }

        public static EngineeringItemGroups LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<EngineeringItemGroups>(EngineeringItems.DataPath + @"\EngineeringItemGroups.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<EngineeringItemGroups>(this, EngineeringItems.DataPath + @"\EngineeringItemGroups.xml");
        }
    }
}
