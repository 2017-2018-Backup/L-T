﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingTypes LoadList()
        {
            PipeFittingTypes items = new PipeFittingTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "ELBOW" });
            items.Add(new NameCodePair() { Code = "02", Name = "TEE" });
            items.Add(new NameCodePair() { Code = "03", Name = "ADAPTER" });
            items.Add(new NameCodePair() { Code = "04", Name = "COUPLING" });
            items.Add(new NameCodePair() { Code = "05", Name = "NIPPLE" });
            items.Add(new NameCodePair() { Code = "06", Name = "PLUG" });
            items.Add(new NameCodePair() { Code = "07", Name = "CAP" });
            items.Add(new NameCodePair() { Code = "08", Name = "BUSHING" });
            items.Add(new NameCodePair() { Code = "09", Name = "HOSE CONNECTION" });
            items.Add(new NameCodePair() { Code = "10", Name = "CROSS" });
            items.Add(new NameCodePair() { Code = "11", Name = "ROXTEC PENETRATION" });
            items.Add(new NameCodePair() { Code = "12", Name = "SCUPPER" });
            items.Add(new NameCodePair() { Code = "17", Name = "MALE CONNECTOR" });
            items.Add(new NameCodePair() { Code = "18", Name = "WELDING BULKHEAD UNION" });
            items.Add(new NameCodePair() { Code = "19", Name = "REDUCING UNION" });
            items.Add(new NameCodePair() { Code = "21", Name = "THREADED SOCKET" });
            items.Add(new NameCodePair() { Code = "22", Name = "FLANGE ADAPTER" });
            items.Add(new NameCodePair() { Code = "24", Name = "FEMALE CONNECTOR" });
            items.Add(new NameCodePair() { Code = "25", Name = "SAE FLANGE" });
            return items;
        }
        public static PipeFittingTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingTypes.xml");
        }

    }
}
