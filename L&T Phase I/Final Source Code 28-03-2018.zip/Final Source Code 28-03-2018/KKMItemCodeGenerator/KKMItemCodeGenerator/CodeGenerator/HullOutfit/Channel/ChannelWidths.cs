﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelWidths : ObservableCollection<NameCodePair>
    {
        public static ChannelWidths LoadList()
        {
            ChannelWidths items = new ChannelWidths();
            items.Add(new NameCodePair() { Code = "040", Name = "40 mm" });
            items.Add(new NameCodePair() { Code = "050", Name = "50 mm" });
            items.Add(new NameCodePair() { Code = "065", Name = "65 mm" });
            items.Add(new NameCodePair() { Code = "066", Name = "66 mm" });
            items.Add(new NameCodePair() { Code = "075", Name = "75 mm" });
            items.Add(new NameCodePair() { Code = "076", Name = "76 mm" });
            items.Add(new NameCodePair() { Code = "080", Name = "80 mm" });
            items.Add(new NameCodePair() { Code = "082", Name = "82 mm" });
            items.Add(new NameCodePair() { Code = "083", Name = "83 mm" });
            items.Add(new NameCodePair() { Code = "090", Name = "90 mm" });
            items.Add(new NameCodePair() { Code = "092", Name = "92 mm" });
            items.Add(new NameCodePair() { Code = "093", Name = "93 mm" });
            items.Add(new NameCodePair() { Code = "100", Name = "100 mm" });
            items.Add(new NameCodePair() { Code = "150", Name = "150 mm" });

            return items;
        }
        public static ChannelWidths LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelWidths LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelWidths>(HullOutfitItems.DataPath + @"\Channel\ChannelWidths.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelWidths>(this, HullOutfitItems.DataPath + @"\Channel\ChannelWidths.xml");
        }
    }
}
