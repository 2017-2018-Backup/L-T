﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KKMSurveyorComment;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace KKMSurveyorComment
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlReferenceDocument : Window
    {
        public System.Windows.Forms.DialogResult DialogResUserControlReferenceDocument = System.Windows.Forms.DialogResult.Cancel;
        bool IsEditMode = false;
        bool IsCheckedOut = false;
        string checkedOutUsername = "";

        public UserControlReferenceDocument(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;
            try
            {
                string _NewFileFolderName = clsStaticGlobal.GetFileNameWithoutExtension(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName);
                clsStaticGlobal.VaultSurvayerReferenceDocFolder = clsStaticGlobal.GetorCreateSurveyorReferenceDocFolder(clsStaticGlobal.VaultSurvayerFolder, _NewFileFolderName);
                clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListReferenceDocument_CollectionChanged);

                ReferenceDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument;
                ReferenceDocumentSearchGridViewBox.UpdateLayout();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            try
            {
                if (clsStaticGlobal.IsReadOnly == true)
                {
                    cmdAddReferenceDocument.Visibility = Visibility.Collapsed;
                    cmdRemoveReferenceDocument.Visibility = Visibility.Collapsed;
                }
                else
                {
                    cmdAddReferenceDocument.Visibility = Visibility.Visible;
                    cmdSave.Visibility = Visibility.Visible;
                    cmdRemoveReferenceDocument.Visibility = Visibility.Visible;
                }
            }
            catch (Exception)
            {

            }

            if (IsCheckedOut == true)
            {
                System.Windows.Forms.MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DialogResUserControlReferenceDocument = System.Windows.Forms.DialogResult.Cancel;
                this.Close();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                string _NewFileFolderName = clsStaticGlobal.GetFileNameWithoutExtension(clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName);
                clsStaticGlobal.VaultSurvayerReferenceDocFolder = clsStaticGlobal.GetorCreateSurveyorReferenceDocFolder(clsStaticGlobal.VaultSurvayerFolder, _NewFileFolderName);
                clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListReferenceDocument_CollectionChanged);

                ReferenceDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument;
                ReferenceDocumentSearchGridViewBox.UpdateLayout();


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListReferenceDocument_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmdAddReferenceDocument_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {                        
                        OpenFileDialog fdlg = new OpenFileDialog();
                        fdlg.Title = " Open File Dialog";
                        fdlg.InitialDirectory = @"c:\";
                        fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
                        fdlg.FilterIndex = 2;
                        fdlg.Multiselect = true;
                        fdlg.RestoreDirectory = true;
                        if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            foreach (var sFIle in fdlg.FileNames)
                            {
                                FileInfo f = new FileInfo(sFIle);
                                string _name = f.Name;

                                clsStaticGlobal.AddReferenceDocintoVault(clsStaticGlobal.VaultSurvayerReferenceDocFolder, f.FullName);
                                string _fullpath = clsStaticGlobal.VaultSurvayerReferenceDocFolder.FullName + "/" + _name;
                                ReferenceDocument objReferenceDocument = new ReferenceDocument { FileName = _name, FileType = "Reference Document", FilePath = _fullpath };
                                clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.Add(objReferenceDocument);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            ReferenceDocumentSearchGridViewBox.UpdateLayout();
        }

        private void cmdRemoveReferenceDocument_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.Count > 0)
                        {
                            if (ReferenceDocumentSearchGridViewBox.SelectedCells.Count > 0)
                            {
                                ReferenceDocument objReferenceDocument = (ReferenceDocument)ReferenceDocumentSearchGridViewBox.SelectedCells[0].Item;
                                clsStaticGlobal.DeleteReferenceDocintoVault(clsStaticGlobal.VaultSurvayerReferenceDocFolder, objReferenceDocument.FilePath);
                                clsStaticGlobal.objSingleSurveyorCommentSummary.ListReferenceDocument.Remove(objReferenceDocument);
                            }
                            else
                            {
                                System.Windows.MessageBox.Show("Please select a row to remove.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                                return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            ReferenceDocumentSearchGridViewBox.UpdateLayout();
        }

        private void DG_Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            //Debugger.Launch();
            try
            {
                if (ReferenceDocumentSearchGridViewBox.SelectedCells.Count > 0)
                {
                    ReferenceDocument objReferenceDocument = (ReferenceDocument)ReferenceDocumentSearchGridViewBox.SelectedCells[0].Item;

                    string downloadfolderpath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\RefFolder";

                    if (clsStaticGlobal.DownloadFileByPath(objReferenceDocument.FileName, objReferenceDocument.FilePath, downloadfolderpath) == true)
                    {
                        if (System.IO.File.Exists(downloadfolderpath + "\\" + objReferenceDocument.FileName))
                        {
                            try
                            {
                                Process.Start(downloadfolderpath + "\\" + objReferenceDocument.FileName);
                            }
                            catch (Exception ex)
                            {
                                clsStaticGlobal.ErrHandlerLog(ex);
                                System.Windows.MessageBox.Show("Reference file unable to open due to file format..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Error);
                                //ProcessStartInfo stinfo = new ProcessStartInfo();
                                //// Assign file name
                                //stinfo.FileName = downloadfolderpath + "\\" + objReferenceDocument.FileName;
                                //// start the process without creating new window default is false
                                //stinfo.CreateNoWindow = true;
                                //// true to use the shell when starting the process; otherwise, the process is created directly from the executable file
                                //stinfo.UseShellExecute = true;
                                //// Creating Process class object to start process 
                                //Process myProcess = Process.Start(stinfo);
                                //// start the process 
                                //myProcess.Start();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.MessageBox.Show("Please select a file to view!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Error); 
            }
            ReferenceDocumentSearchGridViewBox.SelectedItem = null;
            ReferenceDocumentSearchGridViewBox.UpdateLayout();
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlReferenceDocument = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private void cmdDownload_Click(object sender, RoutedEventArgs e)
        {
            //Debugger.Launch();
            //ReferenceDocumentSearchGridViewBox.Items.Refresh();
            //ReferenceDocumentSearchGridViewBox.UpdateLayout();

            if (ReferenceDocumentSearchGridViewBox.SelectedItems.Count > 0)
            {
                FolderBrowserDialog folderDlg = new FolderBrowserDialog();

                folderDlg.ShowNewFolderButton = true;

                // Show the FolderBrowserDialog.

                DialogResult result = folderDlg.ShowDialog();

                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    //textBox1.Text = folderDlg.SelectedPath;
                    //Environment.SpecialFolder root = folderDlg.RootFolder;

                    string downloadfolderpath = folderDlg.SelectedPath;
                    // bool isChecked = false;
                    bool isDownloaded = false;

                    foreach (var item in ReferenceDocumentSearchGridViewBox.SelectedItems)
                    {
                        ReferenceDocument objReferenceDocument = (ReferenceDocument)item;

                        if (clsStaticGlobal.DownloadFileByPath(objReferenceDocument.FileName, objReferenceDocument.FilePath, downloadfolderpath) == false)
                        {
                            System.Windows.MessageBox.Show("Reference file not downloaded.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        else
                        {
                            isDownloaded = true;
                        }
                    }

                    if (isDownloaded == true)
                    {
                        System.Windows.MessageBox.Show("Reference files downloaded successfully.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                try
                {
                    ReferenceDocumentSearchGridViewBox.SelectedItems.Clear();
                }
                catch (Exception)
                {

                }

            }
            else
            {
                System.Windows.MessageBox.Show("Please select a row to download.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }
    }
}
