﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsPipeClampSubTypes : ObservableCollection<NameCodePair>
    {
        public static SupportsPipeClampSubTypes LoadList()
        {
            SupportsPipeClampSubTypes items = new SupportsPipeClampSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "INSULATED TYPE" });
            return items;
        }
        public static SupportsPipeClampSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsPipeClampSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsPipeClampSubTypes>(EngineeringItems.DataPath + @"\Supports\SupportsPipeClampSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsPipeClampSubTypes>(this, EngineeringItems.DataPath + @"\Supports\SupportsPipeClampSubTypes.xml");
        }

    }
}
