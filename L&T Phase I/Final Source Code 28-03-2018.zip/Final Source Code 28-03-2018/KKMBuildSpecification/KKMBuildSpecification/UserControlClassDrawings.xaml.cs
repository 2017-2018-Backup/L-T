﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;
using KKMBuildSpecification;
using System.Collections;
using System.Diagnostics;

namespace KKMBuildSpecification
{
    /// <summary>
    /// Interaction logic for UserControlClassDrawing.xaml
    /// </summary>
    public partial class UserControlClassDrawing : Window
    {
        public List<MasterDrawingFile> ExcelClassApprovedList { get; set; }
        String SFIcode = "";
        public UserControlClassDrawing(List<MasterDrawingFile> _ExcelClassApprovedList, string _SFIcode)
        {
            InitializeComponent();
            ExcelClassApprovedList = _ExcelClassApprovedList;
            SFIcode = _SFIcode;
            try
            {
                clsStaticGlobal.ClassDrawingSearchedItemCollection.Clear();

                int SearchedCount = 1;
                foreach (MasterDrawingFile _item in ExcelClassApprovedList)
                {
                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.DocumentNumber, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);

                    if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                    {
                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                        string fileDec = _item.DocumentDescription;

                        string fileSFI = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                        if (fileSFI == null)
                        {
                            fileSFI = "";
                        }

                        string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                        if (fileSection == null)
                        {
                            fileSection = "";
                        }
                        string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _SearchedFile.Id, false); //Class Approved Drawing Number
                        if (fileRelatedDAD == null)
                        {
                            fileRelatedDAD = "";
                        }
                        if (fileSFI.Trim().ToUpper() == SFIcode.Trim().ToUpper())
                        {
                            clsStaticGlobal.ClassDrawingSearchedItemCollection.Add(new ClassDrawing { Count = SearchedCount, IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = _SearchedFile.Name, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileSection = fileSection, FileRelatedDAD = fileRelatedDAD, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName, FileUsedIn = "", FileLink = "Go To Location" });
                        }
                    }
                    else
                    {
                        string fileDec = _item.DocumentDescription;
                        clsStaticGlobal.ClassDrawingSearchedItemCollection.Add(new ClassDrawing { Count = SearchedCount, IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = _item.DocumentNumber, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileSection = "", FileRelatedDAD = "", FilePath = "", FileRemark = "", FileRevision = "Unable to check SFI code.!", FileStatus = "File not exist.!", FileUsedIn = "", FileLink = "" });
                    }

                    SearchedCount += 1;
                }

                //foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.DADDrawingFiles)
                //{
                //    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                //    string filePath = folder.FullName + "/" + _item.Name;
                //    string fileName = _item.Name;
                //    clsStaticGlobal.ClassDrawingSearchedItemCollection.Add(new ClassDrawing { Count = SearchedCount, IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                //    SearchedCount += 1;
                //}

                ClassDrawingSearchlistview.ItemsSource = clsStaticGlobal.ClassDrawingSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(ClassDrawingSearchlistview.ItemsSource);
                viewSearch.Filter = UserFilter;

                if (ClassDrawingSearchlistview.IsGrouping == false)
                {
                    CollectionView viewSearched = (CollectionView)CollectionViewSource.GetDefaultView(ClassDrawingSearchlistview.ItemsSource);
                    PropertyGroupDescription groupDescriptionSearched = new PropertyGroupDescription("FileType");
                    viewSearched.GroupDescriptions.Add(groupDescriptionSearched);
                }


                ClassApprovedlistview.ItemsSource = clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing;
                if (ClassApprovedlistview.IsGrouping == false)
                {
                    CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ClassApprovedlistview.ItemsSource);
                    PropertyGroupDescription groupDescription = new PropertyGroupDescription("FileType");
                    view.GroupDescriptions.Add(groupDescription);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ClassDrawingSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.ClassDrawingSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListClassDrawing_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                {
                    item.Count = k;
                    k++;
                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void BindClassApprovedDocuments()
        {
            List<ClassDrawing> classDrawingsTemp = new List<ClassDrawing>();

            foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
            {
                if (item.FileType.ToUpper() == "CLASS APPROVED")
                {
                    classDrawingsTemp.Add(item);
                }
            }

            clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Clear();

            ClassApprovedlistview.Items.Refresh();

            foreach (ClassDrawing item in classDrawingsTemp)
            {
                clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = item.FileName, FileNumber = item.FileNumber, FileDesc = item.FileDesc, FileSection = item.FileSection, FilePath = item.FilePath, FileRemark = item.FileRemark, FileRevision = item.FileRevision, FileStatus = item.FileStatus, FileRelatedDAD = item.FileRelatedDAD, FileUsedIn = "", FileLink = "Go To Location" });

                if (item.FilePath != "")
                {
                    Autodesk.Connectivity.WebServices.File[] SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { item.FilePath });
                    if (SingleFiles.Length != 0)
                    {
                        Autodesk.Connectivity.WebServices.File newFile = SingleFiles[0];

                        FileAssocArray[] attachmentsFileList = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFileAssociationsByMasterIds(new long[] { newFile.MasterId }, FileAssociationTypeEnum.Attachment, true, FileAssociationTypeEnum.Attachment, true, true, true, false);
                        try
                        {
                            foreach (FileAssocArray itemFileAssocArray in attachmentsFileList)
                            {
                                foreach (FileAssoc itemFileAssoc in itemFileAssocArray.FileAssocs)
                                {
                                    if (itemFileAssoc.ParFile != null)
                                    {
                                        Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(itemFileAssoc.ParFile.FolderId);
                                        string filePath = folder.FullName + "/" + itemFileAssoc.ParFile.Name;
                                        string fileName = itemFileAssoc.ParFile.Name;
                                        string fileRemark = itemFileAssoc.ParFile.Comm;
                                        string fileStatus = "";
                                        string fileRevision = "";
                                        string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", itemFileAssoc.Id, false);
                                        if (fileDec == null)
                                        {
                                            fileDec = "";
                                        }
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FileNumber = "", FileDesc = fileDec, FilePath = filePath, FileSection = "", FileRemark = fileRemark, FileRevision = fileRevision, FileStatus = fileStatus, FileRelatedDAD = "", FileUsedIn = newFile.Name, FileLink = "Go To Location" });
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }

                    }
                }
            }


            ClassApprovedlistview.Items.Refresh();

            ClassApprovedlistview.UpdateLayout();

        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    ClassDrawingSearchlistview.UpdateLayout();

                    ClassDrawingSearchlistview.Items.Refresh();

                    foreach (ClassDrawing _item in clsStaticGlobal.ClassDrawingSearchedItemCollection)
                    {
                        if (_item.IsCheckedClassDrawing == true)
                        {
                            bool IsFileExist = false;
                            foreach (ClassDrawing _itemExist in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                            {

                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                                else
                                {
                                    var _itemExistTemp = _itemExist.FileName.Split(new char[] { '.' });
                                    var _itemTemp = _item.FileName.Split(new char[] { '.' });
                                    if (_itemExistTemp[0].ToUpper() == _itemTemp[0].ToUpper())
                                    {
                                        IsFileExist = true;
                                    }
                                }

                            }
                            if (IsFileExist == false)
                            {
                                if (_item.FileType.ToUpper() == "CLASS APPROVED")
                                {
                                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.FileName, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);
                                    if (_SearchedFile != null)
                                    {
                                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = _SearchedFile.Name, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSection = _item.FileSection, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label.ToString(), FileStatus = _SearchedFile.FileLfCyc.LfCycStateName.ToString(), FileRelatedDAD = _item.FileRelatedDAD, FileUsedIn = "" });

                                        //System.Diagnostics.Debugger.Launch();

                                        FileAssocArray[] attachmentsFileList = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFileAssociationsByMasterIds(new long[] { _SearchedFile.MasterId }, FileAssociationTypeEnum.Attachment, false, FileAssociationTypeEnum.Attachment, true, true, true, false);

                                        foreach (FileAssocArray itemFileAssocArray in attachmentsFileList)
                                        {
                                            try
                                            {
                                                foreach (FileAssoc itemFileAssoc in itemFileAssocArray.FileAssocs)
                                                {
                                                    try
                                                    {
                                                        if (itemFileAssoc.CldFile != null)
                                                        {
                                                            File DADfile = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFileById(itemFileAssoc.CldFile.Id);

                                                            if ((DADfile != null) && (DADfile.Id != -1) && (_SearchedFile.Name != DADfile.Name))
                                                            {
                                                                Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(DADfile.FolderId);
                                                                string filePath = folder.FullName + "/" + DADfile.Name;
                                                                string fileName = DADfile.Name;
                                                                string fileRemark = DADfile.Comm;
                                                                string fileStatus = "Exist";
                                                                string fileRevision = "";
                                                                string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", itemFileAssoc.Id, false);
                                                                if (fileDec == null)
                                                                {
                                                                    fileDec = "";
                                                                }

                                                                clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FileNumber = "", FileDesc = fileDec, FileSection = "", FilePath = filePath, FileRemark = fileRemark, FileRevision = fileRevision, FileStatus = fileStatus, FileRelatedDAD = "", FileUsedIn = _SearchedFile.Name, FileLink = "Go To Location" });

                                                            }
                                                        }

                                                        if (itemFileAssoc.ParFile != null)
                                                        {
                                                            File DADfile = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFileById(itemFileAssoc.ParFile.Id);

                                                            if ((DADfile != null) && (DADfile.Id != -1) && (_SearchedFile.Name != DADfile.Name))
                                                            {
                                                                Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(DADfile.FolderId);
                                                                string filePath = folder.FullName + "/" + DADfile.Name;
                                                                string fileName = DADfile.Name;
                                                                string fileRemark = DADfile.Comm;
                                                                string fileStatus = "Exist";
                                                                string fileRevision = "";
                                                                string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", itemFileAssoc.Id, false);
                                                                if (fileDec == null)
                                                                {
                                                                    fileDec = "";
                                                                }

                                                                clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FileNumber = "", FileDesc = fileDec, FileSection = "", FilePath = filePath, FileRemark = fileRemark, FileRevision = fileRevision, FileStatus = fileStatus, FileRelatedDAD = "", FileUsedIn = _SearchedFile.Name, FileLink = "Go To Location" });

                                                            }
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        clsStaticGlobal.ErrHandlerLog(ex);
                                                    }

                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                clsStaticGlobal.ErrHandlerLog(ex);
                                            }

                                        }
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = _item.FileName, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSection = _item.FileSection, FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist", FileRelatedDAD = _item.FileRelatedDAD, FileUsedIn = "", FileLink = "" });
                                    }
                                }
                            }
                        }
                    }
                    ClassApprovedlistview.Items.Refresh();
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            ClassApprovedlistview.UpdateLayout();
        }

        private void cmdClassApprovedRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                    {
                        try
                        {
                            bool isChecked = false;
                            List<ClassDrawing> listOfClassDrawing = new List<ClassDrawing>();

                            foreach (var itemClassApproved in ClassApprovedlistview.Items)
                            {
                                ClassDrawing objClassApprovedNumber = (ClassDrawing)itemClassApproved;

                                if (objClassApprovedNumber.IsCheckedClassDrawing == true)
                                {
                                    if (objClassApprovedNumber.FileType != "DAD")
                                    {
                                        isChecked = true;
                                        listOfClassDrawing.Add(objClassApprovedNumber);
                                        //clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(objClassApprovedNumber);

                                        //try
                                        //{
                                        //    foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                                        //    {
                                        //        if (objClassApprovedNumber.FileName == item.FileUsedIn)
                                        //        {
                                        //            clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(item);
                                        //        }

                                        //    }
                                        //}
                                        //catch (Exception)
                                        //{

                                        //}                                        
                                    }
                                }

                            }

                            foreach (ClassDrawing item in listOfClassDrawing)
                            {
                                clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(item);

                                foreach (ClassDrawing itemDAD in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                                {
                                    if (item.FileName == itemDAD.FileUsedIn)
                                    {
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(itemDAD);
                                    }

                                }
                            }

                            ClassApprovedlistview.Items.Refresh();

                            BindClassApprovedDocuments();

                            if (isChecked == false)
                            {
                                MessageBox.Show("Select single file first.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }

                            //if (ClassApprovedlistview.SelectedItems.Count > 0)
                            //{

                            //    ClassDrawing objClassApprovedNumber = (ClassDrawing)ClassApprovedlistview.SelectedItem;

                            //    if (objClassApprovedNumber.FileType != "DAD")
                            //    {
                            //        clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(objClassApprovedNumber);

                            //        try
                            //        {
                            //            foreach (ClassDrawing item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing)
                            //            {
                            //                if (objClassApprovedNumber.FileName == item.FileUsedIn)
                            //                {
                            //                    clsStaticGlobal.objSingleBuildSpecificationSummary.ListClassDrawing.Remove(item);
                            //                }

                            //            }
                            //        }
                            //        catch (Exception)
                            //        {

                            //        }

                            //        ClassApprovedlistview.Items.Refresh();

                            //        BindClassApprovedDocuments();
                            //    }
                            //    else
                            //    {
                            //        MessageBox.Show("Select only Class Approved files to remove..", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            //    }

                            //}
                            //else
                            //{
                            //    MessageBox.Show("Select single file first.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            //}

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }


                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ClassDrawingSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                //ClassDrawingSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            {  return true;}
               
            else
            {
                //ClassDrawing itemitem = (ClassDrawing)item;

                //if (itemitem.FileNumber.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
                return ((item as ClassDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ClassDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            //return ((item as ClassDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
           // return ((item as ClassDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ClassDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(ClassDrawingSearchlistview.ItemsSource).Refresh();
        }

        private void Hyperlink_OnRequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            try
            {
                string hyperlink = "";
                string filepath = "";
                try
                {

                    filepath = ((ClassDrawing)((System.Windows.FrameworkElement)((System.Windows.FrameworkContentElement)sender).Parent).DataContext).FilePath;
                    hyperlink = clsStaticGlobal.GeHyperLink(filepath);

                    // var urlPart = ((Hyperlink)sender).NavigateUri;
                    if (hyperlink != "")
                    {
                        Process.Start(new ProcessStartInfo(hyperlink));
                    }
                    else
                    {
                        MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

            }
            catch (Exception)
            {

            }

            e.Handled = true;
        }
    }

    public class ClassApprovedFileType : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ClassDrawing classapproved = (ClassDrawing)value;

            if (classapproved.FileType.ToUpper() == "CLASS APPROVED")
            {
                if ((classapproved.FileStatus != null) && (classapproved.FileStatus.ToUpper() == "RELEASE"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return null;
            }

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
