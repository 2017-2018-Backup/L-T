﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareMaterials : ObservableCollection<NameCodePair>
    {
        public static HardwareMaterials LoadList()
        {
            HardwareMaterials items = new HardwareMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "Brass" });
            items.Add(new NameCodePair() { Code = "02", Name = "Hardened Steel Grade 4.4" });
            items.Add(new NameCodePair() { Code = "03", Name = "Hardened Steel Grade 6.6" });
            items.Add(new NameCodePair() { Code = "04", Name = "Hardened Steel Grade 8.8" });
            items.Add(new NameCodePair() { Code = "05", Name = "Hardened Steel Grade 10.9" });
            items.Add(new NameCodePair() { Code = "06", Name = "Hardened Steel Grade 12.9" });
            items.Add(new NameCodePair() { Code = "07", Name = "Hardened Steel Grade 5.6" });
            items.Add(new NameCodePair() { Code = "08", Name = "Mild Steel" });
            items.Add(new NameCodePair() { Code = "09", Name = "Copper Alloys" });
            items.Add(new NameCodePair() { Code = "10", Name = "SS 304" });
            items.Add(new NameCodePair() { Code = "11", Name = "SS 310" });
            items.Add(new NameCodePair() { Code = "12", Name = "SS 316" });
            items.Add(new NameCodePair() { Code = "13", Name = "SS 316 L" });
            items.Add(new NameCodePair() { Code = "14", Name = "SS 304 B" });
            items.Add(new NameCodePair() { Code = "15", Name = "SS 304 L" });
            items.Add(new NameCodePair() { Code = "16", Name = "Hardened Steel Grade 8" });
            items.Add(new NameCodePair() { Code = "17", Name = "Hardened Steel Grade 200 HV" });
            items.Add(new NameCodePair() { Code = "18", Name = "Rubber 45-50 shore" });
            items.Add(new NameCodePair() { Code = "19", Name = "AlBr NES833 Part II" });

            return items;
        }
        public static HardwareMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareMaterials LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareMaterials>(HullOutfitItems.DataPath + @"\Hardware\HardwareMaterials.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareMaterials>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareMaterials.xml");
        }
    }
}
