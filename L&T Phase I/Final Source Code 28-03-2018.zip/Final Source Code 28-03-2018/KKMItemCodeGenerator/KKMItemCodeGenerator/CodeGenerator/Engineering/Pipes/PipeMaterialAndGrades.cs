﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeMaterialAndGrades  : ObservableCollection<NameCodePair>
    {
        public static PipeMaterialAndGrades  LoadList()
        {
            PipeMaterialAndGrades  items = new PipeMaterialAndGrades ();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ASTM A 106 GR A" });
            items.Add(new NameCodePair() { Code = "02", Name = "ASTM A 106 GR B" });
            items.Add(new NameCodePair() { Code = "03", Name = "ASTM A 106 GR C" });
            items.Add(new NameCodePair() { Code = "04", Name = "ASTM A53 GR A" });
            items.Add(new NameCodePair() { Code = "05", Name = "ASTM A53 GR B" });
            items.Add(new NameCodePair() { Code = "06", Name = "ASTM A312 TP304" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASTM A312 TP316" });
            items.Add(new NameCodePair() { Code = "08", Name = "ASTM A312 TP316L" });
            items.Add(new NameCodePair() { Code = "09", Name = "ASTM B75 No.C10200" });
            items.Add(new NameCodePair() { Code = "10", Name = "STS 370" });
            items.Add(new NameCodePair() { Code = "11", Name = "P235" });
            items.Add(new NameCodePair() { Code = "12", Name = "St 33" });
            items.Add(new NameCodePair() { Code = "13", Name = "St 37.4" });
            items.Add(new NameCodePair() { Code = "14", Name = "St 52.4" });
            items.Add(new NameCodePair() { Code = "15", Name = "MTL35" });
            items.Add(new NameCodePair() { Code = "16", Name = "MTL 10" });
            items.Add(new NameCodePair() { Code = "17", Name = "GI" });
            items.Add(new NameCodePair() { Code = "18", Name = "CuNi 70/30" });
            items.Add(new NameCodePair() { Code = "19", Name = "CuNi 90/10" });
            items.Add(new NameCodePair() { Code = "20", Name = "LR Grade 2" });
            items.Add(new NameCodePair() { Code = "21", Name = "AA 6082 T5 " });
            items.Add(new NameCodePair() { Code = "22", Name = "ASTM B88 Type-A" });
            items.Add(new NameCodePair() { Code = "23", Name = "ASTM B88 Type-B" });
            items.Add(new NameCodePair() { Code = "24", Name = "ASTM B88 Type-C" });
            items.Add(new NameCodePair() { Code = "25", Name = "Precision Steel" });
            return items;
        }
        public static PipeMaterialAndGrades  LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeMaterialAndGrades  LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeMaterialAndGrades >(EngineeringItems.DataPath + @"\Pipes\PipeMaterialAndGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Pipes"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Pipes");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeMaterialAndGrades >(this, EngineeringItems.DataPath + @"\Pipes\PipeMaterialAndGrades.xml");
        }

    }
}
