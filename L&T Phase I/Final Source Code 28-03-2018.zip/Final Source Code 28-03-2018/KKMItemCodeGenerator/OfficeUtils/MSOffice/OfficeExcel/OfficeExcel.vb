﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.Data
Imports System.Data.OleDb
Imports OfficeUtils.OfficeHelpers

Public Class OfficeExcel
    ' Methods
    Public Shared Function GetSheetColumnNames(ByVal excelFilePath As String, ByVal sheetName As String) As ArrayList
        Dim list2 As New ArrayList
        Dim connectionString As String = OfficeHelpers.BuildOfficeConnection(excelFilePath, OfficeConnectionStringType.ocsExcel, True)
        Dim str3 As String = String.Empty
        Dim str As String = String.Empty
        Using connection As OleDbConnection = New OleDbConnection(connectionString)
            Dim enumerator As IEnumerator = Nothing
            connection.Open()
            Dim oleDbSchemaTable As DataTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, Nothing)
            If (oleDbSchemaTable Is Nothing) Then
                Return list2
            End If
            Try
                enumerator = oleDbSchemaTable.Rows.GetEnumerator
                Do While enumerator.MoveNext
                    Dim current As DataRow = DirectCast(enumerator.Current, DataRow)
                    str3 = current.Item(2).ToString.Trim
                    If (Strings.Mid(str3, 1, 1) = "'") Then
                        str3 = Strings.Mid(str3, 2)
                    End If
                    If (Strings.Mid(str3, Strings.Len(str3), 1) = "'") Then
                        str3 = Strings.Mid(str3, 1, (Strings.Len(str3) - 1))
                    End If
                    If (Strings.Mid(str3, Strings.Len(str3), 1) = "$") Then
                        str3 = Strings.Mid(str3, 1, (Strings.Len(str3) - 1))
                    End If
                    str = current.Item(3).ToString
                    If (Strings.UCase(Strings.Trim(str3)) = Strings.UCase(Strings.Trim(sheetName))) Then
                        list2.Add(str)
                    End If
                Loop
            Finally
                If TypeOf enumerator Is IDisposable Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
        End Using
        Return list2
    End Function

    Public Shared Function GetSheetNames(ByVal excelFilePath As String) As ArrayList
        Dim list2 As New ArrayList
        Dim connectionString As String = OfficeHelpers.BuildOfficeConnection(excelFilePath, OfficeConnectionStringType.ocsExcel, True)
        Dim str As String = String.Empty
        Using connection As OleDbConnection = New OleDbConnection(connectionString)
            Dim enumerator As IEnumerator = Nothing
            connection.Open()
            Dim oleDbSchemaTable As DataTable = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            If (oleDbSchemaTable Is Nothing) Then
                Return list2
            End If
            Try
                enumerator = oleDbSchemaTable.Rows.GetEnumerator
                Do While enumerator.MoveNext
                    Dim current As DataRow = DirectCast(enumerator.Current, DataRow)
                    str = current.Item(2).ToString.Trim
                    If (Strings.Mid(str, 1, 1) = "'") Then
                        str = Strings.Mid(str, 2)
                    End If
                    If (Strings.Mid(str, Strings.Len(str), 1) = "'") Then
                        str = Strings.Mid(str, 1, (Strings.Len(str) - 1))
                    End If
                    If (Strings.Mid(str, Strings.Len(str), 1) = "$") Then
                        str = Strings.Mid(str, 1, (Strings.Len(str) - 1))
                    End If
                    list2.Add(str)
                Loop
            Finally
                If TypeOf enumerator Is IDisposable Then
                    TryCast(enumerator, IDisposable).Dispose()
                End If
            End Try
        End Using
        Return list2
    End Function

    Public Shared Function GetSheetRows(ByVal excelFilePath As String, ByVal sheetName As String) As DataTable
        Dim dataSet As New DataSet
        Dim connectionString As String = OfficeHelpers.BuildOfficeConnection(excelFilePath, OfficeConnectionStringType.ocsExcel, True)
        Dim selectCommandText As String = ("SELECT * FROM [" & sheetName & "$]")
        Using connection As OleDbConnection = New OleDbConnection(connectionString)
            connection.Open()
            Using adapter As OleDbDataAdapter = New OleDbDataAdapter(selectCommandText, connection)
                adapter.TableMappings.Add("Table", sheetName)
                adapter.Fill(dataSet)
            End Using
            connection.Close()
        End Using
        Return dataSet.Tables.Item(sheetName)
    End Function

End Class