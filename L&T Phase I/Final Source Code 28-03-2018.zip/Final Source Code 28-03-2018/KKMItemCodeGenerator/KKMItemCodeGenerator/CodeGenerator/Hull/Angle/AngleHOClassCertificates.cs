﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleHOClassCertificates : ObservableCollection<NameCodePair>
    {
        public static AngleHOClassCertificates LoadList()
        {
            AngleHOClassCertificates items = new AngleHOClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NO CLASS CERFICATE " });
            items.Add(new NameCodePair() { Code = "01", Name = "LR 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "LR 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "03", Name = "GL 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GL 3.2 CERTIFICATE" });

            return items;
        }

        public static AngleHOClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleHOClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleHOClassCertificates>(HullItems.HullDataPath + @"\Angle\AngleHOClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleHOClassCertificates>(this, HullItems.HullDataPath + @"\Angle\AngleHOClassCertificates.xml");
        }
    }
}
