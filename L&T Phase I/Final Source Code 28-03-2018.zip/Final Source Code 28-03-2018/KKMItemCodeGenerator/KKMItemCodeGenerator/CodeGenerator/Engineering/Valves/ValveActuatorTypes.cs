﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveActuatorTypes : ObservableCollection<NameCodePair>
    {
        public static ValveActuatorTypes LoadList()
        {
            ValveActuatorTypes items = new ValveActuatorTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "HAND WHEEL" });
            items.Add(new NameCodePair() { Code = "02", Name = "LEVER" });
            items.Add(new NameCodePair() { Code = "03", Name = "WORM GEAR" });
            items.Add(new NameCodePair() { Code = "04", Name = "PNEUMATIC" });
            items.Add(new NameCodePair() { Code = "05", Name = "HYDRAULIC" });
            items.Add(new NameCodePair() { Code = "06", Name = "ELECTRICAL" });
            items.Add(new NameCodePair() { Code = "07", Name = "ELECTRO HYDRAULIC" });
            items.Add(new NameCodePair() { Code = "08", Name = "SWING TYPE" });
            return items;
        }
        public static ValveActuatorTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveActuatorTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveActuatorTypes>(EngineeringItems.DataPath + @"\Valves\ValveActuatorTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveActuatorTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveActuatorTypes.xml");
        }

    }
}
