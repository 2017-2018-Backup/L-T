﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingCertificates : ObservableCollection<NameCodePair>
    {
        public static PipeFittingCertificates LoadList()
        {
            PipeFittingCertificates items = new PipeFittingCertificates();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Class I" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            items.Add(new NameCodePair() { Code = "E", Name = "Class B" });
            return items;
        }
        public static PipeFittingCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingCertificates>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingCertificates>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCertificates.xml");
        }

    }
}
