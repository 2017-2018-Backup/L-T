﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersSimplexSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersSimplexSubTypes LoadList()
        {
            StrainersSimplexSubTypes items = new StrainersSimplexSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "MANUAL DRAIN" });
            items.Add(new NameCodePair() { Code = "02", Name = "AUTO BACK FLUSH" });
            items.Add(new NameCodePair() { Code = "03", Name = "PRESSURE DIFFERENTIAL SWITCH" });
            items.Add(new NameCodePair() { Code = "04", Name = "MAGNETIC TYPE" });
            return items;
        }
        public static StrainersSimplexSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersSimplexSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersSimplexSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersSimplexSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersSimplexSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersSimplexSubTypes.xml");
        }

    }
}
