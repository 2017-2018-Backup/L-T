﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveClassSocietys : ObservableCollection<NameCodePair>
    {
        public static ValveClassSocietys LoadList()
        {
            ValveClassSocietys items = new ValveClassSocietys();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "GL" });
            items.Add(new NameCodePair() { Code = "B", Name = "LR" });
            items.Add(new NameCodePair() { Code = "C", Name = "EX-PROOF" });
            items.Add(new NameCodePair() { Code = "D", Name = "FIRE-SAFE" });
            items.Add(new NameCodePair() { Code = "E", Name = "ABS" });
            return items;
        }
        public static ValveClassSocietys LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveClassSocietys LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveClassSocietys>(EngineeringItems.DataPath + @"\Valves\ValveClassSocietys.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveClassSocietys>(this, EngineeringItems.DataPath + @"\Valves\ValveClassSocietys.xml");
        }

    }
}
