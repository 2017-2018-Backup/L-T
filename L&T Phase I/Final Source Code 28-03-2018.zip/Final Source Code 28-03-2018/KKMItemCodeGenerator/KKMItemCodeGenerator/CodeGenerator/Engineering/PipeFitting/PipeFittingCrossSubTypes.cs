﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingCrossSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingCrossSubTypes LoadList()
        {
            PipeFittingCrossSubTypes items = new PipeFittingCrossSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "CROSS" });
            return items;
        }
        public static PipeFittingCrossSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingCrossSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingCrossSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCrossSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingCrossSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingCrossSubTypes.xml");
        }

    }
}
