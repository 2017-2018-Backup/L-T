﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsHOClassCertificates : ObservableCollection<NameCodePair>
    {
        public static BarsHOClassCertificates LoadList()
        {
            BarsHOClassCertificates items = new BarsHOClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "LR 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "LR 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "GL 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GL 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "NO CERTIFICATE" });

            return items;
        }
        public static BarsHOClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsHOClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsHOClassCertificates>(HullOutfitItems.DataPath + @"\Bars\BarsHOClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsHOClassCertificates>(this, HullOutfitItems.DataPath + @"\Bars\BarsHOClassCertificates.xml");
        }
    }
}
