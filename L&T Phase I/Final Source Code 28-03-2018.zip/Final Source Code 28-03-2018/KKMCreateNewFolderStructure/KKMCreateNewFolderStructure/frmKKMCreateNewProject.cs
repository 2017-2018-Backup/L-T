﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Diagnostics;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;

namespace KKMCreateNewProjectStructure
{
    public partial class frmKKMCreateNewProject : Form
    {
        VDF.Vault.Currency.Entities.Folder _rootfolder;
        VDF.Vault.Currency.Connections.Connection _connection;
        ProjectProperties objProjectProperties;

        Cat _ProjectCategory = null;
        Cat _FolderCategory = null;

        public frmKKMCreateNewProject()
        {
            InitializeComponent();
        }

        public frmKKMCreateNewProject(VDF.Vault.Currency.Connections.Connection connection)
        {
            InitializeComponent();
            _connection = connection;
            _rootfolder = connection.FolderManager.RootFolder;
        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdCreateProject_Click(object sender, EventArgs e)
        {
            if ((cmbProjectNumber.SelectedItem != null) && (txtProjectNumber.Text.Trim() != ""))
            {
                string _ProjectNumber = cmbProjectNumber.SelectedItem.ToString() + txtProjectNumber.Text;
                if (IsProjectNumberExist(_ProjectNumber) == true)
                {
                    MessageBox.Show("Project Number : " + _ProjectNumber + " already exist.", "Create New Project", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            objProjectProperties = new ProjectProperties();

            if (IsValidateField() == true)
            {
                try
                {
                    objProjectProperties = AssignToObject(objProjectProperties);

                    if (CreateProjectStructure())
                    {
                        clsStaticGlobal._ConnectionContext.Context.ForceRefresh = true;
                        MessageBox.Show("New project created sucessfully..!", "Create New Project", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                }
                catch (Exception)
                {

                }

            }
        }

        private bool CreateProjectStructure()
        {
            try
            {
                Cat[] _Categories = _connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);

                foreach (Cat _cat in _Categories)
                {
                    if (_cat.Name.Trim().ToUpper() == "PROJECT")
                    {
                        _ProjectCategory = _cat;
                    }
                    if (_cat.Name.Trim().ToUpper() == "FOLDER")
                    {
                        _FolderCategory = _cat;
                    }
                }

                Folder _ProjectFolder = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(objProjectProperties.ProjectNumber, _rootfolder.Id, false, _ProjectCategory.Id);
                UpdateMainFolderProjectProperties(_ProjectFolder);

                Folder firstlevelContractCell = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Contract Cell", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelContractCell);
                Folder firstlevelDesignandEngineering = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Design and Engineering", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelDesignandEngineering);
                Folder secondlevelBasicDesignDrawings_DesignInternal = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Basic Design Drawings - Design Internal", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelBasicDesignDrawings_DesignInternal);
                Folder thirdlevelDesignInternal1_HULL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("1.HULL", secondlevelBasicDesignDrawings_DesignInternal.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelDesignInternal1_HULL);
                Folder thirdlevelDesignInternal2_HULLOUTFIT = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("2.HULL OUTFIT", secondlevelBasicDesignDrawings_DesignInternal.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelDesignInternal2_HULLOUTFIT);
                Folder thirdlevelDesignInternal3_ENGINEERING = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("3.ENGINEERING", secondlevelBasicDesignDrawings_DesignInternal.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelDesignInternal3_ENGINEERING);
                Folder thirdlevelDesignInternal4_ELECTRICAL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("4.ELECTRICAL", secondlevelBasicDesignDrawings_DesignInternal.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelDesignInternal4_ELECTRICAL);
                Folder secondlevelChangeRequest = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Change Request", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelChangeRequest);
                Folder secondlevelClassApprovedDrawings = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Class Approved Drawings", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelClassApprovedDrawings);
                Folder thirdlevelClassApproved1_HULL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("1.HULL", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApproved1_HULL);
                Folder thirdlevelClassApproved2_HULLOUTFIT = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("2.HULL OUTFIT", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApproved2_HULLOUTFIT);
                Folder thirdlevelClassApproved3_ENGINEERING = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("3.ENGINEERING", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApproved3_ENGINEERING);
                Folder thirdlevelClassApproved4_ELECTRICAL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("4.ELECTRICAL", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApproved4_ELECTRICAL);
                Folder thirdlevelClassApprovedDAD = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("DAD", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApprovedDAD);
                Folder thirdlevelClassApprovedLocalApprovedDrawings = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Local Approved Drawings", secondlevelClassApprovedDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelClassApprovedLocalApprovedDrawings);
                Folder secondlevelNavyApprovedDocuments = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Navy Approved Documents", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelNavyApprovedDocuments);
                Folder thirdlevelNavyApproved1_HULL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("1.HULL", secondlevelNavyApprovedDocuments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelNavyApproved1_HULL);
                Folder thirdlevelNavyApproved2_HULLOUTFIT = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("2.HULL OUTFIT", secondlevelNavyApprovedDocuments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelNavyApproved2_HULLOUTFIT);
                Folder thirdlevelNavyApproved3_ENGINEERING = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("3.ENGINEERING", secondlevelNavyApprovedDocuments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelNavyApproved3_ENGINEERING);
                Folder thirdlevelNavyApproved4_ELECTRICAL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("4.ELECTRICAL", secondlevelNavyApprovedDocuments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelNavyApproved4_ELECTRICAL);
                Folder secondlevelProductionDrawings = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Production Drawings", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelProductionDrawings);
                Folder thirdlevelProduction1_HULL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("1.HULL", secondlevelProductionDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelProduction1_HULL);
                Folder thirdlevelProduction2_HULLOUTFIT = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("2.HULL OUTFIT", secondlevelProductionDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelProduction2_HULLOUTFIT);
                Folder thirdlevelProduction3_ENGINEERING = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("3.ENGINEERING", secondlevelProductionDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelProduction3_ENGINEERING);
                Folder thirdlevelProduction4_ELECTRICAL = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("4.ELECTRICAL", secondlevelProductionDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelProduction4_ELECTRICAL);
                Folder thirdlevelProductionMASTERDRAWINGLIST = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("MASTER DRAWING LIST", secondlevelProductionDrawings.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(thirdlevelProductionMASTERDRAWINGLIST);
                Folder secondlevelPurchaseData = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Purchase Data", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelPurchaseData);
                Folder secondlevelReferenceDrawingorDocuments = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Reference Drawing or Documents", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelReferenceDrawingorDocuments);
                Folder secondlevelSOTRforNAVY = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("SOTR for NAVY", firstlevelDesignandEngineering.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelSOTRforNAVY);

                clsStaticGlobal.GoLocationFolder = secondlevelSOTRforNAVY;

                Folder firstlevelDesignandSpecifications = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Design and Specifications", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelDesignandSpecifications);
                Folder firstlevelEquipmentManual = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Equipment Manual", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelEquipmentManual);
                Folder firstlevelKnowledgeManagement = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Knowledge Management", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelKnowledgeManagement);
                Folder firstlevelMails = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Mails", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelMails);
                Folder firstlevelManufacturing = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Manufacturing", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelManufacturing);
                Folder firstlevelOthers = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Others", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelOthers);
                Folder firstlevelPlanning = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Planning", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelPlanning);
                Folder firstlevelProcurement = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Procurement", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelProcurement);
                Folder firstlevelProposal = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Proposal", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelProposal);
                Folder firstlevelQC_QA_NDT = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("QC-QA-NDT", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelQC_QA_NDT);
                Folder firstlevelSeaTrials = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Sea Trials", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelSeaTrials);
                Folder firstlevelStores = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Stores", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelStores);
                Folder firstlevelWelding = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Welding", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelWelding);

                Folder firstlevelCustomerComments = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Customer Comments", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelCustomerComments);
                Folder secondlevelBasicCustomerComments_CustomerDocumnetsFolder = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Customer Documents Folder", firstlevelCustomerComments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelBasicCustomerComments_CustomerDocumnetsFolder);
                Folder secondlevelBasicCustomerComments_LandTDocumnetsFolder = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("L&T Documents Folder", firstlevelCustomerComments.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(secondlevelBasicCustomerComments_LandTDocumnetsFolder);

                Folder firstlevelSurveyorComments = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Surveyor Comments", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelSurveyorComments);

                Folder firstlevelBuildSpecification = _connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Build Specification", _ProjectFolder.Id, false, _FolderCategory.Id);
                UpdateSubFolderProperties(firstlevelBuildSpecification);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: creating folder structure " + Environment.NewLine + ex.Message + Environment.NewLine + "Please check access rights..", "Create New Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }

        private bool UpdateMainFolderProjectProperties(Folder _ProjectFolder)
        {
            bool _Sucess = true;

            try
            {
                List<PropInstParam> propInstParams = new List<PropInstParam>();
                PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

                if (_ProjectFolder.Cat.CatName.ToUpper() == "PROJECT")
                {
                    PropInst[] source = _connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FLDR", new long[] { _ProjectFolder.Id });

                    foreach (PropDef def in _connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FLDR"))
                    {
                        if (def.IsSys == false & def.IsAct == true)
                        {
                            if (def.DispName == "PIM")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.PIM;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Project Title")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ProjectTitle;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Category of Project")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CategoryofProject;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Consultant")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Consultant;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Contractual Delivery Date")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ContractualDeliveryDate.Date;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Customer LOI Number")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CustomerLOINumber;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Customer PO Number")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.CustomerPONumber;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Delivery Condition")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.DeliveryCondition;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Description")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Description;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "DOC Enclosed")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.DOCEnclosed;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Is Site Work Required")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.IsSiteWorkRequired;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Licensor")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Licensor;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Classification Society")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ClassificationSociety;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Leading Classification Society")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.LeadingClassificationSociety;
                                propInstParams.Add(propInst);
                            }
                            
                            //txtClassificationSociety
                            if (def.DispName == "LOI Reciept Date")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.LOIRecieptDate.Date;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Owner")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.Owner;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "PO Reciept Date")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.PORecieptDate.Date;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Product End User")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ProductEndUser;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Project Location")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ProjectLocation;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Responsible / Project Owner")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ResponsibleProjectOwner;
                                propInstParams.Add(propInst);
                            }


                            if (def.DispName == "SBU Department")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.SBUDepartment;
                                propInstParams.Add(propInst);
                            }
                            if (def.DispName == "Transportation Scope")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.TransportationScope;
                                propInstParams.Add(propInst);
                            }

                            if (def.DispName == "Type Dsgn Rqd from L&T")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.TypeDesignRqdfromLT;
                                propInstParams.Add(propInst);
                            }


                            if (def.DispName == "Type of Guarantee Required")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.TypeofGuaranteeRequired;
                                propInstParams.Add(propInst);
                            }


                            if (def.DispName == "Zero Date")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ZeroDate.Date;
                                propInstParams.Add(propInst);
                            }

                        }
                    }
                }

                PropInstParamArray propInstParamsArray = new PropInstParamArray();
                propInstParamsArray.Items = propInstParams.ToArray();
                propInstParamsArrays[0] = propInstParamsArray;
                _connection.WebServiceManager.DocumentServiceExtensions.UpdateFolderProperties(new long[] { _ProjectFolder.Id }, propInstParamsArrays);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: updating folder properties " + Environment.NewLine + ex.Message, "Create New Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return _Sucess;
        }

        private bool UpdateSubFolderProperties(Folder _subFolder)
        {
            bool _Sucess = true;

            try
            {
                List<PropInstParam> propInstParams = new List<PropInstParam>();
                PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

                if (_subFolder.Cat.CatName.ToUpper() == "FOLDER")
                {
                    PropInst[] source = _connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FLDR", new long[] { _subFolder.Id });

                    foreach (PropDef def in _connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FLDR"))
                    {
                        if (def.IsSys == false & def.IsAct == true)
                        {
                            if (def.DispName == "Project Title")
                            {
                                PropInstParam propInst = new PropInstParam();
                                propInst.PropDefId = def.Id;
                                propInst.Val = objProjectProperties.ProjectNumber;
                                propInstParams.Add(propInst);
                            }

                        }
                    }
                }

                PropInstParamArray propInstParamsArray = new PropInstParamArray();
                propInstParamsArray.Items = propInstParams.ToArray();
                propInstParamsArrays[0] = propInstParamsArray;
                _connection.WebServiceManager.DocumentServiceExtensions.UpdateFolderProperties(new long[] { _subFolder.Id }, propInstParamsArrays);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: updating folder properties " + Environment.NewLine + ex.Message, "Create New Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return _Sucess;
        }

        private bool IsProjectNumberExist(string _ProjectNumber)
        {
            bool _IsExist = false;
            try
            {
                // check for any sub Folders.
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = _connection.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.EntityName.Trim() == _ProjectNumber)
                        {
                            _IsExist = true;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }

            return _IsExist;
        }

        private bool IsValidateField()
        {
            bool isvalid = true;

            if (cmbProjectNumber.SelectedItem == null)
            {
                errorProvider1.SetError(cmbProjectNumber, "Select Project Code");
                isvalid = false;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (txtProjectNumber.Text.Trim() == "")
            {
                errorProvider2.SetError(txtProjectNumber, "Enter Project Number");
                isvalid = false;
            }
            else
            {
                errorProvider2.Clear();
            }

            if (txtConsultant.Text.Trim() == "")
            {
                errorProvider3.SetError(txtConsultant, "Enter Value For Consultant");
                isvalid = false;
            }
            else
            {
                errorProvider3.Clear();
            }

            if (txtTransportationScope.Text.Trim() == "")
            {
                errorProvider4.SetError(txtTransportationScope, "Enter Value For Transportation Scope");
                isvalid = false;
            }
            else
            {
                errorProvider4.Clear();
            }

            if (cmbIsSiteWorkRequired.SelectedItem == null)
            {
                errorProvider5.SetError(cmbIsSiteWorkRequired, "Select Is Site Work Required");
                isvalid = false;
            }
            else
            {
                errorProvider5.Clear();
            }

            if (txtCategoryofProject.Text.Trim() == "")
            {
                errorProvider6.SetError(txtCategoryofProject, "Enter Value For Category Of Project");
                isvalid = false;
            }
            else
            {
                errorProvider6.Clear();
            }

            if (txtPIM.Text.Trim() == "")
            {
                errorProvider7.SetError(txtPIM, "Enter Value For PIM");
                isvalid = false;
            }
            else
            {
                errorProvider7.Clear();
            }

            return isvalid;
        }

        private ProjectProperties AssignToObject(ProjectProperties _objProjectProperties)
        {
            _objProjectProperties.ProjectNumber = cmbProjectNumber.SelectedItem.ToString() + txtProjectNumber.Text;
            _objProjectProperties.ProjectTitle = txtProjectTitle.Text;
            _objProjectProperties.Description = txtDescription.Text;
            _objProjectProperties.ZeroDate = dtpZeroDate.Value;
            _objProjectProperties.Consultant = txtConsultant.Text;
            _objProjectProperties.ProductEndUser = txtProductEndUser.Text;
            _objProjectProperties.DOCEnclosed = txtDOCEnclosed.Text;
            _objProjectProperties.TransportationScope = txtTransportationScope.Text;
            _objProjectProperties.DeliveryCondition = txtDeliveryCondition.Text;
            _objProjectProperties.TypeofGuaranteeRequired = txtTypeofGuaranteeRequired.Text;
            _objProjectProperties.IsSiteWorkRequired = cmbIsSiteWorkRequired.SelectedItem.ToString();
            _objProjectProperties.TypeDesignRqdfromLT = txtTypeDesignRqdfromLT.Text;
            _objProjectProperties.Licensor = txtLicensor.Text;

            try
            {
                if (lstClassificationSociety.CheckedItems.Count > 0)
                {
                    string itemcollection = "";
                    foreach (var item in lstClassificationSociety.CheckedItems)
                    {
                        if (itemcollection == "")
                        {
                            itemcollection = item.ToString();
                        }
                        else
                        {
                            itemcollection = itemcollection + "; " + item.ToString();
                        }

                    }
                    _objProjectProperties.ClassificationSociety = itemcollection;
                }
                else
                {
                    _objProjectProperties.ClassificationSociety = "";
                }

            }
            catch (Exception)
            {
                _objProjectProperties.ClassificationSociety = "";
            }


            try
            {
                if (cmbLeadingSociety.SelectedItem != null)
                {
                    _objProjectProperties.LeadingClassificationSociety = cmbLeadingSociety.SelectedItem.ToString();
                }
                else
                {
                    _objProjectProperties.LeadingClassificationSociety = "N/A";
                }

            }
            catch (Exception)
            {
                _objProjectProperties.LeadingClassificationSociety = "N/A";
            }

            _objProjectProperties.CategoryofProject = txtCategoryofProject.Text;
            _objProjectProperties.PIM = txtPIM.Text;
            _objProjectProperties.ContractualDeliveryDate = dtpContractualDeliveryDate.Value;
            _objProjectProperties.PORecieptDate = dtpPORecieptDate.Value;
            _objProjectProperties.LOIRecieptDate = dtpLOIRecieptDate.Value;
            _objProjectProperties.CustomerPONumber = txtCustomerPONumber.Text;
            _objProjectProperties.CustomerLOINumber = txtCustomerLOINumber.Text;
            _objProjectProperties.Owner = txtOwner.Text;
            _objProjectProperties.SBUDepartment = txtSBUDepartment.Text;
            _objProjectProperties.ResponsibleProjectOwner = txtResponsibleProjectOwner.Text;
            _objProjectProperties.ProjectLocation = txtProjectLocation.Text;

            return _objProjectProperties;
        }

        private void frmKKMCreateNewFolder_Load(object sender, EventArgs e)
        {
            //cmbClassificationSociety.SelectedIndex = 0;
        }

        private void txtProjectNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void lstClassificationSociety_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbLeadingSociety.Items.Clear();
            cmbLeadingSociety.Items.Add("N/A");
            cmbLeadingSociety.Items.Add("ALL");
            if (lstClassificationSociety.CheckedItems.Count > 0)
            {
                foreach (var item in lstClassificationSociety.CheckedItems)
                {
                    cmbLeadingSociety.Items.Add(item.ToString());
                }
            }
            
        }
    }
}
