﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KKMCustomerComment;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;

namespace KKMCustomerComments
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlRelevantDocByCustomer : Window
    {
        public System.Windows.Forms.DialogResult DialogResUserControlRelevantDocByCustomer = System.Windows.Forms.DialogResult.Cancel;
        bool isEditMode = false;
        public UserControlRelevantDocByCustomer(bool _isEditMode)
        {
            InitializeComponent();
            isEditMode = _isEditMode;

            //if (isEditMode == false)
            //{
            //    cmdAddApprovedDocument.Visibility = Visibility.Hidden;
            //    cmdSave.Visibility = Visibility.Hidden;
            //    cmdRemove.Visibility = Visibility.Hidden;
            //}
            try
            {
                if (clsStaticGlobal.IsReadOnly == true)
                {
                    cmdAddApprovedDocument.Visibility = Visibility.Hidden;
                    cmdSave.Visibility = Visibility.Hidden;
                    cmdRemove.Visibility = Visibility.Hidden;
                }
                else
                {
                    cmdAddApprovedDocument.Visibility = Visibility.Visible;
                    cmdSave.Visibility = Visibility.Visible;
                    cmdRemove.Visibility = Visibility.Visible;
                }
            }
            catch (Exception)
            {
            }
            try
            {
                clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection.Clear();
                int SearchedCount = 1;
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.RelevantDocByCustomerFiles)
                {
                    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                    string filePath = folder.FullName + "/" + _item.Name;
                    string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                    string fileName = _item.Name;
                    int fileExtPos = fileName.LastIndexOf(".");
                    //if (fileExtPos >= 0)
                    //    fileName = fileName.Substring(0, fileExtPos);
                    string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _item.Id, false);
                    if (fileDec == null)
                    {
                        fileDec = "";
                    }

                    clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection.Add(new CustomerRelatedDocument { Count = SearchedCount, IsCheckedCustomerRelatedDocument = false, FileType = _item.Cat.CatName, FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                    SearchedCount += 1;
                }

                //clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(CustomerRelatedDocumentSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListCustomerRelatedDocuments_CollectionChanged);

                CustomerRelatedDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(CustomerRelatedDocumentSearchGridViewBox.ItemsSource);
                viewSearch.Filter = UserFilter;
                CustomerRelatedDocumentSearchGridViewBox.UpdateLayout();

                if (clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                {
                    CustomerRelatedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments;
                    CustomerRelatedDocumentGridViewBox.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void CustomerRelatedDocumentSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListCustomerRelatedDocuments_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            //System.Diagnostics.Debugger.Launch();
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                {
                    item.Count = k;
                    k++;

                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                    //item.FileRemark = _remark;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlRelevantDocByCustomer = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    CustomerRelatedDocumentSearchGridViewBox.UpdateLayout();
                    CustomerRelatedDocumentGridViewBox.Items.Refresh();
                    foreach (CustomerRelatedDocument _item in clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection)
                    {
                        if (_item.IsCheckedCustomerRelatedDocument == true)
                        {
                            bool IsFileExist = false;
                            foreach (CustomerRelatedDocument _itemExist in clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                            {
                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                            }

                            if (IsFileExist == false)
                            {
                                clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Add(new CustomerRelatedDocument { IsCheckedCustomerRelatedDocument = false, FileType = _item.FileType, FileName = _item.FileName, FileDesc = _item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString() });
                            }
                        }
                    }
                    CustomerRelatedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments;
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            CustomerRelatedDocumentGridViewBox.UpdateLayout();
        }

        private void cmdRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    bool isChecked = false;

                    if (clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                    {
                        try
                        {
                            List<CustomerRelatedDocument> listOfCustomerRelatedDocument = new List<CustomerRelatedDocument>();

                            foreach (var itemCustDoc in CustomerRelatedDocumentGridViewBox.Items)
                            {
                                CustomerRelatedDocument objCustomerRelatedDocument = (CustomerRelatedDocument)itemCustDoc;

                                if (objCustomerRelatedDocument.IsCheckedCustomerRelatedDocument == true)
                                {
                                    isChecked = true;
                                    listOfCustomerRelatedDocument.Add(objCustomerRelatedDocument);
                                    //try
                                    //{
                                    //    clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Remove(objCustomerRelatedDocument);
                                    //}
                                    //catch (Exception)
                                    //{

                                    //}
                                }
                            }

                            foreach (CustomerRelatedDocument item in listOfCustomerRelatedDocument)
                            {
                                clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Remove(item);
                                CustomerRelatedDocumentGridViewBox.Items.Refresh();
                            }

                            //if (CustomerRelatedDocumentGridViewBox.SelectedCells.Count > 0)
                            //{
                            //    CustomerRelatedDocument objCustomerRelatedDocument = (CustomerRelatedDocument)CustomerRelatedDocumentGridViewBox.SelectedCells[0].Item;
                            //    clsStaticGlobal.objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Remove(objCustomerRelatedDocument);
                            //    CustomerRelatedDocumentGridViewBox.UpdateLayout();
                            //}
                            //else
                            //{
                            //    MessageBox.Show("Select single file first.", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                            //}

                            CustomerRelatedDocumentGridViewBox.Items.Refresh();

                            if (isChecked == false)
                            {
                                MessageBox.Show("Select file first.", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }

            }
            else
            {
                MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CustomerRelatedDocumentSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                CustomerRelatedDocumentSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlRelevantDocByCustomer = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
                return true;
            else
                //return ((item as CustomerRelatedDocument).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            return ((item as CustomerRelatedDocument).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as CustomerRelatedDocument).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(CustomerRelatedDocumentSearchGridViewBox.ItemsSource).Refresh();
        }
    }

}
