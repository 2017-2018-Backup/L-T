﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleStandards : ObservableCollection<NameCodePair>
    {
        public static AngleStandards LoadList()
        {
            AngleStandards items = new AngleStandards();
            items.Add(new NameCodePair() { Code = "01", Name = "NON - STD" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISA" });           
            return items;
        }
        public static AngleStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleStandards LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleStandards>(HullItems.HullDataPath + @"\Angle\AngleStandards.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleStandards>(this, HullItems.HullDataPath + @"\Angle\AngleStandards.xml");
        }
    }
}
