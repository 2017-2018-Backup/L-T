﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveBallSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveBallSubTypes LoadList()
        {
            ValveBallSubTypes items = new ValveBallSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "FULL BORE" });
            items.Add(new NameCodePair() { Code = "02", Name = "REDUCED BORE" });
            items.Add(new NameCodePair() { Code = "03", Name = "THREE WAY - L PORT" });
            items.Add(new NameCodePair() { Code = "04", Name = "THREE WAY - T PORT" });
            items.Add(new NameCodePair() { Code = "05", Name = "4 WAY" });
            return items;
        }
        public static ValveBallSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveBallSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveBallSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveBallSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveBallSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveBallSubTypes.xml");
        }

    }
}
