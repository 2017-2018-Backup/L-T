﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareThicknesses : ObservableCollection<NameCodePair>
    {
        public static HardwareThicknesses LoadList()
        {
            HardwareThicknesses items = new HardwareThicknesses();
            items.Add(new NameCodePair() { Code = "00", Name = "For Bolt, Screw, Stud, Grub Screw & Nut" });
            items.Add(new NameCodePair() { Code = "02", Name = "2 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "3 mm" });
            items.Add(new NameCodePair() { Code = "40", Name = "40 mm" });

            return items;
        }
        public static HardwareThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareThicknesses>(HullOutfitItems.DataPath + @"\Hardware\HardwareThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareThicknesses>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareThicknesses.xml");
        }
    }
}
