﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingFemaleConnectorTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingFemaleConnectorTypes LoadList()
        {
            PipeFittingFemaleConnectorTypes items = new PipeFittingFemaleConnectorTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "FEMALE CONNECTOR" });
            return items;
        }
        public static PipeFittingFemaleConnectorTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingFemaleConnectorTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingFemaleConnectorTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingFemaleConnectorTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingFemaleConnectorTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingFemaleConnectorTypes.xml");
        }

    }
}
