﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersDuplexSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersDuplexSubTypes LoadList()
        {
            StrainersDuplexSubTypes items = new StrainersDuplexSubTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "MANUAL DRAIN" });
            items.Add(new NameCodePair() { Code = "02", Name = "AUTO BACK FLUSH" });
            items.Add(new NameCodePair() { Code = "03", Name = "PRESSURE DIFFERENTIAL SWITCH" });
            items.Add(new NameCodePair() { Code = "04", Name = "MAGNETIC TYPE" });
            return items;
        }
        public static StrainersDuplexSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersDuplexSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersDuplexSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersDuplexSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersDuplexSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersDuplexSubTypes.xml");
        }

    }
}
