﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HullItems : ObservableCollection<NameCodePair>
    {
        public static String HullDataPath = "";
        public static HullItems LoadList()
        {
            HullItems items = new HullItems();
            items.Add(new NameCodePair() { Code = "PL", Name = "PLATE" });
            items.Add(new NameCodePair() { Code = "BL", Name = "BARS" });
            items.Add(new NameCodePair() { Code = "AN", Name = "ANGLE" });
            return items;
        }
        public static HullItems LoadFromExcel(String path)
        {
            return null;
        }

        public static HullItems LoadFromXml(string path)
        {
            HullItems.HullDataPath = path;
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HullItems>(HullItems.HullDataPath + @"\Items.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HullItems>(this, HullItems.HullDataPath + @"\Items.xml");
        }

    }
}
