﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static PipeFittingMaterialGrades LoadList()
        {
            PipeFittingMaterialGrades items = new PipeFittingMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "JIS G4051-SD25C" });
            items.Add(new NameCodePair() { Code = "02", Name = "JIS G4303-SUS316" });
            items.Add(new NameCodePair() { Code = "03", Name = "JIS H3250-C3604" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN" });
            items.Add(new NameCodePair() { Code = "05", Name = "ASTM A 105" });
            items.Add(new NameCodePair() { Code = "06", Name = "ASTM A 182" });
            items.Add(new NameCodePair() { Code = "07", Name = "ASTM A 536" });
            items.Add(new NameCodePair() { Code = "08", Name = "ASTM A 234 WPB" });
            items.Add(new NameCodePair() { Code = "09", Name = "BRASS" });
            items.Add(new NameCodePair() { Code = "10", Name = "SS" });
            items.Add(new NameCodePair() { Code = "11", Name = "MS Galv" });
            items.Add(new NameCodePair() { Code = "12", Name = "GM" });
            items.Add(new NameCodePair() { Code = "13", Name = "Cu-Ni" });
            items.Add(new NameCodePair() { Code = "14", Name = "Cu" });
            items.Add(new NameCodePair() { Code = "15", Name = "SS 316L" });
            items.Add(new NameCodePair() { Code = "16", Name = "ASTM A 106" });
            items.Add(new NameCodePair() { Code = "17", Name = "Precision Steel" });
            items.Add(new NameCodePair() { Code = "18", Name = "AA 6082 T5" });
            items.Add(new NameCodePair() { Code = "19", Name = "Rubber" });
            return items;
        }
        public static PipeFittingMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingMaterialGrades LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingMaterialGrades>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingMaterialGrades>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingMaterialGrades.xml");
        }

    }
}
