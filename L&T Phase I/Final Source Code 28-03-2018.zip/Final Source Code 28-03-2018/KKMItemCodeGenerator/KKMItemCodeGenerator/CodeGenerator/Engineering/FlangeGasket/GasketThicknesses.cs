﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class GasketThicknesses : ObservableCollection<NameCodePair>
    {
        public static GasketThicknesses LoadList()
        {
            GasketThicknesses items = new GasketThicknesses();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "2 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "2.5 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "3-mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "3.5 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "4 mm" });
            return items;
        }
        public static GasketThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static GasketThicknesses LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<GasketThicknesses>(EngineeringItems.DataPath + @"\FlangeGasket\GasketThicknesses.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<GasketThicknesses>(this, EngineeringItems.DataPath + @"\FlangeGasket\GasketThicknesses.xml");
        }

    }
}
