﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersCertificates : ObservableCollection<NameCodePair>
    {
        public static StrainersCertificates LoadList()
        {
            StrainersCertificates items = new StrainersCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "3.2" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            return items;
        }
        public static StrainersCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersCertificates>(EngineeringItems.DataPath + @"\Strainers\StrainersCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersCertificates>(this, EngineeringItems.DataPath + @"\Strainers\StrainersCertificates.xml");
        }

    }
}
