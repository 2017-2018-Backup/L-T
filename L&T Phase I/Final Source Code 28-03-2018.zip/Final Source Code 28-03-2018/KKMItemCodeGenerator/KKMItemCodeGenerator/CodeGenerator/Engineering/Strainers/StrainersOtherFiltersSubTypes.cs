﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersOtherFiltersSubTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersOtherFiltersSubTypes LoadList()
        {
            StrainersOtherFiltersSubTypes items = new StrainersOtherFiltersSubTypes();
            return items;
        }
        public static StrainersOtherFiltersSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersOtherFiltersSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersOtherFiltersSubTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersOtherFiltersSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersOtherFiltersSubTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersOtherFiltersSubTypes.xml");
        }

    }
}
