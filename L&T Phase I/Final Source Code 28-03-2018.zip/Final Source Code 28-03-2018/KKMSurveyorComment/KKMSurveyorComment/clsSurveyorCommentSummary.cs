﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Autodesk.Connectivity.WebServices;

namespace KKMSurveyorComment
{
    public class SurveyorCommentsCollection
    {
        public List<SingleSurveyorCommentSummary> collectionSurveyorCommentSummary = new List<SingleSurveyorCommentSummary> { };
    }

    public class SingleSurveyorCommentSummary
    {
        public int SurveyorCommentNumber { get; set; }
        public int SurveyorCount { get; set; }
        public int SurveyorCommentCount { get; set; }
        public string SurveyorCommentCommentNumber { get; set; }
        public string SurveyorCommentName { get; set; }
        public string SurveyorCommentFileName { get; set; }
        public string SurveyorCommentFileFullPath { get; set; }
        public string OriginatedDate { get; set; }
        public string RelatedProject { get; set; }
        public string ClassApprovedDocument { get; set; }
        public string DrawingRevision { get; set; }
        public string ClassificationSociety { get; set; }       
        public List<string> ClassificationSocieties = new List<string> { };
        public string SubParaRef { get; set; }
        public string FunctionalGroup { get; set; }
        public string IssueNumber { get; set; }
        public string DrawingRemark { get; set; }
        public string LRremark { get; set; }
        public string Comment { get; set; }
        public string DrawingStatus { get; set; }
        public string EditCommentRemark { get; set; }
        public string RelatedDocumentDADs { get; set; }
        public string ReferenceDocuments { get; set; }
        public string ClassApprovedDocuments { get; set; }
        public string LifeCycle { get; set; }
        public string LifeCycleComment { get; set; }
        public ObservableCollection<ClassApprovedDrawing> ListClassApprovedDrawing = new ObservableCollection<ClassApprovedDrawing> { };
        public ObservableCollection<RelatedDocumentDAD> ListRelatedDocumentDAD = new ObservableCollection<RelatedDocumentDAD> { };
        public ObservableCollection<ReferenceDocument> ListReferenceDocument = new ObservableCollection<ReferenceDocument> { };

    }

    public class ClassApprovedDrawing : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }
        public string FileSection { get; set; }
        public string FileRelatedDAD { get; set; }

        private bool _IsCheckeClassApprovedDrawing;
        public bool IsCheckedClassApprovedDrawing
        {
            get { return _IsCheckeClassApprovedDrawing; }
            set
            {
                _IsCheckeClassApprovedDrawing = value;
                OnPropertyChanged("IsCheckedClassApprovedDrawing");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class RelatedDocumentDAD : INotifyPropertyChanged
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string FileDesc { get; set; }
        public string FileType { get; set;}
        public string FilePath { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }

        private bool _IsCheckedRelatedDocumentDAD;
        public bool IsCheckedRelatedDocumentDAD
        {
            get { return _IsCheckedRelatedDocumentDAD; }
            set
            {
                if (_IsCheckedRelatedDocumentDAD != value)
                {
                    _IsCheckedRelatedDocumentDAD = value;
                    OnPropertyChanged("IsCheckedRelatedDocumentDAD");
                }
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class ReferenceDocument : INotifyPropertyChanged
    {
        public int Count { get; set; }

        public string FileName { get; set; }
        public string FileDesc { get; set; }
        public string FilePath { get; set; }
        public string FileType { get; set; }
        public string FileRevision { get; set; }
        public string FileRemark { get; set; }
        public string FileStatus { get; set; }

        private bool _IsCheckedReferenceDocument;
        public bool IsCheckedReferenceDocument
        {
            get { return _IsCheckedReferenceDocument; }
            set
            {
                _IsCheckedReferenceDocument = value;
                OnPropertyChanged("IsCheckedReferenceDocument");
            }
        }
        protected virtual void OnPropertyChanged(string property = "")
        {
            if (this.PropertyChanged != null) this.PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }    
}
