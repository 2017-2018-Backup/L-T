﻿namespace KKMBuildSpecifications
{
    partial class frmBuildSpecificationLifecycle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuildSpecificationLifecycle));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.m_categoryComboBox = new System.Windows.Forms.ComboBox();
            this.m_lifecycleDefComboBox = new System.Windows.Forms.ComboBox();
            this.txtLifeCycleComment = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmdCancle = new System.Windows.Forms.Button();
            this.cmdProceed = new System.Windows.Forms.Button();
            this.cmdPostDeliveryLifecycle = new System.Windows.Forms.ComboBox();
            this.txtBuildSpecificationCustomerNumber = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(567, 215);
            this.panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.m_categoryComboBox);
            this.groupBox1.Controls.Add(this.m_lifecycleDefComboBox);
            this.groupBox1.Controls.Add(this.txtLifeCycleComment);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmdCancle);
            this.groupBox1.Controls.Add(this.cmdProceed);
            this.groupBox1.Controls.Add(this.cmdPostDeliveryLifecycle);
            this.groupBox1.Controls.Add(this.txtBuildSpecificationCustomerNumber);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(9, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(546, 193);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lifecycle";
            // 
            // m_categoryComboBox
            // 
            this.m_categoryComboBox.FormattingEnabled = true;
            this.m_categoryComboBox.Items.AddRange(new object[] {
            "Pending",
            "Close"});
            this.m_categoryComboBox.Location = new System.Drawing.Point(68, 116);
            this.m_categoryComboBox.Name = "m_categoryComboBox";
            this.m_categoryComboBox.Size = new System.Drawing.Size(168, 25);
            this.m_categoryComboBox.TabIndex = 10;
            this.m_categoryComboBox.Visible = false;
            // 
            // m_lifecycleDefComboBox
            // 
            this.m_lifecycleDefComboBox.FormattingEnabled = true;
            this.m_lifecycleDefComboBox.Items.AddRange(new object[] {
            "Pending",
            "Close"});
            this.m_lifecycleDefComboBox.Location = new System.Drawing.Point(68, 148);
            this.m_lifecycleDefComboBox.Name = "m_lifecycleDefComboBox";
            this.m_lifecycleDefComboBox.Size = new System.Drawing.Size(168, 25);
            this.m_lifecycleDefComboBox.TabIndex = 9;
            this.m_lifecycleDefComboBox.Visible = false;
            this.m_lifecycleDefComboBox.SelectedIndexChanged += new System.EventHandler(this.m_lifecycleDefComboBox_SelectedIndexChanged);
            // 
            // txtLifeCycleComment
            // 
            this.txtLifeCycleComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLifeCycleComment.Location = new System.Drawing.Point(250, 87);
            this.txtLifeCycleComment.Multiline = true;
            this.txtLifeCycleComment.Name = "txtLifeCycleComment";
            this.txtLifeCycleComment.Size = new System.Drawing.Size(287, 62);
            this.txtLifeCycleComment.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(76, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Lifecycle Change Comment :";
            // 
            // cmdCancle
            // 
            this.cmdCancle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdCancle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdCancle.ForeColor = System.Drawing.Color.White;
            this.cmdCancle.Location = new System.Drawing.Point(462, 155);
            this.cmdCancle.Name = "cmdCancle";
            this.cmdCancle.Size = new System.Drawing.Size(75, 25);
            this.cmdCancle.TabIndex = 3;
            this.cmdCancle.Text = "Cancel";
            this.cmdCancle.UseVisualStyleBackColor = false;
            this.cmdCancle.Click += new System.EventHandler(this.cmdCancle_Click);
            // 
            // cmdProceed
            // 
            this.cmdProceed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdProceed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdProceed.ForeColor = System.Drawing.Color.White;
            this.cmdProceed.Location = new System.Drawing.Point(381, 155);
            this.cmdProceed.Name = "cmdProceed";
            this.cmdProceed.Size = new System.Drawing.Size(75, 25);
            this.cmdProceed.TabIndex = 2;
            this.cmdProceed.Text = "Proceed";
            this.cmdProceed.UseVisualStyleBackColor = false;
            this.cmdProceed.Click += new System.EventHandler(this.cmdProceed_Click);
            // 
            // cmdPostDeliveryLifecycle
            // 
            this.cmdPostDeliveryLifecycle.FormattingEnabled = true;
            this.cmdPostDeliveryLifecycle.Location = new System.Drawing.Point(250, 23);
            this.cmdPostDeliveryLifecycle.Name = "cmdPostDeliveryLifecycle";
            this.cmdPostDeliveryLifecycle.Size = new System.Drawing.Size(287, 25);
            this.cmdPostDeliveryLifecycle.TabIndex = 0;
            this.cmdPostDeliveryLifecycle.SelectedValueChanged += new System.EventHandler(this.cmdPostDeliveryLifecycle_SelectedValueChanged);
            this.cmdPostDeliveryLifecycle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmdPostDeliveryLifecycle_KeyPress);
            // 
            // txtBuildSpecificationCustomerNumber
            // 
            this.txtBuildSpecificationCustomerNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBuildSpecificationCustomerNumber.Location = new System.Drawing.Point(250, 55);
            this.txtBuildSpecificationCustomerNumber.Multiline = true;
            this.txtBuildSpecificationCustomerNumber.Name = "txtBuildSpecificationCustomerNumber";
            this.txtBuildSpecificationCustomerNumber.ReadOnly = true;
            this.txtBuildSpecificationCustomerNumber.Size = new System.Drawing.Size(287, 24);
            this.txtBuildSpecificationCustomerNumber.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Build Specification :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Build Specification Number :";
            // 
            // frmBuildSpecificationLifecycle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 215);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmBuildSpecificationLifecycle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Build Specification : Lifecycle";
            this.Load += new System.EventHandler(this.frmBuildSpecificationLifecycle_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdProceed;
        private System.Windows.Forms.ComboBox cmdPostDeliveryLifecycle;
        private System.Windows.Forms.TextBox txtBuildSpecificationCustomerNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdCancle;
        private System.Windows.Forms.TextBox txtLifeCycleComment;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox m_categoryComboBox;
        private System.Windows.Forms.ComboBox m_lifecycleDefComboBox;
    }
}

