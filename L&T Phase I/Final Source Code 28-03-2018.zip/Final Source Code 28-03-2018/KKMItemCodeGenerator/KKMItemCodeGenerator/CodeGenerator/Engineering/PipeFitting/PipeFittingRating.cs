﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingRating : ObservableCollection<NameCodePair>
    {
        public static PipeFittingRating LoadList()
        {
            PipeFittingRating items = new PipeFittingRating();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "150#" });
            items.Add(new NameCodePair() { Code = "02", Name = "300#" });
            items.Add(new NameCodePair() { Code = "03", Name = "2000#" });
            items.Add(new NameCodePair() { Code = "04", Name = "3000#" });
            items.Add(new NameCodePair() { Code = "05", Name = "6000#" });
            items.Add(new NameCodePair() { Code = "06", Name = "9000#" });
            items.Add(new NameCodePair() { Code = "07", Name = "PN6" });
            items.Add(new NameCodePair() { Code = "08", Name = "PN10" });
            items.Add(new NameCodePair() { Code = "09", Name = "PN16" });
            items.Add(new NameCodePair() { Code = "10", Name = "PN25" });
            items.Add(new NameCodePair() { Code = "11", Name = "PN40" });
            return items;
        }
        public static PipeFittingRating LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingRating LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingRating>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingRating.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingRating>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingRating.xml");
        }

    }
}
