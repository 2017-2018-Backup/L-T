﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Reflection;
using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using System.Windows.Forms;

namespace KKMEnquiryProjectStructure
{
    public static class clsStaticGlobal
    {
        public static Autodesk.Connectivity.Explorer.Extensibility.CommandItemEventArgs vaultConnectionContext =null;
        public static VDF.Vault.Currency.Connections.Connection connection;
        public static Autodesk.Connectivity.WebServices.Folder GoLocationFolder = null;
        public static VDF.Vault.Currency.Entities.Folder CustomerTemplateFolder = null;

        public static string CustomerFilename="CustomersForEnquiry.xml";
        public static string VaultCustomerFilePath = "$/Templates/" + CustomerFilename;
        public static string LocalXMLCustomerFolderPath = Path.GetTempPath() + "Templates";

        public static string ErrorFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        public static void ErrHandlerLog(Exception ex)
        {
            try
            {
                string errorFilePath = ErrorFilePath + "/EnquiryErrorLog.txt";
                if (!System.IO.File.Exists(errorFilePath))
                {
                    dynamic fs = System.IO.File.Create(errorFilePath);
                    fs.Close();
                    fs.Dispose();
                }
               // zipFile(ErrorFilePath, "error.txt");

                using (StreamWriter sw = new StreamWriter(errorFilePath, true))
                {
                    try
                    {
                        sw.WriteLine("Log Date & time: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                        sw.WriteLine("Message:" + ex.Message);

                        sw.WriteLine("Type:" + ex.GetType().ToString());
                        if ((ex.StackTrace != null))
                        {
                            sw.WriteLine("Trace: " + ex.StackTrace);
                        }

                        if ((ex.Source != null))
                        {
                            sw.WriteLine("Source: " + ex.Source);
                        }

                        if ((ex.TargetSite != null))
                        {
                            sw.WriteLine("Target: " + ex.TargetSite.ToString());
                        }

                        if ((ex.InnerException != null))
                        {
                            sw.WriteLine("Inner Message:" + ex.InnerException.Message);

                            if ((ex.InnerException.StackTrace != null))
                            {
                                sw.WriteLine("Trace: " + ex.InnerException.StackTrace);
                            }

                            if ((ex.InnerException.Source != null))
                            {
                                sw.WriteLine("Source: " + ex.InnerException.Source);
                            }

                            if ((ex.InnerException.TargetSite != null))
                            {
                                sw.WriteLine("Target: " + ex.InnerException.TargetSite.ToString());
                            }

                        }
                        sw.WriteLine("");
                        sw.WriteLine("");
                    }
                    catch (Exception)
                    {
                        sw.WriteLine("");
                        sw.WriteLine("");
                    }

                    sw.Close();
                }
            }
            catch (Exception)
            {

            }
        }       

        public static Customer ReadCustomerData(string xmlfilepath)
        {
            Customer customer =null;

            try
            {
                if (System.IO.File.Exists(xmlfilepath))
                {
                    XmlSerializer xs = new XmlSerializer(typeof(Customer));

                    using (var sr = new StreamReader(xmlfilepath))
                    {
                        customer = new Customer();
                        customer = (Customer)xs.Deserialize(sr);
                        return customer;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return customer;
            }

            return customer;

        }

        public static void DeleteFileFromDirectory(string _DirectoryPath)
        {
            try
            {
                if (Directory.Exists(_DirectoryPath))
                {
                    foreach (string file in Directory.GetFiles(_DirectoryPath))
                    {
                        System.IO.File.SetAttributes(file, FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error in deleting files.", "Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        public static bool DownlodCustomerFile(VDF.Vault.Currency.Entities.FileIteration fileIteration)
        {
            bool isDownload = false;
            try
            {
                clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerFolderPath);

                if (!Directory.Exists(clsStaticGlobal.LocalXMLCustomerFolderPath))
                {
                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerFolderPath);
                }
                else
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerFolderPath);
                }

                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);

                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLCustomerFolderPath);

                settings.AddFileToAcquire(fileIteration, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);

                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);
                
                foreach (var _res in results.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Success)
                    {
                        isDownload = true;
                    }
                }
                return isDownload;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return isDownload;
            }           

        }

        public static bool CheckoutFile(string VaultFilePath, string _DownloadedPath)
        {
            bool IsCheckout = false;
            try
            { 
                VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
                Autodesk.Connectivity.WebServices.File[] file1;
                try
                {
                    file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { VaultFilePath });

                    if (file1.Length != 0)
                    {
                        if (file1[0].Id != -1)
                        {
                            oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
                        }
                    }
                }
                catch (Exception)
                {

                }                

                if (oFileIteration != null)
                {
                    //clsStaticGlobal.connection.WorkingFoldersManager.SetWorkingFolder()
                    VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                    settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);
                    
                    settings.DefaultAcquisitionOption = VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download;

                    settings.AddEntityToAcquire(oFileIteration);

                    VDF.Vault.Settings.FileRelationshipGatheringSettings fileRelSetting = settings.OptionsRelationshipGathering.FileRelationshipSettings;
                    fileRelSetting.IncludeChildren = true;
                    fileRelSetting.IncludeParents = false;
                    fileRelSetting.IncludeLibraryContents = true;
                    settings.AddEntityToAcquire(oFileIteration);
                    settings.OptionsResolution.SyncWithRemoteSiteSetting = VDF.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;
                    settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

                    var m_res = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                     IsCheckout=true;
                }                
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in file checkout.", "Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return IsCheckout;
            }

            return IsCheckout;

        }
        
        public static void CheckinFile(string VaultFilePath, string _DownloadedPath)
        {
            try
            {               
                VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
                Autodesk.Connectivity.WebServices.File[] file1;
                file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { VaultFilePath });
                if (file1.Length != 0)
                {
                    if (file1[0].Id != -1)
                    {
                        oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
                    }
                }

                if (oFileIteration != null)
                {
                    VDF.Currency.FolderPathAbsolute fldrPath = new VDF.Currency.FolderPathAbsolute(_DownloadedPath);
                    string filePath = Path.Combine(fldrPath.ToString(), oFileIteration.EntityName);
                    VDF.Currency.FilePathAbsolute filePathAbs = new VDF.Currency.FilePathAbsolute(filePath);

                    if (System.IO.File.Exists(filePath))
                    {
                        if (oFileIteration.IsCheckedOut == true)
                        {
                            try
                            {
                                clsStaticGlobal.connection.FileManager.CheckinFile(oFileIteration, "", false, new Autodesk.Connectivity.WebServices.FileAssocParam[] { }, null, false, null,
                                                               Autodesk.Connectivity.WebServices.FileClassification.None, false, filePathAbs);
                            }
                            catch (Exception ex1)
                            {
                                System.Windows.Forms.MessageBox.Show(ex1.ToString() + ex1.StackTrace);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in file checkin.", "Enquiry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public static void GetOrCreateFolder()
        {
            try
            {
                Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);
                Cat _PostDeliveryFolderCategory = null;
                foreach (Cat _cat in _Categories)
                {
                    if (_cat.Name.Trim().ToUpper() == "FOLDER")
                    {
                        _PostDeliveryFolderCategory = _cat;
                        break;
                    }
                }

                VDF.Vault.Currency.Entities.Folder rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
                VDF.Vault.Currency.Entities.Folder _ProjectFolder = null;

                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.EntityName == "Templates")
                        {
                            clsStaticGlobal.CustomerTemplateFolder = folder;
                            break;
                        }
                    }
                }

                if (_ProjectFolder == null)
                {
                    Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory("Template", _ProjectFolder.Id, false, _PostDeliveryFolderCategory.Id);
                    clsStaticGlobal.CustomerTemplateFolder = new Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                }
            }
            catch (Exception)
            {

               
            }
                        
        }

    }
}
