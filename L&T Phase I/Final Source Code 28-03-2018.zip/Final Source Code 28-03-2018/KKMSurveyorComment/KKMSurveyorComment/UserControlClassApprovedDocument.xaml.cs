﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KKMSurveyorComment;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;

namespace KKMSurveyorComment
{
    /// <summary>
    /// Interaction logic for UserControlClassApprovedDocument.xaml
    /// </summary>
    public partial class UserControlClassApprovedDocument : Window
    {
        public event EventHandler<EventArgs> CloseButtonClicked;
        public List<string> StatusList { get; set; }
        public System.Windows.Forms.DialogResult DialogResUserControlClassApprovedDocument = System.Windows.Forms.DialogResult.Cancel;
        bool IsEditMode = false;
        bool IsCheckedOut = false;
        string checkedOutUsername = "";

        public UserControlClassApprovedDocument(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;

            try
            {
                StatusList = new List<string>();
                StatusList.Add("Create");
                StatusList.Add("Release");
                //DrawingStatus.ItemsSource = StatusList;

                clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Clear();
                int cnt = 1;
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.ClassApprovedDrawingFiles)
                {
                    if ((_item.FileLfCyc.LfCycStateName != null) && (_item.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase)))
                    {
                        Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                        string filePath = folder.FullName + "/" + _item.Name;
                        string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                        string fileName = _item.Name;
                        string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _item.Id, false);
                        if (fileDec == null)
                        {
                            fileDec = "";
                        }
                        string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _item.Id, false);
                        if (fileSection == null)
                        {
                            fileSection = "";
                        }
                        string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _item.Id, false); //Class Approved Drawing Number
                        if (fileRelatedDAD == null)
                        {
                            fileRelatedDAD = "";
                        }
                        clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Add(new ClassApprovedDrawing { Count = cnt, IsCheckedClassApprovedDrawing = false, FileType = "Class Approved Document", FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString(), FileSection = fileSection, FileRelatedDAD = fileRelatedDAD });
                        cnt += 1;
                    }
                }

                //clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ClassApprovedDrawingSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListClassApprovedDrawing_CollectionChanged);
                ClassApprovedDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(ClassApprovedDocumentSearchGridViewBox.ItemsSource);
                viewSearch.Filter = UserFilter;
                ClassApprovedDocumentSearchGridViewBox.UpdateLayout();

                //if (clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Count ==0)
                //{
                //    System.Windows.Forms.MessageBox.Show("Class Approved document not available.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                //}

                if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                {
                    ClassApprovedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing;
                    ClassApprovedDocumentGridViewBox.UpdateLayout();
                }

                try
                {
                    if (clsStaticGlobal.IsReadOnly == true)
                    {
                        cmdClassApprovedRemove.Visibility = Visibility.Collapsed;
                        cmdSave.Visibility = Visibility.Collapsed;
                        cmdAddApprovedDocument.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        cmdClassApprovedRemove.Visibility = Visibility.Visible;
                        cmdSave.Visibility = Visibility.Visible;
                        cmdAddApprovedDocument.Visibility = Visibility.Visible;
                    }
                }
                catch (Exception)
                {

                }

                this.Loaded += UserControl_Loaded;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            if (clsStaticGlobal.IsReadOnly == false)
            {
                
            }
            else
            {
               // MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            if (IsCheckedOut == true)
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DialogResUserControlClassApprovedDocument = System.Windows.Forms.DialogResult.Cancel;
                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Count == 0)
            {
                MessageBox.Show("There is no any class approved document in Release state..!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            //if (clsStaticGlobal.IsReadOnly == false)
            //{
            //    try
            //    {
            //        StatusList = new List<string>();
            //        StatusList.Add("Create");
            //        StatusList.Add("Release");
            //        DrawingStatus.ItemsSource = StatusList;

            //        clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Clear();

            //        foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.ClassApprovedDrawingFiles)
            //        {
            //            //System.Diagnostics.Debugger.Launch();
            //            Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
            //            string filePath = folder.FullName + "/" + _item.Name;
            //            string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
            //            string fileName = _item.Name;
            //            clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Add(new ClassApprovedDrawing { IsCheckedClassApprovedDrawing = false, FileType = "Class Approved Document", FileName = fileName, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
            //        }

            //        clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ClassApprovedDrawingSearchedItemCollection_CollectionChanged);
            //        clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListClassApprovedDrawing_CollectionChanged);
            //        ClassApprovedDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection;
            //        ClassApprovedDocumentSearchGridViewBox.UpdateLayout();

            //        //if (clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection.Count ==0)
            //        //{
            //        //    System.Windows.Forms.MessageBox.Show("Class Approved document not available.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
            //        //}

            //        if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
            //        {
            //            ClassApprovedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing;
            //            ClassApprovedDocumentGridViewBox.UpdateLayout();
            //        }

            //    }
            //    catch (Exception ex)
            //    {
            //        clsStaticGlobal.ErrHandlerLog(ex);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            //}

        }

        private void ClassApprovedDrawingSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListClassApprovedDrawing_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                {
                    item.Count = k;
                    k++;

                    string _status = "";
                    string _remark = "";
                    clsStaticGlobal.VaultFileGetStateAndComment(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {               
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        ClassApprovedDocumentSearchGridViewBox.UpdateLayout();
                        ClassApprovedDocumentSearchGridViewBox.Items.Refresh();

                        foreach (ClassApprovedDrawing _item in clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection)
                        {
                            if (_item.IsCheckedClassApprovedDrawing == true)
                            {
                                bool IsFileExist = false;
                                foreach (ClassApprovedDrawing _itemExist in clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                                {

                                    if (_itemExist.FileName == _item.FileName)
                                    {
                                        IsFileExist = true;
                                    }
                                    else
                                    {
                                        var _itemExistTemp = _itemExist.FileName.Split(new char[] { '.' });
                                        var _itemTemp = _item.FileName.Split(new char[] { '.' });
                                        if (_itemExistTemp[0].ToUpper() == _itemTemp[0].ToUpper())
                                        {
                                            IsFileExist = true;
                                        }
                                    }

                                }
                                if (IsFileExist == false)
                                {
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = _item.FileName;
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Add(new ClassApprovedDrawing { IsCheckedClassApprovedDrawing = true, FileType = "Class Approved Document", FileName = _item.FileName, FileDesc = _item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString(), FileSection = _item.FileSection, FileRelatedDAD=_item.FileRelatedDAD });
                                }
                            }
                        }

                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count == 0)
                        //{
                        //    foreach (ClassApprovedDrawing _item in clsStaticGlobal.ClassApprovedDrawingSearchedItemCollection)
                        //    {
                        //        if ((_item.IsCheckedClassApprovedDrawing == true) && (IsAdded == false))
                        //        {
                        //            IsAdded = true;

                        //            clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = _item.FileName;
                        //            clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Add(new ClassApprovedDrawing { IsCheckedClassApprovedDrawing = true, FileType = "Class Approved Document", FileName = _item.FileName, FileDesc = _item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString(), FileSection = _item.FileSection, FileRelatedDAD=_item.FileRelatedDAD });
                        //        }
                        //    }
                        //    ClassApprovedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing;
                        //}
                        //else
                        //{
                        //    System.Windows.Forms.MessageBox.Show("First remove attached Class Approved Document.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        //}

                        ClassApprovedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing;
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            ClassApprovedDocumentGridViewBox.UpdateLayout();
        }

        //private void cmdClassApprovedSaveandClose_Click(object sender, RoutedEventArgs e)
        //{
        //    if (clsStaticGlobal.IsReadOnly == false)
        //    {
        //        try
        //        {
        //            if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count == 0)
        //            {
        //                System.Windows.Forms.MessageBox.Show("Class Approved document should be attached.", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
        //            }
        //            else
        //            {
        //                ClassApprovedDocumentGridViewBox.UpdateLayout();

        //                ClassApprovedDocumentGridViewBox.Focusable = false;
        //                if (this.CloseButtonClicked != null)
        //                    CloseButtonClicked(sender, e);
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            clsStaticGlobal.ErrHandlerLog(ex);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
        //    }

        //}

        private void cmdClassApprovedRemove_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                        {
                            try
                            {
                                bool isChecked = false;
                                List<ClassApprovedDrawing> listOfClassApprovedDrawing = new List<ClassApprovedDrawing>();
                                foreach (var itemClassApprovedDrawing in ClassApprovedDocumentGridViewBox.Items)
                                {
                                    ClassApprovedDrawing objClassApprovedDrawing = (ClassApprovedDrawing)itemClassApprovedDrawing;

                                    if (objClassApprovedDrawing.IsCheckedClassApprovedDrawing == true)
                                    {
                                        isChecked = true;
                                        listOfClassApprovedDrawing.Add(objClassApprovedDrawing);
                                    }
                                }

                                foreach (ClassApprovedDrawing item in listOfClassApprovedDrawing)
                                {
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Remove(item);
                                }

                                ClassApprovedDocumentGridViewBox.Items.Refresh();

                                if (isChecked == false)
                                {
                                    MessageBox.Show("Select single file first.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                                }
                            }
                            catch (Exception ex)
                            {
                                clsStaticGlobal.ErrHandlerLog(ex);
                            }
                            //clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Clear();
                            //ClassApprovedDocumentGridViewBox.UpdateLayout();
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

        }

        private void ClassApprovedDocumentSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                ClassApprovedDocumentSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlClassApprovedDocument = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            {  return true;}
               
            else

            {
                //ClassApprovedDrawing itemitem = (ClassApprovedDrawing)item;

                //if (itemitem.FileName.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
                return ((item as ClassApprovedDrawing).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ClassApprovedDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
                // return ((item as ClassApprovedDrawing).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
               // return ((item as ClassApprovedDrawing).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ClassApprovedDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(ClassApprovedDocumentSearchGridViewBox.ItemsSource).Refresh();
        }

    }

    public class StatusList
    {
        public StatusList()
        {
            StatusItems = new ObservableCollection<string>() { "Open", "Closed" };
        }
        public ObservableCollection<string> StatusItems { get; set; }
    }
}
