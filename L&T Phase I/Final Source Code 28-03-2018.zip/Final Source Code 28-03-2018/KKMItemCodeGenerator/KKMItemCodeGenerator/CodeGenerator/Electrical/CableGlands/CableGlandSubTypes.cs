﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandSubTypes : ObservableCollection<NameCodePair>
    {
        public static CableGlandSubTypes LoadList()
        {
            CableGlandSubTypes items = new CableGlandSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "SINGLE COMPRESSION" });
            items.Add(new NameCodePair() { Code = "02", Name = "DOUBLE COMPRESSION" });
            items.Add(new NameCodePair() { Code = "03", Name = "NA" });
            return items;
        }
        public static CableGlandSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandSubTypes>(ElectricalItems.DataPath + @"\CableGland\CableGlandSubTypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandSubTypes>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandSubTypes.xml");
        }

    }
}
