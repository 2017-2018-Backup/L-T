﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamHeights : ObservableCollection<NameCodePair>
    {
        public static BeamHeights LoadList()
        {
            BeamHeights items = new BeamHeights();
            items.Add(new NameCodePair() { Code = "100", Name = "100 mm" });
            items.Add(new NameCodePair() { Code = "120", Name = "120 mm" });
            items.Add(new NameCodePair() { Code = "125", Name = "125 mm" });
            items.Add(new NameCodePair() { Code = "140", Name = "140 mm" });
            items.Add(new NameCodePair() { Code = "150", Name = "150 mm" });
            items.Add(new NameCodePair() { Code = "152", Name = "152 mm" });
            items.Add(new NameCodePair() { Code = "160", Name = "160 mm" });
            items.Add(new NameCodePair() { Code = "175", Name = "175 mm" });
            items.Add(new NameCodePair() { Code = "180", Name = "180 mm" });
            items.Add(new NameCodePair() { Code = "200", Name = "200 mm" });
            items.Add(new NameCodePair() { Code = "203", Name = "203 mm" });
            items.Add(new NameCodePair() { Code = "220", Name = "220 mm" });
            items.Add(new NameCodePair() { Code = "225", Name = "225 mm" });
            items.Add(new NameCodePair() { Code = "250", Name = "250 mm" });
            items.Add(new NameCodePair() { Code = "252", Name = "252 mm" });
            items.Add(new NameCodePair() { Code = "300", Name = "300 mm" });
            items.Add(new NameCodePair() { Code = "350", Name = "350 mm" });
            items.Add(new NameCodePair() { Code = "400", Name = "400 mm" });
            items.Add(new NameCodePair() { Code = "450", Name = "450 mm" });
            items.Add(new NameCodePair() { Code = "500", Name = "500 mm" });
            items.Add(new NameCodePair() { Code = "550", Name = "550 mm" });
            items.Add(new NameCodePair() { Code = "600", Name = "600 mm" });

            return items;
        }
        public static BeamHeights LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamHeights LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamHeights>(HullOutfitItems.DataPath + @"\Beam\BeamHeights.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamHeights>(this, HullOutfitItems.DataPath + @"\Beam\BeamHeights.xml");
        }
    }
}
