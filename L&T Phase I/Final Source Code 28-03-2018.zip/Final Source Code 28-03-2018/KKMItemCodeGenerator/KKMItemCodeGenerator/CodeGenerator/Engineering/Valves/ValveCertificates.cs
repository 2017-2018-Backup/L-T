﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveCertificates : ObservableCollection<NameCodePair>
    {
        public static ValveCertificates LoadList()
        {
            ValveCertificates items = new ValveCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "3.2" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            return items;
        }
        public static ValveCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveCertificates>(EngineeringItems.DataPath + @"\Valves\ValveCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveCertificates>(this, EngineeringItems.DataPath + @"\Valves\ValveCertificates.xml");
        }

    }
}
