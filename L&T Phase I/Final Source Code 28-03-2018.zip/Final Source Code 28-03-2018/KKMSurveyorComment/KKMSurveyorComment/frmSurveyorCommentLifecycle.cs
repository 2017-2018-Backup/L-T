﻿using KKMSurveyorComment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autodesk.Connectivity.WebServices;

namespace KKMSurveyorComment
{
    public partial class frmSurveyorCommentLifecycle : Form
    {
        public SingleSurveyorCommentSummary _objSingleSurveyorCommentSummary;
        public bool IsEditMode = false;

        public frmSurveyorCommentLifecycle()
        {
            InitializeComponent();
        }

        public frmSurveyorCommentLifecycle(ref SingleSurveyorCommentSummary objSingleSurveyorCommentSummary, bool _IsEditMode)
        {
            InitializeComponent();
            _objSingleSurveyorCommentSummary = objSingleSurveyorCommentSummary;
            IsEditMode = _IsEditMode;
        }

        private void cmdCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdProceed_Click(object sender, EventArgs e)
        {
            _objSingleSurveyorCommentSummary.LifeCycle = ((LifecycleStateListItem)cmdSurveyorLifecycle.SelectedItem).LifecycleState.DispName;
            _objSingleSurveyorCommentSummary.LifeCycleComment = txtLifeCycleComment.Text;
            try
            {

                File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath });
                if (SingleFile.Length != 0)
                {
                    newFile = SingleFile[0];
                    LfCycDef lcDef = null;
                    LifecycleDefinitionListItem lcDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
                    if (lcDefItem != null)
                        lcDef = lcDefItem.LifecycleDefinition;

                    LifecycleStateListItem lcStateItem = cmdSurveyorLifecycle.SelectedItem as LifecycleStateListItem;

                    if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId != lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null && lcStateItem.LifecycleState.Id > 0)
                    {
                        // here we are setting both the lifecycle definition and the state
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleDefinitions(
                            new long[] { newFile.MasterId },
                            new long[] { lcDef.Id }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleSurveyorCommentSummary.LifeCycleComment);

                        newFile = files[0];
                    }
                    else if (lcDef != null && lcDef.Id > 0 && newFile.FileLfCyc.LfCycDefId == lcDef.Id &&
                        lcStateItem != null && lcStateItem.LifecycleState != null &&
                        lcStateItem.LifecycleState.Id > 0 &&
                        newFile.FileLfCyc.LfCycStateId != lcStateItem.LifecycleState.Id)
                    {
                        // here the definition is correct but we need to change the lifecycle
                        File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                            new long[] { newFile.MasterId }, new long[] { lcStateItem.LifecycleState.Id },
                            _objSingleSurveyorCommentSummary.LifeCycleComment);

                        newFile = files[0];
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            this.Close();
        }

        private void GetLifecycles()
        {
            try
            {
                LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
                int index = 1;

                LfCycDef noneDef = new LfCycDef()
                {
                    Id = -1,
                    DispName = "<None>",
                    StateArray = new LfCycState[0]
                };

                m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(noneDef));

                foreach (LfCycDef lcDef in lcDefs)
                {
                    index = m_lifecycleDefComboBox.Items.Add(new LifecycleDefinitionListItem(lcDef));
                    if ((lcDef.DispName.ToUpper() == "SURVEYOR COMMENTS") || (lcDef.Name.ToUpper() == "SURVEYOR COMMENTS"))
                    {
                        m_lifecycleDefComboBox.SelectedIndex = index;
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void GetCategories()
        {
            try
            {
                Cat[] categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FILE", true);
                // create a dummy category
                Cat baseCategory = new Cat()
                {
                    Id = -1,
                    Name = "<Base>"
                };

                int index = m_categoryComboBox.Items.Add(
                    new CategoryListItem(baseCategory));
                m_categoryComboBox.SelectedIndex = index;

                if (categories == null)
                    return;

                foreach (Cat category in categories)
                {
                    index = m_categoryComboBox.Items.Add(new CategoryListItem(category));
                    if (category.Name.ToUpper() == "SURVEYOR COMMENTS")
                    {
                       // m_lifecycleDefComboBox.SelectedIndex = index;
                        m_categoryComboBox.SelectedIndex = index;
                    }
                }

                
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmSurveyorCommentLifecycle_Load(object sender, EventArgs e)
        {
            try
            {
                //System.Diagnostics.Debugger.Launch();
                GetCategories();
                GetLifecycles();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


            try
            {
                if (IsEditMode == true)
                {
                    //cmdSurveyorLifecycle.SelectedItem = _objSingleSurveyorCommentSummary.LifeCycle;
                    //cmdSurveyorLifecycle.SelectedValue = _objSingleSurveyorCommentSummary.LifeCycle;
                    txtSurveyorComment.Text = _objSingleSurveyorCommentSummary.SurveyorCommentName;
                    txtLifeCycleComment.Text = _objSingleSurveyorCommentSummary.LifeCycleComment;
                }
                else
                {
                    //cmdSurveyorLifecycle.SelectedItem = _objSingleSurveyorCommentSummary.LifeCycle;
                    //cmdSurveyorLifecycle.SelectedValue = _objSingleSurveyorCommentSummary.LifeCycle;
                    _objSingleSurveyorCommentSummary.SurveyorCommentName = txtSurveyorComment.Text;
                    _objSingleSurveyorCommentSummary.LifeCycleComment = txtLifeCycleComment.Text;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmdSurveyorLifecycle_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void m_lifecycleDefComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LifecycleDefinitionListItem lifecycleDefItem = m_lifecycleDefComboBox.SelectedItem as LifecycleDefinitionListItem;
            if (lifecycleDefItem == null || lifecycleDefItem.LifecycleDefinition == null)
                return;

            LfCycDef lifecycleDef = lifecycleDefItem.LifecycleDefinition;
            LfCycState[] states = lifecycleDef.StateArray;
            if (states == null)
                return;

            cmdSurveyorLifecycle.Items.Clear();
            cmdSurveyorLifecycle.Text = String.Empty;

            int index;
            foreach (LfCycState state in states)
            {
                index = cmdSurveyorLifecycle.Items.Add(new LifecycleStateListItem(state));
                if ((state.DispName.ToUpper() == _objSingleSurveyorCommentSummary.LifeCycle.ToUpper()) || (state.Name.ToUpper() == _objSingleSurveyorCommentSummary.LifeCycle.ToUpper()))
                {
                    cmdSurveyorLifecycle.SelectedIndex = index;
                }
            }
        }
    }

    public class CategoryListItem
    {
        public Cat Category;

        public CategoryListItem(Cat category)
        {
            this.Category = category;
        }

        public override string ToString()
        {
            return Category.Name;
        }
    }

    public class LifecycleStateListItem
    {
        public LfCycState LifecycleState;

        public LifecycleStateListItem(LfCycState lifecycleState)
        {
            this.LifecycleState = lifecycleState;
        }

        public override string ToString()
        {
            return LifecycleState.DispName;
        }
    }

    public class LifecycleDefinitionListItem
    {
        public LfCycDef LifecycleDefinition;

        public LifecycleDefinitionListItem(LfCycDef lifecycleDefinition)
        {
            this.LifecycleDefinition = lifecycleDefinition;
        }

        public override string ToString()
        {
            return LifecycleDefinition.DispName;
        }
    }
}
