﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class GasketMaterials : ObservableCollection<NameCodePair>
    {
        public static GasketMaterials LoadList()
        {
            GasketMaterials items = new GasketMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "NEOPRENE" });
            items.Add(new NameCodePair() { Code = "02", Name = "NBR" });
            items.Add(new NameCodePair() { Code = "03", Name = "PTFE" });
            items.Add(new NameCodePair() { Code = "04", Name = "NON ASBESTOS" });
            items.Add(new NameCodePair() { Code = "05", Name = "NON ASBESTOS COMP. FIBRE" });
            items.Add(new NameCodePair() { Code = "06", Name = "GRAPHITE" });
            items.Add(new NameCodePair() { Code = "07", Name = "METALLLIC GASKET" });
            items.Add(new NameCodePair() { Code = "08", Name = "COMP. ASBESTOS FIBRE" });
            items.Add(new NameCodePair() { Code = "09", Name = "EPDM" });
            items.Add(new NameCodePair() { Code = "10", Name = "COPPER" });
            items.Add(new NameCodePair() { Code = "11", Name = "MGB 915-1" });
            items.Add(new NameCodePair() { Code = "12", Name = "VITON" });
            items.Add(new NameCodePair() { Code = "13", Name = "NITRILE" });
            items.Add(new NameCodePair() { Code = "14", Name = "FPM 75" });
            items.Add(new NameCodePair() { Code = "15", Name = "Spiral Wound Metallic Graphite" });
            items.Add(new NameCodePair() { Code = "16", Name = "Teflon" });
            return items;
        }
        public static GasketMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static GasketMaterials LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<GasketMaterials>(EngineeringItems.DataPath + @"\FlangeGasket\GasketMaterials.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<GasketMaterials>(this, EngineeringItems.DataPath + @"\FlangeGasket\GasketMaterials.xml");
        }

    }
}
