﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveButerflySubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveButerflySubTypes LoadList()
        {
            ValveButerflySubTypes items = new ValveButerflySubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "WAFER" });
            items.Add(new NameCodePair() { Code = "02", Name = "FLANGED" });
            items.Add(new NameCodePair() { Code = "03", Name = "LUG" });
            return items;
        }
        public static ValveButerflySubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveButerflySubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveButerflySubTypes>(EngineeringItems.DataPath + @"\Valves\ValveButerflySubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveButerflySubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveButerflySubTypes.xml");
        }

    }
}
