﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CTLSizes : ObservableCollection<NameCodePair>
    {
        public static CTLSizes LoadList()
        {
            CTLSizes items = new CTLSizes();
            items.Add(new NameCodePair() { Code = "01", Name = "25 x 10" });
            items.Add(new NameCodePair() { Code = "02", Name = "16 x 10" });
            items.Add(new NameCodePair() { Code = "03", Name = "10 x 10" });
            items.Add(new NameCodePair() { Code = "04", Name = "10 x 6" });
            items.Add(new NameCodePair() { Code = "05", Name = "6 x 10" });
            items.Add(new NameCodePair() { Code = "06", Name = "6 x 6" });
            items.Add(new NameCodePair() { Code = "07", Name = "5MM" });
            items.Add(new NameCodePair() { Code = "08", Name = "8MM" });
            items.Add(new NameCodePair() { Code = "09", Name = "10MM" });
            items.Add(new NameCodePair() { Code = "10", Name = "14MM" });
            items.Add(new NameCodePair() { Code = "11", Name = "16MM" });
            items.Add(new NameCodePair() { Code = "12", Name = "22MM" });
            items.Add(new NameCodePair() { Code = "13", Name = "25MM" });
            items.Add(new NameCodePair() { Code = "14", Name = "38MM" });
            items.Add(new NameCodePair() { Code = "15", Name = "1.25MM" });
            items.Add(new NameCodePair() { Code = "16", Name = "2MM" });
            items.Add(new NameCodePair() { Code = "17", Name = "5.5MM" });
            items.Add(new NameCodePair() { Code = "18", Name = "1.5 MM" });
            items.Add(new NameCodePair() { Code = "19", Name = "2.5 MM" });
            items.Add(new NameCodePair() { Code = "20", Name = "1.5MM" });
            items.Add(new NameCodePair() { Code = "21", Name = "2.5MM" });
            return items;
        }
        public static CTLSizes LoadFromExcel(String path)
        {
            return null;
        }

        public static CTLSizes LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CTLSizes>(ElectricalItems.DataPath + @"\CableTerminalLugs\CTLSizes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CTLSizes>(this, ElectricalItems.DataPath + @"\CableTerminalLugs\CTLSizes.xml");
        }

    }
}
