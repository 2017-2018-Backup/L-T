﻿using KKMSurveyorComment;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.IO;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace KKMSurveyorComment
{
    public partial class frmCreateNewSurveyorComment : Form
    {
        bool IsEditMode = false;
        bool IsCheckedOut = false;
        string checkedOutUsername = "";
        int SurveyorCommentNo = 1;
        public frmCreateNewSurveyorComment()
        {
            InitializeComponent();
        }

        public frmCreateNewSurveyorComment(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;
        }

        private void AddProjectFolderItem(AutoCompleteStringCollection ProjectFolderCOllection)
        {
            try
            {
                // check for any sub Folders.
                VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
                IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
                if (folders != null && folders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                    {
                        if (folder.Category.Name.ToUpper() == "PROJECT")
                        {
                            ProjectFolderCOllection.Add(folder.EntityName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void frmCreateNewSurveyorComment_Load(object sender, EventArgs e)
        {
            try
            {
                if (IsEditMode == true)
                {
                    AssignToControl();
                }
                else
                {
                    txtProjectCode.Text = clsStaticGlobal._ProjectCode;
                    SurveyorCommentNo = clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentNumber + 1;                    
                    txtSurveyorCommentNumber.Text = txtProjectCode.Text + "_" + SurveyorCommentNo.ToString();
                    txtLifeCycle.Text = "Create";
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            if (IsCheckedOut == true)
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdCreateComment_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (IsValidateField() == true)
                        {
                            if (IsEditMode == true)
                            {
                                AssignToObject();
                                MessageBox.Show("Surveyor Comment updated successfully..!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                            }
                            else
                            {
                                string _TempCommentName = txtSurveyorCommentNumber.Text.Trim();
                                string _TempFileName = "PDC_" + _TempCommentName + ".xml";
                                if (IsSurveyarCommentNameExist(_TempFileName, _TempCommentName))
                                {
                                    MessageBox.Show("Surveyor Comment already exist", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    try
                                    {
                                        AssignToObject();
                                        String _xmlFilePath = clsStaticGlobal.LocalXMLSurveyorCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                        clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileFullPath = clsStaticGlobal.VaultSurvayerFolder.FullName + "/" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName;
                                        clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleSurveyorCommentSummary, _xmlFilePath, false);
                                        MessageBox.Show("Surveyor Comment created successfully..!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        this.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        clsStaticGlobal.ErrHandlerLog(ex);
                                        MessageBox.Show("Error in creating Surveyor Comment!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                        MessageBox.Show("Error in creating Surveyor Comment!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IsSurveyarCommentNameExist(string _filename, string _CommentName)
        {
            bool IsExist = false;
            try
            {
                foreach (SingleSurveyorCommentSummary item in clsStaticGlobal.objSurveyorCommentsCollection.collectionSurveyorCommentSummary)
                {
                    if ((item.SurveyorCommentFileName == _filename) || (item.SurveyorCommentName == _CommentName))
                    {
                        IsExist = true;
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return IsExist;
        }

        private void AssignToObject()
        {
            try
            {
                clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentCommentNumber = txtSurveyorCommentNumber.Text.Trim();
                clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName = txtSurveyorCommentNumber.Text.Trim();

                if (IsEditMode == false)
                {
                    clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentFileName = "SC_" + clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentCommentNumber + ".xml";
                }

                clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedProject = txtProjectCode.Text;
                clsStaticGlobal.objSingleSurveyorCommentSummary.IssueNumber = txtIssueNumber.Text;
                clsStaticGlobal.objSingleSurveyorCommentSummary.FunctionalGroup = cmbFunctionalGroup.SelectedItem.ToString();

                string function = "";
                try
                {
                    clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSocieties.Clear();
                }
                catch (Exception)
                {

                }

                clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety = "";

                foreach (ListViewItem item in lstClassificationSociety.Items)
                {
                    if (item.Checked == true)
                    {
                        clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSocieties.Add(item.Text);

                        if (function == "")
                        {
                            function = item.Text;
                        }
                        else
                        {
                            function = function + Environment.NewLine + item.Text;
                        }
                    }
                }

                clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety = function;

               // clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety = cmbClassificationSociety.SelectedItem.ToString();
                clsStaticGlobal.objSingleSurveyorCommentSummary.SubParaRef = txtSubParaRef.Text;
                clsStaticGlobal.objSingleSurveyorCommentSummary.Comment = txtComment.Text;
                clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = txtClassApprovedDoc.Text;
                clsStaticGlobal.objSingleSurveyorCommentSummary.LRremark = cmbLRremark.SelectedItem.ToString();

                if (IsEditMode == true)
                {
                    clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs = clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision = clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus = clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle = clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.OriginatedDate = clsStaticGlobal.objSingleSurveyorCommentSummary.OriginatedDate;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.EditCommentRemark = txtEditCommentRemark.Text;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRemark = clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRemark;
                }
                else
                {
                    //clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDAD = "";
                    //clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision = "";
                    //clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus = "";
                    clsStaticGlobal.objSingleSurveyorCommentSummary.EditCommentRemark = txtEditCommentRemark.Text;
                    clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle = "Create";
                    clsStaticGlobal.objSingleSurveyorCommentSummary.OriginatedDate = DateTime.Now.Date.ToString("dd-MMM-yyyy");
                    //clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycleComment = txtComment.Text;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void AssignToControl()
        {
            try
            {
                txtSurveyorCommentNumber.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.SurveyorCommentName;
                txtSurveyorCommentNumber.Enabled = false;
                txtIssueNumber.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.IssueNumber;
                cmbFunctionalGroup.SelectedValue = clsStaticGlobal.objSingleSurveyorCommentSummary.FunctionalGroup;
                cmbFunctionalGroup.SelectedItem = clsStaticGlobal.objSingleSurveyorCommentSummary.FunctionalGroup;
                //cmbClassificationSociety.SelectedValue = clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety;
                //cmbClassificationSociety.SelectedItem = clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety;
                if ((clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety != "") || (clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSociety != null))
                {
                    foreach (var item in clsStaticGlobal.objSingleSurveyorCommentSummary.ClassificationSocieties)
                    {
                        foreach (ListViewItem _ListViewItem in lstClassificationSociety.Items)
                        {
                            if (_ListViewItem.Text == item)
                            {
                                _ListViewItem.Checked = true;
                            }
                        }
                    }
                }
                cmbLRremark.SelectedValue = clsStaticGlobal.objSingleSurveyorCommentSummary.LRremark;
                cmbLRremark.SelectedItem = clsStaticGlobal.objSingleSurveyorCommentSummary.LRremark;
                txtSubParaRef.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.SubParaRef;
                txtComment.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.Comment;
                txtEditCommentRemark.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.EditCommentRemark;
                //txtEditCommentRemark.Enabled = true;
                txtLifeCycle.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.LifeCycle;
                txtProjectCode.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedProject;
                txtClassApprovedDoc.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument;
                //txtClassApprovedDoc.Enabled = false;
                //button2.Enabled = false;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidateField()
        {
            bool isvalid = true;

            if (txtSubParaRef.Text.Trim() == "")
            {
                errorProvider1.SetError(txtSubParaRef, "Enter Sub Para Ref.");
                isvalid = false;
            }
            else
            {
                errorProvider1.Clear();
            }

            if (txtProjectCode.Text.Trim() == "")
            {
                errorProvider2.SetError(txtProjectCode, "Enter Project Number");
                isvalid = false;
            }
            else
            {
                errorProvider2.Clear();
            }

            if (txtClassApprovedDoc.Text.Trim() == "")
            {
                errorProvider3.SetError(txtClassApprovedDoc, "Select Releted Document");
                isvalid = false;
            }
            else
            {
                errorProvider3.Clear();
            }

            if (txtSurveyorCommentNumber.Text.Trim() == "")
            {
                errorProvider4.SetError(txtSurveyorCommentNumber, "Enter Surveyor Comment Name");
                isvalid = false;
            }
            else
            {
                errorProvider4.Clear();
            }

            return isvalid;
        }

        private void txtIssueNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        clsStaticGlobal.ClassApprovedDrawingFiles = new List<Autodesk.Connectivity.WebServices.File> { };
                        Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.ProjectFolder.FullName);
                        clsStaticGlobal.PrintClassApprovedDocumentFilesInFolder(root, clsStaticGlobal.connection.WebServiceManager, false);

                        UserControlClassApprovedDocument objfrmClassApprovedDocument = new UserControlClassApprovedDocument(true, IsCheckedOut, checkedOutUsername);
                        objfrmClassApprovedDocument.ShowDialog();

                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing.Count > 0)
                        {
                            clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = "";

                            foreach (ClassApprovedDrawing itemClassApprovedDrawing in clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing)
                            {
                                if ((clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments != null) && (clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments != ""))
                                {
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments + Environment.NewLine + itemClassApprovedDrawing.FileName;
                                }
                                else
                                {
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocuments = itemClassApprovedDrawing.FileName;
                                }
                            }

                            //clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDADs = clsStaticGlobal.GetPropertyValue(clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FilePath);
                            clsStaticGlobal.objSingleSurveyorCommentSummary.ClassApprovedDocument = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileName;
                            clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRemark = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRemark;
                            clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingRevision = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileRevision;
                            clsStaticGlobal.objSingleSurveyorCommentSummary.DrawingStatus = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileStatus;
                            txtClassApprovedDoc.Text = clsStaticGlobal.objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FileName;
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }
    }
}
