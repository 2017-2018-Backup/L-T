﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingNippleSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingNippleSubTypes LoadList()
        {
            PipeFittingNippleSubTypes items = new PipeFittingNippleSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "NIPPLE" });
            items.Add(new NameCodePair() { Code = "02", Name = "HEX. NIPPLE" });
            items.Add(new NameCodePair() { Code = "03", Name = "HEX NIPPLE REDUCING" });
            items.Add(new NameCodePair() { Code = "04", Name = "DOUBLE NIPPLE REDUCING" });
            items.Add(new NameCodePair() { Code = "05", Name = "DOUBLE NIPPLE REDUCING" });
            items.Add(new NameCodePair() { Code = "06", Name = "REDUCING NIPPLE" });
            items.Add(new NameCodePair() { Code = "07", Name = "PIPE NIPPLE" });
            return items;
        }
        public static PipeFittingNippleSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingNippleSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingNippleSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingNippleSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingNippleSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingNippleSubTypes.xml");
        }

    }
}
