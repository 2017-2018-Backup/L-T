﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWTubeTeeThickness2s : ObservableCollection<NameCodePair>
    {
        public static BWTubeTeeThickness2s LoadList()
        {
            BWTubeTeeThickness2s items = new BWTubeTeeThickness2s();
            items.Add(new NameCodePair() { Code = "01", Name = "0.5 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "0.8 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "1 mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "1.5 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "2 mm" });
            items.Add(new NameCodePair() { Code = "06", Name = "2.5 mm" });
            items.Add(new NameCodePair() { Code = "07", Name = "3 mm" });
            items.Add(new NameCodePair() { Code = "08", Name = "3.5 mm" });
            items.Add(new NameCodePair() { Code = "09", Name = "4 mm" });
            items.Add(new NameCodePair() { Code = "10", Name = "4.5 mm" });
            items.Add(new NameCodePair() { Code = "11", Name = "5 mm" });
            items.Add(new NameCodePair() { Code = "12", Name = "6 mm" });
            items.Add(new NameCodePair() { Code = "13", Name = "7 mm" });
            items.Add(new NameCodePair() { Code = "14", Name = "8 mm" });
            items.Add(new NameCodePair() { Code = "15", Name = "9 mm" });
            items.Add(new NameCodePair() { Code = "16", Name = "0.9 mm" });
            items.Add(new NameCodePair() { Code = "17", Name = "1.6 mm" });
            return items;
        }
        public static BWTubeTeeThickness2s LoadFromExcel(String path)
        {
            return null;
        }

        public static BWTubeTeeThickness2s LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWTubeTeeThickness2s>(EngineeringItems.DataPath + @"\FittingsBW\BWTubeTeeThickness2s.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWTubeTeeThickness2s>(this, EngineeringItems.DataPath + @"\FittingsBW\BWTubeTeeThickness2s.xml");
        }

    }
}
