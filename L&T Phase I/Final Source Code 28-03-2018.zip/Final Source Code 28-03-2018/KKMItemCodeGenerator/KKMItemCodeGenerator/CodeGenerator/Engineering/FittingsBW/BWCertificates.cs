﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWCertificates : ObservableCollection<NameCodePair>
    {
        public static BWCertificates LoadList()
        {
            BWCertificates items = new BWCertificates();
            items.Add(new NameCodePair() { Code = "0", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "Class I" });
            items.Add(new NameCodePair() { Code = "B", Name = "Class II" });
            items.Add(new NameCodePair() { Code = "C", Name = "Class III" });
            items.Add(new NameCodePair() { Code = "D", Name = "EN 10204 3.1 B" });
            items.Add(new NameCodePair() { Code = "E", Name = "Class B" });
            return items;
        }
        public static BWCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static BWCertificates LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWCertificates>(EngineeringItems.DataPath + @"\FittingsBW\BWCertificates.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWCertificates>(this, EngineeringItems.DataPath + @"\FittingsBW\BWCertificates.xml");
        }

    }
}
