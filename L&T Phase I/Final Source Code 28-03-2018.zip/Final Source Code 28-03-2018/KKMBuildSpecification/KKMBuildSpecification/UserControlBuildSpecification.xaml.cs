﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml.Serialization;
using System.IO;
using System.Diagnostics;
using excel = Microsoft.Office.Interop.Excel;
using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.Windows.Forms;
using KKMBuildSpecification;
using System.Runtime.InteropServices;
using System.Globalization;
using KKMBuildSpecifications;

namespace KKMBuildSpecification
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlBuildSpecificationSummary : Window
    {
        //UserControlSOTRNumber objfrmSOTRNumber;
        //UserControlClassDrawing objfrmClassDrawing;        
        //UserControlProductionDrawing objfrmProductionDrawing;
        frmCreateBuildSpecification objfrmCreateBuildSpecification;
        frmBuildSpecificationLifecycle objfrmBuildSpecificationLifecycle;
        //frmSOTRCollection objfrmSOTRCollection;

        public ObservableCollection<SingleBuildSpecificationSummary> FileCollection { get { return clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection; } }

        public UserControlBuildSpecificationSummary()
        {
            InitializeComponent();
            try
            {
                //Debugger.Launch();
                clsStaticGlobal.DisposeAllObjects();
                clsStaticGlobal.GetProjectCodes();
                cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
                clsStaticGlobal.AllFileStates();
                cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;
                clsStaticGlobal.AllCompletionActivities();
                cmbCompletionActivity.ItemsSource = clsStaticGlobal.CompletionActivitiesCollection;
                chkIsFilter.IsChecked = false;
                IsFilterAllow(false);
                clsStaticGlobal.sficodes =SFIcodes.LoadFromXml(clsStaticGlobal.VaultExplorerFilePath);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {           
            this.Close();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    clsStaticGlobal.DisposeAllObjects();
            //    clsStaticGlobal.GetProjectCodes();
            //    cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
            //    clsStaticGlobal.GetCommentStates();
            //    cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;
            //    chkIsFilter.IsChecked = false;
            //    IsFilterAllow(false);
            //}
            //catch (Exception ex)
            //{
            //    clsStaticGlobal.ErrHandlerLog(ex);
            //}
        }

        private void IsFilterAllow(bool _IsReadOnly)
        {
            if (_IsReadOnly == true)
            {

                txtSection.Visibility = Visibility.Visible;
                lblSection.Visibility = Visibility.Visible;
                cmbCompletionActivity.Visibility = Visibility.Visible;
                lblCompletionActivity.Visibility = Visibility.Visible;
                cmbCommentStatus.Visibility = Visibility.Visible;
                lblCommentStatus.Visibility = Visibility.Visible;
                cmdFilter.Visibility = Visibility.Visible;
            }
            else
            {

                txtSection.Visibility = Visibility.Hidden;
                lblSection.Visibility = Visibility.Hidden;
                cmbCompletionActivity.Visibility = Visibility.Hidden;
                lblCompletionActivity.Visibility = Visibility.Hidden;
                cmbCommentStatus.Visibility = Visibility.Hidden;
                lblCommentStatus.Visibility = Visibility.Hidden;
                //txtDrawingName.Visibility = Visibility.Hidden;
                //lblDrawingName.Visibility = Visibility.Hidden;
                cmdFilter.Visibility = Visibility.Hidden;
            }

        }

        private void cmbProjectCode_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (cmbProjectCode.SelectedItem != null)
            {
                if (chkIsFilter.IsChecked == true)
                {
                    chkIsFilter.IsChecked = false;
                }
                else
                {
                    BindwithFilter();
                }
            }
        }

        private void BindwithFilter()
        {
            try
            {
                clsStaticGlobal.objSingleBuildSpecificationCollection = new clsBuildSpecificationSummary();
                FileCollection.Clear();

                if (((ProjectCodes)cmbProjectCode.SelectedItem) != null)
                {
                    clsStaticGlobal._ProjectCode = ((ProjectCodes)cmbProjectCode.SelectedItem).ProjectCodeName.ToString();
                    clsStaticGlobal.VaultBuildSpecificationFolder = clsStaticGlobal.GetorCreateBuildSpecificationFolder(clsStaticGlobal._ProjectCode);

                    if (clsStaticGlobal.VaultBuildSpecificationFolder != null)
                    {
                        if (GetAllFilesByProjectFolder(clsStaticGlobal._ProjectCode) == true)
                        {
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleBuildSpecificationCollection, clsStaticGlobal.objSingleBuildSpecificationSummary, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridBuildSpecificationSummary.DataContext = this;
                            clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllBuildSpecificationSummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("User does not have full permission for selected Project Folder.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void BindingDataGridView()
        {
            try
            {
                clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.Clear();

                if (clsStaticGlobal.objSingleBuildSpecificationCollection.collectionBuildSpecification != null)
                {
                    foreach (SingleBuildSpecificationSummary objSingleBuildSpecificationSummary in clsStaticGlobal.objSingleBuildSpecificationCollection.collectionBuildSpecification)
                    {
                        if (chkIsFilter.IsChecked == true)
                        {
                            bool IsAdd = false;
                            string Section = txtSection.Text.Trim().Replace("*", "");
                            string ShipTechState = ((CommentStates)cmbCommentStatus.SelectedItem).CommentState.ToString();
                            string ShipTechCompletionAct = ((CompletionActivities)cmbCompletionActivity.SelectedItem).CompletionActivity.ToString();

                            if (objSingleBuildSpecificationSummary.BuildSpecificationSECTION.ToUpper().Contains(Section.ToUpper()))
                            {
                                if (ShipTechState == "All")
                                {
                                    IsAdd = true;
                                }
                                else
                                {
                                    if (objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle == ShipTechState)
                                    {
                                        IsAdd = true;
                                    }
                                }
                            }
                            if (IsAdd == true)
                            {
                                if (ShipTechCompletionAct == "All")
                                {
                                    IsAdd = true;
                                }
                                else
                                {
                                    if (objSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity == ShipTechCompletionAct)
                                    {
                                        IsAdd = true;
                                    }
                                    else
                                    {
                                        IsAdd = false;
                                    }
                                }
                            }
                            else
                            {
                                IsAdd = false;
                            }


                            if (IsAdd == true)
                            {
                                clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.Add(objSingleBuildSpecificationSummary);
                            }
                        }
                        else
                        {
                            clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.Add(objSingleBuildSpecificationSummary);
                        }
                    }

                    DataGridBuildSpecificationSummary.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        void AllBuildSpecificationSummary_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection)
                {
                    item.BuildSpecificationCount = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private SingleBuildSpecificationSummary GetSelectedDataGridRow(object sender)
        {
            try
            {
                if (DataGridBuildSpecificationSummary.SelectedItems.Count > 0)
                {
                    if (DataGridBuildSpecificationSummary.SelectedItems.Count == 1)
                    {
                        SingleBuildSpecificationSummary objSingleBuildSpecificationSummary = (SingleBuildSpecificationSummary)DataGridBuildSpecificationSummary.SelectedCells[0].Item;
                        return objSingleBuildSpecificationSummary;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return null;
            }
        }

        private void DeleteFileFromDirectory(string _DirectoryPath)
        {
            try
            {
                if (Directory.Exists(_DirectoryPath))
                {
                    foreach (string file in Directory.GetFiles(_DirectoryPath))
                    {
                        System.IO.File.SetAttributes(file, FileAttributes.Normal);
                        System.IO.File.Delete(file);
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private bool GetAllFilesByProjectFolder(string _ProjectCode)
        {
            try
            {
                try
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }

                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultBuildSpecificationFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.BuildSpecificationFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            FileIterations.Add(new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file));
                        }
                    }
                    ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters = (ICollection<VDF.Vault.Currency.Entities.FileIteration>)FileIterations;
                    DownlodAllProjectSpecificBuildSpecificationFiles(fileIters, _ProjectCode);
                    return true;

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("No Build Specifications available.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return false;
            }
        }

        public void DownlodAllProjectSpecificBuildSpecificationFiles(ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters, string _ProjectCode)
        {
            try
            {
                DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);

                if (!Directory.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode))
                {
                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
                }
                else
                {
                    DeleteFileFromDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
                }


                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + _ProjectCode);
                foreach (VDF.Vault.Currency.Entities.FileIteration fileIter in fileIters)
                {
                    settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                }
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Build Specification", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void AddBuildSpecification_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.IsReadOnly = false;

                    clsStaticGlobal.objSingleBuildSpecificationSummary = new SingleBuildSpecificationSummary();

                    List<int> lstCommentsNumbers = GetAllCommentsNumbers(clsStaticGlobal._ProjectCode);

                    if (lstCommentsNumbers.Count > 0)
                    {
                        clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber = lstCommentsNumbers.Last();
                    }
                    else
                    {
                        clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber = 0;
                    }

                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationIsDocumentsInRelease = false;
                    objfrmCreateBuildSpecification = new frmCreateBuildSpecification(false, false, "");
                    objfrmCreateBuildSpecification.ShowDialog();

                    if (clsStaticGlobal.objSingleBuildSpecificationSummary != null)
                    {
                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber != 0)
                        {
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleBuildSpecificationCollection, clsStaticGlobal.objSingleBuildSpecificationSummary, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridBuildSpecificationSummary.DataContext = this;
                            clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllBuildSpecificationSummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void EditComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleBuildSpecificationSummary != null)
                    {
                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;

                            clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;

                            String _xmlFilePath = clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;

                            string checkedOutUsername = "";

                            bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath, out checkedOutUsername);

                            string CurrentUser = "";
                            UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                           
                            CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);

                            if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                            {
                                if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark);
                                }

                                IsCheckedOut = false;
                            }

                            if (IsCheckedOut == false)
                            {
                                if (Directory.Exists(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                                {
                                    if (System.IO.File.Exists(_xmlFilePath))
                                    {
                                        System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                        System.IO.File.Delete(_xmlFilePath);
                                    }
                                }
                                else
                                {
                                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                                }
                                clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath);
                            }

                            if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper() == "RELEASE")
                            {
                                clsStaticGlobal.IsReadOnly = true;
                            }
                            objfrmCreateBuildSpecification = new frmCreateBuildSpecification(true, IsCheckedOut, checkedOutUsername);

                            if (objfrmCreateBuildSpecification.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                            {
                                if (IsCheckedOut == false)
                                {
                                    if (clsStaticGlobal.IsReadOnly == false)
                                    {
                                        if (System.IO.File.Exists(_xmlFilePath))
                                        {
                                            System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                            System.IO.File.Delete(_xmlFilePath);
                                        }
                                        XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));
                                        TextWriter tw = new StreamWriter(_xmlFilePath);
                                        xs.Serialize(tw, clsStaticGlobal.objSingleBuildSpecificationSummary);
                                        tw.Close();

                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark);

                                        //clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleBuildSpecificationSummary, _xmlFilePath, true);
                                        clsStaticGlobal.UpdateFileRemark(clsStaticGlobal.objSingleBuildSpecificationSummary);
                                        clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleBuildSpecificationCollection, clsStaticGlobal.objSingleBuildSpecificationSummary, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal._ProjectCode);
                                        DataGridBuildSpecificationSummary.DataContext = this;
                                        clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllBuildSpecificationSummary_CollectionChanged);
                                        BindingDataGridView();
                                    }
                                }
                            }
                            else
                            {
                                if (IsCheckedOut == false)
                                {
                                    if (System.IO.File.Exists(_xmlFilePath))
                                    {
                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark);
                                    }
                                    else
                                    {
                                        XmlSerializer xs = new XmlSerializer(typeof(SingleBuildSpecificationSummary));
                                        TextWriter tw = new StreamWriter(_xmlFilePath);
                                        xs.Serialize(tw, clsStaticGlobal.objSingleBuildSpecificationSummary);
                                        tw.Close();
                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark);
                                    }
                                }
                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Build Specification.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Build Specification First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void LifeCycle_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleBuildSpecificationSummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleBuildSpecificationSummary != null)
                    {
                        if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;
                            clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;

                            string _LifeCycle = clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle;

                            bool isOpen = false;
                            if (_LifeCycle.ToUpper() == "RELEASE")
                            {
                                if (clsStaticGlobal.connection.UserName.ToString().ToUpper() == "ADMINISTRATOR")
                                {
                                    isOpen = true;
                                }
                                else
                                {
                                    isOpen = false;
                                    System.Windows.Forms.MessageBox.Show("Select Build Specification are in release state. Only Administrator can change state.!", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
                                    return;
                                }

                            }
                            else
                            {
                                isOpen = true;
                            }

                            if (isOpen == true)
                            {
                                string _LifeCycleComment = clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationRemark;
                                objfrmBuildSpecificationLifecycle = new frmBuildSpecificationLifecycle(ref clsStaticGlobal.objSingleBuildSpecificationSummary, true);
                                objfrmBuildSpecificationLifecycle.ShowDialog();
                                if (clsStaticGlobal.IsReadOnly == false)
                                {
                                    if ((_LifeCycle != clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle) || (_LifeCycleComment != clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle))
                                    {
                                        clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleBuildSpecificationCollection, clsStaticGlobal.objSingleBuildSpecificationSummary, clsStaticGlobal.LocalXMLBuildSpecificationFolderPath, clsStaticGlobal._ProjectCode);
                                        DataGridBuildSpecificationSummary.DataContext = this;
                                        clsStaticGlobal.SingleBuildSpecificationSummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllBuildSpecificationSummary_CollectionChanged);
                                        BindingDataGridView();
                                    }
                                }
                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Build Specification.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Build Specification First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }            

        }
        
        //private void SOTRNumber_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        if (cmbProjectCode.SelectedItem != null)
        //        {
        //            clsStaticGlobal.objSingleBuildSpecificationSummary = GetSelectedDataGridRow(sender);

        //            if (clsStaticGlobal.objSingleBuildSpecificationSummary != null)
        //            {
        //                if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationNumber != 0)
        //                {
        //                    clsStaticGlobal.IsReadOnly = false;
        //                    clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationFileName;
        //                    if (clsStaticGlobal.objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle.ToUpper() == "RELEASE")
        //                    {
        //                        clsStaticGlobal.IsReadOnly = true;
        //                    }
        //                    clsStaticGlobal.SOTRNumberFiles = new List<Autodesk.Connectivity.WebServices.File> { };
        //                    //Autodesk.Connectivity.WebServices.Folder root = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderByPath(clsStaticGlobal.ProjectFolder.FullName);
        //                    clsStaticGlobal.PrintSOTRNumberFilesInFolder(clsStaticGlobal.VaultBuildSpecificationFolder, clsStaticGlobal.connection.WebServiceManager, false);

        //                    objfrmSOTRCollection = new frmSOTRCollection(false);
        //                    objfrmSOTRCollection.ShowDialog();
        //                }
        //                else
        //                {
        //                    System.Windows.Forms.MessageBox.Show("Select Build Specification.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
        //                }
        //            }
        //            else
        //            {
        //                System.Windows.Forms.MessageBox.Show("Select Build Specification First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
        //            }
        //        }
        //        else
        //        {
        //            System.Windows.Forms.MessageBox.Show("Select Project First.", "Build Specification", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        clsStaticGlobal.ErrHandlerLog(ex);
        //    }
        //}

        private void cmdExport_Click(object sender, RoutedEventArgs e)
        {
            excel.Application xlApp;
            excel.Workbook xlWorkBook;
            excel.Worksheet xlWorkSheet;
            bool IsExport = true;

            List<SingleBuildSpecificationSummary> excelSingleBuildSpecificationSummaryList = new List<SingleBuildSpecificationSummary>();
            foreach (var item in DataGridBuildSpecificationSummary.SelectedItems)
            {
                excelSingleBuildSpecificationSummaryList.Add((SingleBuildSpecificationSummary)item);
            }
            try
            {
                if (excelSingleBuildSpecificationSummaryList.Count > 0)
                {                   
                    if (IsExport == true)
                    {

                        string _Filename = "Build Specifications";
                        System.Windows.Forms.Application.DoEvents();
                        System.Windows.Forms.SaveFileDialog saveFileDialog = new System.Windows.Forms.SaveFileDialog();
                        saveFileDialog.Title = "Save Excel Report";
                        saveFileDialog.RestoreDirectory = true;
                        saveFileDialog.FileName = "Build Specifications Summary_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        saveFileDialog.DefaultExt = "xlsx";

                        if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            _Filename = saveFileDialog.FileName;
                        }
                        else
                        {
                            return;
                        }

                        /////////////////////// Create Excel Application Object
                        object mMissingValue = System.Reflection.Missing.Value;
                        xlApp = new excel.Application();
                        xlApp.DisplayAlerts = false;
                        xlWorkBook = xlApp.Workbooks.Add(mMissingValue);
                        xlWorkSheet = null;

                        try
                        {
                            var prevSheet = xlWorkSheet;

                            if (prevSheet == null)
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(xlWorkBook.Sheets[1], mMissingValue, mMissingValue, mMissingValue);
                            }
                            else
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(mMissingValue, prevSheet, mMissingValue, mMissingValue);
                            }
                            xlWorkSheet.Name = "Build Specifications";
                            int BorderStartindex = 0;
                            int RowNo = 2;
                            int ColNo = 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Build Specifications";
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Size = 16;
                            RowNo += 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Downloaded Date";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = "'" + DateTime.Now.ToLongDateString();
                            RowNo += 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "User ID";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = clsStaticGlobal.connection.UserName.ToString();
                            RowNo += 2;

                            int LoopRowNo = RowNo;
                            int LoopColNo = ColNo;

                            int StartRowNo = RowNo;
                            int StartColNo = ColNo;

                            xlWorkSheet.Cells[RowNo, ColNo - 1] = "Sr.No.";
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Project Code";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Technical Ship Specification No.";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SECTION";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Lifecycle Status";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Para Number";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Sub Para Number";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SFI\\Material Code";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SFI\\Material Description";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Ref. Build Specification Line";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Responsible Person";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Sub Responsible Person";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Responsible Coordinator";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Sub Responsible Coordinator";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Function";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SOTR Required";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SOTR Numbers";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "SOTR Numbers File Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Approved Drawings";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Class Approved Drawings File Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Production Drawings";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Production Drawings Path";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Extension";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Remark";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Completion of activity";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;

                            BorderStartindex = RowNo;
                            int SrNoCnt = 1;
                            int NextCol = LoopColNo;

                            foreach (SingleBuildSpecificationSummary _ObjSingleBuildSpecificationSummary in excelSingleBuildSpecificationSummaryList)
                            {
                                LoopRowNo = LoopRowNo + 1;
                                NextCol = LoopColNo;

                                xlWorkSheet.Cells[LoopRowNo, NextCol - 1] = SrNoCnt.ToString();
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationProjectCode;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationUniqNumber;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSECTION;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationLifeCycle;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationParaNumber;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSubParaNumber;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSFI;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSFIDesc;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationFunction;
                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired;

                                // SOTR Documents File Name

                                if (_ObjSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                                {
                                    string _SOTRNumber = "";
                                    string _SOTRNumberDAD = "";

                                    foreach (SOTRNumber item in _ObjSingleBuildSpecificationSummary.ListSOTRNumber)
                                    {

                                        if (item.FileType == "SOTR")
                                        {
                                            if (_SOTRNumber.Trim() == "")
                                            {
                                                _SOTRNumber = "SOTR : " + item.FileName + "  :  " + item.FileStatus;
                                            }
                                            else
                                            {
                                                _SOTRNumber = _SOTRNumber + "," + Environment.NewLine + "SOTR : " + item.FileName;
                                            }
                                        }                                       

                                    }


                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _SOTRNumber + Environment.NewLine + _SOTRNumberDAD;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                // SOTR Documents File Path

                                if (_ObjSingleBuildSpecificationSummary.ListSOTRNumber.Count > 0)
                                {
                                    string _SOTRNumberPath = "";
                                    string _SOTRNumberDADPath = "";

                                    foreach (SOTRNumber item in _ObjSingleBuildSpecificationSummary.ListSOTRNumber)
                                    {

                                        if (item.FileType.ToUpper() == "SOTR")
                                        {
                                            if (_SOTRNumberPath.Trim() == "")
                                            {
                                                _SOTRNumberPath = "SOTR : " + item.FilePath;
                                            }
                                            else
                                            {
                                                _SOTRNumberPath = _SOTRNumberPath + "," + Environment.NewLine + "SOTR : " + item.FilePath;
                                            }
                                        }
                                        //else
                                        //{
                                        //    if (_SOTRNumberDADPath.Trim() == "")
                                        //    {
                                        //        _SOTRNumberDADPath = "DAD : " + item.FilePath;
                                        //    }
                                        //    else
                                        //    {
                                        //        _SOTRNumberDADPath = _SOTRNumberDADPath + "," + Environment.NewLine + "DAD : " + item.FilePath;
                                        //    }
                                        //}

                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _SOTRNumberPath + Environment.NewLine + _SOTRNumberDADPath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                /// Class Approved Drawing
                                if (_ObjSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                                {
                                    string _ClassDrawing = "";
                                    string _ClassDrawingDAD = "";

                                    foreach (ClassDrawing item in _ObjSingleBuildSpecificationSummary.ListClassDrawing)
                                    {

                                        if (item.FileType.ToUpper() == "CLASS APPROVED")
                                        {
                                            if (_ClassDrawing.Trim() == "")
                                            {
                                                _ClassDrawing = "CLASS APPROVED : " + item.FileName;
                                            }
                                            else
                                            {
                                                _ClassDrawing = _ClassDrawing + "," + Environment.NewLine + "CLASS APPROVED : " + item.FileName;
                                            }
                                        }
                                        else
                                        {
                                            if (_ClassDrawingDAD.Trim() == "")
                                            {
                                                _ClassDrawingDAD = "DAD : " + item.FileName + "   Used in : " + item.FileUsedIn;
                                            }
                                            else
                                            {
                                                _ClassDrawingDAD = _ClassDrawingDAD + "," + Environment.NewLine + "DAD : " + item.FileName;
                                            }
                                        }

                                    }


                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ClassDrawing + Environment.NewLine + _ClassDrawingDAD;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }


                                if (_ObjSingleBuildSpecificationSummary.ListClassDrawing.Count > 0)
                                {
                                    string _ClassDrawingPath = "";
                                    string _ClassDrawingDADPath = "";

                                    foreach (ClassDrawing item in _ObjSingleBuildSpecificationSummary.ListClassDrawing)
                                    {

                                        if (item.FileType.ToUpper() == "CLASS APPROVED")
                                        {
                                            if (_ClassDrawingPath.Trim() == "")
                                            {
                                                _ClassDrawingPath = "CLASS APPROVED : " + item.FilePath;
                                            }
                                            else
                                            {
                                                _ClassDrawingPath = _ClassDrawingPath + "," + Environment.NewLine + "CLASS APPROVED : " + item.FilePath;
                                            }
                                        }
                                        else
                                        {
                                            if (_ClassDrawingDADPath.Trim() == "")
                                            {
                                                _ClassDrawingDADPath = "DAD : " + item.FilePath;
                                            }
                                            else
                                            {
                                                _ClassDrawingDADPath = _ClassDrawingDADPath + "," + Environment.NewLine + "DAD : " + item.FilePath;
                                            }
                                        }

                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ClassDrawingPath + Environment.NewLine + _ClassDrawingDADPath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                /// Production Drawing

                                if (_ObjSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                                {
                                    string _ProductionDrawing = "";
                                    string _ProductionDrawingDAD = "";

                                    foreach (ProductionDrawing item in _ObjSingleBuildSpecificationSummary.ListProductionDrawing)
                                    {

                                        if (item.FileType.ToUpper() == "PRODUCTION")
                                        {
                                            if (_ProductionDrawing.Trim() == "")
                                            {
                                                _ProductionDrawing = "PRODUCTION : " + item.FileName;
                                            }
                                            else
                                            {
                                                _ProductionDrawing = _ProductionDrawing + "," + Environment.NewLine + "PRODUCTION : " + item.FileName;
                                            }
                                        }
                                        else
                                        {
                                            if (_ProductionDrawingDAD.Trim() == "")
                                            {
                                                _ProductionDrawingDAD = "DAD : " + item.FileName;
                                            }
                                            else
                                            {
                                                _ProductionDrawingDAD = _ProductionDrawingDAD + "," + Environment.NewLine + "DAD : " + item.FileName;
                                            }
                                        }

                                    }


                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ProductionDrawing + Environment.NewLine + _ProductionDrawingDAD;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                if (_ObjSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                                {
                                    string _ProductionDrawingPath = "";
                                    string _ProductionDrawingDADPath = "";

                                    foreach (ProductionDrawing item in _ObjSingleBuildSpecificationSummary.ListProductionDrawing)
                                    {

                                        if (item.FileType.ToUpper() == "PRODUCTION")
                                        {
                                            if (_ProductionDrawingPath.Trim() == "")
                                            {
                                                _ProductionDrawingPath = "PRODUCTION : " + item.FilePath;
                                            }
                                            else
                                            {
                                                _ProductionDrawingPath = _ProductionDrawingPath + "," + Environment.NewLine + "PRODUCTION : " + item.FilePath;
                                            }
                                        }
                                        else
                                        {
                                            if (_ProductionDrawingDADPath.Trim() == "")
                                            {
                                                _ProductionDrawingDADPath = "DAD : " + item.FilePath;
                                            }
                                            else
                                            {
                                                _ProductionDrawingDADPath = _ProductionDrawingDADPath + "," + Environment.NewLine + "DAD : " + item.FilePath;
                                            }
                                        }

                                    }
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ProductionDrawingPath + Environment.NewLine + _ProductionDrawingDADPath;
                                }
                                else
                                {
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                }

                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationExtension;

                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationRemark;

                                NextCol = NextCol + 1;
                                xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleBuildSpecificationSummary.BuildSpecificationCompletionofActivity;

                                SrNoCnt = SrNoCnt + 1;

                            }

                            for (int m = 2; m <= NextCol; m++)
                            {
                                xlWorkSheet.Columns[m].AutoFit();
                            }

                            xlWorkSheet.Range[xlWorkSheet.Cells[StartRowNo, StartColNo - 1], xlWorkSheet.Cells[LoopRowNo, NextCol]].Cells.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;

                            xlWorkSheet.Activate();
                            xlWorkBook.SaveAs(_Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                            xlWorkBook.Close(true, mMissingValue, mMissingValue);
                            System.Windows.MessageBox.Show("Build Specification summary report exported successfully..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Information);

                            //if (ExportSOTRSheet(excelSingleBuildSpecificationSummaryList, xlApp, xlWorkBook, null))
                            //{
                            //    xlWorkSheet.Activate();
                            //    xlWorkBook.SaveAs(_Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                            //    xlWorkBook.Close(true, mMissingValue, mMissingValue);
                            //    System.Windows.MessageBox.Show("Build Specification summary report exported successfully..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Information);

                            //}
                            //else
                            //{
                            //    System.Windows.MessageBox.Show("Error in report export.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                            //    //clsStaticGlobal.ErrHandlerLog(ex);
                            //}

                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            try
                            {
                                clsStaticGlobal.ReleaseObject(xlWorkBook);

                            }
                            catch (Exception)
                            {

                            }
                            xlApp.Quit();
                            clsStaticGlobal.ReleaseObject(xlApp);
                        }
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("There is no Build Specifications in complete state", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex1)
            {
                System.Windows.MessageBox.Show("Excel application not installed.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Warning);
                clsStaticGlobal.ErrHandlerLog(ex1);
            }

        }      

        private void cmdFilter_Click(object sender, RoutedEventArgs e)
        {
            BindwithFilter();
        }

        private void chkIsFilter_Checked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == true)
            {
                IsFilterAllow(true);
            }

        }

        private void chkIsFilter_Unchecked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == false)
            {
                IsFilterAllow(false);
                BindwithFilter();
            }
        }

        private void cmdcmdMassUpload_Click(object sender, RoutedEventArgs e)
        {   
            if (cmbProjectCode.SelectedItem != null)
            {
                OpenFileDialog fdlg = new OpenFileDialog();
                fdlg.Title = "Open File Dialog For Excel File";
                fdlg.InitialDirectory = @"c:\";
                fdlg.Filter = "All files (*.xls)|*.xls|All files (*.xlsx)|*.xlsx";
                fdlg.FilterIndex = 2;
                fdlg.RestoreDirectory = true;
                if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {                        
                        excel.Application xlApp = new excel.Application();
                        excel.Workbook xlWorkbook = xlApp.Workbooks.Open(fdlg.FileName);

                        excel._Worksheet xlWorksheet = xlWorkbook.Sheets["Build Specifications"];
                        excel.Range xlRange = xlWorksheet.UsedRange;

                        try
                        {
                            List<SingleBuildSpecificationSummary> _listBuildSpecification = new List<SingleBuildSpecificationSummary> { };

                            int rowCount = xlRange.Rows.Count;
                            int colCount = 20;
                            int actualRowCnt = 1;

                            for (int i = 1; i <= rowCount; i++)
                            {
                                if ((xlRange.Cells[i, 2].Value2 != null) && (xlRange.Cells[i, 2].Value2.ToString().Trim() != ""))
                                {
                                    actualRowCnt = i;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            rowCount = actualRowCnt;
                            bool isBreak = false;
                            int _BuildSpecificationNumber = 0;
                            if (clsStaticGlobal.ListBuildSpecificationNumbers.Count > 0)
                            {
                                _BuildSpecificationNumber = clsStaticGlobal.ListBuildSpecificationNumbers.Last();
                            }
                           
                            bool IsFormatCorrect = true;
                            for (int i = 1; i <= rowCount; i++)
                            {
                                if (i == 1)
                                {
                                    for (int j = 1; j <= colCount; j++)
                                    {
                                        switch (j)
                                        {
                                            case 1:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sr.No.") { IsFormatCorrect = false; }
                                                break;
                                            case 2:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Project Code") { IsFormatCorrect = false; }
                                                break;
                                            case 3:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Build Specification Number") { IsFormatCorrect = false; }
                                                break;
                                            case 4:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Section") { IsFormatCorrect = false; }
                                                break;
                                            //case 5:
                                            //    if (xlRange.Cells[i, j].Value2.ToString() != "Lifecycle Status") { IsFormatCorrect = false; }
                                            //    break;
                                            case 5:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Para Number") { IsFormatCorrect = false; }
                                                break;
                                            case 6:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sub Para Number") { IsFormatCorrect = false; }
                                                break;
                                            case 7:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "SFI") { IsFormatCorrect = false; }
                                                break;
                                            case 8:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Ref. Build Specification Line") { IsFormatCorrect = false; }
                                                break;
                                            case 9:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Responsible Person") { IsFormatCorrect = false; }
                                                break;
                                            case 10:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sub Responsible Person") { IsFormatCorrect = false; }
                                                break;
                                            case 11:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Responsible Coordinator") { IsFormatCorrect = false; }
                                                break;
                                            case 12:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sub Responsible Coordinator") { IsFormatCorrect = false; }
                                                break;
                                            case 13:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Function") { IsFormatCorrect = false; }
                                                break;
                                            case 14:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "SOTR Required") { IsFormatCorrect = false; }
                                                break;
                                            case 15:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "SOTR Numbers") { IsFormatCorrect = false; }
                                                break;
                                            case 16:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Class Approved Drawings") { IsFormatCorrect = false; }
                                                break;
                                            case 17:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Production Drawings") { IsFormatCorrect = false; }
                                                break;
                                            case 18:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Extension") { IsFormatCorrect = false; }
                                                break;
                                            case 19:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Remark") { IsFormatCorrect = false; }
                                                break;
                                            default:
                                                break;
                                        }

                                    }
                                }
                                else
                                {
                                    if (IsFormatCorrect)
                                    {
                                        bool isSOTRRequired = false;
                                        _BuildSpecificationNumber = _BuildSpecificationNumber + 1;
                                        SingleBuildSpecificationSummary _objSingleBuildSpecificationSummary = new SingleBuildSpecificationSummary();
                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = true;
                                        _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = "Create";

                                        for (int j = 1; j <= colCount; j++)
                                        {
                                            if (isBreak == false)
                                            {
                                                switch (j)
                                                {
                                                    case 1:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() == "")
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Sr.No.)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Sr.No.)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 2:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    if (xlRange.Cells[i, j].Value2.ToString().Trim() == clsStaticGlobal._ProjectCode)
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationProjectCode = clsStaticGlobal._ProjectCode;
                                                                    }
                                                                    else
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        System.Windows.MessageBox.Show("Selected project and project in mass upload excel missmatch.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        isBreak = true;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Project Code)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Project Code)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 3:
                                                        {
                                                            try
                                                            {
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationNumber = _BuildSpecificationNumber;
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber = clsStaticGlobal._ProjectCode + "_" + _BuildSpecificationNumber.ToString();
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationFileName = "STS_" + _objSingleBuildSpecificationSummary.BuildSpecificationUniqNumber + ".xml";

                                                            }
                                                            catch (Exception)
                                                            {

                                                            }
                                                            break;
                                                        }
                                                    case 4:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationSECTION = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Section)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Section)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    //case 5:
                                                    //    {
                                                    //        try
                                                    //        {
                                                    //            if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                    //            {
                                                    //                _objSingleBuildSpecificationSummary.BuildSpecificationLifeCycle = "Create";
                                                    //            }
                                                    //            else
                                                    //            {
                                                    //                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Lifecycle Status)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                    //                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                    //                isBreak = true;
                                                    //            }
                                                    //        }
                                                    //        catch (Exception)
                                                    //        {
                                                    //            System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Lifecycle Status)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                    //            _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                    //            isBreak = true;
                                                    //        }

                                                    //        break;
                                                    //    }
                                                    case 5:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationParaNumber = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Para Number)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Para Number)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;                                                            
                                                        }
                                                    case 6:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationSubParaNumber = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Sub Para Number)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Sub Para Number)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 7:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationSFI = xlRange.Cells[i, j].Value2.ToString();
                                                                    string value = "";
                                                                    bool IsSFIdesc = false;
                                                                    foreach (var item in clsStaticGlobal.sficodes)
                                                                    {
                                                                        NameCodePair objNameCodePair = (NameCodePair)item;
                                                                        if(objNameCodePair.Code.ToUpper() == _objSingleBuildSpecificationSummary.BuildSpecificationSFI.ToUpper())
                                                                        {
                                                                            IsSFIdesc = true;
                                                                            value = objNameCodePair.Name;
                                                                            break;
                                                                        }
                                                                    }

                                                                    if (IsSFIdesc)
                                                                    {
                                                                        try
                                                                        {
                                                                            //value = SFIallList[_objSingleBuildSpecificationSummary.BuildSpecificationSFI.Trim()];
                                                                            if (value != null)
                                                                            {
                                                                                _objSingleBuildSpecificationSummary.BuildSpecificationSFIDesc = value.ToString();
                                                                            }
                                                                            else
                                                                            {
                                                                                _objSingleBuildSpecificationSummary.BuildSpecificationSFIDesc = "";
                                                                            }

                                                                        }
                                                                        catch (Exception)
                                                                        {
                                                                            System.Windows.MessageBox.Show("Mass upload excel data should not empty. (SFI)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                            _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                            isBreak = true;
                                                                        }
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (SFI)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (SFI)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 8:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationReferenceBuildSpecificationLine = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Ref. Build Specification Line)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (Ref. Build Specification Line)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 9:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string _ResponsiblePerson = "";
                                                                    _ResponsiblePerson = clsStaticGlobal.GetUserNameWithFirstandLast(xlRange.Cells[i, j].Value2.ToString().Trim());
                                                                    if (_ResponsiblePerson != "")
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson = _ResponsiblePerson;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Responsible person does not exist..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        isBreak = true;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationResponsiblePerson = "";
                                                            }

                                                            break;
                                                        }

                                                    case 10:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string _SubResponsiblePerson = "";
                                                                    _SubResponsiblePerson = clsStaticGlobal.GetUserNameWithFirstandLast(xlRange.Cells[i, j].Value2.ToString().Trim());
                                                                    if (_SubResponsiblePerson != "")
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson = _SubResponsiblePerson;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Sub Responsible person does not exist..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        isBreak = true;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsiblePerson = "";
                                                            }

                                                            break;
                                                        }
                                                    case 11:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string _ResponsiblePerson = "";
                                                                    _ResponsiblePerson = clsStaticGlobal.GetUserNameWithFirstandLast(xlRange.Cells[i, j].Value2.ToString().Trim());
                                                                    if (_ResponsiblePerson != "")
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator = _ResponsiblePerson;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Responsible Coordinator does not exist..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        isBreak = true;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationResponsibleCoordinator = "";
                                                            }

                                                            break;
                                                            
                                                        }

                                                    case 12:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string _SubResponsiblePerson = "";
                                                                    _SubResponsiblePerson = clsStaticGlobal.GetUserNameWithFirstandLast(xlRange.Cells[i, j].Value2.ToString().Trim());
                                                                    if (_SubResponsiblePerson != "")
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator = _SubResponsiblePerson;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Sub Responsible Coordinator does not exist..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        isBreak = true;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationSubResponsibleCoordinator = "";
                                                            }

                                                            break;

                                                        }
                                                    case 13:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string function = xlRange.Cells[i, j].Value2.ToString();
                                                                    function = function.Replace("\n", "");
                                                                    function = function.Replace("\r", "");
                                                                    string[] functions = function.Split(new char[] { ';', ',' });
                                                                    string _function = "";
                                                                    List<string> _functions = new List<string>();

                                                                    foreach (var item in functions)
                                                                    {
                                                                        if (_function.Trim() == "")
                                                                        {
                                                                            _function = item;
                                                                        }
                                                                        else
                                                                        {
                                                                            _function = _function + Environment.NewLine + item;
                                                                        }
                                                                        _functions.Add(item);

                                                                    }
                                                                    if (_function == "")
                                                                    {
                                                                        System.Windows.MessageBox.Show("Mass upload excel specified file does not exist. (Functions)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                        isBreak = true;
                                                                    }
                                                                    else
                                                                    {
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationFunction = _function;
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationFunctions = _functions;
                                                                    }

                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel specified file does not exist. (Functions)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 14:
                                                        {
                                                            try
                                                            {

                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string val = xlRange.Cells[i, j].Value2.ToString().Trim();
                                                                    if ((val.ToUpper() == "NA") || (val.ToUpper() == "YES") || (val.ToUpper() == "NO"))
                                                                    {
                                                                        if ((val.ToUpper() == "NA") || (val.ToUpper() == "NO"))
                                                                        {
                                                                            isSOTRRequired = false;
                                                                        }
                                                                        else
                                                                        {
                                                                            isSOTRRequired = true;
                                                                        }
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired = val;
                                                                    }
                                                                    else
                                                                    {
                                                                        isSOTRRequired = false;
                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationSOTRRequired = "NA";
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Mass upload excel data should not empty. (SOTR Required)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel data should not empty. (SOTR Required)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 15:
                                                        {
                                                            try
                                                            {                                                               
                                                                if ((xlRange.Cells[i, j].Value2 != null) && (xlRange.Cells[i, j].Value2.ToString().Trim() != ""))
                                                                {
                                                                    if (isSOTRRequired == true)
                                                                    {
                                                                        string SOTRDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                        SOTRDoc = SOTRDoc.Replace("\n", "");
                                                                        SOTRDoc = SOTRDoc.Replace("\r", "");
                                                                        string[] SOTRDocs = SOTRDoc.Split(new char[] { ';', ',' });

                                                                        string _SOTRNumber = "";
                                                                        string _SOTRNumberDAD = "";

                                                                        foreach (string item in SOTRDocs)
                                                                        {
                                                                            Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item, "SOTR", clsStaticGlobal.ProjectFolder);

                                                                            if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                                                            {
                                                                                Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                                                                string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                                                                                string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                                                                if (fileDec == null)
                                                                                {
                                                                                    fileDec = "";
                                                                                }
                                                                                string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                                                                                if (fileSection == null)
                                                                                {
                                                                                    fileSection = "";
                                                                                }

                                                                                string revision = _SearchedFile.FileRev.Label;
                                                                                if (revision == null)
                                                                                {
                                                                                    revision = "";
                                                                                }
                                                                                
                                                                                _objSingleBuildSpecificationSummary.ListSOTRNumber.Add(new SOTRNumber { Count = 0, IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = _SearchedFile.Name, FileNumber = item, FileDesc = fileDec, FileSection = fileSection, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = revision, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName});
                                                                            }
                                                                            else
                                                                            {
                                                                                string fileDec = item;
                                                                                _objSingleBuildSpecificationSummary.ListSOTRNumber.Add(new SOTRNumber { Count = 0, IsCheckedSOTRNumber = false, FileType = "SOTR", FileName = item, FileNumber = item, FileDesc = "", FileSection = "", FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist"});
                                                                            }
                                                                            
                                                                        }

                                                                        foreach (SOTRNumber item in _objSingleBuildSpecificationSummary.ListSOTRNumber)
                                                                        {
                                                                            if (item.FileType == "SOTR")
                                                                            {
                                                                                if (_SOTRNumber.Trim() == "")
                                                                                {
                                                                                    _SOTRNumber = "SOTR : " + item.FileName;
                                                                                }
                                                                                else
                                                                                {
                                                                                    _SOTRNumber = _SOTRNumber + "," + Environment.NewLine + "SOTR : " + item.FileName;
                                                                                }
                                                                            }

                                                                        }

                                                                        _objSingleBuildSpecificationSummary.BuildSpecificationSOTRNumber = _SOTRNumber + Environment.NewLine + _SOTRNumberDAD;

                                                                    }

                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel specified file does not exist. (SOTR Numbers)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 16:
                                                        {
                                                            try
                                                            {
                                                                if ((xlRange.Cells[i, j].Value2 != null) && (xlRange.Cells[i, j].Value2.ToString().Trim() != ""))
                                                                {
                                                                    string ClassApprovedDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    ClassApprovedDoc = ClassApprovedDoc.Replace("\n", "");
                                                                    ClassApprovedDoc = ClassApprovedDoc.Replace("\r", "");
                                                                    string[] ClassApprovedDocs = ClassApprovedDoc.Split(new char[] { ';', ',' });

                                                                    string _ClassDrawing = "";
                                                                    string _ClassDrawingDAD = "";

                                                                    foreach (string item in ClassApprovedDocs)
                                                                    {
                                                                        Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item, "CLASS APPROVED DOCUMENT", clsStaticGlobal.ProjectFolder);

                                                                        if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                                                        {
                                                                            Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                                                            string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                                                                            string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                                                            if (fileDec == null)
                                                                            {
                                                                                fileDec = "";
                                                                            }
                                                                            string fileSection = clsStaticGlobal.GetFilePropertyValue("Section", _SearchedFile.Id, false);
                                                                            if (fileSection == null)
                                                                            {
                                                                                fileSection = "";
                                                                            }
                                                                            string fileRelatedDAD = clsStaticGlobal.GetFilePropertyValue("Related DAD", _SearchedFile.Id, false); //Class Approved Drawing Number
                                                                            if (fileRelatedDAD == null)
                                                                            {
                                                                                fileRelatedDAD = "";
                                                                            }

                                                                            _objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { Count = 0, IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = _SearchedFile.Name, FileNumber = item, FileDesc = fileDec, FileSection = fileSection, FileRelatedDAD = fileRelatedDAD, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName, FileUsedIn = "" });

                                                                            FileAssocArray[] attachmentsFileList = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFileAssociationsByMasterIds(new long[] { _SearchedFile.MasterId }, FileAssociationTypeEnum.Attachment, true, FileAssociationTypeEnum.Attachment, true, true, true, false);

                                                                            foreach (FileAssocArray itemFileAssocArray in attachmentsFileList)
                                                                            {
                                                                                try
                                                                                {
                                                                                    foreach (FileAssoc itemFileAssoc in itemFileAssocArray.FileAssocs)
                                                                                    {
                                                                                        try
                                                                                        {
                                                                                            if (itemFileAssoc.ParFile != null)
                                                                                            {
                                                                                                Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(itemFileAssoc.ParFile.FolderId);
                                                                                                string filePath = folder.FullName + "/" + itemFileAssoc.ParFile.Name;
                                                                                                string fileName = itemFileAssoc.ParFile.Name;
                                                                                                string fileRemark = itemFileAssoc.ParFile.Comm;
                                                                                                string fileStatus = itemFileAssoc.ParFile.FileLfCyc.LfCycStateName;
                                                                                                string fileRevision = itemFileAssoc.ParFile.FileRev.Label.ToString();
                                                                                                string fileDec1 = clsStaticGlobal.GetFilePropertyValue("Description", itemFileAssoc.Id, false);
                                                                                                if (fileDec1 == null)
                                                                                                {
                                                                                                    fileDec1 = "";
                                                                                                }
                                                                                                _objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { IsCheckedClassDrawing = false, FileType = "DAD", FileName = fileName, FileNumber = "", FileDesc = fileDec1, FileSection = "", FilePath = filePath, FileRemark = fileRemark, FileRevision = fileRevision, FileStatus = fileStatus, FileRelatedDAD = "", FileUsedIn = _SearchedFile.Name });
                                                                                            }
                                                                                        }
                                                                                        catch (Exception ex)
                                                                                        {
                                                                                            clsStaticGlobal.ErrHandlerLog(ex);
                                                                                        }

                                                                                    }
                                                                                }
                                                                                catch (Exception ex)
                                                                                {
                                                                                    clsStaticGlobal.ErrHandlerLog(ex);
                                                                                }

                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            string fileDec = item;
                                                                            _objSingleBuildSpecificationSummary.ListClassDrawing.Add(new ClassDrawing { Count = 0, IsCheckedClassDrawing = false, FileType = "CLASS APPROVED", FileName = item, FileNumber = item, FileDesc = fileDec, FileSection = "", FileRelatedDAD = "", FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist", FileUsedIn = "" });
                                                                        }

                                                                    }

                                                                    foreach (ClassDrawing _item in _objSingleBuildSpecificationSummary.ListClassDrawing)
                                                                    {
                                                                        if (_item.FileType == "CLASS APPROVED")
                                                                        {
                                                                            if (_ClassDrawing.Trim() == "")
                                                                            {
                                                                                _ClassDrawing = "CLASS APPROVED : " + _item.FileName;
                                                                            }
                                                                            else
                                                                            {
                                                                                _ClassDrawing = _ClassDrawing + "," + Environment.NewLine + "CLASS APPROVED : " + _item.FileName;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (_ClassDrawingDAD.Trim() == "")
                                                                            {
                                                                                _ClassDrawingDAD = "DAD : " + _item.FileName;
                                                                            }
                                                                            else
                                                                            {
                                                                                _ClassDrawingDAD = _ClassDrawingDAD + "," + Environment.NewLine + "DAD : " + _item.FileName;
                                                                            }
                                                                        }

                                                                    }
                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationClassDrawing = _ClassDrawing + Environment.NewLine + _ClassDrawingDAD;
                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel specified file does not exist. (Class Approved Document)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 17:
                                                        {
                                                            try
                                                            {

                                                                if ((xlRange.Cells[i, j].Value2 != null) && (xlRange.Cells[i, j].Value2.ToString().Trim() != ""))
                                                                {
                                                                    string _ProductionDrawing = "";
                                                                    string ProductionDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    ProductionDoc = ProductionDoc.Replace("\n", "");
                                                                    ProductionDoc = ProductionDoc.Replace("\r", "");
                                                                    string[] ProductionDocs = ProductionDoc.Split(new char[] { ';', ',' });

                                                                    foreach (string item in ProductionDocs)
                                                                    {
                                                                        Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(item, "PRODUCTION DOCUMENT", clsStaticGlobal.ProjectFolder);

                                                                        if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                                                                        {
                                                                            Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                                                            string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                                                                            string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _SearchedFile.Id, false);
                                                                            if (fileDec == null)
                                                                            {
                                                                                fileDec = "";
                                                                            }
                                                                            string fileElement = clsStaticGlobal.GetFilePropertyValue("Element", _SearchedFile.Id, false);
                                                                            if (fileElement == null)
                                                                            {
                                                                                fileElement = "";
                                                                            }
                                                                            string filesfi = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                                                                            if (filesfi == null)
                                                                            {
                                                                                filesfi = "";
                                                                            }
                                                                            string fileRelevantClassApproved = clsStaticGlobal.GetFilePropertyValue("Class Approved Drawing Number", _SearchedFile.Id, false); //Class Approved Drawing Number
                                                                            if (fileRelevantClassApproved == null)
                                                                            {
                                                                                fileRelevantClassApproved = "";
                                                                            }
                                                                            _objSingleBuildSpecificationSummary.ListProductionDrawing.Add(new ProductionDrawing { Count = 0, IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _SearchedFile.Name, FileNumber = item, FileDesc = fileDec, FileElement = fileElement, FileSFI = filesfi, FileRelevantClassApproved = fileRelevantClassApproved, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName, FileUsedIn = "", });
                                                                        }
                                                                        else
                                                                        {
                                                                            string fileDec = item;
                                                                            _objSingleBuildSpecificationSummary.ListProductionDrawing.Add(new ProductionDrawing { Count = 0, IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = item, FileNumber = item, FileDesc = fileDec, FileElement = "", FileSFI = "", FileRelevantClassApproved = "", FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist", FileUsedIn = "" });
                                                                        }
                                                                                                                                                
                                                                    }

                                                                    foreach (ProductionDrawing item in _objSingleBuildSpecificationSummary.ListProductionDrawing)
                                                                    {
                                                                        if (_ProductionDrawing.Trim() == "")
                                                                        {
                                                                            _ProductionDrawing = "PRODUCTION : " + item.FileName;
                                                                        }
                                                                        else
                                                                        {
                                                                            _ProductionDrawing = _ProductionDrawing + "," + Environment.NewLine + "PRODUCTION : " + item.FileName;
                                                                        }
                                                                    }

                                                                    _objSingleBuildSpecificationSummary.BuildSpecificationProductionDrawing = _ProductionDrawing;

                                                                }
                                                            }
                                                            catch (Exception)
                                                            {
                                                                System.Windows.MessageBox.Show("Mass upload excel specified file does not exist. (Production Documents)", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleBuildSpecificationSummary.BuildSpecificationIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 18:
                                                        {
                                                            _objSingleBuildSpecificationSummary.BuildSpecificationExtension = xlRange.Cells[i, j].Value2.ToString();
                                                            break;
                                                        }
                                                    case 19:
                                                        {
                                                            _objSingleBuildSpecificationSummary.BuildSpecificationRemark = xlRange.Cells[i, j].Value2.ToString();
                                                            break;
                                                        }
                                                    default:
                                                        break;
                                                }

                                            }

                                        }

                                        _listBuildSpecification.Add(_objSingleBuildSpecificationSummary);

                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Invalid column header..!!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                        isBreak = true;
                                    }

                                }

                            }

                            //cleanup
                            GC.Collect();
                            GC.WaitForPendingFinalizers();

                            if (isBreak == false)
                            {
                                if (_listBuildSpecification.Count > 0)
                                {
                                    if (MassUpload(_listBuildSpecification))
                                    {
                                        System.Windows.MessageBox.Show("Mass upload done successfully.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Information);
                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                    }

                                }
                                else
                                {
                                    System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                                }

                            }
                            else
                            {
                                System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                            }

                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            try
                            {
                                Marshal.ReleaseComObject(xlRange);
                                Marshal.ReleaseComObject(xlWorksheet);

                                //close and release
                                xlWorkbook.Close();
                                Marshal.ReleaseComObject(xlWorkbook);

                                //quit and release
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);

                            }
                            catch (Exception)
                            {
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);
                            }

                        }

                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Excel application not installed or else Build Specification sheet not found.!", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Warning);
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                System.Windows.MessageBox.Show("Select project first.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void cmdcmdMassUploadFormat_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string MassUploadFileFormatPath = clsStaticGlobal.ErrorFilePath + "/Build Specifications Mass Upload.xlsx";
                FolderBrowserDialog openfolderdialog1 = new FolderBrowserDialog();
                openfolderdialog1.ShowNewFolderButton = true;
                if (openfolderdialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string MassUploadDestinationFilePath = openfolderdialog1.SelectedPath + "/Build Specifications Mass Upload_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";
                    if (System.IO.File.Exists(MassUploadFileFormatPath))
                    {
                        if (System.IO.File.Exists(MassUploadDestinationFilePath))
                            System.IO.File.Delete(MassUploadDestinationFilePath);
                        System.IO.File.Copy(MassUploadFileFormatPath, MassUploadDestinationFilePath);
                        System.Windows.MessageBox.Show("Build Specifications Mass Upload File Format Exported Successfully.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Build Specifications Mass Upload File Format Exported Failed.", "Build Specifications", MessageBoxButton.OK, MessageBoxImage.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool MassUpload(List<SingleBuildSpecificationSummary> _listSingleBuildSpecificationSummary)
        {

            bool _isSuccess = false;
            try
            {
                //Debugger.Launch();
                foreach (SingleBuildSpecificationSummary _objSingleBuildSpecificationSummary in _listSingleBuildSpecificationSummary)
                {
                    String _xmlFilePath = clsStaticGlobal.LocalXMLBuildSpecificationFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + _objSingleBuildSpecificationSummary.BuildSpecificationFileName;
                    _objSingleBuildSpecificationSummary.BuildSpecificationFileFullPath = clsStaticGlobal.VaultBuildSpecificationFolder.FullName + "/" + _objSingleBuildSpecificationSummary.BuildSpecificationFileName;
                    clsStaticGlobal.BindingDataSingleWrite(_objSingleBuildSpecificationSummary, _xmlFilePath, false);
                    clsStaticGlobal.UpdateFileRemark(_objSingleBuildSpecificationSummary);
                }

                BindwithFilter();

                _isSuccess = true;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _isSuccess;
        }

        private List<int> GetAllCommentsNumbers(string _ProjectCode)
        {
            List<int> listCommentsNumbers = new List<int>();
            try
            {
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultBuildSpecificationFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.BuildSpecificationFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            string[] CommentsNumberSplite = file.Name.Split(new char[] { '_' });
                            string CommentNumber = CommentsNumberSplite[2].ToUpper().Replace(".XML", "");
                            listCommentsNumbers.Add(int.Parse(CommentNumber));
                            listCommentsNumbers.Sort();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return listCommentsNumbers;
        }

    }

    public class ProjectCodes
    {
        private string mProjectCode;

        public string ProjectCodeName
        {
            get { return mProjectCode; }
            set { mProjectCode = value; }
        }
    }

    public class CommentStates
    {
        private string mCommentState;

        public string CommentState
        {
            get { return mCommentState; }
            set { mCommentState = value; }
        }

    }

    public class CompletionActivities
    {
        private string mCompletionActivity;

        public string CompletionActivity
        {
            get { return mCompletionActivity; }
            set { mCompletionActivity = value; }
        }

    }

}
