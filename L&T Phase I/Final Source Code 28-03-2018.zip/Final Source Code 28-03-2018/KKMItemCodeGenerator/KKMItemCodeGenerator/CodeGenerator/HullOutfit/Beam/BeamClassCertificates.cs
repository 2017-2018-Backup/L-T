﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamClassCertificates : ObservableCollection<NameCodePair>
    {
        public static BeamClassCertificates LoadList()
        {
            BeamClassCertificates items = new BeamClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "LR 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "LR 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "GL 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GL 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "NO CERTIFICATE" });

            return items;
        }
        public static BeamClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamClassCertificates>(HullOutfitItems.DataPath + @"\Beam\BeamClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamClassCertificates>(this, HullOutfitItems.DataPath + @"\Beam\BeamClassCertificates.xml");
        }
    }
}
