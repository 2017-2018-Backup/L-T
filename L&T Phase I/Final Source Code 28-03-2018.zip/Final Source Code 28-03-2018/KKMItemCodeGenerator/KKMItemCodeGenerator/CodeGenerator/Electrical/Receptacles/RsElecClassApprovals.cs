﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class RsElecClassApprovals : ObservableCollection<NameCodePair>
    {
        public static RsElecClassApprovals LoadList()
        {
            RsElecClassApprovals items = new RsElecClassApprovals();
            items.Add(new NameCodePair() { Code = "01", Name = "LR" });
            items.Add(new NameCodePair() { Code = "02", Name = "GL" });
            items.Add(new NameCodePair() { Code = "03", Name = "NIL" });
            items.Add(new NameCodePair() { Code = "04", Name = "DNV" });
            items.Add(new NameCodePair() { Code = "05", Name = "ABS" });
            items.Add(new NameCodePair() { Code = "06", Name = "IRS" });

            return items;
        }
        public static RsElecClassApprovals LoadFromExcel(String path)
        {
            return null;
        }

        public static RsElecClassApprovals LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<RsElecClassApprovals>(ElectricalItems.DataPath + @"\Receptacles\ElecClassApprovals.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<RsElecClassApprovals>(this, ElectricalItems.DataPath + @"\Receptacles\ElecClassApprovals.xml");
        }

    }
}
