﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandCableODs : ObservableCollection<NameCodePair>
    {
        public static CableGlandCableODs LoadList()
        {
            CableGlandCableODs items = new CableGlandCableODs();
            items.Add(new NameCodePair() { Code = "01", Name = "6 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "8 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "9 - 9.9 mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "10-10.9 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "11-11.9 mm" });
            items.Add(new NameCodePair() { Code = "06", Name = "12-12.9 mm" });
            items.Add(new NameCodePair() { Code = "07", Name = "13-13.9 mm" });
            items.Add(new NameCodePair() { Code = "08", Name = "15-15.9 mm" });
            items.Add(new NameCodePair() { Code = "09", Name = "16-16.9 mm" });
            items.Add(new NameCodePair() { Code = "10", Name = "17-17.9 mm" });
            items.Add(new NameCodePair() { Code = "11", Name = "18 mm" });
            items.Add(new NameCodePair() { Code = "12", Name = "20-20.9 mm" });
            items.Add(new NameCodePair() { Code = "13", Name = "21-21.9 mm" });
            items.Add(new NameCodePair() { Code = "14", Name = "23 mm" });
            items.Add(new NameCodePair() { Code = "15", Name = "24-24.9 mm" });
            items.Add(new NameCodePair() { Code = "16", Name = "25-25.9 mm" });
            items.Add(new NameCodePair() { Code = "17", Name = "26 mm" });
            items.Add(new NameCodePair() { Code = "18", Name = "27.8 mm" });
            items.Add(new NameCodePair() { Code = "19", Name = "32.2 mm" });
            items.Add(new NameCodePair() { Code = "20", Name = "37 mm" });
            items.Add(new NameCodePair() { Code = "21", Name = "50.7 mm" });
            items.Add(new NameCodePair() { Code = "22", Name = "53.6 mm" });

            return items;
        }
        public static CableGlandCableODs LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandCableODs LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandCableODs>(ElectricalItems.DataPath + @"\CableGland\CableGlandCableODs.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandCableODs>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandCableODs.xml");
        }

    }
}
