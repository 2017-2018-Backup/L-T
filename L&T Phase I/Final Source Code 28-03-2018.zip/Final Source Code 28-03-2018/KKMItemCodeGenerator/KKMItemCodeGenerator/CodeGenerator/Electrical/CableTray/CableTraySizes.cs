﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTraySizes : ObservableCollection<NameCodePair>
    {
        public static CableTraySizes LoadList()
        {
            CableTraySizes items = new CableTraySizes();
            items.Add(new NameCodePair() { Code = "001", Name = "Width 1000 mm" });
            items.Add(new NameCodePair() { Code = "002", Name = "Width 600 mm" });
            items.Add(new NameCodePair() { Code = "003", Name = "Width 500 mm" });
            items.Add(new NameCodePair() { Code = "004", Name = "Width 300 mm" });
            items.Add(new NameCodePair() { Code = "005", Name = "Width 200 mm" });
            items.Add(new NameCodePair() { Code = "007", Name = "Width 100 mm" });
            items.Add(new NameCodePair() { Code = "006", Name = "Width 1000x600 mm" });
            items.Add(new NameCodePair() { Code = "008", Name = "Width 400 mm" });
            items.Add(new NameCodePair() { Code = "009", Name = "Width 150 mm" });
            items.Add(new NameCodePair() { Code = "011", Name = "Width 1000 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "012", Name = "Width 600 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "013", Name = "Width 500 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "014", Name = "Width 300 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "015", Name = "Width 200 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "017", Name = "Width 100 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "016", Name = "Width 1000x600 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "018", Name = "Width 400 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "019", Name = "Width 150 mm H-(50mm)" });
            items.Add(new NameCodePair() { Code = "021", Name = "Width 1000 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "022", Name = "Width 600 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "023", Name = "Width 500 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "024", Name = "Width 300 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "025", Name = "Width 200 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "027", Name = "Width 100 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "026", Name = "Width 1000x600 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "028", Name = "Width 400 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "029", Name = "Width 150 mm H-(20mm)" });
            items.Add(new NameCodePair() { Code = "031", Name = "Width 50 mm" });
            items.Add(new NameCodePair() { Code = "032", Name = "Width 400 to 300 mm" });
            items.Add(new NameCodePair() { Code = "033", Name = "Width 400 to 200 mm" });
            items.Add(new NameCodePair() { Code = "034", Name = "Width 400 to 150 mm" });
            items.Add(new NameCodePair() { Code = "035", Name = "Width 400 to 100 mm" });
            items.Add(new NameCodePair() { Code = "036", Name = "Width 300 to 200 mm" });
            items.Add(new NameCodePair() { Code = "037", Name = "Width 300 to 150 mm" });
            items.Add(new NameCodePair() { Code = "038", Name = "Width 300 to 100 mm" });
            items.Add(new NameCodePair() { Code = "039", Name = "Width 200 to 150 mm" });
            items.Add(new NameCodePair() { Code = "041", Name = "Width 200 to 100 mm" });
            items.Add(new NameCodePair() { Code = "042", Name = "Width 150 to 100 mm" });
            items.Add(new NameCodePair() { Code = "043", Name = "W=1000 TO 600 mm" });
            items.Add(new NameCodePair() { Code = "044", Name = "W=1000 TO 400 mm" });
            items.Add(new NameCodePair() { Code = "045", Name = "W=600 TO 400 mm" });
            items.Add(new NameCodePair() { Code = "046", Name = "W=600 TO 300 mm" });
            items.Add(new NameCodePair() { Code = "047", Name = "W=600 TO 200 mm" });
            items.Add(new NameCodePair() { Code = "048", Name = "W=500 TO 300 mm" });
            items.Add(new NameCodePair() { Code = "049", Name = "W=500 TO 400 mm" });
            items.Add(new NameCodePair() { Code = "051", Name = "W=500 TO 200 mm" });
            items.Add(new NameCodePair() { Code = "052", Name = "W=300 TO 200 mm" });
            items.Add(new NameCodePair() { Code = "053", Name = "NA" });
            return items;
        }
        public static CableTraySizes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTraySizes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTraySizes>(ElectricalItems.DataPath + @"\CableTray\CableTraySizes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTraySizes>(this, ElectricalItems.DataPath + @"\CableTray\CableTraySizes.xml");
        }

    }
}
