﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ElectricalItemGroups : ObservableCollection<NameCodePair>
    {
        public static ElectricalItemGroups LoadList()
        {
            ElectricalItemGroups items = new ElectricalItemGroups();
            items.Add(new NameCodePair() { Code = "NCE", Name = "Navigaton & Communication Eqpt" });
            items.Add(new NameCodePair() { Code = "AUI", Name = "Automation & Instrumentation" });
            items.Add(new NameCodePair() { Code = "ELE", Name = "Electrical Items" });
            items.Add(new NameCodePair() { Code = "ECT", Name = "Electrical Cables & Trays" });
            items.Add(new NameCodePair() { Code = "PAC", Name = "Painting Consumables" });
            items.Add(new NameCodePair() { Code = "MAI", Name = "Maintenanace Items" });
            items.Add(new NameCodePair() { Code = "TAB", Name = "Tools& Abrasives" });
            items.Add(new NameCodePair() { Code = "ACV", Name = "AC & Ventilation items" });
            items.Add(new NameCodePair() { Code = "CAN", Name = "Canteen Items" });
            items.Add(new NameCodePair() { Code = "VEH", Name = "Motor Vehicles & Accessories" });
            items.Add(new NameCodePair() { Code = "MIS", Name = "Miscellaneous Items" });
            items.Add(new NameCodePair() { Code = "COM", Name = "Computer Items" });
            items.Add(new NameCodePair() { Code = "INP", Name = "Insulation & Protection" });
            items.Add(new NameCodePair() { Code = "FFA", Name = "Fire Fighting appliances" });

            return items;
        }
        public static ElectricalItemGroups LoadFromExcel(String path)
        {
            return null;
        }

        public static ElectricalItemGroups LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ElectricalItemGroups>(ElectricalItems.DataPath + @"\ElectricalItemGroups.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ElectricalItemGroups>(this, ElectricalItems.DataPath + @"\ElectricalItemGroups.xml");
        }
    }
}
