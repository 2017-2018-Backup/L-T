﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersMeshSizes : ObservableCollection<NameCodePair>
    {
        public static StrainersMeshSizes LoadList()
        {
            StrainersMeshSizes items = new StrainersMeshSizes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "0.1 mm" });
            items.Add(new NameCodePair() { Code = "02", Name = "1.5 mm" });
            items.Add(new NameCodePair() { Code = "03", Name = "3 mm" });
            items.Add(new NameCodePair() { Code = "04", Name = "8 mm" });
            items.Add(new NameCodePair() { Code = "05", Name = "10 mm" });
            items.Add(new NameCodePair() { Code = "06", Name = "2 mm" });
            items.Add(new NameCodePair() { Code = "07", Name = "1 mm" });
            items.Add(new NameCodePair() { Code = "08", Name = "15 mm" });
            items.Add(new NameCodePair() { Code = "09", Name = "0.6 mm" });
            return items;
        }
        public static StrainersMeshSizes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersMeshSizes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersMeshSizes>(EngineeringItems.DataPath + @"\Strainers\StrainersMeshSizes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersMeshSizes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersMeshSizes.xml");
        }

    }
}
