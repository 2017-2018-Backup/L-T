﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveGlobeSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveGlobeSubTypes LoadList()
        {
            ValveGlobeSubTypes items = new ValveGlobeSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "3 WAY" });
            items.Add(new NameCodePair() { Code = "02", Name = "REDUCED BORE" });
            items.Add(new NameCodePair() { Code = "03", Name = "FLOW REGULATING VALVE" });
            return items;
        }
        public static ValveGlobeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveGlobeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveGlobeSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveGlobeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveGlobeSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveGlobeSubTypes.xml");
        }

    }
}
