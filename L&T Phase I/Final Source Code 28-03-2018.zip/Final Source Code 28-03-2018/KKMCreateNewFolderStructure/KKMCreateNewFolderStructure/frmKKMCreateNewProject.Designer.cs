﻿namespace KKMCreateNewProjectStructure
{
    partial class frmKKMCreateNewProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKKMCreateNewProject));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbLeadingSociety = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.lstClassificationSociety = new System.Windows.Forms.CheckedListBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtLicensor = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtProjectLocation = new System.Windows.Forms.TextBox();
            this.dtpLOIRecieptDate = new System.Windows.Forms.DateTimePicker();
            this.dtpPORecieptDate = new System.Windows.Forms.DateTimePicker();
            this.dtpContractualDeliveryDate = new System.Windows.Forms.DateTimePicker();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTypeDesignRqdfromLT = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbIsSiteWorkRequired = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.dtpZeroDate = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtResponsibleProjectOwner = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSBUDepartment = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtOwner = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCustomerLOINumber = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCustomerPONumber = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPIM = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtCategoryofProject = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTypeofGuaranteeRequired = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDeliveryCondition = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTransportationScope = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDOCEnclosed = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProductEndUser = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtConsultant = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProjectTitle = new System.Windows.Forms.TextBox();
            this.cmbProjectNumber = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProjectNumber = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cmdCreateProject = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider7 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(925, 612);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 32);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(925, 542);
            this.panel2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.cmbLeadingSociety);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.lstClassificationSociety);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.txtLicensor);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.txtProjectLocation);
            this.groupBox1.Controls.Add(this.dtpLOIRecieptDate);
            this.groupBox1.Controls.Add(this.dtpPORecieptDate);
            this.groupBox1.Controls.Add(this.dtpContractualDeliveryDate);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtTypeDesignRqdfromLT);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.cmbIsSiteWorkRequired);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.dtpZeroDate);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtResponsibleProjectOwner);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtSBUDepartment);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtOwner);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtCustomerLOINumber);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtCustomerPONumber);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtPIM);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.txtCategoryofProject);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtTypeofGuaranteeRequired);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtDeliveryCondition);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtTransportationScope);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtDOCEnclosed);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtProductEndUser);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtConsultant);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtDescription);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtProjectTitle);
            this.groupBox1.Controls.Add(this.cmbProjectNumber);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtProjectNumber);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(925, 542);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Project Properties :";
            // 
            // cmbLeadingSociety
            // 
            this.cmbLeadingSociety.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLeadingSociety.FormattingEnabled = true;
            this.cmbLeadingSociety.Items.AddRange(new object[] {
            "N/A",
            "ALL"});
            this.cmbLeadingSociety.Location = new System.Drawing.Point(729, 25);
            this.cmbLeadingSociety.Name = "cmbLeadingSociety";
            this.cmbLeadingSociety.Size = new System.Drawing.Size(165, 24);
            this.cmbLeadingSociety.TabIndex = 14;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(510, 27);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(215, 16);
            this.label35.TabIndex = 72;
            this.label35.Text = "Leading Classification Society :";
            // 
            // lstClassificationSociety
            // 
            this.lstClassificationSociety.CheckOnClick = true;
            this.lstClassificationSociety.FormattingEnabled = true;
            this.lstClassificationSociety.Items.AddRange(new object[] {
            "ABS",
            "BV",
            "CCS",
            "CRS",
            "DNV",
            "GL",
            "IRS",
            "KR",
            "LR",
            "NNK",
            "PRS",
            "RINA",
            "RS"});
            this.lstClassificationSociety.Location = new System.Drawing.Point(210, 377);
            this.lstClassificationSociety.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.lstClassificationSociety.MultiColumn = true;
            this.lstClassificationSociety.Name = "lstClassificationSociety";
            this.lstClassificationSociety.Size = new System.Drawing.Size(265, 148);
            this.lstClassificationSociety.Sorted = true;
            this.lstClassificationSociety.TabIndex = 13;
            this.lstClassificationSociety.UseCompatibleTextRendering = true;
            this.lstClassificationSociety.SelectedIndexChanged += new System.EventHandler(this.lstClassificationSociety_SelectedIndexChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(47, 381);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(160, 16);
            this.label34.TabIndex = 70;
            this.label34.Text = "Classification Society :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(652, 60);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(73, 16);
            this.label33.TabIndex = 68;
            this.label33.Text = "Licensor :";
            // 
            // txtLicensor
            // 
            this.txtLicensor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicensor.Location = new System.Drawing.Point(729, 57);
            this.txtLicensor.Name = "txtLicensor";
            this.txtLicensor.Size = new System.Drawing.Size(165, 23);
            this.txtLicensor.TabIndex = 15;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(897, 149);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 18);
            this.label32.TabIndex = 66;
            this.label32.Text = "*";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(897, 120);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 18);
            this.label31.TabIndex = 65;
            this.label31.Text = "*";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(897, 91);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 18);
            this.label30.TabIndex = 64;
            this.label30.Text = "*";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(598, 383);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(127, 16);
            this.label29.TabIndex = 63;
            this.label29.Text = "Project Location :";
            // 
            // txtProjectLocation
            // 
            this.txtProjectLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProjectLocation.Location = new System.Drawing.Point(729, 380);
            this.txtProjectLocation.Name = "txtProjectLocation";
            this.txtProjectLocation.Size = new System.Drawing.Size(165, 23);
            this.txtProjectLocation.TabIndex = 26;
            // 
            // dtpLOIRecieptDate
            // 
            this.dtpLOIRecieptDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLOIRecieptDate.Location = new System.Drawing.Point(729, 203);
            this.dtpLOIRecieptDate.Name = "dtpLOIRecieptDate";
            this.dtpLOIRecieptDate.Size = new System.Drawing.Size(165, 23);
            this.dtpLOIRecieptDate.TabIndex = 20;
            // 
            // dtpPORecieptDate
            // 
            this.dtpPORecieptDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPORecieptDate.Location = new System.Drawing.Point(729, 174);
            this.dtpPORecieptDate.Name = "dtpPORecieptDate";
            this.dtpPORecieptDate.Size = new System.Drawing.Size(165, 23);
            this.dtpPORecieptDate.TabIndex = 19;
            // 
            // dtpContractualDeliveryDate
            // 
            this.dtpContractualDeliveryDate.CustomFormat = "";
            this.dtpContractualDeliveryDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpContractualDeliveryDate.Location = new System.Drawing.Point(729, 145);
            this.dtpContractualDeliveryDate.Name = "dtpContractualDeliveryDate";
            this.dtpContractualDeliveryDate.Size = new System.Drawing.Size(165, 23);
            this.dtpContractualDeliveryDate.TabIndex = 18;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(14, 350);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(193, 16);
            this.label28.TabIndex = 58;
            this.label28.Text = "Type Design Rqd from L&&T :";
            // 
            // txtTypeDesignRqdfromLT
            // 
            this.txtTypeDesignRqdfromLT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeDesignRqdfromLT.Location = new System.Drawing.Point(210, 348);
            this.txtTypeDesignRqdfromLT.Name = "txtTypeDesignRqdfromLT";
            this.txtTypeDesignRqdfromLT.Size = new System.Drawing.Size(265, 23);
            this.txtTypeDesignRqdfromLT.TabIndex = 12;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(480, 322);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 18);
            this.label27.TabIndex = 56;
            this.label27.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(480, 232);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 18);
            this.label26.TabIndex = 55;
            this.label26.Text = "*";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(480, 146);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 18);
            this.label25.TabIndex = 54;
            this.label25.Text = "*";
            // 
            // cmbIsSiteWorkRequired
            // 
            this.cmbIsSiteWorkRequired.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIsSiteWorkRequired.FormattingEnabled = true;
            this.cmbIsSiteWorkRequired.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbIsSiteWorkRequired.Location = new System.Drawing.Point(210, 317);
            this.cmbIsSiteWorkRequired.Name = "cmbIsSiteWorkRequired";
            this.cmbIsSiteWorkRequired.Size = new System.Drawing.Size(265, 24);
            this.cmbIsSiteWorkRequired.TabIndex = 11;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(46, 319);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(161, 16);
            this.label24.TabIndex = 52;
            this.label24.Text = "Is Site Work Required :";
            // 
            // dtpZeroDate
            // 
            this.dtpZeroDate.Cursor = System.Windows.Forms.Cursors.Default;
            this.dtpZeroDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpZeroDate.Location = new System.Drawing.Point(210, 113);
            this.dtpZeroDate.Name = "dtpZeroDate";
            this.dtpZeroDate.Size = new System.Drawing.Size(265, 23);
            this.dtpZeroDate.TabIndex = 4;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(482, 28);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(19, 18);
            this.label23.TabIndex = 49;
            this.label23.Text = "*";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(520, 352);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(205, 16);
            this.label22.TabIndex = 48;
            this.label22.Text = "Responsible / Project Owner :";
            // 
            // txtResponsibleProjectOwner
            // 
            this.txtResponsibleProjectOwner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtResponsibleProjectOwner.Location = new System.Drawing.Point(729, 349);
            this.txtResponsibleProjectOwner.Name = "txtResponsibleProjectOwner";
            this.txtResponsibleProjectOwner.Size = new System.Drawing.Size(165, 23);
            this.txtResponsibleProjectOwner.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(598, 322);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 16);
            this.label13.TabIndex = 46;
            this.label13.Text = "SBU Department :";
            // 
            // txtSBUDepartment
            // 
            this.txtSBUDepartment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSBUDepartment.Location = new System.Drawing.Point(729, 319);
            this.txtSBUDepartment.Name = "txtSBUDepartment";
            this.txtSBUDepartment.Size = new System.Drawing.Size(165, 23);
            this.txtSBUDepartment.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(669, 293);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 44;
            this.label14.Text = "Client :";
            // 
            // txtOwner
            // 
            this.txtOwner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOwner.Location = new System.Drawing.Point(729, 290);
            this.txtOwner.Name = "txtOwner";
            this.txtOwner.Size = new System.Drawing.Size(165, 23);
            this.txtOwner.TabIndex = 23;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(563, 264);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(162, 16);
            this.label15.TabIndex = 42;
            this.label15.Text = "Customer LOI Number :";
            // 
            // txtCustomerLOINumber
            // 
            this.txtCustomerLOINumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerLOINumber.Location = new System.Drawing.Point(729, 261);
            this.txtCustomerLOINumber.Name = "txtCustomerLOINumber";
            this.txtCustomerLOINumber.Size = new System.Drawing.Size(165, 23);
            this.txtCustomerLOINumber.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(567, 235);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(158, 16);
            this.label16.TabIndex = 40;
            this.label16.Text = "Customer PO Number :";
            // 
            // txtCustomerPONumber
            // 
            this.txtCustomerPONumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCustomerPONumber.Location = new System.Drawing.Point(729, 232);
            this.txtCustomerPONumber.Name = "txtCustomerPONumber";
            this.txtCustomerPONumber.Size = new System.Drawing.Size(165, 23);
            this.txtCustomerPONumber.TabIndex = 21;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(594, 206);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 16);
            this.label17.TabIndex = 38;
            this.label17.Text = "LOI Reciept Date :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(598, 177);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 16);
            this.label18.TabIndex = 36;
            this.label18.Text = "PO Reciept Date :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(536, 148);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(189, 16);
            this.label19.TabIndex = 34;
            this.label19.Text = "Contractual Delivery Date :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(682, 119);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 16);
            this.label20.TabIndex = 32;
            this.label20.Text = "PIM :";
            // 
            // txtPIM
            // 
            this.txtPIM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPIM.Location = new System.Drawing.Point(729, 116);
            this.txtPIM.Name = "txtPIM";
            this.txtPIM.Size = new System.Drawing.Size(165, 23);
            this.txtPIM.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(576, 90);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(149, 16);
            this.label21.TabIndex = 30;
            this.label21.Text = "Category of Project :";
            // 
            // txtCategoryofProject
            // 
            this.txtCategoryofProject.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCategoryofProject.Location = new System.Drawing.Point(729, 87);
            this.txtCategoryofProject.Name = "txtCategoryofProject";
            this.txtCategoryofProject.Size = new System.Drawing.Size(165, 23);
            this.txtCategoryofProject.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Type of Guarantee Required :";
            // 
            // txtTypeofGuaranteeRequired
            // 
            this.txtTypeofGuaranteeRequired.BackColor = System.Drawing.Color.White;
            this.txtTypeofGuaranteeRequired.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTypeofGuaranteeRequired.Location = new System.Drawing.Point(210, 287);
            this.txtTypeofGuaranteeRequired.Name = "txtTypeofGuaranteeRequired";
            this.txtTypeofGuaranteeRequired.Size = new System.Drawing.Size(265, 23);
            this.txtTypeofGuaranteeRequired.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 260);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Delivery Condition :";
            // 
            // txtDeliveryCondition
            // 
            this.txtDeliveryCondition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDeliveryCondition.Location = new System.Drawing.Point(210, 258);
            this.txtDeliveryCondition.Name = "txtDeliveryCondition";
            this.txtDeliveryCondition.Size = new System.Drawing.Size(265, 23);
            this.txtDeliveryCondition.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(45, 231);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(162, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "Transportation Scope :";
            // 
            // txtTransportationScope
            // 
            this.txtTransportationScope.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTransportationScope.Location = new System.Drawing.Point(210, 229);
            this.txtTransportationScope.Name = "txtTransportationScope";
            this.txtTransportationScope.Size = new System.Drawing.Size(265, 23);
            this.txtTransportationScope.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(97, 202);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 16);
            this.label11.TabIndex = 19;
            this.label11.Text = "DOC Enclosed :";
            // 
            // txtDOCEnclosed
            // 
            this.txtDOCEnclosed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDOCEnclosed.Location = new System.Drawing.Point(210, 200);
            this.txtDOCEnclosed.Name = "txtDOCEnclosed";
            this.txtDOCEnclosed.Size = new System.Drawing.Size(265, 23);
            this.txtDOCEnclosed.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(74, 173);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 16);
            this.label12.TabIndex = 16;
            this.label12.Text = "Product End User :";
            // 
            // txtProductEndUser
            // 
            this.txtProductEndUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProductEndUser.Location = new System.Drawing.Point(210, 171);
            this.txtProductEndUser.Name = "txtProductEndUser";
            this.txtProductEndUser.Size = new System.Drawing.Size(265, 23);
            this.txtProductEndUser.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(117, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Consultant :";
            // 
            // txtConsultant
            // 
            this.txtConsultant.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConsultant.Location = new System.Drawing.Point(210, 142);
            this.txtConsultant.Name = "txtConsultant";
            this.txtConsultant.Size = new System.Drawing.Size(265, 23);
            this.txtConsultant.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(122, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Zero Date :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(116, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Description :";
            // 
            // txtDescription
            // 
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescription.Location = new System.Drawing.Point(210, 84);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(265, 23);
            this.txtDescription.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(107, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Project Title :";
            // 
            // txtProjectTitle
            // 
            this.txtProjectTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProjectTitle.Location = new System.Drawing.Point(210, 55);
            this.txtProjectTitle.Name = "txtProjectTitle";
            this.txtProjectTitle.Size = new System.Drawing.Size(265, 23);
            this.txtProjectTitle.TabIndex = 2;
            // 
            // cmbProjectNumber
            // 
            this.cmbProjectNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectNumber.FormattingEnabled = true;
            this.cmbProjectNumber.Items.AddRange(new object[] {
            "CNB",
            "DNB",
            "Ship repair"});
            this.cmbProjectNumber.Location = new System.Drawing.Point(210, 25);
            this.cmbProjectNumber.Name = "cmbProjectNumber";
            this.cmbProjectNumber.Size = new System.Drawing.Size(87, 24);
            this.cmbProjectNumber.Sorted = true;
            this.cmbProjectNumber.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Project Number :";
            // 
            // txtProjectNumber
            // 
            this.txtProjectNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProjectNumber.Location = new System.Drawing.Point(303, 25);
            this.txtProjectNumber.MaxLength = 200;
            this.txtProjectNumber.Name = "txtProjectNumber";
            this.txtProjectNumber.Size = new System.Drawing.Size(172, 23);
            this.txtProjectNumber.TabIndex = 1;
            this.txtProjectNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProjectNumber_KeyPress);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.cmdCreateProject);
            this.panel3.Controls.Add(this.cmdCancel);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 574);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(925, 38);
            this.panel3.TabIndex = 2;
            // 
            // cmdCreateProject
            // 
            this.cmdCreateProject.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCreateProject.Location = new System.Drawing.Point(680, 4);
            this.cmdCreateProject.Margin = new System.Windows.Forms.Padding(4);
            this.cmdCreateProject.Name = "cmdCreateProject";
            this.cmdCreateProject.Size = new System.Drawing.Size(115, 30);
            this.cmdCreateProject.TabIndex = 0;
            this.cmdCreateProject.Text = "Create Project";
            this.cmdCreateProject.UseVisualStyleBackColor = true;
            this.cmdCreateProject.Click += new System.EventHandler(this.cmdCreateProject_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancel.Location = new System.Drawing.Point(806, 4);
            this.cmdCancel.Margin = new System.Windows.Forms.Padding(4);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(115, 30);
            this.cmdCancel.TabIndex = 1;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancle_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(925, 32);
            this.panel4.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(678, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "*";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SansSerif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.Location = new System.Drawing.Point(694, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marked properties are mandatory";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // errorProvider7
            // 
            this.errorProvider7.ContainerControl = this;
            // 
            // frmKKMCreateNewProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 612);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmKKMCreateNewProject";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create New Project";
            this.Load += new System.EventHandler(this.frmKKMCreateNewFolder_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button cmdCreateProject;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbProjectNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtProjectNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtProjectTitle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTypeofGuaranteeRequired;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDeliveryCondition;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTransportationScope;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDOCEnclosed;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProductEndUser;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtConsultant;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtResponsibleProjectOwner;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSBUDepartment;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtOwner;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCustomerLOINumber;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCustomerPONumber;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPIM;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtCategoryofProject;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DateTimePicker dtpZeroDate;
        private System.Windows.Forms.ComboBox cmbIsSiteWorkRequired;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtTypeDesignRqdfromLT;
        private System.Windows.Forms.DateTimePicker dtpLOIRecieptDate;
        private System.Windows.Forms.DateTimePicker dtpPORecieptDate;
        private System.Windows.Forms.DateTimePicker dtpContractualDeliveryDate;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtProjectLocation;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.ErrorProvider errorProvider7;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtLicensor;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckedListBox lstClassificationSociety;
        private System.Windows.Forms.ComboBox cmbLeadingSociety;
        private System.Windows.Forms.Label label35;
    }
}