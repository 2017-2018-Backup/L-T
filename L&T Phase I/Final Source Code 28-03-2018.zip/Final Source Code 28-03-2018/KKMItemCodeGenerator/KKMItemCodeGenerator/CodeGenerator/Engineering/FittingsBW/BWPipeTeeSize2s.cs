﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWPipeTeeSize2s : ObservableCollection<NameCodePair>
    {
        public static BWPipeTeeSize2s LoadList()
        {
            BWPipeTeeSize2s items = new BWPipeTeeSize2s();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "6 NB" });
            items.Add(new NameCodePair() { Code = "02", Name = "8 NB" });
            items.Add(new NameCodePair() { Code = "03", Name = "10 NB" });
            items.Add(new NameCodePair() { Code = "04", Name = "15 NB" });
            items.Add(new NameCodePair() { Code = "05", Name = "20 NB" });
            items.Add(new NameCodePair() { Code = "06", Name = "25 NB" });
            items.Add(new NameCodePair() { Code = "07", Name = "32 NB" });
            items.Add(new NameCodePair() { Code = "08", Name = "40 NB" });
            items.Add(new NameCodePair() { Code = "09", Name = "50 NB" });
            items.Add(new NameCodePair() { Code = "10", Name = "65 NB" });
            items.Add(new NameCodePair() { Code = "11", Name = "80 NB" });
            items.Add(new NameCodePair() { Code = "12", Name = "100 NB" });
            items.Add(new NameCodePair() { Code = "13", Name = "125 NB" });
            items.Add(new NameCodePair() { Code = "14", Name = "150 NB" });
            items.Add(new NameCodePair() { Code = "14A", Name = "175 NB" });
            items.Add(new NameCodePair() { Code = "15", Name = "200NB" });
            items.Add(new NameCodePair() { Code = "16", Name = "250NB" });
            items.Add(new NameCodePair() { Code = "17", Name = "300NB" });
            items.Add(new NameCodePair() { Code = "18", Name = "350NB" });
            items.Add(new NameCodePair() { Code = "19", Name = "400NB" });
            items.Add(new NameCodePair() { Code = "20", Name = "450NB" });
            items.Add(new NameCodePair() { Code = "21", Name = "500NB" });
            items.Add(new NameCodePair() { Code = "22", Name = "550NB" });
            items.Add(new NameCodePair() { Code = "23", Name = "600NB" });
            items.Add(new NameCodePair() { Code = "24", Name = "650NB" });
            items.Add(new NameCodePair() { Code = "25", Name = "700NB" });
            items.Add(new NameCodePair() { Code = "26", Name = "750NB" });
            items.Add(new NameCodePair() { Code = "27", Name = "800NB" });
            items.Add(new NameCodePair() { Code = "28", Name = "850NB" });
            items.Add(new NameCodePair() { Code = "29", Name = "900NB" });
            items.Add(new NameCodePair() { Code = "30", Name = "1000NB" });
            items.Add(new NameCodePair() { Code = "31", Name = "1100NB" });
            items.Add(new NameCodePair() { Code = "32", Name = "1200NB" });
            return items;
        }
        public static BWPipeTeeSize2s LoadFromExcel(String path)
        {
            return null;
        }

        public static BWPipeTeeSize2s LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWPipeTeeSize2s>(EngineeringItems.DataPath + @"\FittingsBW\BWPipeTeeSize2s.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWPipeTeeSize2s>(this, EngineeringItems.DataPath + @"\FittingsBW\BWPipeTeeSize2s.xml");
        }

    }
}
