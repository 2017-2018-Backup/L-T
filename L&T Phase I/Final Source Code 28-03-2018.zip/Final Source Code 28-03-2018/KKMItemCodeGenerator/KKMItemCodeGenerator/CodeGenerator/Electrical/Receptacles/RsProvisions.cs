﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class RsProvisions : ObservableCollection<NameCodePair>
    {
       public static RsProvisions LoadList()
        {
            RsProvisions items = new RsProvisions();
            items.Add(new NameCodePair() { Code = "01", Name = "SINGLE" });
            items.Add(new NameCodePair() { Code = "02", Name = "DUPLEX" });
            items.Add(new NameCodePair() { Code = "03", Name = "TRIPLEX" });
            return items;
        }
        public static RsProvisions LoadFromExcel(String path)
        {
            return null;
        }

        public static RsProvisions LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<RsProvisions>(ElectricalItems.DataPath + @"\Receptacles\RsProvisions.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<RsProvisions>(this, ElectricalItems.DataPath + @"\Receptacles\RsProvisions.xml");
        }

    }
}
