﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PlateProfileCertificates : ObservableCollection<NameCodePair>
    {
        public static PlateProfileCertificates LoadList()
        {
            PlateProfileCertificates items = new PlateProfileCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "NO CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "GL 3.2 certificate" });
            items.Add(new NameCodePair() { Code = "02", Name = "LR 3.2 certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "04", Name = "ABS & IRS Certificate" });
            return items;
        }

        public static PlateProfileCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static PlateProfileCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PlateProfileCertificates>(HullItems.HullDataPath + @"\Plate\PlateProfileCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PlateProfileCertificates>(this, HullItems.HullDataPath + @"\Plate\PlateProfileCertificates.xml");
        }
    }
}
