﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using KKMCustomerComment;
using System.Xml.Serialization;
using System.IO;
using System.Diagnostics;
using excel = Microsoft.Office.Interop.Excel;
using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework;
using Autodesk.DataManagement.Client.Framework.Vault;
using System.Windows.Forms;
using KKMCustomerComments;
using System.Runtime.InteropServices;
using System.Globalization;
namespace KKMCustomerComments
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlCustomerCommentsummary : Window
    {
        UserControlRelevantDocByCustomer objfrmRelevantDocByCustomer;
        UserControlRelatedDocByLandT objfrmRelatedDocByLandT;
        frmCreateCustomerComments objfrmCreateCustomerComment;
        frmCustomerCommentsLifecycle objfrmCustomerCommentLifecycle;
        frmHistoryCustomerComments objfrmHistoryCustomerComment;

        public ObservableCollection<SingleCustomerCommentsummary> FileCollection { get { return clsStaticGlobal.SingleCustomerCommentsummaryItemCollection; } }

        public UserControlCustomerCommentsummary()
        {
            InitializeComponent();
            try
            {
                clsStaticGlobal.DisposeAllObjects();
                clsStaticGlobal.GetProjectCodes();
                cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
                clsStaticGlobal.AllFileStates();

                cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;

                chkIsFilter.IsChecked = false;

                IsFilterAllow(false);

                List<string> userlist = new List<string>();
                userlist.Add("All");
                List<string> userlistTemp = clsStaticGlobal.GetAllUserList();
                userlistTemp.Sort();
                userlist.AddRange(userlistTemp);

                cmbResponsiblePerson.ItemsSource = userlist;

                List<string> finalAcceptancebycustomerlist = new List<string>();
                finalAcceptancebycustomerlist.Add("All");
                finalAcceptancebycustomerlist.Add("Yes");
                finalAcceptancebycustomerlist.Add("No");
                cmbFinalAcceptance.ItemsSource = finalAcceptancebycustomerlist;

                cmbCommentStatus.SelectedIndex = 0;
                cmbResponsiblePerson.SelectedIndex = 0;
                cmbFinalAcceptance.SelectedIndex = 0;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void IsFilterAllow(bool _IsReadOnly)
        {
            if (_IsReadOnly == true)
            {

                txtCustomerCommentName.Visibility = Visibility.Visible;
                lblCustomerCommentName.Visibility = Visibility.Visible;
                txtLandTCommentName.Visibility = Visibility.Visible;
                lblLandTCommentName.Visibility = Visibility.Visible;
                cmbCommentStatus.Visibility = Visibility.Visible;
                lblCommentStatus.Visibility = Visibility.Visible;

                cmbFinalAcceptance.Visibility = Visibility.Visible;
                lblFinalAcceptance.Visibility = Visibility.Visible;
                cmbResponsiblePerson.Visibility = Visibility.Visible;
                lblResponsiblePerson.Visibility = Visibility.Visible;
                txtCostImplications.Visibility = Visibility.Visible;
                lblCostImplications.Visibility = Visibility.Visible;
                txtTimeImplications.Visibility = Visibility.Visible;
                lblTimeImplications.Visibility = Visibility.Visible;

                cmdFilter.Visibility = Visibility.Visible;
            }
            else
            {

                txtCustomerCommentName.Visibility = Visibility.Hidden;
                lblCustomerCommentName.Visibility = Visibility.Hidden;
                txtLandTCommentName.Visibility = Visibility.Hidden;
                lblLandTCommentName.Visibility = Visibility.Hidden;
                cmbCommentStatus.Visibility = Visibility.Hidden;
                lblCommentStatus.Visibility = Visibility.Hidden;

                cmbFinalAcceptance.Visibility = Visibility.Hidden;
                lblFinalAcceptance.Visibility = Visibility.Hidden;
                cmbResponsiblePerson.Visibility = Visibility.Hidden;
                lblResponsiblePerson.Visibility = Visibility.Hidden;
                txtCostImplications.Visibility = Visibility.Hidden;
                lblCostImplications.Visibility = Visibility.Hidden;
                txtTimeImplications.Visibility = Visibility.Hidden;
                lblTimeImplications.Visibility = Visibility.Hidden;

                cmdFilter.Visibility = Visibility.Hidden;
            }

        }

        private void cmbProjectCode_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (cmbProjectCode.SelectedItem != null)
            {
                if (chkIsFilter.IsChecked == true)
                {
                    chkIsFilter.IsChecked = false;
                }
                else
                {
                    BindwithFilter();
                }
            }
        }

        private void BindwithFilter()
        {
            try
            {
                clsStaticGlobal.objSingleCustomerCommentCollection = new clsCustomerCommentsummary();
                FileCollection.Clear();
                DataGridCustomerCommentsummary.Items.Refresh();
                if (((ProjectCodes)cmbProjectCode.SelectedItem) != null)
                {
                    clsStaticGlobal._ProjectCode = ((ProjectCodes)cmbProjectCode.SelectedItem).ProjectCodeName.ToString();
                    clsStaticGlobal.VaultCustomerFolder = clsStaticGlobal.GetorCreateCustomerCommentFolder(clsStaticGlobal._ProjectCode);

                    if (clsStaticGlobal.VaultCustomerFolder != null)
                    {
                        if (GetAllFilesByProjectFolder(clsStaticGlobal._ProjectCode) == true)
                        {
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleCustomerCommentCollection, clsStaticGlobal.objSingleCustomerCommentsummary, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridCustomerCommentsummary.DataContext = this;
                            clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllCustomerCommentsummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("User does not have full permission for selected Project Folder.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void BindingDataGridView()
        {
            try
            {
                clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.Clear();

                if (clsStaticGlobal.objSingleCustomerCommentCollection.collectionCustomerComment != null)
                {
                    foreach (SingleCustomerCommentsummary objSingleCustomerCommentsummary in clsStaticGlobal.objSingleCustomerCommentCollection.collectionCustomerComment)
                    {
                        if (chkIsFilter.IsChecked == true)
                        {
                            bool IsAdd = false;
                            string CustomerCommentName = txtCustomerCommentName.Text.Trim().Replace("*", "");
                            string LandTCommentName = txtLandTCommentName.Text.Trim().Replace("*", "");
                            string CommentState = ((CommentStates)cmbCommentStatus.SelectedItem).CommentState.ToString();

                            string ResponsiblePer = cmbResponsiblePerson.SelectedItem.ToString();
                            string FinalAcceptancebyCust = cmbFinalAcceptance.SelectedItem.ToString();

                            string CostImplem = txtCostImplications.Text.Trim().Replace("*", "");
                            string TimeImplem = txtTimeImplications.Text.Trim().Replace("*", "");

                            if ((objSingleCustomerCommentsummary.CustomerCustomerComment.ToUpper().Contains(CustomerCommentName.Trim().ToUpper()))
                                && (objSingleCustomerCommentsummary.CustomerCommentLandTComment.ToUpper().Contains(LandTCommentName.Trim().ToUpper()))
                                && (objSingleCustomerCommentsummary.CustomerCommentTimeImplications.ToUpper().Contains(TimeImplem.Trim().ToUpper()))
                                && (objSingleCustomerCommentsummary.CustomerCommentCostImplications.ToUpper().Contains(CostImplem.Trim().ToUpper()))
                                )
                            {

                                if (ResponsiblePer == "All")
                                {
                                    if (FinalAcceptancebyCust == "All")
                                    {
                                        if (CommentState == "All")
                                        {
                                            IsAdd = true;
                                        }
                                        else
                                        {
                                            if (objSingleCustomerCommentsummary.CustomerCommentLifeCycle == CommentState)
                                            {
                                                IsAdd = true;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (objSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer == FinalAcceptancebyCust)
                                        {
                                            if (CommentState == "All")
                                            {
                                                IsAdd = true;
                                            }
                                            else
                                            {
                                                if (objSingleCustomerCommentsummary.CustomerCommentLifeCycle == CommentState)
                                                {
                                                    IsAdd = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (objSingleCustomerCommentsummary.CustomerCommentResponsiblePerson == ResponsiblePer)
                                    {
                                        if (FinalAcceptancebyCust == "All")
                                        {
                                            if (CommentState == "All")
                                            {
                                                IsAdd = true;
                                            }
                                            else
                                            {
                                                if (objSingleCustomerCommentsummary.CustomerCommentLifeCycle == CommentState)
                                                {
                                                    IsAdd = true;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (objSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer == FinalAcceptancebyCust)
                                            {
                                                if (CommentState == "All")
                                                {
                                                    IsAdd = true;
                                                }
                                                else
                                                {
                                                    if (objSingleCustomerCommentsummary.CustomerCommentLifeCycle == CommentState)
                                                    {
                                                        IsAdd = true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                            }

                            if (IsAdd == true)
                            {
                                clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.Add(objSingleCustomerCommentsummary);
                            }
                        }
                        else
                        {
                            clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.Add(objSingleCustomerCommentsummary);
                        }
                    }
                    DataGridCustomerCommentsummary.Items.Refresh();
                    DataGridCustomerCommentsummary.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            DataGridCustomerCommentsummary.Items.Refresh();

        }

        void AllCustomerCommentsummary_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.SingleCustomerCommentsummaryItemCollection)
                {
                    item.CustomerCommentCount = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private SingleCustomerCommentsummary GetSelectedDataGridRow(object sender)
        {
            try
            {
                if (DataGridCustomerCommentsummary.SelectedItems.Count > 0)
                {
                    if (DataGridCustomerCommentsummary.SelectedItems.Count == 1)
                    {
                        SingleCustomerCommentsummary objSingleCustomerCommentsummary = (SingleCustomerCommentsummary)DataGridCustomerCommentsummary.SelectedCells[0].Item;
                        return objSingleCustomerCommentsummary;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }                    

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return null;
            }
        }

        private bool GetAllFilesByProjectFolder(string _ProjectCode)
        {
            try
            {
                try
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }

                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultCustomerFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.CustomerCommentFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            FileIterations.Add(new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file));
                        }
                    }
                    ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters = (ICollection<VDF.Vault.Currency.Entities.FileIteration>)FileIterations;
                    DownlodAllProjectSpecificCustomerCommentFiles(fileIters, _ProjectCode);
                    return true;

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("No Customer Comments available.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                return false;
            }
        }

        public void DownlodAllProjectSpecificCustomerCommentFiles(ICollection<VDF.Vault.Currency.Entities.FileIteration> fileIters, string _ProjectCode)
        {
            try
            {
                clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);

                if (!Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode))
                {
                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
                }
                else
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
                }


                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
                foreach (VDF.Vault.Currency.Entities.FileIteration fileIter in fileIters)
                {
                    settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                }
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
                System.Windows.Forms.MessageBox.Show("Error in downloading files.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void AddCustomerComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.IsReadOnly = false;

                    clsStaticGlobal.objSingleCustomerCommentsummary = new SingleCustomerCommentsummary();
                    List<int> lstCommentsNumbers = GetAllCommentsNumbers(clsStaticGlobal._ProjectCode);
                    //Debugger.Launch();
                    if (lstCommentsNumbers.Count > 0)
                    {
                        clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber = lstCommentsNumbers.Last();
                    }
                    else
                    {
                        clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber = 0;
                    }
                    objfrmCreateCustomerComment = new frmCreateCustomerComments(false, false, "");
                    objfrmCreateCustomerComment.ShowDialog();

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber != 0)
                        {
                            clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleCustomerCommentCollection, clsStaticGlobal.objSingleCustomerCommentsummary, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal._ProjectCode);
                            DataGridCustomerCommentsummary.DataContext = this;
                            clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllCustomerCommentsummary_CollectionChanged);
                            BindingDataGridView();
                        }
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void EditComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;                          

                            clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;

                            String _xmlFilePath = clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;

                            string checkedOutUsername = "";

                            bool IsCheckedOut = clsStaticGlobal.IsFileCheckedOut(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath, out checkedOutUsername);

                            string CurrentUser = "";
                            UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(clsStaticGlobal.connection.UserID);
                            //if (userinfo.User.FirstName.Trim() == "")
                            //{
                            //    CurrentUser = userinfo.User.LastName.Trim();
                            //}
                            //else
                            //{
                            //    CurrentUser = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                            //}

                            CurrentUser = clsStaticGlobal.GetUserName(userinfo.User);

                            if ((IsCheckedOut == true) && (checkedOutUsername == CurrentUser))
                            {
                                if (true == clsStaticGlobal.DownloadFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath))
                                {
                                    clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark);
                                }

                                IsCheckedOut = false;
                            }

                            if (IsCheckedOut == false)
                            {
                                if (Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
                                {
                                    if (System.IO.File.Exists(_xmlFilePath))
                                    {
                                        System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                        System.IO.File.Delete(_xmlFilePath);
                                    }
                                }
                                else
                                {
                                    Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
                                }
                                clsStaticGlobal.CheckoutFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath);
                            }

                            if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper() == "RELEASE")
                            {
                                clsStaticGlobal.IsReadOnly = true;
                            }
                            objfrmCreateCustomerComment = new frmCreateCustomerComments(true, IsCheckedOut, checkedOutUsername);

                            if (objfrmCreateCustomerComment.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                            {
                                if (IsCheckedOut == false)
                                {
                                    if (clsStaticGlobal.IsReadOnly == false)
                                    {
                                        if (System.IO.File.Exists(_xmlFilePath))
                                        {
                                            System.IO.File.SetAttributes(_xmlFilePath, FileAttributes.Normal);
                                            System.IO.File.Delete(_xmlFilePath);
                                        }
                                        XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                                        TextWriter tw = new StreamWriter(_xmlFilePath);
                                        xs.Serialize(tw, clsStaticGlobal.objSingleCustomerCommentsummary);
                                        tw.Close();

                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark);

                                        //clsStaticGlobal.BindingDataSingleWrite(clsStaticGlobal.objSingleCustomerCommentsummary, _xmlFilePath, true);
                                        clsStaticGlobal.UpdateFileRemark(clsStaticGlobal.objSingleCustomerCommentsummary);
                                        clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleCustomerCommentCollection, clsStaticGlobal.objSingleCustomerCommentsummary, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal._ProjectCode);
                                        DataGridCustomerCommentsummary.DataContext = this;
                                        clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllCustomerCommentsummary_CollectionChanged);
                                        BindingDataGridView();
                                    }
                                }
                            }
                            else
                            {
                                if (IsCheckedOut == false)
                                {
                                    if (System.IO.File.Exists(_xmlFilePath))
                                    {
                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark);
                                    }
                                    else
                                    {
                                        XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                                        TextWriter tw = new StreamWriter(_xmlFilePath);
                                        xs.Serialize(tw, clsStaticGlobal.objSingleCustomerCommentsummary);
                                        tw.Close();
                                        clsStaticGlobal.CheckinFile(clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark);
                                    }
                                }
                            }

                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void History_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        objfrmHistoryCustomerComment = new frmHistoryCustomerComments(false, false, "");

                        objfrmHistoryCustomerComment.ShowDialog();
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            
        }

        private void LifeCycle_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;
                            clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;
                           
                            string _LifeCycle = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle;
                            string _LifeCycleComment = clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentRemark;
                            objfrmCustomerCommentLifecycle = new frmCustomerCommentsLifecycle(ref clsStaticGlobal.objSingleCustomerCommentsummary, true);
                            objfrmCustomerCommentLifecycle.ShowDialog();
                            if (clsStaticGlobal.IsReadOnly == false)
                            {
                                if ((_LifeCycle != clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle) || (_LifeCycleComment != clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle))
                                {
                                    clsStaticGlobal.BindingDataMultipleRead(ref clsStaticGlobal.objSingleCustomerCommentCollection, clsStaticGlobal.objSingleCustomerCommentsummary, clsStaticGlobal.LocalXMLCustomerCommentFolderPath, clsStaticGlobal._ProjectCode);
                                    DataGridCustomerCommentsummary.DataContext = this;
                                    clsStaticGlobal.SingleCustomerCommentsummaryItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(AllCustomerCommentsummary_CollectionChanged);
                                    BindingDataGridView();
                                }
                            }
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Customer Comment First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void CustomerRelatedDocument_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;
                            clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;
                            if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper() == "RELEASE")
                            {
                                clsStaticGlobal.IsReadOnly = true;
                            }
                            clsStaticGlobal.RelevantDocByCustomerFiles = new List<Autodesk.Connectivity.WebServices.File> { };                            
                            clsStaticGlobal.PrintCustomerRelevantDocumentsFilesInFolder(clsStaticGlobal.VaultCustomerCustomerFolder, clsStaticGlobal.connection.WebServiceManager, false);

                            objfrmRelevantDocByCustomer = new UserControlRelevantDocByCustomer(false);
                            objfrmRelevantDocByCustomer.ShowDialog();
                            
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Customer Comment First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void LandTRelatedDocument_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedItem != null)
                {
                    clsStaticGlobal.objSingleCustomerCommentsummary = GetSelectedDataGridRow(sender);

                    if (clsStaticGlobal.objSingleCustomerCommentsummary != null)
                    {
                        if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentNumber != 0)
                        {
                            clsStaticGlobal.IsReadOnly = false;
                            clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentFileName;
                            if (clsStaticGlobal.objSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper() == "RELEASE")
                            {
                                clsStaticGlobal.IsReadOnly = true;
                            }
                            clsStaticGlobal.RelatedDocByLandTFiles = new List<Autodesk.Connectivity.WebServices.File> { };                            
                            clsStaticGlobal.PrintLandTRelatedDocumentFilesInFolder(clsStaticGlobal.VaultCustomerLandTFolder, clsStaticGlobal.connection.WebServiceManager, false);

                            objfrmRelatedDocByLandT = new UserControlRelatedDocByLandT(false);
                            objfrmRelatedDocByLandT.ShowDialog();
                            
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Select Customer Comment.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Select Project First.", "Customer Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }


            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdExport_Click(object sender, RoutedEventArgs e)
        {
            excel.Application xlApp;
            excel.Workbook xlWorkBook;
            excel.Worksheet xlWorkSheet;
            //bool IsExport = false;
            bool IsExport = true;
            List<SingleCustomerCommentsummary> excelSingleCustomerCommentsummaryList = new List<SingleCustomerCommentsummary>();
            foreach (var item in DataGridCustomerCommentsummary.SelectedItems)
            {
                excelSingleCustomerCommentsummaryList.Add((SingleCustomerCommentsummary)item);
            }
            try
            {
                if (excelSingleCustomerCommentsummaryList.Count > 0)
                {                    

                    if (IsExport == true)
                    {

                        string _Filename = "Customer Comments";
                        System.Windows.Forms.Application.DoEvents();
                        System.Windows.Forms.SaveFileDialog saveFileDialog = new System.Windows.Forms.SaveFileDialog();
                        saveFileDialog.Title = "Save Excel Report";
                        saveFileDialog.RestoreDirectory = true;
                        saveFileDialog.FileName = "Customer Comments Summary_" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        saveFileDialog.DefaultExt = "xlsx";

                        if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            _Filename = saveFileDialog.FileName;
                        }
                        else
                        {
                            return;
                        }

                        /////////////////////// Create Excel Application Object
                        object mMissingValue = System.Reflection.Missing.Value;
                        xlApp = new excel.Application();
                        xlApp.DisplayAlerts = false;
                        xlWorkBook = xlApp.Workbooks.Add(mMissingValue);
                        xlWorkSheet = null;

                        try
                        {
                            var prevSheet = xlWorkSheet;

                            if (prevSheet == null)
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(xlWorkBook.Sheets[1], mMissingValue, mMissingValue, mMissingValue);
                            }
                            else
                            {
                                xlWorkSheet = xlWorkBook.Sheets.Add(mMissingValue, prevSheet, mMissingValue, mMissingValue);
                            }
                            xlWorkSheet.Name = "Customer Comments Summary";
                            int BorderStartindex = 0;
                            int RowNo = 2;
                            int ColNo = 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comments";
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Size = 16;
                            RowNo += 2;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Downloaded Date";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = "'" + DateTime.Now.ToLongDateString();
                            RowNo += 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "User ID";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo + 1] = clsStaticGlobal.connection.UserName.ToString();
                            RowNo += 2;

                            int LoopRowNo = RowNo;
                            int LoopColNo = ColNo;

                            int StartRowNo = RowNo;
                            int StartColNo = ColNo;

                            xlWorkSheet.Cells[RowNo, ColNo - 1] = "Sr.No.";
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo - 1].Font.Bold = true;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Project Code";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comment Number";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Customer Comment";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Lifecycle Status";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. by Customer";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. path by Customer";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "System";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Responsible Person";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Comment Closure Target Date";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "L&T Comment";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. by L&T";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Relevant Doc. path by L&T";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Time Implications";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Cost Implications (currency rate)";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Final Acceptance by Customer";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            ColNo = ColNo + 1;

                            xlWorkSheet.Cells[RowNo, ColNo] = "Remark";
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                            xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                            xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;

                            BorderStartindex = RowNo;
                            int SrNoCnt = 1;
                            int NextCol = LoopColNo;
                            foreach (SingleCustomerCommentsummary _ObjSingleCustomerCommentsummary in excelSingleCustomerCommentsummaryList)
                            {
                                //if (_ObjSingleCustomerCommentsummary.CustomerCommentLifeCycle.ToUpper() == "RELEASE")
                                //{
                                    LoopRowNo = LoopRowNo + 1;
                                    NextCol = LoopColNo;

                                    xlWorkSheet.Cells[LoopRowNo, NextCol - 1] = SrNoCnt.ToString();
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentProjectCode;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCustomerCommentNumber;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCustomerComment;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentLifeCycle;

                                    if (_ObjSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                                    {
                                        string _collfilename = "";
                                        foreach (CustomerRelatedDocument item in _ObjSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                                        {
                                            if (_collfilename != "")
                                            {
                                                _collfilename = _collfilename + "; " + Environment.NewLine + item.FileName;
                                            }
                                            else
                                            {
                                                _collfilename = item.FileName;
                                            }
                                        }
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                                    }
                                    else
                                    {
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    }


                                    if (_ObjSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                                    {
                                        string _collfilepath = "";
                                        foreach (CustomerRelatedDocument item in _ObjSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                                        {
                                            if (_collfilepath != "")
                                            {
                                                _collfilepath = _collfilepath + "; " + Environment.NewLine + item.FilePath;
                                            }
                                            else
                                            {
                                                _collfilepath = item.FilePath;
                                            }
                                        }
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                                    }
                                    else
                                    {
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    }

                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentsystem;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentResponsiblePerson;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentCloserDate;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentLandTComment;

                                    if (_ObjSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                                    {
                                        string _collfilename = "";
                                        foreach (LandTRelatedDocument item in _ObjSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                                        {
                                            if (_collfilename != "")
                                            {
                                                _collfilename = _collfilename + "; " + Environment.NewLine + item.FileName;
                                            }
                                            else
                                            {
                                                _collfilename = item.FileName;
                                            }
                                        }
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilename;
                                    }
                                    else
                                    {
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    }

                                    if (_ObjSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                                    {
                                        string _collfilepath = "";
                                        foreach (LandTRelatedDocument item in _ObjSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                                        {
                                            if (_collfilepath != "")
                                            {
                                                _collfilepath = _collfilepath + "; " + Environment.NewLine + item.FilePath;
                                            }
                                            else
                                            {
                                                _collfilepath = item.FilePath;
                                            }
                                        }
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = _collfilepath;
                                    }
                                    else
                                    {
                                        NextCol = NextCol + 1;
                                        xlWorkSheet.Cells[LoopRowNo, NextCol] = "";
                                    }

                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentTimeImplications;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentCostImplications;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer;
                                    NextCol = NextCol + 1;
                                    xlWorkSheet.Cells[LoopRowNo, NextCol] = _ObjSingleCustomerCommentsummary.CustomerCommentRemark;

                                    SrNoCnt = SrNoCnt + 1;
                                //}

                            }

                            for (int m = 2; m <= NextCol; m++)
                            {
                                xlWorkSheet.Columns[m].AutoFit();
                            }

                            xlWorkSheet.Range[xlWorkSheet.Cells[StartRowNo, StartColNo - 1], xlWorkSheet.Cells[LoopRowNo, NextCol]].Cells.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;

                            xlWorkBook.SaveAs(_Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                            xlWorkBook.Close(true, mMissingValue, mMissingValue);
                            System.Windows.MessageBox.Show("Customer Comment summary report exported successfully..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Information);

                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            try
                            {
                                clsStaticGlobal.ReleaseObject(xlWorkBook);

                            }
                            catch (Exception)
                            {

                            }
                            xlApp.Quit();
                            clsStaticGlobal.ReleaseObject(xlApp);
                        }

                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("There is no Customer Comments selected to export.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex1)
            {
                System.Windows.MessageBox.Show("Excel application not installed.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                clsStaticGlobal.ErrHandlerLog(ex1);
            }

        }

        private void cmdFilter_Click(object sender, RoutedEventArgs e)
        {
            BindwithFilter();
        }

        private void chkIsFilter_Checked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == true)
            {
                IsFilterAllow(true);
            }

        }

        private void chkIsFilter_Unchecked(object sender, RoutedEventArgs e)
        {
            if (chkIsFilter.IsChecked == false)
            {
                IsFilterAllow(false);
                BindwithFilter();
            }
        }

        private void cmdMassUpload_Click(object sender, RoutedEventArgs e)
        {
            if (cmbProjectCode.SelectedItem != null)
            {
                OpenFileDialog fdlg = new OpenFileDialog();
                fdlg.Title = "Open File Dialog For Excel File";
                fdlg.InitialDirectory = @"c:\";
                fdlg.Filter = "All files (*.xls)|*.xls|All files (*.xlsx)|*.xlsx";
                fdlg.FilterIndex = 2;
                fdlg.RestoreDirectory = true;
                if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        //Create COM Objects. Create a COM object for everything that is referenced
                        excel.Application xlApp = new excel.Application();
                        excel.Workbook xlWorkbook = xlApp.Workbooks.Open(fdlg.FileName);

                        excel._Worksheet xlWorksheet = xlWorkbook.Sheets["Customer Comments"];
                        excel.Range xlRange = xlWorksheet.UsedRange;

                        try
                        {
                            List<SingleCustomerCommentsummary> _listCustomerComment = new List<SingleCustomerCommentsummary> { };

                            //int rowCount = xlRange.Rows.Count;
                            //int colCount = xlRange.Columns.Count;
                            int rowCount = xlRange.Rows.Count;
                            int colCount = 16;
                            int actualRowCnt = 1;

                            for (int i = 1; i <= rowCount; i++)
                            {
                                if ((xlRange.Cells[i, 2].Value2 != null) && (xlRange.Cells[i, 2].Value2.ToString().Trim() != ""))
                                {
                                    actualRowCnt = i;
                                }
                                else
                                {
                                    break;
                                }
                            }
                            rowCount = actualRowCnt;

                            bool isBreak = false;
                            int _CustomerNumber = 0;
                            if (clsStaticGlobal.ListCustomerCommentNumbers.Count > 0)
                            {
                                _CustomerNumber = clsStaticGlobal.ListCustomerCommentNumbers.Last();
                            }

                            bool IsFormatCorrect = true;
                            for (int i = 1; i <= rowCount; i++)
                            {
                                if (i == 1)
                                {
                                    for (int j = 1; j <= colCount; j++)
                                    {
                                        switch (j)
                                        {
                                            case 1:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Sr.No.") { IsFormatCorrect = false; }
                                                break;
                                            case 2:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Project Code") { IsFormatCorrect = false; }
                                                break;
                                            case 3:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Customer Comment Number") { IsFormatCorrect = false; }
                                                break;
                                            case 4:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Customer Comment") { IsFormatCorrect = false; }
                                                break;
                                            //case 5:
                                            //    if (xlRange.Cells[i, j].Value2.ToString() != "Lifecycle Status") { IsFormatCorrect = false; }
                                            //    break;
                                            case 5:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Relevant Doc. by Customer") { IsFormatCorrect = false; }
                                                break;
                                            case 6:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "System") { IsFormatCorrect = false; }
                                                break;
                                            case 7:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Responsible Person") { IsFormatCorrect = false; }
                                                break;
                                            case 8:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Comment Closure Target Date") { IsFormatCorrect = false; }
                                                break;
                                            case 9:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "L&T Comment") { IsFormatCorrect = false; }
                                                break;
                                            case 10:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Relevant Doc. by L&T") { IsFormatCorrect = false; }
                                                break;
                                            case 11:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Time Implications") { IsFormatCorrect = false; }
                                                break;
                                            case 12:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Cost Implications (currency rate)") { IsFormatCorrect = false; }
                                                break;
                                            case 13:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Final Acceptance by Customer") { IsFormatCorrect = false; }
                                                break;
                                            case 14:
                                                if (xlRange.Cells[i, j].Value2.ToString() != "Remark") { IsFormatCorrect = false; }
                                                break;
                                            default:
                                                break;
                                        }

                                    }
                                }
                                else
                                {
                                    if (IsFormatCorrect)
                                    {
                                        _CustomerNumber = _CustomerNumber + 1;
                                        SingleCustomerCommentsummary _objSingleCustomerCommentsummary = new SingleCustomerCommentsummary();
                                        _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = true;
                                        _objSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";

                                        for (int j = 1; j <= colCount; j++)
                                        {
                                            if (isBreak == false)
                                            {
                                                switch (j)
                                                {
                                                    case 1:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() == "")
                                                                {
                                                                    System.Windows.MessageBox.Show("Sr.No. column should not empty.!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                System.Windows.MessageBox.Show("Sr.No. column should not empty.!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                isBreak = true;
                                                            }

                                                            break;
                                                        }
                                                    case 2:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    if (xlRange.Cells[i, j].Value2.ToString().Trim() == clsStaticGlobal._ProjectCode)
                                                                    {
                                                                        _objSingleCustomerCommentsummary.CustomerCommentProjectCode = clsStaticGlobal._ProjectCode;
                                                                    }
                                                                    else
                                                                    {
                                                                        _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                        System.Windows.MessageBox.Show("Selected project and project in mass upload excel is missmatch..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        isBreak = true;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    System.Windows.MessageBox.Show("Project code column should not empty..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                    _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                    isBreak = true;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                System.Windows.MessageBox.Show("Project code column should not empty..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                isBreak = true;

                                                            }

                                                            break;
                                                        }
                                                    case 3:
                                                        {
                                                            try
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentNumber = _CustomerNumber;
                                                                _objSingleCustomerCommentsummary.CustomerCustomerCommentNumber = clsStaticGlobal._ProjectCode + "_" + _CustomerNumber.ToString();
                                                                _objSingleCustomerCommentsummary.CustomerCommentFileName = "PDC_" + _objSingleCustomerCommentsummary.CustomerCustomerCommentNumber + ".xml";
                                                            }
                                                            catch (Exception ex)
                                                            {

                                                            }

                                                            break;
                                                        }
                                                    case 4:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCustomerComment = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCustomerComment = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCustomerComment = "";

                                                            }

                                                            break;
                                                        }
                                                    //case 5:
                                                    //    {
                                                    //        try
                                                    //        {
                                                    //            if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                    //            {
                                                    //                _objSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";
                                                    //            }
                                                    //            else
                                                    //            {
                                                    //                _objSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";
                                                    //            }
                                                    //        }
                                                    //        catch (Exception ex)
                                                    //        {
                                                    //            _objSingleCustomerCommentsummary.CustomerCommentLifeCycle = "Create";
                                                    //        }

                                                    //        break;
                                                    //    }
                                                    case 5:
                                                        {
                                                            try
                                                            {
                                                                string _CustomerRelatedDocuments = "";

                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string CustomerDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    CustomerDoc = CustomerDoc.Replace("\n", "");
                                                                    CustomerDoc = CustomerDoc.Replace("\r", "");
                                                                    string[] CustomerDocs = CustomerDoc.Split(new char[] { ';', ',' });

                                                                    foreach (var item in CustomerDocs)
                                                                    {
                                                                        string _filepath = clsStaticGlobal.VaultCustomerCustomerFolder.FullName + "/" + item;
                                                                        Autodesk.Connectivity.WebServices.File _file = clsStaticGlobal.IsFileExistintoVault(clsStaticGlobal.VaultCustomerCustomerFolder, item);
                                                                        if (_file != null)
                                                                        {
                                                                            _objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Add(new CustomerRelatedDocument { IsCheckedCustomerRelatedDocument = true, FileType = "Customer Related Document", FileName = item, FilePath = _filepath, FileRemark = "", FileRevision = _file.FileRev.Label.ToString(), FileStatus = _file.FileLfCyc.LfCycStateName.ToString() });
                                                                            if (_CustomerRelatedDocuments.Trim() == "")
                                                                            {
                                                                                _CustomerRelatedDocuments = item;
                                                                            }
                                                                            else
                                                                            {
                                                                                _CustomerRelatedDocuments = _CustomerRelatedDocuments + Environment.NewLine + item;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            System.Windows.MessageBox.Show("Relevant doc.by customer column does not exist..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                            _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                            isBreak = true;
                                                                        }
                                                                    }
                                                                    _objSingleCustomerCommentsummary.CustomerCommentCustomerRelatedDocuments = _CustomerRelatedDocuments;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {

                                                            }

                                                            break;
                                                        }
                                                    case 6:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCommentsystem = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCommentsystem = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentsystem = "";
                                                            }

                                                            break;
                                                        }
                                                    case 7:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string _ResponsiblePerson = "";
                                                                    _ResponsiblePerson = clsStaticGlobal.GetUserNameWithFirstandLast(xlRange.Cells[i, j].Value2.ToString().Trim());
                                                                    if (_ResponsiblePerson != "")
                                                                    {
                                                                        _objSingleCustomerCommentsummary.CustomerCommentResponsiblePerson = _ResponsiblePerson;
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Responsible person does not exist..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                        isBreak = true;
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCommentResponsiblePerson = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentResponsiblePerson = "";
                                                            }

                                                            break;
                                                        }
                                                    case 8:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    try
                                                                    {
                                                                        string sDate = (xlRange.Cells[i, j] as excel.Range).Value2.ToString();

                                                                        double date = double.Parse(sDate);

                                                                        var dateTime = DateTime.FromOADate(date).ToString("dd-MMM-yyyy");

                                                                        _objSingleCustomerCommentsummary.CustomerCommentCloserDate = dateTime.ToString();

                                                                    }
                                                                    catch (Exception)
                                                                    {
                                                                        System.Windows.MessageBox.Show("Comment closure target date invalid format..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                        isBreak = true;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    var dateTime = DateTime.Now.ToString("dd-MMM-yyyy");
                                                                    _objSingleCustomerCommentsummary.CustomerCommentCloserDate = dateTime.ToString();
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                var dateTime = DateTime.Now.ToString("dd-MMM-yyyy");
                                                                _objSingleCustomerCommentsummary.CustomerCommentCloserDate = dateTime.ToString();
                                                            }

                                                            break;
                                                        }
                                                    case 9:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCommentLandTComment = xlRange.Cells[i, j].Value2.ToString();
                                                                }
                                                                else
                                                                {
                                                                    _objSingleCustomerCommentsummary.CustomerCommentLandTComment = "";
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentLandTComment = "";
                                                            }

                                                            break;
                                                        }
                                                    case 10:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    string LandTDoc = xlRange.Cells[i, j].Value2.ToString();
                                                                    LandTDoc = LandTDoc.Replace("\n", "");
                                                                    LandTDoc = LandTDoc.Replace("\r", "");
                                                                    string[] LandTDocs = LandTDoc.Split(new char[] { ';', ',' });
                                                                    string _LandTRelatedDocuments = "";
                                                                    foreach (var item in LandTDocs)
                                                                    {
                                                                        string _filepath = clsStaticGlobal.VaultCustomerLandTFolder.FullName + "/" + item;
                                                                        Autodesk.Connectivity.WebServices.File _file = clsStaticGlobal.IsFileExistintoVault(clsStaticGlobal.VaultCustomerLandTFolder, item);
                                                                        if (_file != null)
                                                                        {
                                                                            _objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Add(new LandTRelatedDocument { IsCheckedLandTRelatedDocument = true, FileType = "L&T Related Document", FileName = item, FilePath = _filepath, FileRemark = "", FileRevision = _file.FileRev.Label.ToString(), FileStatus = _file.FileLfCyc.LfCycStateName.ToString() });
                                                                            if (_LandTRelatedDocuments.Trim() == "")
                                                                            {
                                                                                _LandTRelatedDocuments = item;
                                                                            }
                                                                            else
                                                                            {
                                                                                _LandTRelatedDocuments = _LandTRelatedDocuments + Environment.NewLine + item;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            System.Windows.MessageBox.Show("Relevant doc.by L&T file does not exist..!!" + Environment.NewLine + _filepath, "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                            _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                            isBreak = true;
                                                                        }
                                                                    }
                                                                    _objSingleCustomerCommentsummary.CustomerCommentLandTRelatedDocuments = _LandTRelatedDocuments;
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {

                                                            }

                                                            break;
                                                        }
                                                    case 11:
                                                        {
                                                            try
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentTimeImplications = xlRange.Cells[i, j].Value2.ToString();
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentTimeImplications = "";
                                                            }

                                                            break;
                                                        }
                                                    case 12:
                                                        {
                                                            try
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentCostImplications = xlRange.Cells[i, j].Value2.ToString();
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentCostImplications = "";
                                                            }

                                                            break;
                                                        }
                                                    case 13:
                                                        {
                                                            try
                                                            {
                                                                if (xlRange.Cells[i, j].Value2.ToString().Trim() != "")
                                                                {
                                                                    if ((xlRange.Cells[i, j].Value2.ToString().ToUpper() == "YES") || (xlRange.Cells[i, j].Value2.ToString().ToUpper() == "NO"))
                                                                    {
                                                                        _objSingleCustomerCommentsummary.CustomerCommentFindAcceptanceFromCustomer = xlRange.Cells[i, j].Value2.ToString();
                                                                    }
                                                                    else
                                                                    {
                                                                        System.Windows.MessageBox.Show("Final Acceptance by customer format missmatch..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                                                        _objSingleCustomerCommentsummary.CustomerCommentIsSuccess = false;
                                                                        isBreak = true;
                                                                    }
                                                                }
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                clsStaticGlobal.ErrHandlerLog(ex);
                                                            }
                                                            break;
                                                        }
                                                    case 14:
                                                        {
                                                            try
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentRemark = xlRange.Cells[i, j].Value2.ToString();
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                _objSingleCustomerCommentsummary.CustomerCommentRemark = "";
                                                            }

                                                            break;
                                                        }
                                                    default:
                                                        break;
                                                }

                                            }

                                        }

                                        _listCustomerComment.Add(_objSingleCustomerCommentsummary);

                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Invalid column header..!!", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                                        isBreak = true;
                                    }

                                }

                            }

                            //cleanup
                            GC.Collect();
                            GC.WaitForPendingFinalizers();

                            if (isBreak == false)
                            {
                                if (_listCustomerComment.Count > 0)
                                {
                                    if (MassUpload(_listCustomerComment))
                                    {
                                        System.Windows.MessageBox.Show("Mass upload done successfully.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Information);

                                    }
                                    else
                                    {
                                        System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                                    }

                                }
                                else
                                {
                                    System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                                }

                            }
                            else
                            {
                                System.Windows.MessageBox.Show("Mass upload fail due to invalid format.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);

                            }

                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show("Error in report export.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                        finally
                        {
                            try
                            {
                                Marshal.ReleaseComObject(xlRange);
                                Marshal.ReleaseComObject(xlWorksheet);

                                //close and release
                                xlWorkbook.Close();
                                Marshal.ReleaseComObject(xlWorkbook);

                                //quit and release
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);

                            }
                            catch (Exception)
                            {
                                xlApp.Quit();
                                Marshal.ReleaseComObject(xlApp);
                            }

                        }

                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Excel application not installed.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                System.Windows.MessageBox.Show("Select project first.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void cmdMassUploadFormat_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string MassUploadFileFormatPath = clsStaticGlobal.ErrorFilePath + "/Customer Comments Mass Upload.xlsx";
                FolderBrowserDialog openfolderdialog1 = new FolderBrowserDialog();
                openfolderdialog1.ShowNewFolderButton = true;
                if (openfolderdialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string MassUploadDestinationFilePath = openfolderdialog1.SelectedPath + "/Customer Comments Mass Upload Format.xlsx";
                    if (System.IO.File.Exists(MassUploadFileFormatPath))
                    {
                        if (System.IO.File.Exists(MassUploadDestinationFilePath))
                            System.IO.File.Delete(MassUploadDestinationFilePath);
                        System.IO.File.Copy(MassUploadFileFormatPath, MassUploadDestinationFilePath);
                        System.Windows.MessageBox.Show("Customer Comments Mass Upload File Format Exported Successfully.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Customer Comments Mass Upload File Format Exported Failed.", "Customer Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool MassUpload(List<SingleCustomerCommentsummary> _listSingleCustomerCommentsummary)
        {
            ////Debugger.Launch();
            bool _isSuccess = false;
            try
            {
                foreach (SingleCustomerCommentsummary _objSingleCustomerCommentsummary in _listSingleCustomerCommentsummary)
                {
                    String _xmlFilePath = clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode + "\\" + _objSingleCustomerCommentsummary.CustomerCommentFileName;
                    _objSingleCustomerCommentsummary.CustomerCommentFileFullPath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + _objSingleCustomerCommentsummary.CustomerCommentFileName;
                    clsStaticGlobal.BindingDataSingleWrite(_objSingleCustomerCommentsummary, _xmlFilePath, false);
                    clsStaticGlobal.UpdateFileRemark(_objSingleCustomerCommentsummary);

                }

                BindwithFilter();

                _isSuccess = true;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _isSuccess;
        }

        private void Referesh_Click(object sender, RoutedEventArgs e)
        {
            try

            {
                //Debugger.Launch();
                int SelectedIndex = -1;
                SelectedIndex = cmbProjectCode.SelectedIndex;
                clsStaticGlobal.DisposeAllObjects();
                clsStaticGlobal.GetProjectCodes();
                cmbProjectCode.ItemsSource = clsStaticGlobal.ProjectCodeItemCollection;
                clsStaticGlobal.AllFileStates();

                cmbCommentStatus.ItemsSource = clsStaticGlobal.CommentStatesCollection;
                chkIsFilter.IsChecked = false;
                IsFilterAllow(false);

                List<string> userlist = new List<string>();
                userlist.Add("All");
                List<string> userlistTemp = clsStaticGlobal.GetAllUserList();
                userlistTemp.Sort();
                userlist.AddRange(userlistTemp);
                cmbResponsiblePerson.ItemsSource = userlist;
                List<string> finalAcceptancebycustomerlist = new List<string>();
                finalAcceptancebycustomerlist.Add("All");
                finalAcceptancebycustomerlist.Add("Yes");
                finalAcceptancebycustomerlist.Add("No");
                cmbFinalAcceptance.ItemsSource = finalAcceptancebycustomerlist;

                cmbCommentStatus.SelectedIndex = 0;
                cmbResponsiblePerson.SelectedIndex = 0;
                cmbFinalAcceptance.SelectedIndex = 0;

                if (SelectedIndex != -1)
                {
                    //Debugger.Launch();
                    cmbProjectCode.SelectedIndex = SelectedIndex;

                    if (cmbProjectCode.SelectedItem != null)
                    {
                        if (chkIsFilter.IsChecked == true)
                        {
                            chkIsFilter.IsChecked = false;
                        }
                        else
                        {
                            BindwithFilter();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private List<int> GetAllCommentsNumbers(string _ProjectCode)
        {
            List<int> listCommentsNumbers = new List<int>();
            try
            {
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(clsStaticGlobal.VaultCustomerFolder.Id, true);

                if (files != null)
                {
                    List<VDF.Vault.Currency.Entities.FileIteration> FileIterations = new List<VDF.Vault.Currency.Entities.FileIteration> { };
                    foreach (Autodesk.Connectivity.WebServices.File file in files)
                    {
                        if (clsStaticGlobal.CustomerCommentFileCategory.ToUpper() == file.Cat.CatName.ToUpper())
                        {
                            string[] CommentsNumberSplite = file.Name.Split(new char[] { '_' });
                            string CommentNumber = CommentsNumberSplite[2].ToUpper().Replace(".XML", "");
                            listCommentsNumbers.Add(int.Parse(CommentNumber));
                            listCommentsNumbers.Sort();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
            return listCommentsNumbers;
        }
               
    }

    public class ProjectCodes
    {
        private string mProjectCode;

        public string ProjectCodeName
        {
            get { return mProjectCode; }
            set { mProjectCode = value; }
        }
    }

    public class CommentStates
    {
        private string mCommentState;

        public string CommentState
        {
            get { return mCommentState; }
            set { mCommentState = value; }
        }

    }

}
