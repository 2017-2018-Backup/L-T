﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PlateWidthCollection : ObservableCollection<NameCodePair>
    {
        public static PlateWidthCollection LoadList()
        {
            PlateWidthCollection items = new PlateWidthCollection();
            items.Add(new NameCodePair() { Code = "001", Name = "180" });
            items.Add(new NameCodePair() { Code = "002", Name = "200" });
            items.Add(new NameCodePair() { Code = "003", Name = "300" });
            items.Add(new NameCodePair() { Code = "004", Name = "400" });
            items.Add(new NameCodePair() { Code = "005", Name = "500" });
            items.Add(new NameCodePair() { Code = "007", Name = "700" });
            items.Add(new NameCodePair() { Code = "008", Name = "800" });
            items.Add(new NameCodePair() { Code = "010", Name = "1000" });
            items.Add(new NameCodePair() { Code = "011", Name = "1250" });
            items.Add(new NameCodePair() { Code = "012", Name = "1200" });
            items.Add(new NameCodePair() { Code = "013", Name = "1300" });
            items.Add(new NameCodePair() { Code = "015", Name = "1500" });
            items.Add(new NameCodePair() { Code = "016", Name = "1600" });
            items.Add(new NameCodePair() { Code = "018", Name = "1800" });
            items.Add(new NameCodePair() { Code = "019", Name = "1900" });
            items.Add(new NameCodePair() { Code = "020", Name = "2000" });
            items.Add(new NameCodePair() { Code = "021", Name = "2100" });
            items.Add(new NameCodePair() { Code = "022", Name = "2200" });
            items.Add(new NameCodePair() { Code = "023", Name = "2300" });
            items.Add(new NameCodePair() { Code = "024", Name = "2400" });
            items.Add(new NameCodePair() { Code = "025", Name = "2500" });
            items.Add(new NameCodePair() { Code = "026", Name = "2600" });
            items.Add(new NameCodePair() { Code = "030", Name = "3000" });
            items.Add(new NameCodePair() { Code = "032", Name = "3200" });
            items.Add(new NameCodePair() { Code = "033", Name = "3300" });
            items.Add(new NameCodePair() { Code = "041", Name = "4100" });
            items.Add(new NameCodePair() { Code = "050", Name = "5000" });
            return items;
        }

        public static PlateWidthCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static PlateWidthCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PlateWidthCollection>(HullItems.HullDataPath + @"\Plate\PlateWidthCollection.xml");
        }
        
        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PlateWidthCollection>(this, HullItems.HullDataPath + @"\Plate\PlateWidthCollection.xml");
        }
    }
}
