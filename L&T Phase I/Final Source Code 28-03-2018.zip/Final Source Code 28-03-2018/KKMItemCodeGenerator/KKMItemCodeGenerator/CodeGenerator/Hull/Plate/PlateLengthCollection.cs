﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PlateLengthCollection : ObservableCollection<NameCodePair>
    {
        public static PlateLengthCollection LoadList()
        {
            PlateLengthCollection items = new PlateLengthCollection();
            items.Add(new NameCodePair() { Code = "003", Name = "300" });
            items.Add(new NameCodePair() { Code = "004", Name = "400" });
            items.Add(new NameCodePair() { Code = "005", Name = "500" });
            items.Add(new NameCodePair() { Code = "006", Name = "600" });
            items.Add(new NameCodePair() { Code = "007", Name = "700" });
            items.Add(new NameCodePair() { Code = "010", Name = "1000" });
            items.Add(new NameCodePair() { Code = "015", Name = "1500" });
            items.Add(new NameCodePair() { Code = "018", Name = "1800" });
            items.Add(new NameCodePair() { Code = "020", Name = "2000" });
            items.Add(new NameCodePair() { Code = "025", Name = "2500" });
            items.Add(new NameCodePair() { Code = "030", Name = "3000" });
            items.Add(new NameCodePair() { Code = "033", Name = "3300" });
            items.Add(new NameCodePair() { Code = "035", Name = "3500" });
            items.Add(new NameCodePair() { Code = "038", Name = "3800" });
            items.Add(new NameCodePair() { Code = "040", Name = "4000" });
            items.Add(new NameCodePair() { Code = "041", Name = "4100" });
            items.Add(new NameCodePair() { Code = "050", Name = "5000" });
            items.Add(new NameCodePair() { Code = "055", Name = "5500" });
            items.Add(new NameCodePair() { Code = "060", Name = "6000" });
            items.Add(new NameCodePair() { Code = "063", Name = "6300" });
            items.Add(new NameCodePair() { Code = "065", Name = "6500" });
            items.Add(new NameCodePair() { Code = "070", Name = "7000" });
            items.Add(new NameCodePair() { Code = "075", Name = "7500" });
            items.Add(new NameCodePair() { Code = "078", Name = "7800" });
            items.Add(new NameCodePair() { Code = "079", Name = "7900" });
            items.Add(new NameCodePair() { Code = "080", Name = "8000" });
            items.Add(new NameCodePair() { Code = "081", Name = "8100" });
            items.Add(new NameCodePair() { Code = "082", Name = "8200" });
            items.Add(new NameCodePair() { Code = "085", Name = "8500" });
            items.Add(new NameCodePair() { Code = "086", Name = "8600" });
            items.Add(new NameCodePair() { Code = "088", Name = "8800" });
            items.Add(new NameCodePair() { Code = "090", Name = "9000" });
            items.Add(new NameCodePair() { Code = "093", Name = "9300" });
            items.Add(new NameCodePair() { Code = "094", Name = "9400" });
            items.Add(new NameCodePair() { Code = "095", Name = "9500" });
            items.Add(new NameCodePair() { Code = "098", Name = "9800" });
            items.Add(new NameCodePair() { Code = "100", Name = "10000" });
            items.Add(new NameCodePair() { Code = "118", Name = "11800" });
            items.Add(new NameCodePair() { Code = "110", Name = "11000" });
            items.Add(new NameCodePair() { Code = "120", Name = "12000" });
            items.Add(new NameCodePair() { Code = "125", Name = "12500" });
            items.Add(new NameCodePair() { Code = "130", Name = "13000" });
            items.Add(new NameCodePair() { Code = "160", Name = "16000" });

            return items;
        }

        public static PlateLengthCollection LoadFromExcel(String path)
        {
            return null;
        }

        public static PlateLengthCollection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PlateLengthCollection>(HullItems.HullDataPath + @"\Plate\PlateLengthCollection.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PlateLengthCollection>(this, HullItems.HullDataPath + @"\Plate\PlateLengthCollection.xml");
        }
    }
}
