﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HullGroupItems : ObservableCollection<NameCodePair>
    {
        
        public static HullGroupItems LoadList()
        {
            HullGroupItems items = new HullGroupItems();
            items.Add(new NameCodePair() { Code = "STP", Name = "Steel & Structural Items - Plates" });
            items.Add(new NameCodePair() { Code = "STR", Name = "Steel & Structural Items - Profiles" });
            return items;
        }
        public static HullGroupItems LoadFromExcel(String path)
        {
            return null;
        }

        public static HullGroupItems LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HullGroupItems>(HullItems.HullDataPath + @"\HullGroupItems.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HullGroupItems>(this, HullItems.HullDataPath + @"\HullGroupItems.xml");
        }

    }
}
