﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Autodesk.Connectivity.Explorer.Extensibility;
using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using VDF = Autodesk.DataManagement.Client.Framework;
// The extension ID needs to be unique for each extension.  
// Make sure to generate your own ID when writing your own extension. 
[assembly: Autodesk.Connectivity.Extensibility.Framework.ExtensionId("F7810E51-005E-4BF7-B959-A49F0368BA41")]

// This number gets incremented for each Vault release.
[assembly: Autodesk.Connectivity.Extensibility.Framework.ApiVersion("11.0")]

namespace KKMItemCodeGenerator
{
    public class KKMItemCodeGenerator : IExplorerExtension
    {
        public IEnumerable<CommandSite> CommandSites()
        {  
            //// Create the Hello World command object.
            CommandItem KKMItemCodeGeneratorCmdItem = new CommandItem("KKMItemCodeGeneratorCommand", "Item Code Generator")
            {
                // this command is active when a File is selected
               // NavigationTypes = new SelectionTypeId[] { SelectionTypeId.Folder },
                Image=Properties.Resources.L_T,
                // this command is not active if there are multiple entities selected
                MultiSelectEnabled = false
            };

            // The HelloWorldCommandHandler function is called when the custom command is executed.
            KKMItemCodeGeneratorCmdItem.Execute += KKMItemCodeGeneratorCommandHandler;

            // Create a command site to hook the command to the Advanced toolbar
            CommandSite KKMItemCodeGeneratorCmdSite1 = new CommandSite("KKMItemCodeGeneratorCommand.Toolbar", "Item Code Generator")
            {
                Location = CommandSiteLocation.StandardToolbar,
                DeployAsPulldownMenu = false
            };
            KKMItemCodeGeneratorCmdSite1.AddCommand(KKMItemCodeGeneratorCmdItem);

            // Create a command site to hook the command to the Advanced toolbar
            CommandSite KKMItemCodeGeneratorCmdSite2 = new CommandSite("KKMItemCodeGeneratorCommand.Toolbar", "Item Code Generator")
            {
                Location = CommandSiteLocation.ToolsMenu,
                DeployAsPulldownMenu = false
            };
            KKMItemCodeGeneratorCmdSite2.AddCommand(KKMItemCodeGeneratorCmdItem);

            // Now the custom command is available in 2 places.

            // Gather the sites in a List.
            List<CommandSite> sites = new List<CommandSite>();
            sites.Add(KKMItemCodeGeneratorCmdSite1);
            sites.Add(KKMItemCodeGeneratorCmdSite2);

            // Return the list of CommandSites.
            return sites;
        }

        private void KKMItemCodeGeneratorCommandHandler(object sender, CommandItemEventArgs e)
        {            
            try
            {
                VDF.Vault.Currency.Connections.Connection vConnection = e.Context.Application.Connection;               
                MainWindow obj = new MainWindow(vConnection);
                obj.ShowDialog();
                e.Context.ForceRefresh = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Item Code Generator",MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        public IEnumerable<CustomEntityHandler> CustomEntityHandlers()
        {
            return null;
        }

        public IEnumerable<DetailPaneTab> DetailTabs()
        {
            return null;
        }

        public IEnumerable<string> HiddenCommands()
        {
            return null;
        }

        public void OnLogOff(IApplication application)
        {

        }

        public void OnLogOn(IApplication application)
        {
            
        }

        public void OnShutdown(IApplication application)
        {

        }

        public void OnStartup(IApplication application)
        {

        }

    }
}
