﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;
using KKMCustomerComment;

namespace KKMCustomerComments
{
    /// <summary>
    /// Interaction logic for UserControlLandTRelatedDocument.xaml
    /// </summary>
    public partial class UserControlRelatedDocByLandT : Window
    {
        public System.Windows.Forms.DialogResult DialogResUserControlRelatedDocByLandT = System.Windows.Forms.DialogResult.Cancel;
        public List<string> StatusList { get; set; }
        bool isEditMode = false;
        public UserControlRelatedDocByLandT(bool _isEditMode)
        {
            InitializeComponent();
            isEditMode = _isEditMode;
            try
            {
                if (clsStaticGlobal.IsReadOnly == true)
                {
                    cmdAddApprovedDocument.Visibility = Visibility.Hidden;
                    cmdSave.Visibility = Visibility.Hidden;
                    cmdRemove.Visibility = Visibility.Hidden;
                }
                else
                {
                    cmdAddApprovedDocument.Visibility = Visibility.Visible;
                    cmdSave.Visibility = Visibility.Visible;
                    cmdRemove.Visibility = Visibility.Visible;
                }
            }
            catch (Exception)
            {
                           }
           
            try
            {
                StatusList = new List<string>();
                StatusList.Add("Create");
                StatusList.Add("Release");
                //DrawingStatus.ItemsSource = StatusList;

                clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection.Clear();
                int SearchedCount = 1;
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.RelatedDocByLandTFiles)
                {
                    //System.Diagnostics.
                    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                    string filePath = folder.FullName + "/" + _item.Name;
                    string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                    string fileName = _item.Name;
                    string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _item.Id, false);
                    if (fileDec == null)
                    {
                        fileDec = "";
                    }
                    clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection.Add(new LandTRelatedDocument { Count = SearchedCount, IsCheckedLandTRelatedDocument = false, FileType = _item.Cat.CatName, FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                    SearchedCount += 1;
                }

                //clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(LandTRelatedDocumentSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListLandTRelatedDocuments_CollectionChanged);

                LandTRelatedDocumentSearchGridViewBox.ItemsSource = clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(LandTRelatedDocumentSearchGridViewBox.ItemsSource);
                viewSearch.Filter = UserFilter;
                LandTRelatedDocumentSearchGridViewBox.UpdateLayout();

                if (clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                {
                    LandTRelatedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments;
                    LandTRelatedDocumentGridViewBox.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DialogResUserControlRelatedDocByLandT = System.Windows.Forms.DialogResult.Cancel;
                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void LandTRelatedDocumentSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListLandTRelatedDocuments_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                {
                    item.Count = k;
                    k++;
                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                    //item.FileRemark = _remark;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    LandTRelatedDocumentSearchGridViewBox.UpdateLayout();
                    LandTRelatedDocumentSearchGridViewBox.Items.Refresh();
                    foreach (LandTRelatedDocument _item in clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection)
                    {
                        if (_item.IsCheckedLandTRelatedDocument == true)
                        {
                            bool IsFileExist = false;
                            foreach (LandTRelatedDocument _itemExist in clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                            {
                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                            }
                            if (IsFileExist == false)
                            {
                                clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Add(new LandTRelatedDocument { IsCheckedLandTRelatedDocument = false, FileType = _item.FileType, FileName = _item.FileName, FileDesc = _item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString() });
                            }
                        }
                    }
                    LandTRelatedDocumentGridViewBox.ItemsSource = clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments;
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            LandTRelatedDocumentGridViewBox.UpdateLayout();
        }

        private void cmdClassApprovedRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    bool isChecked = false;

                    if (clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                    {
                        try
                        {
                            //System.Diagnostics.Debugger.Launch();

                            List<LandTRelatedDocument> listOfLandTRelatedDocument = new List<LandTRelatedDocument>();

                            foreach (var itemlandTDoc in LandTRelatedDocumentGridViewBox.Items)
                            {
                                LandTRelatedDocument objLandTRelatedDocument = (LandTRelatedDocument)itemlandTDoc;

                                if (objLandTRelatedDocument.IsCheckedLandTRelatedDocument == true)
                                {
                                    isChecked = true;

                                    listOfLandTRelatedDocument.Add(objLandTRelatedDocument);
                                    //try
                                    //{
                                    //    clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Remove(objLandTRelatedDocument);
                                    //    LandTRelatedDocumentGridViewBox.Items.Refresh();
                                    //}
                                    //catch (Exception)
                                    //{

                                    //}
                                                              
                                }
                            }

                            foreach (LandTRelatedDocument item in listOfLandTRelatedDocument)
                            {
                                clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Remove(item);
                                LandTRelatedDocumentGridViewBox.Items.Refresh();
                            }
                            //if (LandTRelatedDocumentGridViewBox.SelectedCells.Count > 0)
                            //{
                            //    LandTRelatedDocument objLandTRelatedDocument = (LandTRelatedDocument)LandTRelatedDocumentGridViewBox.SelectedCells[0].Item;
                            //    clsStaticGlobal.objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Remove(objLandTRelatedDocument);
                            //    LandTRelatedDocumentGridViewBox.UpdateLayout();
                            //}
                            //else
                            //{
                            //    MessageBox.Show("Select single file first.", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                            //}

                            LandTRelatedDocumentGridViewBox.Items.Refresh();

                            if (isChecked == false)
                            {
                                MessageBox.Show("Select file first.", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }
                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Customer Comment in Release state. User can not edit..!!", "Customer Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void LandTRelatedDocumentSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                LandTRelatedDocumentSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DialogResUserControlRelatedDocByLandT = System.Windows.Forms.DialogResult.OK;
                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
                return true;
            else
                return ((item as LandTRelatedDocument).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as LandTRelatedDocument).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(LandTRelatedDocumentSearchGridViewBox.ItemsSource).Refresh();
        }
    }

}
