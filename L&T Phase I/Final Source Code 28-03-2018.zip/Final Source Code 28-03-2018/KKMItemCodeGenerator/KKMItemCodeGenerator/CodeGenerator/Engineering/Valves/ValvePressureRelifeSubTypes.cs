﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValvePressureRelifeSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValvePressureRelifeSubTypes LoadList()
        {
            ValvePressureRelifeSubTypes items = new ValvePressureRelifeSubTypes();

            items.Add(new NameCodePair() { Code = "01", Name = "Pressure - Vacuum Valve" });
            return items;
        }
        public static ValvePressureRelifeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValvePressureRelifeSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValvePressureRelifeSubTypes>(EngineeringItems.DataPath + @"\Valves\ValvePressureRelifeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValvePressureRelifeSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValvePressureRelifeSubTypes.xml");
        }

    }
}
