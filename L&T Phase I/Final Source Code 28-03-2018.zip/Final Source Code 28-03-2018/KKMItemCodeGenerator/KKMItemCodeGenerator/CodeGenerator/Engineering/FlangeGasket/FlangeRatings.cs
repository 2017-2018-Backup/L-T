﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeRatings : ObservableCollection<NameCodePair>
    {
        public static FlangeRatings LoadList()
        {
            FlangeRatings items = new FlangeRatings();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "PN 4" });
            items.Add(new NameCodePair() { Code = "02", Name = "PN-6" });
            items.Add(new NameCodePair() { Code = "03", Name = "PN-10" });
            items.Add(new NameCodePair() { Code = "04", Name = "PN-16" });
            items.Add(new NameCodePair() { Code = "05", Name = "PN 20" });
            items.Add(new NameCodePair() { Code = "06", Name = "PN 25" });
            items.Add(new NameCodePair() { Code = "07", Name = "PN 40" });
            items.Add(new NameCodePair() { Code = "08", Name = "PN 50" });
            items.Add(new NameCodePair() { Code = "09", Name = "PN 64" });
            items.Add(new NameCodePair() { Code = "10", Name = "PN 100" });
            items.Add(new NameCodePair() { Code = "11", Name = "5K" });
            items.Add(new NameCodePair() { Code = "12", Name = "10K" });
            items.Add(new NameCodePair() { Code = "13", Name = "16K" });
            items.Add(new NameCodePair() { Code = "14", Name = "20K" });
            items.Add(new NameCodePair() { Code = "15", Name = "#150" });
            items.Add(new NameCodePair() { Code = "16", Name = "#300" });
            items.Add(new NameCodePair() { Code = "17", Name = "#600" });
            items.Add(new NameCodePair() { Code = "18", Name = "#3000" });
            items.Add(new NameCodePair() { Code = "19", Name = "#6000" });
            items.Add(new NameCodePair() { Code = "20", Name = "#900" });
            return items;
        }
        public static FlangeRatings LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeRatings LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeRatings>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeRatings.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeRatings>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeRatings.xml");
        }

    }
}
