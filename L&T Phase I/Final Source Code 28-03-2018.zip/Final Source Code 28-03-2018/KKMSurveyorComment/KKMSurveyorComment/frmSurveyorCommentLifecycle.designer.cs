﻿namespace KKMSurveyorComment
{
    partial class frmSurveyorCommentLifecycle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSurveyorCommentLifecycle));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.m_categoryComboBox = new System.Windows.Forms.ComboBox();
            this.m_lifecycleDefComboBox = new System.Windows.Forms.ComboBox();
            this.txtLifeCycleComment = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmdCancle = new System.Windows.Forms.Button();
            this.cmdProceed = new System.Windows.Forms.Button();
            this.cmdSurveyorLifecycle = new System.Windows.Forms.ComboBox();
            this.txtSurveyorComment = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(468, 202);
            this.panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.m_categoryComboBox);
            this.groupBox1.Controls.Add(this.m_lifecycleDefComboBox);
            this.groupBox1.Controls.Add(this.txtLifeCycleComment);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmdCancle);
            this.groupBox1.Controls.Add(this.cmdProceed);
            this.groupBox1.Controls.Add(this.cmdSurveyorLifecycle);
            this.groupBox1.Controls.Add(this.txtSurveyorComment);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(12, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(444, 180);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lifecycle";
            // 
            // m_categoryComboBox
            // 
            this.m_categoryComboBox.FormattingEnabled = true;
            this.m_categoryComboBox.Items.AddRange(new object[] {
            "Pending",
            "Close"});
            this.m_categoryComboBox.Location = new System.Drawing.Point(5, 117);
            this.m_categoryComboBox.Name = "m_categoryComboBox";
            this.m_categoryComboBox.Size = new System.Drawing.Size(168, 25);
            this.m_categoryComboBox.TabIndex = 10;
            this.m_categoryComboBox.Visible = false;
            // 
            // m_lifecycleDefComboBox
            // 
            this.m_lifecycleDefComboBox.FormattingEnabled = true;
            this.m_lifecycleDefComboBox.Items.AddRange(new object[] {
            "Pending",
            "Close"});
            this.m_lifecycleDefComboBox.Location = new System.Drawing.Point(5, 149);
            this.m_lifecycleDefComboBox.Name = "m_lifecycleDefComboBox";
            this.m_lifecycleDefComboBox.Size = new System.Drawing.Size(168, 25);
            this.m_lifecycleDefComboBox.TabIndex = 9;
            this.m_lifecycleDefComboBox.Visible = false;
            this.m_lifecycleDefComboBox.SelectedIndexChanged += new System.EventHandler(this.m_lifecycleDefComboBox_SelectedIndexChanged);
            // 
            // txtLifeCycleComment
            // 
            this.txtLifeCycleComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLifeCycleComment.Location = new System.Drawing.Point(180, 94);
            this.txtLifeCycleComment.Multiline = true;
            this.txtLifeCycleComment.Name = "txtLifeCycleComment";
            this.txtLifeCycleComment.Size = new System.Drawing.Size(258, 49);
            this.txtLifeCycleComment.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Lifecycle Change Comment :";
            // 
            // cmdCancle
            // 
            this.cmdCancle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdCancle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdCancle.ForeColor = System.Drawing.Color.White;
            this.cmdCancle.Location = new System.Drawing.Point(363, 149);
            this.cmdCancle.Name = "cmdCancle";
            this.cmdCancle.Size = new System.Drawing.Size(75, 25);
            this.cmdCancle.TabIndex = 3;
            this.cmdCancle.Text = "Cancel";
            this.cmdCancle.UseVisualStyleBackColor = false;
            this.cmdCancle.Click += new System.EventHandler(this.cmdCancle_Click);
            // 
            // cmdProceed
            // 
            this.cmdProceed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(152)))), ((int)(((byte)(236)))));
            this.cmdProceed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdProceed.ForeColor = System.Drawing.Color.White;
            this.cmdProceed.Location = new System.Drawing.Point(282, 149);
            this.cmdProceed.Name = "cmdProceed";
            this.cmdProceed.Size = new System.Drawing.Size(75, 25);
            this.cmdProceed.TabIndex = 2;
            this.cmdProceed.Text = "Proceed";
            this.cmdProceed.UseVisualStyleBackColor = false;
            this.cmdProceed.Click += new System.EventHandler(this.cmdProceed_Click);
            // 
            // cmdSurveyorLifecycle
            // 
            this.cmdSurveyorLifecycle.FormattingEnabled = true;
            this.cmdSurveyorLifecycle.Location = new System.Drawing.Point(180, 30);
            this.cmdSurveyorLifecycle.Name = "cmdSurveyorLifecycle";
            this.cmdSurveyorLifecycle.Size = new System.Drawing.Size(258, 25);
            this.cmdSurveyorLifecycle.TabIndex = 0;
            this.cmdSurveyorLifecycle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmdSurveyorLifecycle_KeyPress);
            // 
            // txtSurveyorComment
            // 
            this.txtSurveyorComment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSurveyorComment.Location = new System.Drawing.Point(180, 62);
            this.txtSurveyorComment.Multiline = true;
            this.txtSurveyorComment.Name = "txtSurveyorComment";
            this.txtSurveyorComment.ReadOnly = true;
            this.txtSurveyorComment.Size = new System.Drawing.Size(258, 24);
            this.txtSurveyorComment.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Surveyor Lifecycle :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Surveyor Comment Name :";
            // 
            // frmSurveyorCommentLifecycle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 202);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmSurveyorCommentLifecycle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Surveyor Lifecycle";
            this.Load += new System.EventHandler(this.frmSurveyorCommentLifecycle_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdProceed;
        private System.Windows.Forms.ComboBox cmdSurveyorLifecycle;
        private System.Windows.Forms.TextBox txtSurveyorComment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdCancle;
        private System.Windows.Forms.TextBox txtLifeCycleComment;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox m_categoryComboBox;
        private System.Windows.Forms.ComboBox m_lifecycleDefComboBox;
    }
}

