﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersTypes : ObservableCollection<NameCodePair>
    {
        public static StrainersTypes LoadList()
        {
            StrainersTypes items = new StrainersTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "SIMPLEX STRAINER" });
            items.Add(new NameCodePair() { Code = "02", Name = "DUPLEX STRAINER" });
            items.Add(new NameCodePair() { Code = "03", Name = "Y-TYPE STRAINER" });
            items.Add(new NameCodePair() { Code = "04", Name = "FOOT VALVE WITH STRAINER" });
            items.Add(new NameCodePair() { Code = "05", Name = "STRUM BOX" });
            items.Add(new NameCodePair() { Code = "06", Name = "MUD BOX" });
            items.Add(new NameCodePair() { Code = "07", Name = "OTHER FILTERS" });
            return items;
        }
        public static StrainersTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersTypes>(EngineeringItems.DataPath + @"\Strainers\StrainersTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersTypes>(this, EngineeringItems.DataPath + @"\Strainers\StrainersTypes.xml");
        }

    }
}
