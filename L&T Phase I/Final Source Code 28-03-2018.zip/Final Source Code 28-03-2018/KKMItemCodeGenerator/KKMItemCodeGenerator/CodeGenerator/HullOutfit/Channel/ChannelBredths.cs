﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelBredths : ObservableCollection<NameCodePair>
    {
        public static ChannelBredths LoadList()
        {
            ChannelBredths items = new ChannelBredths();
            items.Add(new NameCodePair() { Code = "075", Name = "75 mm" });
            items.Add(new NameCodePair() { Code = "100", Name = "100 mm" });
            items.Add(new NameCodePair() { Code = "125", Name = "125 mm" });
            items.Add(new NameCodePair() { Code = "150", Name = "150 mm" });
            items.Add(new NameCodePair() { Code = "175", Name = "175 mm" });
            items.Add(new NameCodePair() { Code = "200", Name = "200 mm" });
            items.Add(new NameCodePair() { Code = "225", Name = "225 mm" });
            items.Add(new NameCodePair() { Code = "250", Name = "250 mm" });
            items.Add(new NameCodePair() { Code = "300", Name = "300 mm" });
            items.Add(new NameCodePair() { Code = "350", Name = "350 mm" });
            items.Add(new NameCodePair() { Code = "400", Name = "400 mm" });

            return items;
        }
        public static ChannelBredths LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelBredths LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelBredths>(HullOutfitItems.DataPath + @"\Channel\ChannelBredths.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelBredths>(this, HullOutfitItems.DataPath + @"\Channel\ChannelBredths.xml");
        }
    }
}
