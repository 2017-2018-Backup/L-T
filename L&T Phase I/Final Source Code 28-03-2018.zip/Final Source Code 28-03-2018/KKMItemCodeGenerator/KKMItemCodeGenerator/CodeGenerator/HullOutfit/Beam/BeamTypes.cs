﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamTypes : ObservableCollection<NameCodePair>
    {
        public static BeamTypes LoadList()
        {
            BeamTypes items = new BeamTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "I-BEAM" });
            items.Add(new NameCodePair() { Code = "02", Name = "T-BEAM" });
            return items;
        }
        public static BeamTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamTypes>(HullOutfitItems.DataPath + @"\Beam\BeamTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamTypes>(this, HullOutfitItems.DataPath + @"\Beam\BeamTypes.xml");
        }
    }
}
