﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareNutSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareNutSubTypes LoadList()
        {
            HardwareNutSubTypes items = new HardwareNutSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Hex.Nut" });
            items.Add(new NameCodePair() { Code = "02", Name = "Hex. Lock Nut" });
            items.Add(new NameCodePair() { Code = "03", Name = "Dome Nut" });
            items.Add(new NameCodePair() { Code = "04", Name = "Wing Nut" });
            items.Add(new NameCodePair() { Code = "05", Name = "Knurled Nut" });
            items.Add(new NameCodePair() { Code = "06", Name = "Nyloc Nut" });
            items.Add(new NameCodePair() { Code = "07", Name = "Eye Nut" });
            return items;
        }
        public static HardwareNutSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareNutSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareNutSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareNutSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareNutSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareNutSubTypes.xml");
        }
    }
}
