﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class RsVoltages : ObservableCollection<NameCodePair>
    {
        public static RsVoltages LoadList()
        {
            RsVoltages items = new RsVoltages();
            items.Add(new NameCodePair() { Code = "01", Name = "230V" });
            items.Add(new NameCodePair() { Code = "02", Name = "440V" });
            items.Add(new NameCodePair() { Code = "03", Name = "110V" });
            items.Add(new NameCodePair() { Code = "04", Name = "240V" });
            items.Add(new NameCodePair() { Code = "05", Name = "415V" });
            items.Add(new NameCodePair() { Code = "06", Name = "450V" });
            items.Add(new NameCodePair() { Code = "07", Name = "400V" });         
            return items;
        }
        public static RsVoltages LoadFromExcel(String path)
        {
            return null;
        }

        public static RsVoltages LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<RsVoltages>(ElectricalItems.DataPath + @"\Receptacles\RsVoltages.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<RsVoltages>(this, ElectricalItems.DataPath + @"\Receptacles\RsVoltages.xml");
        }

    }
}
