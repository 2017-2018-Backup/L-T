﻿using OfficeUtils;
using System;
using System.Data;

namespace DataSerialiser.Helpers
{
    public class ExcelHelper
    {
        public DataTable LoadExcel(String filePath)
        {
            try
            {
                DataTable dt = OfficeExcel.GetSheetRows(filePath, "Sheet1");
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
