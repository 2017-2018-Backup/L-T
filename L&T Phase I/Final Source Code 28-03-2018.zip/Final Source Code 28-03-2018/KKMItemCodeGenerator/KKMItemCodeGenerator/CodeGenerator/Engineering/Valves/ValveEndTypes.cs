﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveEndTypes : ObservableCollection<NameCodePair>
    {
        public static ValveEndTypes LoadList()
        {
            ValveEndTypes items = new ValveEndTypes();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "BSPP Female" });
            items.Add(new NameCodePair() { Code = "02", Name = "BSPP Male" });
            items.Add(new NameCodePair() { Code = "03", Name = "NPT F" });
            items.Add(new NameCodePair() { Code = "04", Name = "NPT M" });
            items.Add(new NameCodePair() { Code = "05", Name = "BW" });
            items.Add(new NameCodePair() { Code = "06", Name = "SW" });
            items.Add(new NameCodePair() { Code = "07", Name = "RF Flange" });
            items.Add(new NameCodePair() { Code = "08", Name = "FF Flange" });
            items.Add(new NameCodePair() { Code = "09", Name = "Wafer Type" });
            items.Add(new NameCodePair() { Code = "10", Name = "Butt welding" });
            items.Add(new NameCodePair() { Code = "11", Name = "RF-SmF" });
            items.Add(new NameCodePair() { Code = "12", Name = "Soft sealing" });
            items.Add(new NameCodePair() { Code = "13", Name = "Socket welding" });
            items.Add(new NameCodePair() { Code = "14", Name = "BITE TYPE" });
            return items;
        }
        public static ValveEndTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveEndTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveEndTypes>(EngineeringItems.DataPath + @"\Valves\ValveEndTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveEndTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveEndTypes.xml");
        }

    }
}
