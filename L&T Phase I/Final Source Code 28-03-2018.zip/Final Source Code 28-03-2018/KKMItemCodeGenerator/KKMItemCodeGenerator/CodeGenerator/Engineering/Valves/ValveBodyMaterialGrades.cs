﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveBodyMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static ValveBodyMaterialGrades LoadList()
        {
            ValveBodyMaterialGrades items = new ValveBodyMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "00.NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "01.BRONZE" });
            items.Add(new NameCodePair() { Code = "02", Name = "02.CAST IRON" });
            items.Add(new NameCodePair() { Code = "03", Name = "03.BRASS" });
            items.Add(new NameCodePair() { Code = "04", Name = "04.STAINLESS STEEL 316" });
            items.Add(new NameCodePair() { Code = "05", Name = "05.GUN METAL" });
            items.Add(new NameCodePair() { Code = "06", Name = "06.MILD-STEEL" });
            items.Add(new NameCodePair() { Code = "07", Name = "07.MS GALVANIZED" });
            items.Add(new NameCodePair() { Code = "08", Name = "08.CAST-STEEL" });
            items.Add(new NameCodePair() { Code = "09", Name = "09.FORGED-STEEL" });
            items.Add(new NameCodePair() { Code = "10", Name = "10.GGG40" });
            items.Add(new NameCodePair() { Code = "11", Name = "11.GG25" });
            items.Add(new NameCodePair() { Code = "12", Name = "12. NAB (NES 747 Part II)" });
            items.Add(new NameCodePair() { Code = "13", Name = "13. GM TO BS1400LG4C" });
            items.Add(new NameCodePair() { Code = "14", Name = "14.CAST STEEL GALVANISED" });
            items.Add(new NameCodePair() { Code = "15", Name = "15. GM TO CC492K" });
            items.Add(new NameCodePair() { Code = "16", Name = "16. SS 304L" });
            items.Add(new NameCodePair() { Code = "17", Name = "17. AA 6082 T5" });
            return items;
        }
        public static ValveBodyMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveBodyMaterialGrades LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveBodyMaterialGrades>(EngineeringItems.DataPath + @"\Valves\ValveBodyMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveBodyMaterialGrades>(this, EngineeringItems.DataPath + @"\Valves\ValveBodyMaterialGrades.xml");
        }

    }
}
