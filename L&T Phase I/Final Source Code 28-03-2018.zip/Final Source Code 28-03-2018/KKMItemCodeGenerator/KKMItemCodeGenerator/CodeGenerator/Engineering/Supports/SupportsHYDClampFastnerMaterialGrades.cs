﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsHYDClampFastnerMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static SupportsHYDClampFastnerMaterialGrades LoadList()
        {
            SupportsHYDClampFastnerMaterialGrades items = new SupportsHYDClampFastnerMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "SS304" });
            return items;
        }
        public static SupportsHYDClampFastnerMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsHYDClampFastnerMaterialGrades LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsHYDClampFastnerMaterialGrades>(EngineeringItems.DataPath + @"\Supports\SupportsHYDClampFastnerMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsHYDClampFastnerMaterialGrades>(this, EngineeringItems.DataPath + @"\Supports\SupportsHYDClampFastnerMaterialGrades.xml");
        }

    }
}
