﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareClassCertificates : ObservableCollection<NameCodePair>
    {
        public static HardwareClassCertificates LoadList()
        {
            HardwareClassCertificates items = new HardwareClassCertificates();
            items.Add(new NameCodePair() { Code = "00", Name = "LR 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "01", Name = "LR 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "02", Name = "Material Test Certificate" });
            items.Add(new NameCodePair() { Code = "03", Name = "GL 3.1 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GL 3.2 CERTIFICATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "NO CERTIFICATE" });

            return items;
        }
        public static HardwareClassCertificates LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareClassCertificates LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareClassCertificates>(HullOutfitItems.DataPath + @"\Hardware\HardwareClassCertificates.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareClassCertificates>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareClassCertificates.xml");
        }
    }
}
