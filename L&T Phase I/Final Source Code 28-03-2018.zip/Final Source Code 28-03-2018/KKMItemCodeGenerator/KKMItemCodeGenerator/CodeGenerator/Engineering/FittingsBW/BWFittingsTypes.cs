﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWFittingsTypes : ObservableCollection<NameCodePair>
    {
        public static BWFittingsTypes LoadList()
        {
            BWFittingsTypes items = new BWFittingsTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "PIPE ELBOW" });
            items.Add(new NameCodePair() { Code = "02", Name = "TUBE ELBOW" });
            items.Add(new NameCodePair() { Code = "03", Name = "PIPE TEE" });
            items.Add(new NameCodePair() { Code = "04", Name = "TUBE TEE" });
            items.Add(new NameCodePair() { Code = "05", Name = "PIPE REDUCER" });
            items.Add(new NameCodePair() { Code = "06", Name = "TUBE REDUCER" });
            items.Add(new NameCodePair() { Code = "07", Name = "ERW ELBOW" });
            items.Add(new NameCodePair() { Code = "08", Name = "ERW REDUCER" });
            return items;
        }
        public static BWFittingsTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static BWFittingsTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWFittingsTypes>(EngineeringItems.DataPath + @"\FittingsBW\BWFittingsTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWFittingsTypes>(this, EngineeringItems.DataPath + @"\FittingsBW\BWFittingsTypes.xml");
        }

    }
}
