﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareWasherSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareWasherSubTypes LoadList()
        {
            HardwareWasherSubTypes items = new HardwareWasherSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Plain Washer" });
            items.Add(new NameCodePair() { Code = "02", Name = "Machined Washer" });
            items.Add(new NameCodePair() { Code = "03", Name = "Punched Washer" });
            items.Add(new NameCodePair() { Code = "04", Name = "Spring Washer" });

            return items;
        }
        public static HardwareWasherSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareWasherSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareWasherSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareWasherSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareWasherSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareWasherSubTypes.xml");
        }
    }
}
