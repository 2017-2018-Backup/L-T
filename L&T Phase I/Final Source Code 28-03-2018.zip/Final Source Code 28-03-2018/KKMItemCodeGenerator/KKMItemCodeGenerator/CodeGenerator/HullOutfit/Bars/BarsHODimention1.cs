﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsHODimention1 : ObservableCollection<NameCodePair>
    {
        public static BarsHODimention1 LoadList()
        {
            BarsHODimention1 items = new BarsHODimention1();
            items.Add(new NameCodePair() { Code = "005", Name = "005" });
            items.Add(new NameCodePair() { Code = "006", Name = "006" });
            items.Add(new NameCodePair() { Code = "010", Name = "010" });
            items.Add(new NameCodePair() { Code = "012", Name = "012" });
            items.Add(new NameCodePair() { Code = "015", Name = "015" });
            items.Add(new NameCodePair() { Code = "016", Name = "016" });
            items.Add(new NameCodePair() { Code = "018", Name = "018" });
            items.Add(new NameCodePair() { Code = "019", Name = "019" });
            items.Add(new NameCodePair() { Code = "020", Name = "020" });
            items.Add(new NameCodePair() { Code = "022", Name = "022" });
            items.Add(new NameCodePair() { Code = "025", Name = "025" });
            items.Add(new NameCodePair() { Code = "030", Name = "030" });
            items.Add(new NameCodePair() { Code = "032", Name = "032" });
            items.Add(new NameCodePair() { Code = "035", Name = "035" });
            items.Add(new NameCodePair() { Code = "038", Name = "038" });
            items.Add(new NameCodePair() { Code = "040", Name = "040" });
            items.Add(new NameCodePair() { Code = "045", Name = "045" });
            items.Add(new NameCodePair() { Code = "050", Name = "050" });
            items.Add(new NameCodePair() { Code = "060", Name = "060" });
            items.Add(new NameCodePair() { Code = "070", Name = "070" });
            items.Add(new NameCodePair() { Code = "080", Name = "080" });
            items.Add(new NameCodePair() { Code = "100", Name = "100" });
            items.Add(new NameCodePair() { Code = "150", Name = "150" });
            items.Add(new NameCodePair() { Code = "200", Name = "200" });
            items.Add(new NameCodePair() { Code = "032", Name = "032" });
            items.Add(new NameCodePair() { Code = "038", Name = "038" });
            items.Add(new NameCodePair() { Code = "050", Name = "050" });
            items.Add(new NameCodePair() { Code = "028", Name = "028" });

            return items;
        }
        public static BarsHODimention1 LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsHODimention1 LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsHODimention1>(HullOutfitItems.DataPath + @"\Bars\BarsHODimention1.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsHODimention1>(this, HullOutfitItems.DataPath + @"\Bars\BarsHODimention1.xml");
        }
    }
}
