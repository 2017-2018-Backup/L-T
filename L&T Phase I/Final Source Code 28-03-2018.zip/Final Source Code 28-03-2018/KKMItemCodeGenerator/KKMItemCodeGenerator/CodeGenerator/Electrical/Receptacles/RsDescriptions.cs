﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class RsDescriptions : ObservableCollection<NameCodePair>
    {
        public static RsDescriptions LoadList()
        {
            RsDescriptions items = new RsDescriptions();
            items.Add(new NameCodePair() { Code = "01", Name = "DIN RAIL MOUNTED" });
            items.Add(new NameCodePair() { Code = "02", Name = "PANEL MOUNTED" });
            items.Add(new NameCodePair() { Code = "03", Name = "FLUSH MOUNTED" });
            items.Add(new NameCodePair() { Code = "04", Name = "DECORATIVE SWITCH" });
            items.Add(new NameCodePair() { Code = "05", Name = "GANG SOCKET OUTLET" });
            items.Add(new NameCodePair() { Code = "06", Name = "PLUG SOCKET SWITCH WITH PROTECTIVE CUTOFF" });
            items.Add(new NameCodePair() { Code = "07", Name = "PLUG SOCKET SWITCH (W/T TYPE)" });
            items.Add(new NameCodePair() { Code = "08", Name = "PLUG SOCKET WITH SWITCH (3PH WITH EARTH)" });
            items.Add(new NameCodePair() { Code = "09", Name = "POLE ONE WAY SWITCH" });
            items.Add(new NameCodePair() { Code = "10", Name = "PROOF ON/OFF SWITCH" });
            items.Add(new NameCodePair() { Code = "11", Name = "RECESSED TWO POLE SWITCH" });
            items.Add(new NameCodePair() { Code = "12", Name = "RECESSED TWO POLE SWITCH WITH DIMMER" });
            items.Add(new NameCodePair() { Code = "13", Name = "RECESSED SOCKET" });
            items.Add(new NameCodePair() { Code = "14", Name = "SURFACE SOCKET 2P+E" });
            items.Add(new NameCodePair() { Code = "15", Name = "SURFACE TWO POLE SWITCH" });
            items.Add(new NameCodePair() { Code = "16", Name = "TWIN SOCKET OUTLET" });
            return items;
        }
        public static RsDescriptions LoadFromExcel(String path)
        {
            return null;
        }

        public static RsDescriptions LoadFromXml()
        {
           
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<RsDescriptions>(ElectricalItems.DataPath + @"\Receptacles\RsDescriptions.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<RsDescriptions>(this, ElectricalItems.DataPath + @"\Receptacles\RsDescriptions.xml");
        }

    }
}
