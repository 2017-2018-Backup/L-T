﻿using Autodesk.Connectivity.WebServices;
using Autodesk.Connectivity.WebServicesTools;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Xml.Serialization;
using KKMCustomerComments;
using VDF = Autodesk.DataManagement.Client.Framework;
using KKMCustomerComment;
using System.IO.Packaging;
using System.Reflection;
using Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties;

public static class clsStaticGlobal
{
    public static bool IsReadOnly = false;
    public static bool IsFilter = false;
    public static VDF.Vault.Currency.Connections.Connection connection;
    public static string _ProjectCode = "";
    public static string CustomerCommentFolderName = "Customer Comments";
    public static string CustomerCommentFileCategory = "Customer Comments";
    public static string CustomerCommentByCustomerFolderName = "Customer Documents Folder";
    public static string CustomerCommentByLandTFolderName = "L&T Documents Folder";
    public static string LocalXMLCustomerCommentFolderPath = Path.GetTempPath() + CustomerCommentFolderName;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder ProjectFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultCustomerFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultCustomerCustomerFolder = null;
    public static Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder VaultCustomerLandTFolder = null;

    public static List<Autodesk.Connectivity.WebServices.File> RelevantDocByCustomerFiles = null;
    public static List<Autodesk.Connectivity.WebServices.File> RelatedDocByLandTFiles = null;
    public static List<int> ListCustomerCommentNumbers = null;

    public static ObservableCollection<ProjectCodes> ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();
    public static ObservableCollection<CommentStates> CommentStatesCollection = new ObservableCollection<CommentStates>();
    public static SingleCustomerCommentsummary objSingleCustomerCommentsummary;
    public static clsCustomerCommentsummary objSingleCustomerCommentCollection;
    public static ObservableCollection<SingleCustomerCommentsummary> SingleCustomerCommentsummaryItemCollection = new ObservableCollection<SingleCustomerCommentsummary>();

    public static ObservableCollection<LandTRelatedDocument> LandTRelatedDocumentSearchedItemCollection = new ObservableCollection<LandTRelatedDocument>();
    public static ObservableCollection<CustomerRelatedDocument> CustomerRelatedDocumentSearchedItemCollection = new ObservableCollection<CustomerRelatedDocument>();

    public static string ErrorFilePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

    public static void ErrHandlerLog(Exception ex)
    {
        try
        {
            string errorFilePath = ErrorFilePath + "/CustomerCommentErrorLog.txt";
            if (!System.IO.File.Exists(errorFilePath))
            {
                dynamic fs = System.IO.File.Create(errorFilePath);
                fs.Close();
                fs.Dispose();
            }
            zipFile(ErrorFilePath, "error.txt");

            using (StreamWriter sw = new StreamWriter(errorFilePath, true))
            {
                try
                {
                    sw.WriteLine("Log Date & time: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss"));

                    sw.WriteLine("Message:" + ex.Message);

                    sw.WriteLine("Type:" + ex.GetType().ToString());
                    if ((ex.StackTrace != null))
                    {
                        sw.WriteLine("Trace: " + ex.StackTrace);
                    }

                    if ((ex.Source != null))
                    {
                        sw.WriteLine("Source: " + ex.Source);
                    }

                    if ((ex.TargetSite != null))
                    {
                        sw.WriteLine("Target: " + ex.TargetSite.ToString());
                    }

                    if ((ex.InnerException != null))
                    {
                        sw.WriteLine("Inner Message:" + ex.InnerException.Message);

                        if ((ex.InnerException.StackTrace != null))
                        {
                            sw.WriteLine("Trace: " + ex.InnerException.StackTrace);
                        }

                        if ((ex.InnerException.Source != null))
                        {
                            sw.WriteLine("Source: " + ex.InnerException.Source);
                        }

                        if ((ex.InnerException.TargetSite != null))
                        {
                            sw.WriteLine("Target: " + ex.InnerException.TargetSite.ToString());
                        }

                    }
                    sw.WriteLine("");
                    sw.WriteLine("");
                }
                catch (Exception)
                {
                    sw.WriteLine("");
                    sw.WriteLine("");
                }

                sw.Close();
            }
        }
        catch (Exception)
        {

        }
    }

    public static void zipFile(string errorFolderPath, string errorFileName)
    {
        try
        {
            dynamic mFileName = errorFolderPath + "\\" + errorFileName;
            System.IO.FileInfo info = new System.IO.FileInfo(mFileName);
            string ZipFileName = "Error_" + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss").Replace("-", "_").Replace(" ", "_").Replace(":", "_") + ".zip";
            if (info.Length >= 1048576)
            {

                Package zip = ZipPackage.Open(errorFolderPath + "\\" + ZipFileName, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);

                //Replace spaces with an underscore (_)
                string uriFileName = mFileName.Replace(" ", "_");

                //A Uri always starts with a forward slash "/"
                string zipUri = string.Concat("/", System.IO.Path.GetFileName(uriFileName));

                Uri partUri = new Uri(zipUri, UriKind.Relative);
                string contentType = System.Net.Mime.MediaTypeNames.Application.Zip;

                //The PackagePart contains the information:
                //Where to extract the file when it's extracted (partUri)
                //The type of content stream (MIME type) - (contentType)
                //The type of compression to use (CompressionOption.Normal)
                PackagePart pkgPart = zip.CreatePart(partUri, contentType, CompressionOption.Normal);

                //Read all of the bytes from the file to add to the zip file
                byte[] bites = System.IO.File.ReadAllBytes(mFileName);

                //Compress and write the bytes to the zip file
                pkgPart.GetStream().Write(bites, 0, bites.Length);

                zip.Close();
                //Close the zip file

                System.IO.File.Delete(mFileName);

                dynamic fs = System.IO.File.Create(mFileName);
                fs.Close();
                fs.Dispose();
            }
        }
        catch (Exception)
        {

        }

    }

    public static string GetUserName(User item)
    {
        string UserName = "";
        try
        {
            if (item.FirstName != null)
            {
                UserName = item.FirstName.Trim();
            }
            if (item.LastName != null)
            {
                if (UserName.Trim() == "")
                {
                    UserName = item.LastName.Trim();
                }
                else
                {
                    UserName = UserName.Trim() + " " + item.LastName.Trim();
                }

                UserName.Trim();
            }

            if (UserName.Trim() == "")
            {
                UserName = item.Name.Trim();
            }
        }
        catch (Exception)
        {

        }

        return UserName;
    }

    public static List<string> GetAllUserList()
    {
        List<string> userList = new List<string> { };

        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllUsers();
            foreach (User item in users)
            {
                userList.Add(clsStaticGlobal.GetUserName(item));
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return userList;
    }

    public static string GetUserNameWithFirstandLast(string _name)
    {
        string UsernamewithFirstandLast = "";
        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            User[] users = clsStaticGlobal.connection.WebServiceManager.AdminService.GetAllUsers();
            foreach (User item in users)
            {
                if (item.LastName.Trim() == "")
                {
                    if ((_name.ToUpper().Trim() == item.Name.ToUpper().Trim()) || (item.FirstName.ToUpper().Trim() == _name.ToUpper().Trim()))
                    {
                        UsernamewithFirstandLast = item.FirstName.Trim();
                        break;
                    }
                    else
                    {
                        string[] CustomerDocs = item.Name.Split(new char[] { '\\' });

                        if (CustomerDocs.Count() > 1)
                        {
                            if (CustomerDocs[1].Trim() == _name.Trim())
                            {
                                UsernamewithFirstandLast = item.FirstName.Trim();
                                break;
                            }
                        }


                    }
                }
                else
                {
                    if ((_name.ToUpper().Trim() == item.Name.ToUpper().Trim()) || (item.FirstName.ToUpper().Trim() + " " + item.LastName.ToUpper().Trim() == _name.ToUpper().Trim()))
                    {
                        UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                        break;
                    }
                    else
                    {

                        string[] CustomerDocs = item.Name.Split(new char[] { '\\' });
                        if (CustomerDocs.Count() > 1)
                        {
                            if (CustomerDocs[1].Trim() == _name.Trim())
                            {
                                UsernamewithFirstandLast = item.FirstName.Trim() + " " + item.LastName.Trim();
                                break;
                            }
                        }

                    }
                }
            }



        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return UsernamewithFirstandLast;
    }

    public static long GetCustomerCommentsLifeCycleStateID()
    {
        long _stateID = -1;

        LfCycDef _ProjectLifeCycleDef = null;
        LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
        foreach (LfCycDef lcDef in lcDefs)
        {
            if (lcDef.DispName.ToUpper() == "PROJECT")
            {
                _ProjectLifeCycleDef = lcDef;
                break;
            }
        }

        if (_ProjectLifeCycleDef != null)
        {
            LfCycDef lifecycleDef = _ProjectLifeCycleDef;
            LfCycState[] states = lifecycleDef.StateArray;

            foreach (LfCycState state in states)
            {
                if ((state.DispName.ToUpper() == "CUSTOMER COMMENTS") || (state.Name.ToUpper() == "CUSTOMER COMMENTS"))
                {
                    _stateID = state.Id;
                    return _stateID;
                }
            }
        }

        return _stateID;
    }

    public static void GetProjectCodes()
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;

            clsStaticGlobal.ProjectCodeItemCollection = new ObservableCollection<ProjectCodes> { };

            long _StateID = clsStaticGlobal.GetCustomerCommentsLifeCycleStateID();
            //
            if (_StateID != -1)
            {
                Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(_rootfolder.Id, false);
                foreach (Autodesk.Connectivity.WebServices.Folder _folder in Recursivefolders)
                {
                    if ((_folder.Cat.CatName.ToUpper() == "PROJECT") && (_folder.LfCyc != null))
                    {
                        if (_StateID == _folder.LfCyc.LfCycStateId)
                        {
                            clsStaticGlobal.ProjectCodeItemCollection.Add(new ProjectCodes() { ProjectCodeName = _folder.Name });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void AllFileStates()
    {
        try
        {
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            LfCycDef lfcycledefCustomer = null;
            foreach (LfCycDef lfcycledef in lcDefs)
            {
                if ((lfcycledef.DispName.ToUpper() == "CUSTOMER COMMENTS") || (lfcycledef.Name.ToUpper() == "CUSTOMER COMMENTS") || (lfcycledef.Name.ToUpper() == "PD_CRAR") || (lfcycledef.DispName.ToUpper() == "PD_CRAR"))
                {
                    lfcycledefCustomer = lfcycledef;
                    break;
                }
            }

            if (lfcycledefCustomer != null)
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                foreach (LfCycState LfCycStateitem in lfcycledefCustomer.StateArray)
                {
                    clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = LfCycStateitem.DispName });
                }
            }
            else
            {
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "All" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Create" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Review" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Approve" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Release" });
                clsStaticGlobal.CommentStatesCollection.Add(new CommentStates() { CommentState = "Obsolete" });
            }



        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static String GetFilePropertyValue(string PropName, long fileID, bool isSystemProp)
    {
        String value = null;

        PropInst[] fileProperties = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { fileID });
        try
        {
            foreach (PropInst prop in fileProperties)
            {
                PropertyDefinition propdef = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitionById(prop.PropDefId);

                if (propdef.IsSystem == isSystemProp)
                {
                    if ((propdef.DisplayName.ToUpper().Trim() == PropName.ToUpper().Trim()) || (propdef.SystemName.ToUpper().Trim() == PropName.ToUpper().Trim()))
                    {
                        if ((prop.Val != null) && (prop.Val.ToString().Trim() != ""))
                        {
                            try
                            {
                                return prop.Val.ToString();
                            }
                            catch (Exception)
                            {

                            }
                        }

                    }
                }

            }
        }
        catch (Exception)
        {

        }


        return value;
    }

    public static void ReleaseObject(object obj)
    {
        try
        {
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            obj = null;
        }
        catch (Exception)
        {

            obj = null;
        }
        finally
        {
            GC.Collect();
        }
    }

    public static string GetPropertyValue(string _VaultfilePath)
    {
        string _RelatedDAD = "";
        try
        {
            PropertyDefinitionDictionary props = clsStaticGlobal.connection.PropertyManager.GetPropertyDefinitions(VDF.Vault.Currency.Entities.EntityClassIds.Files, null, PropertyDefinitionFilter.IncludeAll);
            PropertyDefinition myRelatedDAD = null;
            PropertyDefinition propDef;
            foreach (KeyValuePair<string, Autodesk.DataManagement.Client.Framework.Vault.Currency.Properties.PropertyDefinition> myKeyValPair in props)
            {
                propDef = myKeyValPair.Value;

                if (propDef.DisplayName.ToUpper().Trim() == "RELATED DAD")
                {
                    myRelatedDAD = propDef;
                    break;
                }
            }

            if (myRelatedDAD != null)
            {
                Autodesk.Connectivity.WebServices.File[] SingleFile;
                SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
                if (SingleFile.Length != 0)
                {
                    VDF.Vault.Currency.Entities.FileIteration myFile = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, SingleFile[0]);
                    _RelatedDAD = clsStaticGlobal.connection.PropertyManager.GetPropertyValue(myFile, myRelatedDAD, null).ToString();
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _RelatedDAD;
    }

    public static VDF.Vault.Currency.Entities.Folder GetorCreateCustomerCommentFolder(string SelectedProjectCode)
    {
        try
        {
            Cat[] _Categories = clsStaticGlobal.connection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("FLDR", true);
            Cat _CustomerFolderCategory = null;
            foreach (Cat _cat in _Categories)
            {
                if (_cat.Name.Trim().ToUpper() == "FOLDER")
                {
                    _CustomerFolderCategory = _cat;
                    break;
                }
            }

            VDF.Vault.Currency.Entities.Folder _rootfolder = clsStaticGlobal.connection.FolderManager.RootFolder;
            VDF.Vault.Currency.Entities.Folder _ProjectFolder = null;
            VDF.Vault.Currency.Entities.Folder _CustomerFolder = null;
            VDF.Vault.Currency.Entities.Folder _CustomerByCustomerFolder = null;
            VDF.Vault.Currency.Entities.Folder _CustomerByLandTFolder = null;

            IEnumerable<VDF.Vault.Currency.Entities.Folder> folders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (VDF.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.EntityName == SelectedProjectCode)
                    {
                        _ProjectFolder = folder;
                        clsStaticGlobal.ProjectFolder = folder;
                        break;
                    }
                }
            }

            if (_ProjectFolder != null)
            {
                IEnumerable<VDF.Vault.Currency.Entities.Folder> SubFolders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_ProjectFolder, false, false);
                if (SubFolders != null && SubFolders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in SubFolders)
                    {
                        if (folder.EntityName == CustomerCommentFolderName)
                        {
                            _CustomerFolder = folder;
                            break;
                        }
                    }
                }
            }

            if (_CustomerFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(CustomerCommentFolderName, _ProjectFolder.Id, false, _CustomerFolderCategory.Id);
                _CustomerFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                clsStaticGlobal.VaultCustomerFolder = _CustomerFolder;
            }
            else
            {
                clsStaticGlobal.VaultCustomerFolder = _CustomerFolder;
            }

            if (_CustomerFolder != null)
            {
                IEnumerable<VDF.Vault.Currency.Entities.Folder> SubFolders = clsStaticGlobal.connection.FolderManager.GetChildFolders(_CustomerFolder, false, false);
                if (SubFolders != null && SubFolders.Any())
                {
                    foreach (VDF.Vault.Currency.Entities.Folder folder in SubFolders)
                    {
                        if (folder.EntityName.ToUpper() == CustomerCommentByCustomerFolderName.ToUpper())
                        {
                            _CustomerByCustomerFolder = folder;
                        }
                        else if (folder.EntityName.ToUpper() == CustomerCommentByLandTFolderName.ToUpper())
                        {
                            _CustomerByLandTFolder = folder;
                        }
                        else
                        {

                        }
                    }
                }
            }

            if (_CustomerByCustomerFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(CustomerCommentByCustomerFolderName, _CustomerFolder.Id, false, _CustomerFolderCategory.Id);
                _CustomerByCustomerFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                clsStaticGlobal.VaultCustomerCustomerFolder = _CustomerByCustomerFolder;
            }
            else
            {
                clsStaticGlobal.VaultCustomerCustomerFolder = _CustomerByCustomerFolder;
            }

            if (_CustomerByLandTFolder == null)
            {
                Autodesk.Connectivity.WebServices.Folder _MyFolder = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.AddFolderWithCategory(CustomerCommentByLandTFolderName, _CustomerFolder.Id, false, _CustomerFolderCategory.Id);
                _CustomerByLandTFolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _MyFolder);
                clsStaticGlobal.VaultCustomerLandTFolder = _CustomerByLandTFolder;
            }
            else
            {
                clsStaticGlobal.VaultCustomerLandTFolder = _CustomerByLandTFolder;
            }

            return _CustomerFolder;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return null;
        }

    }

    public static string GetFileNameWithoutExtension(string _filename)
    {
        int fileExtPos = _filename.LastIndexOf(".");
        if (fileExtPos >= 0)
            _filename = _filename.Substring(0, fileExtPos);
        return _filename;
    }

    public static string GetFileExtension(string fileName)
    {
        string ext = string.Empty;
        try
        {
            int fileExtPos = fileName.LastIndexOf(".", StringComparison.Ordinal);
            if (fileExtPos >= 0)
            {
                ext = fileName.Substring(fileExtPos, fileName.Length - fileExtPos);
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return ext;
    }

    public static void DeleteFileFromDirectory(string _DirectoryPath)
    {
        try
        {
            if (Directory.Exists(_DirectoryPath))
            {
                foreach (string file in Directory.GetFiles(_DirectoryPath))
                {
                    System.IO.File.SetAttributes(file, FileAttributes.Normal);
                    System.IO.File.Delete(file);
                }
            }
        }
        catch (Exception ex)
        {
            System.Windows.Forms.MessageBox.Show("Error in deleting files.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void BindingDataSingleWrite(SingleCustomerCommentsummary _objSingleCustomerCommentsummary, string XMLFilePath, bool _IsEdit)
    {
        try
        {
            if (Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode))
            {
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
            }
            else
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + clsStaticGlobal._ProjectCode);
            }

            if (_IsEdit == true)
            {
                CheckoutFile(_objSingleCustomerCommentsummary.CustomerCommentFileName, LocalXMLCustomerCommentFolderPath);
                if (System.IO.File.Exists(XMLFilePath))
                {
                    System.IO.File.SetAttributes(XMLFilePath, FileAttributes.Normal);
                    System.IO.File.Delete(XMLFilePath);
                }
                XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, _objSingleCustomerCommentsummary);
                tw.Close();

                CheckinFile(_objSingleCustomerCommentsummary.CustomerCommentFileName, LocalXMLCustomerCommentFolderPath, _objSingleCustomerCommentsummary.CustomerCommentRemark);
            }
            else
            {
                XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
                TextWriter tw = new StreamWriter(XMLFilePath);
                xs.Serialize(tw, _objSingleCustomerCommentsummary);
                tw.Close();
                AddFileintoVault(clsStaticGlobal.VaultCustomerFolder, XMLFilePath, _objSingleCustomerCommentsummary.CustomerCustomerCommentNumber, _objSingleCustomerCommentsummary.CustomerCommentRemark);
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void AddFileintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _CustomerCommentFolder, string _XMLfilePath, string _CustomerCommentName, string _remark)
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _CustomerCommentFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_XMLfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_XMLfilePath), _remark, DateTime.Now, null, null, FileClassification.None, false, fileStream);
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool UpdateFileProperties(Autodesk.Connectivity.WebServices.File _File, string _FileCategory, string _DisplayName, string _Value)
    {
        bool _Sucess = true;
        try
        {
            List<PropInstParam> propInstParams = new List<PropInstParam>();
            PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

            if (_File.Cat.CatName == _FileCategory)
            {
                PropInst[] source = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertiesByEntityIds("FILE", new long[] { _File.MasterId });

                foreach (PropDef def in clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE"))
                {
                    if (def.IsSys == false & def.IsAct == true)
                    {
                        if (def.DispName == _DisplayName)
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = _DisplayName;
                            propInstParams.Add(propInst);
                            break;
                        }
                    }
                }
            }

            PropInstParamArray propInstParamsArray = new PropInstParamArray();
            propInstParamsArray.Items = propInstParams.ToArray();
            propInstParamsArrays[0] = propInstParamsArray;
            clsStaticGlobal.connection.WebServiceManager.DocumentService.UpdateFileProperties(new long[] { _File.MasterId }, propInstParamsArrays);

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _Sucess;
    }

    public static bool DownloadFile(string _XMLfileName, string _DownloadedPath)
    {
        string _VaultFilePath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + _XMLfileName;
        _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

        bool isSucess = false;
        try
        {
            if (!Directory.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode))
            {
                Directory.CreateDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
            }
            else
            {
                if (System.IO.File.Exists(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName))
                {
                    clsStaticGlobal.DeleteFileFromDirectory(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode + "\\" + _XMLfileName);
                }
            }

            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                VDF.Vault.Currency.Entities.FileIteration fileIter = new FileIteration(clsStaticGlobal.connection, newFile);

                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new VDF.Currency.FolderPathAbsolute(clsStaticGlobal.LocalXMLCustomerCommentFolderPath + "\\" + _ProjectCode);
                settings.AddFileToAcquire(fileIter, VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);
                VDF.Vault.Results.AcquireFilesResults results = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in results.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }
                isSucess = true;
            }
            else
            {
                isSucess = false;
            }


        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            System.Windows.Forms.MessageBox.Show("Error in file download.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        return isSucess;

    }

    public static void CheckoutFile(string _XMLfileName, string _DownloadedPath)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;

            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                //clsStaticGlobal.connection.WorkingFoldersManager.SetWorkingFolder()
                VDF.Vault.Settings.AcquireFilesSettings settings = new VDF.Vault.Settings.AcquireFilesSettings(clsStaticGlobal.connection);
                settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);
                //
                settings.DefaultAcquisitionOption = VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | VDF.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download;

                settings.AddEntityToAcquire(oFileIteration);

                VDF.Vault.Settings.FileRelationshipGatheringSettings fileRelSetting = settings.OptionsRelationshipGathering.FileRelationshipSettings;
                fileRelSetting.IncludeChildren = true;
                fileRelSetting.IncludeParents = false;
                fileRelSetting.IncludeLibraryContents = true;
                settings.AddEntityToAcquire(oFileIteration);
                settings.OptionsResolution.SyncWithRemoteSiteSetting = VDF.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;
                settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

                var m_res = clsStaticGlobal.connection.FileManager.AcquireFiles(settings);

                foreach (var _res in m_res.FileResults)
                {
                    if (_res.Status == VDF.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                    {
                        DownlodFile_Fource(_res.File, clsStaticGlobal.connection, _DownloadedPath);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            System.Windows.Forms.MessageBox.Show("Error in file checkout.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }

    public static void DownlodFile_Fource(VDF.Vault.Currency.Entities.FileIteration file, VDF.Vault.Currency.Connections.Connection connection, string _DownloadedPath)
    {
        try
        {
            //' download individual files to a temp location
            VDF.Vault.Settings.AcquireFilesSettings settings = new Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings(connection);

            settings.LocalPath = new Autodesk.DataManagement.Client.Framework.Currency.FolderPathAbsolute(_DownloadedPath);

            settings.AddFileToAcquire(file, Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Checkout | Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.AcquisitionOption.Download);

            settings.OptionsResolution.SyncWithRemoteSiteSetting = Autodesk.DataManagement.Client.Framework.Vault.Settings.AcquireFilesSettings.SyncWithRemoteSite.Always;

            settings.OptionsResolution.OverwriteOption = VDF.Vault.Settings.AcquireFilesSettings.AcquireFileResolutionOptions.OverwriteOptions.ForceOverwriteAll;

            Autodesk.DataManagement.Client.Framework.Vault.Results.AcquireFilesResults results = connection.FileManager.AcquireFiles(settings);

            foreach (var _res in results.FileResults)
            {
                if (_res.Status == Autodesk.DataManagement.Client.Framework.Vault.Results.FileAcquisitionResult.AcquisitionStatus.Skipped)
                {
                    System.Windows.MessageBox.Show("Unable to Download File : " + Environment.NewLine + _res.File.EntityName + Environment.NewLine + "Download manualy and Resolve Link after Complete.", "Download Vault File", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static void CheckinFile(string _XMLfileName, string _DownloadedPath, string _remark)
    {
        try
        {
            string _VaultFilePath = clsStaticGlobal.VaultCustomerFolder.FullName + "/" + _XMLfileName;
            _DownloadedPath = _DownloadedPath + "\\" + clsStaticGlobal._ProjectCode;
            VDF.Vault.Currency.Entities.FileIteration oFileIteration = null;
            Autodesk.Connectivity.WebServices.File[] file1;
            file1 = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (file1.Length != 0)
            {
                oFileIteration = new VDF.Vault.Currency.Entities.FileIteration(clsStaticGlobal.connection, file1[0]);
            }

            if (oFileIteration != null)
            {
                VDF.Currency.FolderPathAbsolute fldrPath = new VDF.Currency.FolderPathAbsolute(_DownloadedPath);
                string filePath = Path.Combine(fldrPath.ToString(), oFileIteration.EntityName);
                VDF.Currency.FilePathAbsolute filePathAbs = new VDF.Currency.FilePathAbsolute(filePath);

                if (System.IO.File.Exists(filePath))
                {
                    if (oFileIteration.IsCheckedOut == true)
                    {
                        try
                        {
                            clsStaticGlobal.connection.FileManager.CheckinFile(oFileIteration, _remark, false, new Autodesk.Connectivity.WebServices.FileAssocParam[] { }, null, false, null,
                                                           Autodesk.Connectivity.WebServices.FileClassification.None, false, filePathAbs);
                        }
                        catch (Exception ex1)
                        {
                            System.Windows.Forms.MessageBox.Show(ex1.ToString() + ex1.StackTrace);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            System.Windows.Forms.MessageBox.Show("Error in file checkin.", "Customer Comment", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }

    public static void BindingDataMultipleRead(ref clsCustomerCommentsummary objCustomerCommentsCollection, SingleCustomerCommentsummary objSingleCustomerCommentsummary, string _XMLFolderPath, string _ProjectCode)
    {
        try
        {
            List<SingleCustomerCommentsummary> listSingleCustomerCommentsummary = new List<SingleCustomerCommentsummary>();

            clsStaticGlobal.ListCustomerCommentNumbers = new List<int>();
            _XMLFolderPath = _XMLFolderPath + "\\" + _ProjectCode;
            objCustomerCommentsCollection = new clsCustomerCommentsummary();
            XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));
            objSingleCustomerCommentsummary = new SingleCustomerCommentsummary();
            string[] filePaths = Directory.GetFiles(_XMLFolderPath, "*.xml", SearchOption.TopDirectoryOnly);
            foreach (string _filepath in filePaths)
            {
                using (var sr = new StreamReader(_filepath))
                {
                    objSingleCustomerCommentsummary = (SingleCustomerCommentsummary)xs.Deserialize(sr);
                }
                if (objSingleCustomerCommentsummary != null)
                {
                    string _Poststatus = "";
                    string _Postremark = "";
                    string _Postrevision = "";
                    clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(objSingleCustomerCommentsummary.CustomerCommentFileFullPath, out _Poststatus, out _Postremark, out _Postrevision);
                    objSingleCustomerCommentsummary.CustomerCommentLifeCycle = _Poststatus;
                    objSingleCustomerCommentsummary.CustomerCommentRemark = _Postremark;
                    //Debugger.Launch();
                    string currentVersion = "";
                    objSingleCustomerCommentsummary.CustomerCommentHistoryVersions = clsStaticGlobal.GetFileVersions(objSingleCustomerCommentsummary.CustomerCommentFileFullPath, out currentVersion);
                    objSingleCustomerCommentsummary.CustomerCommentLatestVersion = currentVersion;
                    objSingleCustomerCommentsummary.CustomerCommentHistoryVersions.Sort();

                    if (objSingleCustomerCommentsummary.ListCustomerRelatedDocuments.Count > 0)
                    {
                        foreach (CustomerRelatedDocument item in objSingleCustomerCommentsummary.ListCustomerRelatedDocuments)
                        {
                            string _status = "";
                            string _remark = "";
                            string _revision = "";
                            clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                            item.FileStatus = _status;
                            item.FileRemark = _remark;
                            item.FileRevision = _revision;
                            item.IsCheckedCustomerRelatedDocument = false;
                        }
                        //objSingleSurveyorCommentSummary.RelatedDocumentDAD = clsStaticGlobal.GetPropertyValue(objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FilePath);
                    }

                    if (objSingleCustomerCommentsummary.ListLandTRelatedDocuments.Count > 0)
                    {
                        foreach (LandTRelatedDocument item in objSingleCustomerCommentsummary.ListLandTRelatedDocuments)
                        {
                            string _status = "";
                            string _remark = "";
                            string _revision = "";
                            clsStaticGlobal.GetValutFileStatusAndRemarkAndRevision(item.FilePath, out _status, out _remark, out _revision);
                            item.FileStatus = _status;
                            item.FileRemark = _remark;
                            item.FileRevision = _revision;
                            item.IsCheckedLandTRelatedDocument = false;
                        }
                        //objSingleSurveyorCommentSummary.RelatedDocumentDAD = clsStaticGlobal.GetPropertyValue(objSingleSurveyorCommentSummary.ListClassApprovedDrawing[0].FilePath);
                    }

                    clsStaticGlobal.ListCustomerCommentNumbers.Add(objSingleCustomerCommentsummary.CustomerCommentNumber);
                    listSingleCustomerCommentsummary.Add(objSingleCustomerCommentsummary);
                    //objCustomerCommentsCollection.collectionCustomerComment.Add(objSingleCustomerCommentsummary);
                    clsStaticGlobal.ListCustomerCommentNumbers.Sort();
                    clsStaticGlobal.ListCustomerCommentNumbers.Distinct();

                    objCustomerCommentsCollection.collectionCustomerComment = listSingleCustomerCommentsummary.OrderBy(o => o.CustomerCommentNumber).ToList();
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

    }

    public static SingleCustomerCommentsummary BindingDataSingleRead(SingleCustomerCommentsummary objSingleCustomerCommentsummary, string _XMLFilePath)
    {
        objSingleCustomerCommentsummary = new SingleCustomerCommentsummary();

        try
        {
            if (System.IO.File.Exists(_XMLFilePath) == true)
            {
                XmlSerializer xs = new XmlSerializer(typeof(SingleCustomerCommentsummary));

                using (var sr = new StreamReader(_XMLFilePath))
                {
                    objSingleCustomerCommentsummary = (SingleCustomerCommentsummary)xs.Deserialize(sr);
                    return objSingleCustomerCommentsummary;
                }
            }
            else
            {
                return objSingleCustomerCommentsummary;
            }

        }
        catch (Exception ex)
        {
            return objSingleCustomerCommentsummary;
        }

    }

    public static void PrintCustomerRelevantDocumentsFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper() == CustomerCommentByCustomerFolderName.ToUpper())
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if ((file.Cat.CatName.Equals("DOCUMENT", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("CORRESPONDENCE", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("EMAIL", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("SHBD DESIGN DOCUMENT", StringComparison.OrdinalIgnoreCase)))
                            {
                                clsStaticGlobal.RelevantDocByCustomerFiles.Add(file);
                            }
                            else
                            {
                                if (file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase))
                                {
                                    clsStaticGlobal.RelevantDocByCustomerFiles.Add(file);
                                }
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintCustomerRelevantDocumentsFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintCustomerRelevantDocumentsFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }


    }

    public static void RecursivePrintCustomerRelevantDocumentsFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if ((file.Cat.CatName.Equals("DOCUMENT", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("CORRESPONDENCE", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("EMAIL", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("SHBD DESIGN DOCUMENT", StringComparison.OrdinalIgnoreCase)))
                    {
                        clsStaticGlobal.RelevantDocByCustomerFiles.Add(file);
                    }
                    else
                    {
                        if (file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase))
                        {
                            clsStaticGlobal.RelevantDocByCustomerFiles.Add(file);
                        }
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintCustomerRelevantDocumentsFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void PrintLandTRelatedDocumentFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            if (IsFolderFound == false)
            {
                if (parentFolder.Name.ToUpper() == CustomerCommentByLandTFolderName.ToUpper())
                {
                    IsFolderFound = true;
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
                    if (files != null && files.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.File file in files)
                        {
                            if ((file.Cat.CatName.Equals("DOCUMENT", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("CORRESPONDENCE", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("EMAIL", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("SHBD DESIGN DOCUMENT", StringComparison.OrdinalIgnoreCase)))
                            {
                                clsStaticGlobal.RelatedDocByLandTFiles.Add(file);
                            }
                            else
                            {
                                if (file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase))
                                {
                                    clsStaticGlobal.RelatedDocByLandTFiles.Add(file);
                                }
                            }
                        }
                    }

                    Autodesk.Connectivity.WebServices.Folder[] Recursivefolders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                    if (Recursivefolders != null && Recursivefolders.Length > 0)
                    {
                        foreach (Autodesk.Connectivity.WebServices.Folder folder in Recursivefolders)
                        {
                            RecursivePrintLandTRelatedDocumentsFilesInFolder(folder, serviceManager, IsFolderFound);
                        }
                    }
                }

                Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
                if (folders != null && folders.Length > 0)
                {
                    foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                    {
                        PrintLandTRelatedDocumentFilesInFolder(folder, serviceManager, IsFolderFound);
                    }
                }

            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void RecursivePrintLandTRelatedDocumentsFilesInFolder(Autodesk.Connectivity.WebServices.Folder parentFolder, WebServiceManager serviceManager, bool IsFolderFound)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if ((file.Cat.CatName.Equals("DOCUMENT", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("CORRESPONDENCE", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("EMAIL", StringComparison.OrdinalIgnoreCase)) || (file.Cat.CatName.Equals("SHBD DESIGN DOCUMENT", StringComparison.OrdinalIgnoreCase)))
                    {
                        clsStaticGlobal.RelatedDocByLandTFiles.Add(file);
                    }
                    else
                    {
                        if (file.FileLfCyc.LfCycStateName.Equals("RELEASE", StringComparison.OrdinalIgnoreCase))
                        {
                            clsStaticGlobal.RelatedDocByLandTFiles.Add(file);
                        }
                    }
                }
            }

            Autodesk.Connectivity.WebServices.Folder[] folders = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFoldersByParentId(parentFolder.Id, false);
            if (folders != null && folders.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.Folder folder in folders)
                {
                    RecursivePrintLandTRelatedDocumentsFilesInFolder(folder, serviceManager, IsFolderFound);
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static bool AddReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _CustomerCommentReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            VDF.Vault.Currency.Entities.Folder myfolder = new VDF.Vault.Currency.Entities.Folder(clsStaticGlobal.connection, _CustomerCommentReferenceDocFolder);
            VDF.Vault.Currency.Entities.FileIteration myFile = null;
            Stream fileStream = new FileStream(_LocalfilePath, FileMode.Open, FileAccess.Read);
            myFile = clsStaticGlobal.connection.FileManager.AddFile(myfolder, Path.GetFileName(_LocalfilePath), Path.GetFileName(_LocalfilePath), DateTime.Now, null, null, FileClassification.None, false, fileStream);
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static bool DeleteReferenceDocintoVault(Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _CustomerCommentReferenceDocFolder, string _LocalfilePath)
    {
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(_CustomerCommentReferenceDocFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (_CustomerCommentReferenceDocFolder.FullName + "/" + file.Name == _LocalfilePath)
                    {
                        clsStaticGlobal.connection.WebServiceManager.DocumentService.DeleteFileFromFolder(file.MasterId, _CustomerCommentReferenceDocFolder.Id);
                        return true;
                    }
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static string GetClassApprovedDrawingStatus(string _VaultfilePath)
    {
        string _DrawingStatus = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _DrawingStatus = SingleFile[0].FileLfCyc.LfCycStateName;
            }
            return _DrawingStatus;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _DrawingStatus;
        }
    }

    public static void GetFileStateAndRemark(string _VaultfilePath, out string state, out string remark)
    {
        state = "";
        remark = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                state = SingleFile[0].FileLfCyc.LfCycStateName;
                remark = SingleFile[0].Comm;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static string GetClassApprovedDrawingRevision(string _VaultfilePath)
    {
        string _DrawingRevison = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                _DrawingRevison = SingleFile[0].FileRev.Label.ToString();
            }
            return _DrawingRevison;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _DrawingRevison;
        }
    }

    public static List<int> GetFileVersions(string _VaultfilePath, out string currentVersion)
    {
        currentVersion = "1";

        List<int> _FileVersionList = new List<int> { };
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };

            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });

            if (SingleFile.Length != 0)
            {
                currentVersion = SingleFile[0].VerNum.ToString();
                _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFilesByMasterId(SingleFile[0].MasterId);

            }
            Dictionary<string, List<int>> DisctRevAndVersions = new Dictionary<string, List<int>> { };

            foreach (Autodesk.Connectivity.WebServices.File item in _LatestFileswithVersions)
            {
                _FileVersionList.Add(item.VerNum);
            }
            return _FileVersionList;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return _FileVersionList;
        }
    }

    public static Dictionary<string, List<int>> GetFileRevisionwithVersions(string _VaultfilePath)
    {
        Dictionary<string, List<int>> revisionwithVersions = new Dictionary<string, List<int>> { };

        List<int> _FileVersionList = new List<int> { };

        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };

            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });

            if (SingleFile.Length != 0)
            {
                _LatestFileswithVersions = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFilesByMasterId(SingleFile[0].MasterId);
            }

            foreach (Autodesk.Connectivity.WebServices.File item in _LatestFileswithVersions)
            {
                if (item.FileRev.Label != null)
                {
                    if (revisionwithVersions.ContainsKey(item.FileRev.Label.ToString()))
                    {
                        List<int> oldFileVers = new List<int> { };
                        oldFileVers = revisionwithVersions[item.FileRev.Label.ToString()];
                        oldFileVers.Add(item.VerNum);
                        revisionwithVersions[item.FileRev.Label.ToString()] = oldFileVers;
                    }
                    else
                    {
                        List<int> newFilVersions = new List<int> { };
                        newFilVersions.Add(item.VerNum);
                        revisionwithVersions.Add(item.FileRev.Label.ToString(), newFilVersions);
                    }
                }

                _FileVersionList.Add(item.VerNum);
            }
            return revisionwithVersions;
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return revisionwithVersions;
        }
    }

    public static bool IsFileCheckedOut(string _VaultfilePath, out string username)
    {
        username = "";

        List<int> _FileVersionList = new List<int> { };
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            Autodesk.Connectivity.WebServices.File[] _LatestFileswithVersions = new Autodesk.Connectivity.WebServices.File[] { };

            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                try
                {
                    if (SingleFile[0].CheckedOut == true)
                    {
                        long userid = SingleFile[0].CkOutUserId;

                        UserInfo userinfo = clsStaticGlobal.connection.WebServiceManager.AdminService.GetUserInfoByUserId(userid);
                        //if (userinfo.User.FirstName.Trim() == "")
                        //{
                        //    username = userinfo.User.FirstName.Trim();
                        //}
                        //else
                        //{
                        //    username = userinfo.User.FirstName.Trim() + " " + userinfo.User.LastName.Trim();
                        //}
                        username = clsStaticGlobal.GetUserName(userinfo.User);

                    }
                }
                catch (Exception)
                {

                }

                return SingleFile[0].CheckedOut;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            return false;
        }
    }

    public static Autodesk.Connectivity.WebServices.File IsFileExistintoVault(Autodesk.Connectivity.WebServices.Folder parentFolder, string _Vaultfilename)
    {
        Autodesk.Connectivity.WebServices.File _file = null;
        try
        {
            Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetLatestFilesByFolderId(parentFolder.Id, false);
            if (files != null && files.Length > 0)
            {
                foreach (Autodesk.Connectivity.WebServices.File file in files)
                {
                    if (file.Name.ToUpper().Trim() == _Vaultfilename.ToUpper().Trim())
                    {
                        _file = file;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _file;
    }

    public static bool UpdateFileRemark(SingleCustomerCommentsummary _objSingleCustomerCommentsummary)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _objSingleCustomerCommentsummary.CustomerCommentFileFullPath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _objSingleCustomerCommentsummary.CustomerCommentRemark);
                newFile = files[0];
                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }

        return _IsSuccess;
    }

    public static void DisposeAllObjects()
    {
        try
        {
            IsReadOnly = false;
            IsFilter = false;

            clsStaticGlobal.VaultCustomerFolder = null;
            clsStaticGlobal.VaultCustomerLandTFolder = null;
            clsStaticGlobal.VaultCustomerCustomerFolder = null;
            clsStaticGlobal.ProjectFolder = null;
            clsStaticGlobal.RelevantDocByCustomerFiles = null;
            clsStaticGlobal.RelatedDocByLandTFiles = null;
            clsStaticGlobal.ListCustomerCommentNumbers = new List<int> { };

            clsStaticGlobal.ProjectCodeItemCollection = new ObservableCollection<ProjectCodes>();
            clsStaticGlobal.CommentStatesCollection = new ObservableCollection<CommentStates>();
            clsStaticGlobal.objSingleCustomerCommentsummary = null;
            clsStaticGlobal.objSingleCustomerCommentCollection = null;
            clsStaticGlobal.SingleCustomerCommentsummaryItemCollection = new ObservableCollection<SingleCustomerCommentsummary>();

            clsStaticGlobal.LandTRelatedDocumentSearchedItemCollection = new ObservableCollection<LandTRelatedDocument>();
            clsStaticGlobal.CustomerRelatedDocumentSearchedItemCollection = new ObservableCollection<CustomerRelatedDocument>();

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    #region Global Function

    public static bool VaultFileCommentUpdate(string _VaultFilePath, string _NewComment)
    {
        bool _IsSuccess = false;
        try
        {
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                //Debugger.Launch();
                newFile = SingleFiles[0];
                Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                new long[] { newFile.MasterId }, new long[] { newFile.FileLfCyc.LfCycStateId }, _NewComment);

                _IsSuccess = true;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static bool VaultFileChangeStateAndComment(string _VaultFilePath, string _StateName, string _Comment)
    {
        bool _IsSuccess = false;
        try
        {

            long _stateID = -1;

            LfCycDef _CustomerCommentsLifeCycleDef = null;
            LfCycDef[] lcDefs = clsStaticGlobal.connection.WebServiceManager.LifeCycleService.GetAllLifeCycleDefinitions();
            foreach (LfCycDef lcDef in lcDefs)
            {
                if ((lcDef.DispName.ToUpper() == "CUSTOMER COMMENTS") || (lcDef.Name.ToUpper() == "CUSTOMER COMMENTS"))
                {
                    _CustomerCommentsLifeCycleDef = lcDef;
                    break;
                }
            }

            if (_CustomerCommentsLifeCycleDef != null)
            {
                LfCycDef lifecycleDef = _CustomerCommentsLifeCycleDef;
                LfCycState[] states = lifecycleDef.StateArray;

                foreach (LfCycState state in states)
                {
                    if ((state.DispName.ToUpper() == _StateName.ToUpper()) || (state.Name.ToUpper() == _StateName.ToUpper()))
                    {
                        _stateID = state.Id;
                        break;
                    }
                }
            }
            if (_stateID != -1)
            {
                Autodesk.Connectivity.WebServices.File newFile = null;
                Autodesk.Connectivity.WebServices.File[] SingleFiles;
                SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
                if (SingleFiles.Length != 0)
                {
                    newFile = SingleFiles[0];
                    Autodesk.Connectivity.WebServices.File[] files = clsStaticGlobal.connection.WebServiceManager.DocumentServiceExtensions.UpdateFileLifeCycleStates(
                    new long[] { newFile.MasterId }, new long[] { _stateID }, _Comment);
                    newFile = files[0];
                    _IsSuccess = true;


                }
            }

        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
        return _IsSuccess;
    }

    public static void VaultFileGetStateAndComment(string _VaultFilePath, out string _StateName, out string _Comment)
    {
        _StateName = "";
        _Comment = "";
        try
        {
            //Debugger.Launch();
            Autodesk.Connectivity.WebServices.File newFile = null;
            Autodesk.Connectivity.WebServices.File[] SingleFiles;
            SingleFiles = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultFilePath });
            if (SingleFiles.Length != 0)
            {
                newFile = SingleFiles[0];
                _StateName = newFile.FileLfCyc.LfCycStateName;
                _Comment = newFile.Comm;
                // System.Windows.MessageBox.Show("Hi");
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void GetValutFileStatusAndRemarkAndRevision(string _VaultfilePath, out string _Status, out string _Remark, out string _Revision)
    {
        _Status = "";
        _Remark = "";
        _Revision = "";

        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                if (SingleFile[0].Id != -1)
                {
                    _Status = SingleFile[0].FileLfCyc.LfCycStateName;
                    _Remark = SingleFile[0].Comm;
                    _Revision = SingleFile[0].FileRev.Label.ToString(); ;
                }
                else
                {
                    _Remark = "File not available in Vault.";
                }
            }
            else
            {
                _Remark = "File not available in Vault.";
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
            _Remark = "File not available in Vault.";
        }
    }

    public static void GetValutFileStatus(string _VaultfilePath, out string status)
    {
        status = "";
        try
        {
            Autodesk.Connectivity.WebServices.File[] SingleFile;
            SingleFile = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindLatestFilesByPaths(new string[] { _VaultfilePath });
            if (SingleFile.Length != 0)
            {
                status = SingleFile[0].FileLfCyc.LfCycStateName;
            }
        }
        catch (Exception ex)
        {
            clsStaticGlobal.ErrHandlerLog(ex);
        }
    }

    public static void FindFileByFileName(Autodesk.Connectivity.WebServices.Folder folder, string filename)
    {
        // C#
        PropDef[] filePropDefs = clsStaticGlobal.connection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId("FILE");
        PropDef filenamePropdef = filePropDefs.Single(n => n.SysName == "ClientFileName");


        SrchCond srchfileByfilename = new SrchCond()
        {
            PropDefId = filenamePropdef.Id,
            PropTyp = PropertySearchType.SingleProperty,
            SrchOper = 3, // is not empty
            SrchRule = SearchRuleType.Must,
            SrchTxt = "File1.txt"
        };

        string bookmark = string.Empty;
        SrchStatus status = null;
        List<Autodesk.Connectivity.WebServices.File> totalResults = new List<Autodesk.Connectivity.WebServices.File>();
        while (status == null || totalResults.Count < status.TotalHits)
        {
            Autodesk.Connectivity.WebServices.File[] results = clsStaticGlobal.connection.WebServiceManager.DocumentService.FindFilesBySearchConditions(
                new SrchCond[] { srchfileByfilename },
                null, new long[] { folder.Id }, false, true, ref bookmark, out status);

            if (results != null)
                totalResults.AddRange(results);
            else
                break;
        }

    }

    #endregion



}
