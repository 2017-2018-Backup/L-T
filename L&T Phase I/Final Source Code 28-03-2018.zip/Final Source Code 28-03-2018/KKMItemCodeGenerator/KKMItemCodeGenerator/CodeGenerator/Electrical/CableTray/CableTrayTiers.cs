﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTrayTiers : ObservableCollection<NameCodePair>
    {
        public static CableTrayTiers LoadList()
        {
            CableTrayTiers items = new CableTrayTiers();
            items.Add(new NameCodePair() { Code = "01", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "02", Name = "SINGLE TIER" });
            items.Add(new NameCodePair() { Code = "03", Name = "DOUBLE TIER" });
            items.Add(new NameCodePair() { Code = "04", Name = "THREE TIER" });

            return items;
        }
        public static CableTrayTiers LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTrayTiers LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTrayTiers>(ElectricalItems.DataPath + @"\CableTray\CableTrayTiers.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTrayTiers>(this, ElectricalItems.DataPath + @"\CableTray\CableTrayTiers.xml");
        }

    }
}
