﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingSeaFlangeSubTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingSeaFlangeSubTypes LoadList()
        {
            PipeFittingSeaFlangeSubTypes items = new PipeFittingSeaFlangeSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "SAE FLANGE" });
            return items;
        }
        public static PipeFittingSeaFlangeSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingSeaFlangeSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingSeaFlangeSubTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSeaFlangeSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingSeaFlangeSubTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingSeaFlangeSubTypes.xml");
        }

    }
}
