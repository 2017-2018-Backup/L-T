﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ElectricalItems : ObservableCollection<NameCodePair>
    {
        public static String DataPath = "";
        public static ElectricalItems LoadList()
        {
            ElectricalItems items = new ElectricalItems();
            items.Add(new NameCodePair() { Code = "CT", Name = "CABLE TRAY" });
            items.Add(new NameCodePair() { Code = "CA", Name = "CABLES" });
            items.Add(new NameCodePair() { Code = "CL", Name = "CABLE TERMINALS LUGS" });
            items.Add(new NameCodePair() { Code = "CG", Name = "CABLE GLANDS" });
            items.Add(new NameCodePair() { Code = "RS", Name = "RECEPTACLES" });

            return items;
        }
        public static ElectricalItems LoadFromExcel(String path)
        {
            return null;
        }

        public static ElectricalItems LoadFromXml(string path)
        {
            ElectricalItems.DataPath = path + @"\Electrical";
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ElectricalItems>(ElectricalItems.DataPath + @"\ElectricalItems.xml");
        }

        public void ExportToXml(string path)
        {
            ElectricalItems.DataPath = path + @"\Electrical";
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath);
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ElectricalItems>(this, ElectricalItems.DataPath + @"\ElectricalItems.xml");
        }

    }
}
