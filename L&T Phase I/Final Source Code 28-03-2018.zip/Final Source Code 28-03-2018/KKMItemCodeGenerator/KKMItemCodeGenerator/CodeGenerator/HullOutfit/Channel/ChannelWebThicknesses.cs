﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelWebThicknesses : ObservableCollection<NameCodePair>
    {
        public static ChannelWebThicknesses LoadList()
        {
            ChannelWebThicknesses items = new ChannelWebThicknesses();
            items.Add(new NameCodePair() { Code = "04H", Name = "4.8 mm" });
            items.Add(new NameCodePair() { Code = "005", Name = "5.0 mm" });
            items.Add(new NameCodePair() { Code = "05C", Name = "5.3 mm" });
            items.Add(new NameCodePair() { Code = "05G", Name = "5.7 mm" });
            items.Add(new NameCodePair() { Code = "006", Name = "6.0 mm" });
            items.Add(new NameCodePair() { Code = "06B", Name = "6.2 mm" });
            items.Add(new NameCodePair() { Code = "06E", Name = "6.5 mm" });
            items.Add(new NameCodePair() { Code = "07B", Name = "7.2 mm" });
            items.Add(new NameCodePair() { Code = "07E", Name = "7.5 mm" });
            items.Add(new NameCodePair() { Code = "07H", Name = "7.8 mm" });
            items.Add(new NameCodePair() { Code = "08C", Name = "8.3 mm" });
            items.Add(new NameCodePair() { Code = "08H", Name = "8.8 mm" });
            items.Add(new NameCodePair() { Code = "009", Name = "9.0 mm" });
            items.Add(new NameCodePair() { Code = "010", Name = "10.0 mm" });
            items.Add(new NameCodePair() { Code = "011", Name = "11.0 mm" });
            items.Add(new NameCodePair() { Code = "012", Name = "12.0 mm" });

            return items;
        }
        public static ChannelWebThicknesses LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelWebThicknesses LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelWebThicknesses>(HullOutfitItems.DataPath + @"\Channel\ChannelThicknesses.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelWebThicknesses>(this, HullOutfitItems.DataPath + @"\Channel\ChannelThicknesses.xml");
        }
    }
}
