﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveTrims : ObservableCollection<NameCodePair>
    {
        public static ValveTrims LoadList()
        {
            ValveTrims items = new ValveTrims();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "BRASS" });
            items.Add(new NameCodePair() { Code = "02", Name = "BRONZE" });
            items.Add(new NameCodePair() { Code = "03", Name = "GUN METAL" });
            items.Add(new NameCodePair() { Code = "04", Name = "STAINLESS STEEL 316" });
            items.Add(new NameCodePair() { Code = "05", Name = "ALUMINIUM-BRONZE" });
            items.Add(new NameCodePair() { Code = "06", Name = "CAST-STEEL" });
            items.Add(new NameCodePair() { Code = "07", Name = "BRONZE RG5" });
            items.Add(new NameCodePair() { Code = "08", Name = "FORGED-STEEL" });
            items.Add(new NameCodePair() { Code = "09", Name = "SS 304L" });
            items.Add(new NameCodePair() { Code = "10", Name = "NAB (NES 747 Part II)" });
            items.Add(new NameCodePair() { Code = "11", Name = "GM TO BS1400LG4C" });
            items.Add(new NameCodePair() { Code = "12", Name = "PRECISION STEEL" });
            items.Add(new NameCodePair() { Code = "13", Name = "POLYETHYLENE" });
            items.Add(new NameCodePair() { Code = "14", Name = "AA 6082 T5" });
            return items;
        }
        public static ValveTrims LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveTrims LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveTrims>(EngineeringItems.DataPath + @"\Valves\ValveTrims.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveTrims>(this, EngineeringItems.DataPath + @"\Valves\ValveTrims.xml");
        }

    }
}
