﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersClassSocietys : ObservableCollection<NameCodePair>
    {
        public static StrainersClassSocietys LoadList()
        {
            StrainersClassSocietys items = new StrainersClassSocietys();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "A", Name = "GL" });
            items.Add(new NameCodePair() { Code = "B", Name = "LR" });
            items.Add(new NameCodePair() { Code = "C", Name = "EX-PROOF" });
            items.Add(new NameCodePair() { Code = "D", Name = "FIRE-SAFE" });
            items.Add(new NameCodePair() { Code = "E", Name = "ABS" });
            return items;
        }
        public static StrainersClassSocietys LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersClassSocietys LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersClassSocietys>(EngineeringItems.DataPath + @"\Strainers\StrainersClassSocietys.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersClassSocietys>(this, EngineeringItems.DataPath + @"\Strainers\StrainersClassSocietys.xml");
        }

    }
}
