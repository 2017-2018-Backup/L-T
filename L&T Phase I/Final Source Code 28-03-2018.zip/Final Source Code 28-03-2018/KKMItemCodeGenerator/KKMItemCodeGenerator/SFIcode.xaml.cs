﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KKMItemCodeGenerator
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class SFIcode : Window
    {
        SFIcodes _SFIcodes;
        public string SFIcodenumber = "";
        public string SFIcodeDesc = "";
        public System.Windows.Forms.DialogResult _DialogResult = System.Windows.Forms.DialogResult.Cancel;
        public SFIcode()
        {
            InitializeComponent();

            _SFIcodes = SFIcodes.LoadFromXml(clsStaticGlobal.BuildFilePath + @"\Data");
          
            SFIcodeSearchGridViewBox.ItemsSource = _SFIcodes;
            CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(SFIcodeSearchGridViewBox.ItemsSource);
            viewSearch.Filter = UserFilter;
            SFIcodeSearchGridViewBox.UpdateLayout();
            
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            { return true; }

            else

            {
                //ClassApprovedDrawing itemitem = (ClassApprovedDrawing)item;

                //if (itemitem.FileName.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
                return ((item as NameCodePair).Code.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as NameCodePair).Name.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            // return ((item as ClassApprovedDrawing).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            // return ((item as ClassApprovedDrawing).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ClassApprovedDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(SFIcodeSearchGridViewBox.ItemsSource).Refresh();
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            SFIcodenumber = "";
            SFIcodeDesc = "";
            _DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            _DialogResult = System.Windows.Forms.DialogResult.OK;

            if (SFIcodeSearchGridViewBox.SelectedItems.Count > 0)
            {
                foreach (var item in SFIcodeSearchGridViewBox.SelectedItems)
                {
                    SFIcodenumber = ((NameCodePair)item).Code;
                    SFIcodeDesc =((NameCodePair)item).Name;
                }
                this.Close();
            }
            else
            {
                SFIcodenumber = "";
                SFIcodeDesc = "";
            }
            
        }
    }
}
