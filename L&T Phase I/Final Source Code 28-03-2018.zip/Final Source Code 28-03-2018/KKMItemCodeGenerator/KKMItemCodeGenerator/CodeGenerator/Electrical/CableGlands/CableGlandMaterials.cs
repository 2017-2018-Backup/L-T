﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableGlandMaterials : ObservableCollection<NameCodePair>
    {
        public static CableGlandMaterials LoadList()
        {
            CableGlandMaterials items = new CableGlandMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "BRASS" });
            items.Add(new NameCodePair() { Code = "02", Name = "COPPER" });
            items.Add(new NameCodePair() { Code = "03", Name = "MS" });
            items.Add(new NameCodePair() { Code = "04", Name = "PVC" });
            items.Add(new NameCodePair() { Code = "05", Name = "NA" });

            return items;
        }
        public static CableGlandMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static CableGlandMaterials LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableGlandMaterials>(ElectricalItems.DataPath + @"\CableGland\CableGlandMaterials.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableGlandMaterials>(this, ElectricalItems.DataPath + @"\CableGland\CableGlandMaterials.xml");
        }

    }
}
