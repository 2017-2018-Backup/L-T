﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BarsPlateProfileMaterials : ObservableCollection<NameCodePair>
    {
        public static BarsPlateProfileMaterials LoadList()
        {
            BarsPlateProfileMaterials items = new BarsPlateProfileMaterials();
            items.Add(new NameCodePair() { Code = "01", Name = "A" });
            items.Add(new NameCodePair() { Code = "02", Name = "AH32" });
            items.Add(new NameCodePair() { Code = "03", Name = "AH36" });
            items.Add(new NameCodePair() { Code = "04", Name = "AH40" });
            items.Add(new NameCodePair() { Code = "05", Name = "D" });
            items.Add(new NameCodePair() { Code = "06", Name = "DH32" });
            items.Add(new NameCodePair() { Code = "07", Name = "DH36" });
            items.Add(new NameCodePair() { Code = "08", Name = "DH40" });
            items.Add(new NameCodePair() { Code = "09", Name = "E" });
            items.Add(new NameCodePair() { Code = "10", Name = "EH32" });
            items.Add(new NameCodePair() { Code = "11", Name = "EH36" });
            items.Add(new NameCodePair() { Code = "12", Name = "EH40" });
            items.Add(new NameCodePair() { Code = "13", Name = "B" });
            items.Add(new NameCodePair() { Code = "14", Name = "IS2062 GRA" });
            items.Add(new NameCodePair() { Code = "15", Name = "GALV IS 2062 GR A" });
            items.Add(new NameCodePair() { Code = "16", Name = "IS2062GRB" });
            items.Add(new NameCodePair() { Code = "17", Name = "SS304" });
            items.Add(new NameCodePair() { Code = "18", Name = "SS310" });
            items.Add(new NameCodePair() { Code = "19", Name = "SS316" });
            items.Add(new NameCodePair() { Code = "20", Name = "SS316L" });
            items.Add(new NameCodePair() { Code = "21", Name = "AISI316" });
            items.Add(new NameCodePair() { Code = "22", Name = "AISI316L" });
            items.Add(new NameCodePair() { Code = "23", Name = "AISI410" });
            items.Add(new NameCodePair() { Code = "24", Name = "AH 36 Z 25" });
            items.Add(new NameCodePair() { Code = "25", Name = "DH 36 Z 25" });
            items.Add(new NameCodePair() { Code = "26", Name = "EH 36 Z 25" });
            items.Add(new NameCodePair() { Code = "27", Name = "DH36+EN10164-Z25" });
            items.Add(new NameCodePair() { Code = "28", Name = "A Z 25" });
            items.Add(new NameCodePair() { Code = "29", Name = "S355J2G3" });
            items.Add(new NameCodePair() { Code = "30", Name = "S355J2G4" });
            items.Add(new NameCodePair() { Code = "31", Name = "S355J2+N" });
            items.Add(new NameCodePair() { Code = "32", Name = "S690 QL" });
            items.Add(new NameCodePair() { Code = "33", Name = "42 CR MO 4 V" });
            items.Add(new NameCodePair() { Code = "34", Name = "WELDOX 700" });
            items.Add(new NameCodePair() { Code = "35", Name = "MTL57" });
            items.Add(new NameCodePair() { Code = "36", Name = "ST52 – 3 N" });
            items.Add(new NameCodePair() { Code = "37", Name = "ASTM A 105/53 GRADE B" });
            items.Add(new NameCodePair() { Code = "38", Name = "GALVANISED IRON" });
            items.Add(new NameCodePair() { Code = "39", Name = "Hardened Steel Gr 4.4" });
            items.Add(new NameCodePair() { Code = "40", Name = "Hardened Steel Gr 6.6" });
            items.Add(new NameCodePair() { Code = "41", Name = "Hardened Steel Gr 8.8" });
            items.Add(new NameCodePair() { Code = "42", Name = "Hardened Steel Gr 10.9" });
            items.Add(new NameCodePair() { Code = "43", Name = "Hardened Steel Gr 12.9" });
            items.Add(new NameCodePair() { Code = "44", Name = "Aluminium" });
            items.Add(new NameCodePair() { Code = "45", Name = "ASTM A516 GR 70" });
            items.Add(new NameCodePair() { Code = "46", Name = "SU 304L" });
            items.Add(new NameCodePair() { Code = "47", Name = "AA 5083 H116" });
            items.Add(new NameCodePair() { Code = "48", Name = "AA 6082" });
            items.Add(new NameCodePair() { Code = "49", Name = "MTL 07" });
            items.Add(new NameCodePair() { Code = "50", Name = "MTL 10" });
            items.Add(new NameCodePair() { Code = "51", Name = "MTL 12" });
            items.Add(new NameCodePair() { Code = "52", Name = "MTL 35" });
            items.Add(new NameCodePair() { Code = "53", Name = "S355J2" });
            items.Add(new NameCodePair() { Code = "54", Name = "ASME SA 105N-07" });
            items.Add(new NameCodePair() { Code = "55", Name = "DMR 249 A" });
            items.Add(new NameCodePair() { Code = "56", Name = "ASTM A 27 Gr 65-35 Class 1" });
            //items.Add(new NameCodePair() { Code = "57", Name = "IS2062 E250A" });
            return items;
        }
        public static BarsPlateProfileMaterials LoadFromExcel(String path)
        {
            return null;
        }

        public static BarsPlateProfileMaterials LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BarsPlateProfileMaterials>(HullItems.HullDataPath + @"\Bars\BarsPlateProfileMaterials.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BarsPlateProfileMaterials>(this, HullItems.HullDataPath + @"\Bars\BarsPlateProfileMaterials.xml");
        }
    }
}
