﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableTypes : ObservableCollection<NameCodePair>
    {
        public static CableTypes LoadList()
        {
            CableTypes items = new CableTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "CABLES POWER" });
            items.Add(new NameCodePair() { Code = "02", Name = "CABLES CONTROL" });
            items.Add(new NameCodePair() { Code = "03", Name = "DATA & SIGNAL CABLE" });

            return items;
        }
        public static CableTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableTypes>(ElectricalItems.DataPath + @"\Cable\CableTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(ElectricalItems.DataPath + @"\Cable"))
            {
                System.IO.Directory.CreateDirectory(ElectricalItems.DataPath + @"\Cable");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableTypes>(this, ElectricalItems.DataPath + @"\Cable\CableTypes.xml");
        }

    }
}
