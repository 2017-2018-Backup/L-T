﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class SupportsRatings : ObservableCollection<NameCodePair>
    {
        public static SupportsRatings LoadList()
        {
            SupportsRatings items = new SupportsRatings();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "LIGHT" });
            items.Add(new NameCodePair() { Code = "02", Name = "STANDARD" });
            items.Add(new NameCodePair() { Code = "03", Name = "HEAVY" });
            return items;
        }
        public static SupportsRatings LoadFromExcel(String path)
        {
            return null;
        }

        public static SupportsRatings LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<SupportsRatings>(EngineeringItems.DataPath + @"\Supports\SupportsRatings.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Supports"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Supports");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<SupportsRatings>(this, EngineeringItems.DataPath + @"\Supports\SupportsRatings.xml");
        }

    }
}
