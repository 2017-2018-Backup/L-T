﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;
using KKMBuildSpecification;
using System.Diagnostics;

namespace KKMBuildSpecification
{
    /// <summary>
    /// Interaction logic for UserControlProductionDrawing.xaml
    /// </summary>
    public partial class UserControlProductionDrawing : Window
    {
        public List<MasterDrawingFile> ExcelProductionList { get; set; }
        String SFIcode = "";
        public UserControlProductionDrawing(List<MasterDrawingFile> _ExcelProductionList, string _SFIcode)
        {
            InitializeComponent();
            ExcelProductionList = _ExcelProductionList;
            SFIcode = _SFIcode;
            try
            {
                clsStaticGlobal.ProductionDrawingSearchedItemCollection.Clear();
                int SearchedCount = 1;
                foreach (MasterDrawingFile _item in ExcelProductionList)
                {
                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.DocumentNumber, "PRODUCTION DOCUMENT", clsStaticGlobal.ProjectFolder);
                    if ((_SearchedFile != null) && (_SearchedFile.Id != -1))
                    {
                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;

                        string fileDec = _item.DocumentDescription;

                        string fileSFI = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                        if (fileSFI == null)
                        {
                            fileSFI = "";
                        }

                        string fileElement = clsStaticGlobal.GetFilePropertyValue("Element", _SearchedFile.Id, false);
                        if (fileElement == null)
                        {
                            fileElement = "";
                        }
                        string filesfi = clsStaticGlobal.GetFilePropertyValue("SFI", _SearchedFile.Id, false);
                        if (filesfi == null)
                        {
                            filesfi = "";
                        }
                        string fileRelevantClassApproved = clsStaticGlobal.GetFilePropertyValue("Class Approved Drawing Number", _SearchedFile.Id, false); //Class Approved Drawing Number
                        if (fileRelevantClassApproved == null)
                        {
                            fileRelevantClassApproved = "";
                        }

                        if (fileSFI.Trim().ToUpper() == SFIcode.Trim().ToUpper())
                        {
                            clsStaticGlobal.ProductionDrawingSearchedItemCollection.Add(new ProductionDrawing { Count = SearchedCount, IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _SearchedFile.Name, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileElement = fileElement, FileSFI = filesfi, FileRelevantClassApproved = fileRelevantClassApproved, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label, FileStatus = _SearchedFile.FileLfCyc.LfCycStateName, FileUsedIn = "", FileLink = "Go To Location" });
                        }
                    }
                    else
                    {
                        string fileDec = _item.DocumentDescription;
                        clsStaticGlobal.ProductionDrawingSearchedItemCollection.Add(new ProductionDrawing { Count = SearchedCount, IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _item.DocumentNumber, FileNumber = _item.DocumentNumber, FileDesc = fileDec, FileElement = "", FileSFI = "", FileRelevantClassApproved = "", FilePath = "", FileRemark = "Unable to check SFI code.!", FileRevision = "", FileStatus = "File not exist.!", FileUsedIn = "", FileLink = "" });
                    }
                    //clsStaticGlobal.ProductionDrawingSearchedItemCollection.Add(new ProductionDrawing { Count = SearchedCount, IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _item, FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "" });
                    SearchedCount += 1;
                }

                //foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.DADDrawingFiles)
                //{
                //    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                //    string filePath = folder.FullName + "/" + _item.Name;                   
                //    string fileName = _item.Name;
                //    clsStaticGlobal.ProductionDrawingSearchedItemCollection.Add(new ProductionDrawing { Count = SearchedCount, IsCheckedProductionDrawing = false, FileType = "DAD", FileName = fileName, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                //    SearchedCount += 1;
                //}

                ProductionDrawingSearchlistview.ItemsSource = clsStaticGlobal.ProductionDrawingSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(ProductionDrawingSearchlistview.ItemsSource);
                viewSearch.Filter = UserFilter;

                if (ProductionDrawingSearchlistview.IsGrouping == false)
                {
                    CollectionView viewSearched = (CollectionView)CollectionViewSource.GetDefaultView(ProductionDrawingSearchlistview.ItemsSource);
                    PropertyGroupDescription groupDescriptionSearched = new PropertyGroupDescription("FileType");
                    viewSearched.GroupDescriptions.Add(groupDescriptionSearched);
                }

                Productionlistview.ItemsSource = clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing;
                if (Productionlistview.IsGrouping == false)
                {
                    CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(Productionlistview.ItemsSource);
                    PropertyGroupDescription groupDescription = new PropertyGroupDescription("FileType");
                    view.GroupDescriptions.Add(groupDescription);
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                this.Close();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ProductionDrawingSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.ProductionDrawingSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListProductionDrawing_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                {
                    item.Count = k;
                    k++;
                    string _status = "";
                    string _remark = "";

                    clsStaticGlobal.GetFileStateAndRemark(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                    //item.FileRemark = _remark;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            //System.Diagnostics.Debugger.Launch();
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    ProductionDrawingSearchlistview.UpdateLayout();
                    ProductionDrawingSearchlistview.Items.Refresh();
                    foreach (ProductionDrawing _item in clsStaticGlobal.ProductionDrawingSearchedItemCollection)
                    {
                        if (_item.IsCheckedProductionDrawing == true)
                        {
                            bool IsFileExist = false;
                            foreach (ProductionDrawing _itemExist in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                            {

                                if (_itemExist.FileName == _item.FileName)
                                {
                                    IsFileExist = true;
                                }
                                else
                                {
                                    var _itemExistTemp = _itemExist.FileName.Split(new char[] { '.' });
                                    var _itemTemp = _item.FileName.Split(new char[] { '.' });
                                    if (_itemExistTemp[0].ToUpper() == _itemTemp[0].ToUpper())
                                    {
                                        IsFileExist = true;
                                    }
                                }

                            }
                            if (IsFileExist == false)
                            {
                                if (_item.FileType.ToUpper() == "PRODUCTION")
                                {
                                    Autodesk.Connectivity.WebServices.File _SearchedFile = clsStaticGlobal.SearchFileByName(_item.FileName, "PRODUCTION DOCUMENT", clsStaticGlobal.ProjectFolder);
                                    if (_SearchedFile != null)
                                    {
                                        Folder _folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_SearchedFile.FolderId);
                                        string _filepath = _folder.FullName + "/" + _SearchedFile.Name;
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Add(new ProductionDrawing { IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _SearchedFile.Name, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSFI = _item.FileSFI, FileElement = _item.FileElement, FileRelevantClassApproved = _item.FileRelevantClassApproved, FilePath = _filepath, FileRemark = _SearchedFile.Comm, FileRevision = _SearchedFile.FileRev.Label.ToString(), FileStatus = _SearchedFile.FileLfCyc.LfCycStateName.ToString(), FileUsedIn = "", FileLink = "Go To Location" });
                                    }
                                    else
                                    {
                                        clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Add(new ProductionDrawing { IsCheckedProductionDrawing = false, FileType = "PRODUCTION", FileName = _item.FileName, FileNumber = _item.FileNumber, FileDesc = _item.FileDesc, FileSFI = "", FileElement = "", FileRelevantClassApproved = "", FilePath = "", FileRemark = "", FileRevision = "", FileStatus = "File not exist", FileUsedIn = "", FileLink = "" });
                                    }
                                }
                            }
                        }
                    }

                    Productionlistview.Items.Refresh();
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            Productionlistview.UpdateLayout();
        }

        private void cmdProductionRemove_Click(object sender, RoutedEventArgs e)
        {
            if (clsStaticGlobal.IsReadOnly == false)
            {
                try
                {
                    if (clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Count > 0)
                    {
                        try
                        {
                            bool isChecked = false;
                            List<ProductionDrawing> listOfProductionDrawing = new List<ProductionDrawing>();
                            foreach (var itemProductionDocument in Productionlistview.Items)
                            {
                                ProductionDrawing objProductionNumber = (ProductionDrawing)itemProductionDocument;

                                if (objProductionNumber.IsCheckedProductionDrawing == true)
                                {
                                    isChecked = true;
                                    listOfProductionDrawing.Add(objProductionNumber);
                                    //clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Remove(objProductionNumber);
                                }
                            }



                            foreach (ProductionDrawing item in listOfProductionDrawing)
                            {
                                clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Remove(item);

                                //foreach (ClassDrawing itemDAD in clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing)
                                //{
                                //    if (item.FileName == itemDAD.FileUsedIn)
                                //    {
                                //        clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Remove(itemDAD);
                                //    }
                                //}
                            }

                            Productionlistview.Items.Refresh();

                            if (isChecked == false)
                            {
                                MessageBox.Show("Select single file first.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            }

                            //if (Productionlistview.SelectedItems.Count > 0)
                            //{
                            //    ProductionDrawing objProductionNumber = (ProductionDrawing)Productionlistview.SelectedItem;
                            //    clsStaticGlobal.objSingleBuildSpecificationSummary.ListProductionDrawing.Remove(objProductionNumber);
                            //    Productionlistview.Items.Refresh();
                            //}
                            //else
                            //{
                            //    MessageBox.Show("Select single file first.", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                            //}

                        }
                        catch (Exception ex)
                        {
                            clsStaticGlobal.ErrHandlerLog(ex);
                        }

                    }
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
            else
            {
                MessageBox.Show("Build Specification in Release state. User can not edit..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ProductionDrawingSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                //ProductionDrawingSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }


        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            { return true; }

            else
            {
                //ProductionDrawing itemitem = (ProductionDrawing)item;

                //if (itemitem.FileNumber.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
                return ((item as ProductionDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ProductionDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            // return ((item as ProductionDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
            // return ((item as ProductionDrawing).FileNumber.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as ProductionDrawing).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(ProductionDrawingSearchlistview.ItemsSource).Refresh();
        }

        private void Hyperlink_OnRequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            // Debugger.Launch();
            try
            {
                string hyperlink = "";
                string filepath = "";
                try
                {

                    filepath = ((ProductionDrawing)((System.Windows.FrameworkElement)((System.Windows.FrameworkContentElement)sender).Parent).DataContext).FilePath;
                    hyperlink = clsStaticGlobal.GeHyperLink(filepath);

                    // var urlPart = ((Hyperlink)sender).NavigateUri;
                    if (hyperlink != "")
                    {
                        Process.Start(new ProcessStartInfo(hyperlink));
                    }
                    else
                    {
                        MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to redirect ..!!", "Build Specification", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

            }
            catch (Exception)
            {

            }

            e.Handled = true;
        }
    }

    public class ProductionFileType : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value.ToString().ToUpper() == "RELEASE")
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
