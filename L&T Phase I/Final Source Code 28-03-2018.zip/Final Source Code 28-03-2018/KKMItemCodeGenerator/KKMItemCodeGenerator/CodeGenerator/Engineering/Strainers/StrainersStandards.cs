﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersStandards : ObservableCollection<NameCodePair>
    {
        public static StrainersStandards LoadList()
        {
            StrainersStandards items = new StrainersStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ANSI B31.4" });
            items.Add(new NameCodePair() { Code = "02", Name = "ANSI B31.3.8" });
            items.Add(new NameCodePair() { Code = "03", Name = "ASME VIII DIV 1" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 3202-F1" });
            items.Add(new NameCodePair() { Code = "05", Name = "ANSI B16.10" });
            items.Add(new NameCodePair() { Code = "06", Name = "ANSI B16.5" });
            items.Add(new NameCodePair() { Code = "07", Name = "DIN 86037" });
            return items;
        }
        public static StrainersStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersStandards>(EngineeringItems.DataPath + @"\Strainers\StrainersStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersStandards>(this, EngineeringItems.DataPath + @"\Strainers\StrainersStandards.xml");
        }

    }
}
