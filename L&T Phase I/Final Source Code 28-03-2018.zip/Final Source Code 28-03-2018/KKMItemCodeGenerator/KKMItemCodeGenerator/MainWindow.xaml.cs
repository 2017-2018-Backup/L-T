﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Autodesk.Connectivity.WebServices;
using KKMItemCodeGenerator.CodeGenerator;
using excel = Microsoft.Office.Interop.Excel;

namespace KKMItemCodeGenerator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        private String dataPath = "";
        SFIcodes _SFIcodes;
        private ObservableCollection<NameCodePair> nullCollection = new ObservableCollection<NameCodePair>();
        Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections.Connection vConnection;

        public MainWindow(Autodesk.DataManagement.Client.Framework.Vault.Currency.Connections.Connection vCon)
        {
            InitializeComponent();
            nullCollection.Add(new NameCodePair() { Name = "--", Code = "" });
            vConnection = vCon;
            dataPath = clsStaticGlobal.BuildFilePath + @"\Data";
            if (System.IO.Directory.Exists(clsStaticGlobal._ItemexcelPath) == false)
            {
                System.IO.Directory.CreateDirectory(clsStaticGlobal._ItemexcelPath);
            }

            _SFIcodes = SFIcodes.LoadFromXml(dataPath);
        }

        private bool AddItem(string itemNumber)
        {
            bool retValue = true;

            try
            {
                ItemService itemSvc = vConnection.WebServiceManager.ItemService;
                Cat[] categories = vConnection.WebServiceManager.CategoryService.GetCategoriesByEntityClassId("ITEM", true);
                long catId = -1;
                foreach (Cat category in categories)
                {
                    if ((category.Name == "Part"))
                    {
                        catId = category.Id;
                    }
                }

                Item editableItem = vConnection.WebServiceManager.ItemService.AddItemRevision(catId);

                NumSchm[] numSchms = null;
                numSchms = itemSvc.GetNumberingSchemesByType(NumSchmType.Activated);
                ArrayList numArr = default(ArrayList);
                numArr = new ArrayList();
                foreach (NumSchm _numSchm in numSchms)
                {
                    if ((_numSchm.Name == "Mapped"))
                        numArr.Add(_numSchm.SchmID);
                }
                long[] numSchmIds = (from long ln in numArr select ln).ToArray();
                long[] masterIds = new long[1];
                masterIds[0] = editableItem.MasterId;
                string[] newItem = null;
                newItem = new string[] { itemNumber };
                StringArray[] fieldInputs = new StringArray[1];
                StringArray tempArr = new StringArray();
                tempArr.Items = newItem;
                fieldInputs[0] = tempArr;
                ProductRestric[] restric;
                ItemNum[] numbers = itemSvc.AddItemNumbers(masterIds, numSchmIds, fieldInputs, out restric);
                editableItem.ItemNum = numbers[0].ItemNum1;
                Item[] items = new Item[1];
                items[0] = editableItem;
                itemSvc.UpdateAndCommitItems(items);

                var entityClassId = "ITEM";
                Item item = items[0];
                //Edit Item
                var editItem = vConnection.WebServiceManager.ItemService.EditItems(new[] { item.RevId }).First();

                var prtDefs = vConnection.WebServiceManager.PropertyService.GetPropertyDefinitionsByEntityClassId(entityClassId);
                //Update "Item's Project Code"
                List<PropInstParam> propInstParams = new List<PropInstParam>();
                PropInstParamArray[] propInstParamsArrays = new PropInstParamArray[1];

                //PropDef prtDef = prtDefs.GroupBy(ps => ps.Id).Select(p => p.First()).Single(p => p.DispName.ToUpper().Equals(ItemsProjectCode.ToUpper()) || p.SysName.ToUpper().Equals(ItemsProjectCode.ToUpper()));

                foreach (PropDef def in prtDefs)
                {
                    if (def.IsSys == false & def.IsAct == true)
                    {
                        if (def.DispName == "Item's Project code")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._ItemsProjectCode;
                            propInstParams.Add(propInst);
                        }
                        else if (def.DispName == "Number")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._ItemCode;
                            propInstParams.Add(propInst);
                        }

                        else if (def.DispName == "Item Group")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._ItemGroup;
                            propInstParams.Add(propInst);
                        }

                        else if (def.DispName == "Unit")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._Unit;
                            propInstParams.Add(propInst);
                        }

                        else if (def.DispName == "Budget SFI")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._BudgetSFI;
                            propInstParams.Add(propInst);
                        }
                        else if (def.SysName == "Description")
                        {
                            PropInstParam propInst = new PropInstParam();
                            propInst.PropDefId = def.Id;
                            propInst.Val = clsStaticGlobal._Desc;
                            propInstParams.Add(propInst);
                        }

                    }
                }

                PropInstParamArray propInstParamsArray = new PropInstParamArray();
                propInstParamsArray.Items = propInstParams.ToArray();
                propInstParamsArrays[0] = propInstParamsArray;

                vConnection.WebServiceManager.ItemService.UpdateItemProperties(new[] { editItem.RevId }, propInstParamsArrays);
                itemSvc.UpdateAndCommitItems(new[] { editItem });

                var editItemnew = vConnection.WebServiceManager.ItemService.EditItems(new[] { item.RevId }).First();

                editItemnew.Title = clsStaticGlobal._Title;
                Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.ItemRevision _ItemRevision = new Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.ItemRevision(vConnection, editItemnew);

                _ItemRevision.Description = clsStaticGlobal._Desc;

                itemSvc.UpdateAndCommitItems(new[] { editItemnew });

            }
            catch (Exception ex)
            {
                retValue = false;
                clsStaticGlobal.ErrHandlerLog(ex);
                MessageBox.Show("Error in item creation.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return retValue;
        }

        #region HUll Objects

        private string HullDescription = "";
        private string HullItemsDataPath;
        HullItems hullItems;

        HullGroupItems hullGroupItems;
        HullUnits hullUnits;

        #region Plate
        PlateTypes plateTypes;
        PlateProfileCertificates plateProfileCertificates;
        PlateProfileMaterials plateProfileMaterials;
        PlateLengthCollection plateLengthCollection;
        PlateWidthCollection plateWidthCollection;
        PlateThicknessCollection plateThicknessCollection;
        #endregion

        #region Angle
        AngleTypes angleTypes;
        AngleStandards angleStandards;
        AngleClassCertificates angleClassCertificates;
        AngleMaterials angleMaterials;
        AngleSize1Collection angleSize1Collection;
        AngleSize2Collection angleSize2Collection;
        AngleThicknessCollection angleThicknessCollection;
        #endregion

        #region Bars
        BarsSubTypes barsSubTypes;
        BarsPlateProfileCertificates barsPlateProfileCertificates;
        BarsPlateProfileMaterials barsPlateProfileMaterials;
        BarsWidthCollection barsWidthCollection;
        BarsThicknessCollection barsThicknessCollection;
        #endregion

        #region Loading HullObjects

        private void loadHullItems()
        {
            try
            {
                HullItemsDataPath = this.dataPath + @"\Hull";
                hullItems = HullItems.LoadFromXml(HullItemsDataPath);

                //Added for HULL Tab
                hullGroupItems = HullGroupItems.LoadFromXml();
                hullUnits = HullUnits.LoadFromXml();

                #region Plate
                plateTypes = PlateTypes.LoadFromXml();
                plateProfileCertificates = PlateProfileCertificates.LoadFromXml();
                plateProfileMaterials = PlateProfileMaterials.LoadFromXml();
                plateLengthCollection = PlateLengthCollection.LoadFromXml();
                plateWidthCollection = PlateWidthCollection.LoadFromXml();
                plateThicknessCollection = PlateThicknessCollection.LoadFromXml();
                #endregion

                #region Angle
                angleTypes = AngleTypes.LoadFromXml();
                angleStandards = AngleStandards.LoadFromXml();
                angleClassCertificates = AngleClassCertificates.LoadFromXml();
                angleHOClassCertificates = AngleHOClassCertificates.LoadFromXml();
                angleMaterials = AngleMaterials.LoadFromXml();
                angleHOMaterials = AngleHOMaterials.LoadFromXml();
                angleSize1Collection = AngleSize1Collection.LoadFromXml();
                angleSize2Collection = AngleSize2Collection.LoadFromXml();
                angleThicknessCollection = AngleThicknessCollection.LoadFromXml();
                #endregion

                #region Bars
                barsSubTypes = BarsSubTypes.LoadFromXml();
                barsPlateProfileCertificates = BarsPlateProfileCertificates.LoadFromXml();
                barsPlateProfileMaterials = BarsPlateProfileMaterials.LoadFromXml();
                barsWidthCollection = BarsWidthCollection.LoadFromXml();
                barsThicknessCollection = BarsThicknessCollection.LoadFromXml();
                #endregion
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        #endregion

        #region Generating Code

        private void btnGenerateHullItemCode_Click(object sender, RoutedEventArgs e)
        {
            if (IsValidHull() == true)
            {
                generateHullCode();

                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtHullItemCode.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtHullItemCode.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);

                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (AddItem(txtHullItemCode.Text))
                        {
                            ExportItemCodeDetails("Standard");
                            MessageBox.Show(txtHullItemCode.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);
                            //clearHullComboBoxes(true);
                            //cboHullItems1.SelectedItem = null;
                            //cmbxItemGroupHull.SelectedItem = null;
                            //cboHullItemsUnit.SelectedItem = null;
                        }
                    }
                    catch (Exception ex1)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex1);
                    }
                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void OnHullTabSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                clearHullComboBoxes();
                loadHullItems();
                initializeHullTab();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void initializeHullTab()
        {
            try
            {
                cboHullItems1.ItemsSource = null;
                cmbxItemGroupHull.ItemsSource = null;
                cboHullItemsUnit.ItemsSource = null;
                cboHullItems1.ItemsSource = hullItems;
                cmbxItemGroupHull.ItemsSource = hullGroupItems;
                cboHullItemsUnit.ItemsSource = hullUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidHull()
        {
            bool _IsValidHull = true;
            try
            {
                if ((cboHullItems1.IsVisible == true) && (cboHullItems1.SelectedItem == null))
                {
                    _IsValidHull = false;
                }

                if ((cboHullItems2.IsVisible == true) && (cboHullItems2.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cmbxItemGroupHull.IsVisible == true) && (cmbxItemGroupHull.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItemsUnit.IsVisible == true) && (cboHullItemsUnit.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItems3.IsVisible == true) && (cboHullItems3.SelectedItem == null))
                {
                    _IsValidHull = false;
                }

                if ((cboHullItems4.IsVisible == true) && (cboHullItems4.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItems5.IsVisible == true) && (cboHullItems5.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItems6.IsVisible == true) && (cboHullItems6.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItems7.IsVisible == true) && (cboHullItems7.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if ((cboHullItems8.IsVisible == true) && (cboHullItems8.SelectedItem == null))
                {
                    _IsValidHull = false;
                }
                if (txtSFICodeHull.Text.Trim() == "")
                {
                    _IsValidHull = false;
                }
                if (txtSFICodeDescHull.Text.Trim() == "")
                {
                    _IsValidHull = false;
                }
                if (txtHullItemDesc.Text.Trim() == "")
                {
                    _IsValidHull = false;
                }
                if (txtHullItemCode.Text.Trim() == "")
                {
                    _IsValidHull = false;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidHull;

        }

        private void clearHullComboBoxes(bool isSecondLevel = true)
        {
            try
            {
                if (!isSecondLevel)
                {
                    cboHullItems2.ItemsSource = null;
                    cmbxItemGroupHull.ItemsSource = null;
                    cboHullItemsUnit.ItemsSource = null;
                }

                cboHullItems3.ItemsSource = null;
                cboHullItems4.ItemsSource = null;
                cboHullItems5.ItemsSource = null;
                cboHullItems6.ItemsSource = null;
                cboHullItems7.ItemsSource = null;
                cboHullItems8.ItemsSource = null;
                txtSFICodeHull.Text = "";
                txtSFICodeDescHull.Text = "";
                txtHullItemDesc.Text = "";
                txtHullItemCode.Text = "";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void BindHullComboBoxesData()
        {
            HullDescription = "";

            try
            {
                if (cboHullItems1.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems1.SelectedItem.ToString();
                }
                if (cboHullItems2.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems2.SelectedItem.ToString();
                }

                if (cboHullItems3.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems3.SelectedItem.ToString();
                }

                if (cboHullItems4.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems4.SelectedItem.ToString();
                }

                if (cboHullItems5.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems5.SelectedItem.ToString();
                }

                if (cboHullItems6.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems6.SelectedItem.ToString();
                }

                if (cboHullItems7.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems7.SelectedItem.ToString();
                }

                if (cboHullItems8.SelectedItem != null)
                {
                    HullDescription = HullDescription + " " + cboHullItems8.SelectedItem.ToString();
                }

                txtHullItemDesc.Text = HullDescription.Trim();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void generateHullCode()
        {
            try
            {
                string code = txtHullItems1.Text +
                                        txtHullItems2.Text +
                                        txtHullItems3.Text +
                                        txtHullItems4.Text +
                                        txtHullItems5.Text +
                                        txtHullItems6.Text +
                                        txtHullItems7.Text +
                                        txtHullItems8.Text;

                if (((NameCodePair)cboHullItems1.SelectedItem).Name.ToUpper() == "BARS")
                {
                    code += "00";
                }

                txtHullItemCode.Text = code;

                clsStaticGlobal._ItemCode = code;
                clsStaticGlobal._ItemsProjectCode = "";
                clsStaticGlobal._Unit = txtHullItemsUnit.Text;
                clsStaticGlobal._ItemGroup = txtItemGroupHull.Text;
                clsStaticGlobal._BudgetSFI = txtSFICodeHull.Text;
                clsStaticGlobal._Desc = txtHullItemDesc.Text;
                clsStaticGlobal._Title = "Standard Hull";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        #endregion

        #region  "Events"

        private void txtSFICodeHull_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void txtSFICodeHull_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSFICodeDescHull.Text = "";
                var _res = _SFIcodes.Where(n => n.Code == txtSFICodeHull.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtSFICodeDescHull.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    clearHullComboBoxes(false);
                    cmbxItemGroupHull.ItemsSource = hullGroupItems;
                    cboHullItemsUnit.ItemsSource = hullUnits;

                    switch (((NameCodePair)((ComboBox)sender).SelectedItem).Name.ToUpper())
                    {
                        case "PLATE":
                            cboHullItems2.ItemsSource = plateTypes;
                            cboHullItems3.ItemsSource = plateProfileCertificates;
                            cboHullItems4.ItemsSource = plateProfileMaterials;
                            cboHullItems5.ItemsSource = plateLengthCollection;
                            cboHullItems6.ItemsSource = plateWidthCollection;
                            cboHullItems7.ItemsSource = plateThicknessCollection.OrderBy(_ => Double.Parse(_.Name));

                            hullLabel2.Content = "Plate Type";
                            hullLabel3.Content = "Plate Profile Certificate";
                            hullLabel4.Content = "Plate Profile Material";
                            hullLabel5.Content = "Plate Length";
                            hullLabel6.Content = "Plate Width";
                            hullLabel7.Content = "Plate Thickness";

                            hullLabel7.Visibility = System.Windows.Visibility.Visible;
                            cboHullItems7.Visibility = System.Windows.Visibility.Visible;
                            txtHullItems7.Visibility = System.Windows.Visibility.Visible;

                            hullLabel8.Visibility = System.Windows.Visibility.Collapsed;
                            cboHullItems8.Visibility = System.Windows.Visibility.Collapsed;
                            txtHullItems8.Visibility = System.Windows.Visibility.Collapsed;
                            break;
                        case "ANGLE":
                            cboHullItems2.ItemsSource = angleTypes;
                            cboHullItems3.ItemsSource = angleStandards;
                            cboHullItems4.ItemsSource = angleClassCertificates;
                            cboHullItems5.ItemsSource = angleMaterials;
                            cboHullItems6.ItemsSource = angleSize1Collection;
                            cboHullItems7.ItemsSource = angleSize2Collection;
                            cboHullItems8.ItemsSource = angleThicknessCollection.OrderBy(_ => Double.Parse(_.Name));

                            hullLabel2.Content = "Angle Type";
                            hullLabel3.Content = "Angle Standard";
                            hullLabel4.Content = "Angle Class Certificate";
                            hullLabel5.Content = "Angle Material";
                            hullLabel6.Content = "Size 1";
                            hullLabel7.Content = "Size 2";
                            hullLabel8.Content = "Angle Thickness";

                            hullLabel7.Visibility = System.Windows.Visibility.Visible;
                            cboHullItems7.Visibility = System.Windows.Visibility.Visible;
                            txtHullItems7.Visibility = System.Windows.Visibility.Visible;

                            hullLabel8.Visibility = System.Windows.Visibility.Visible;
                            cboHullItems8.Visibility = System.Windows.Visibility.Visible;
                            txtHullItems8.Visibility = System.Windows.Visibility.Visible;
                            break;
                        case "BARS":
                            cboHullItems2.ItemsSource = barsSubTypes;
                            cboHullItems3.ItemsSource = barsPlateProfileCertificates;
                            cboHullItems4.ItemsSource = barsPlateProfileMaterials;
                            cboHullItems5.ItemsSource = barsWidthCollection;
                            cboHullItems6.ItemsSource = barsThicknessCollection.OrderBy(_ => Double.Parse(_.Name));

                            hullLabel2.Content = "Sub Type";
                            hullLabel3.Content = "Plate Profile Certificate";
                            hullLabel4.Content = "Plate Profile Material";
                            hullLabel5.Content = "Bar Width";
                            hullLabel6.Content = "Bar Thickness";

                            hullLabel7.Visibility = System.Windows.Visibility.Collapsed;
                            cboHullItems7.Visibility = System.Windows.Visibility.Collapsed;
                            txtHullItems7.Visibility = System.Windows.Visibility.Collapsed;

                            hullLabel8.Visibility = System.Windows.Visibility.Collapsed;
                            cboHullItems8.Visibility = System.Windows.Visibility.Collapsed;
                            txtHullItems8.Visibility = System.Windows.Visibility.Collapsed;
                            break;
                        default:
                            break;
                    }

                }
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems1.Text = ((NameCodePair)cboHullItems1.SelectedItem).Code;
                }
                else
                {
                    txtHullItems1.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void cboHullItems2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems2.Text = ((NameCodePair)cboHullItems2.SelectedItem).Code;
                }
                else
                {
                    txtHullItems2.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems3.Text = ((NameCodePair)cboHullItems3.SelectedItem).Code;
                }
                else
                {
                    txtHullItems3.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems4.Text = ((NameCodePair)cboHullItems4.SelectedItem).Code;
                }
                else
                {
                    txtHullItems4.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems5_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems5.Text = ((NameCodePair)cboHullItems5.SelectedItem).Code;
                }
                else
                {
                    txtHullItems5.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems6_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems6.Text = ((NameCodePair)cboHullItems6.SelectedItem).Code;
                }
                else
                {
                    txtHullItems6.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void cboHullItems7_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems7.Text = ((NameCodePair)cboHullItems7.SelectedItem).Code;
                }
                else
                {
                    txtHullItems7.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItems8_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItems8.Text = ((NameCodePair)cboHullItems8.SelectedItem).Code;
                }
                else
                {
                    txtHullItems8.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullGroupItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtItemGroupHull.Text = ((NameCodePair)cmbxItemGroupHull.SelectedItem).Code;
                }
                else
                {
                    txtItemGroupHull.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboHullItemsUnit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtHullItemsUnit.Text = ((NameCodePair)cboHullItemsUnit.SelectedItem).Code;
                }
                else
                {
                    txtHullItemsUnit.Text = string.Empty;
                }

                BindHullComboBoxesData();
                generateHullCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        #endregion

        #endregion

        #region Hull Outfit

        private string HulloutfitDescription = "";
        private string hullOutfitDataPath;

        #region Objects

        HullOutfitItems hullOutfitItems;
        ItemGroups itemGroups;
        Units units;

        #region Angle
        AngleHOClassCertificates angleHOClassCertificates;
        AngleHOMaterials angleHOMaterials;
        #endregion

        #region Channel
        ChannelTypes channelTypes;
        ChannelStandards channelStandards;
        ChannelClassCertificates channelClassCertificates;
        ChannelMaterials channelMaterials;
        ChannelBredths channelBredths;
        ChannelWidths channelWidths;
        ChannelWebThicknesses channelWebThicknesses;
        ChannelFlangeThicknesses channelFlangeThicknesses;
        #endregion

        #region Beam
        BeamTypes beamTypes;
        BeamStandards beamStandards;
        BeamClassCertificates beamClassCertificates;
        BeamMaterials beamMaterials;
        BeamHeights beamHeights;
        BeamFlangeWidths beamFlangeWidths;
        BeamWebThicknesses beamWebThicknesses;
        BeamFlangeThicknesses beamFlangeThicknesses;
        #endregion

        #region Bars
        BarsHOTypes barsHOTypes;
        BarsHOStandards barsHOStandards;
        BarsHOClassCertificates barsHOClassCertificates;
        BarsHOMaterials barsHOMaterials;
        BarsHODimention1 barsHODimention1;
        BarsHODimention2 barsHODimention2;
        BarsHOThicknesses barsHOThicknesses;
        #endregion

        #region Hardware Materials
        HardwareItems hardwareItems;
        HardwareBoltSubTypes hardwareBoltSubTypes;
        HardwareScrewSubTypes hardwareScrewSubTypes;
        HardwareNutSubTypes hardwareNutSubTypes;
        HardwareWasherSubTypes hardwareWasherSubTypes;
        HardwareGrubScrewSubTypes hardwareGrubScrewSubTypes;
        HardwareStudSubTypes hardwareStudSubTypes;

        HardwareMaterials hardwareMaterials;
        HardwareSizes hardwareSizes;
        HardwareLengths hardwareLengths;
        HardwareThicknesses hardwareThicknesses;
        HardwareTreatments hardwareTreatments;
        HardwareStandards hardwareStandards;
        HardwareHoles hardwareHoles;
        #endregion

        #endregion

        #region Generating Code

        private void loadHullOutfitItems(bool isTabLoaded = false, string item = "")
        {
            try
            {
                if (isTabLoaded)
                {
                    hullOutfitDataPath = this.dataPath + @"\HullOutfit";
                    hullOutfitItems = HullOutfitItems.LoadFromXml(hullOutfitDataPath);

                    itemGroups = ItemGroups.LoadFromXml(hullOutfitDataPath);
                    units = Units.LoadFromXml(hullOutfitDataPath);
                }

                HullItemsDataPath = this.dataPath + @"\Hull";
                hullItems = HullItems.LoadFromXml(HullItemsDataPath);

                switch (item.ToUpper())
                {
                    case "ANGLE":
                        #region Angle
                        if (angleTypes == null)
                        {
                            angleTypes = AngleTypes.LoadFromXml();
                            angleStandards = AngleStandards.LoadFromXml();
                            angleClassCertificates = AngleClassCertificates.LoadFromXml();
                            angleHOClassCertificates = AngleHOClassCertificates.LoadFromXml();
                            angleMaterials = AngleMaterials.LoadFromXml();
                            angleHOMaterials = AngleHOMaterials.LoadFromXml();
                            angleSize1Collection = AngleSize1Collection.LoadFromXml();
                            angleSize2Collection = AngleSize2Collection.LoadFromXml();
                            angleThicknessCollection = AngleThicknessCollection.LoadFromXml();

                        }
                        #endregion
                        break;
                    case "CHANNEL":
                        #region Channel
                        if (channelTypes == null)
                        {
                            channelTypes = ChannelTypes.LoadFromXml();
                            channelStandards = ChannelStandards.LoadFromXml();
                            channelClassCertificates = ChannelClassCertificates.LoadFromXml();
                            channelMaterials = ChannelMaterials.LoadFromXml();
                            channelBredths = ChannelBredths.LoadFromXml();
                            channelWidths = ChannelWidths.LoadFromXml();
                            channelWebThicknesses = ChannelWebThicknesses.LoadFromXml();
                            channelFlangeThicknesses = ChannelFlangeThicknesses.LoadFromXml();
                        }
                        #endregion
                        break;

                    case "BEAMS":
                        #region Beam
                        if (beamTypes == null)
                        {
                            beamTypes = BeamTypes.LoadFromXml();
                            beamStandards = BeamStandards.LoadFromXml();
                            beamClassCertificates = BeamClassCertificates.LoadFromXml();
                            beamMaterials = BeamMaterials.LoadFromXml();
                            beamHeights = BeamHeights.LoadFromXml();
                            beamFlangeWidths = BeamFlangeWidths.LoadFromXml();
                            beamWebThicknesses = BeamWebThicknesses.LoadFromXml();
                            beamFlangeThicknesses = BeamFlangeThicknesses.LoadFromXml();
                        }
                        #endregion
                        break;

                    case "BARS":
                        #region Bars
                        if (barsHOTypes == null)
                        {
                            barsHOTypes = BarsHOTypes.LoadFromXml();
                            barsHOStandards = BarsHOStandards.LoadFromXml();
                            barsHOClassCertificates = BarsHOClassCertificates.LoadFromXml();
                            barsHOMaterials = BarsHOMaterials.LoadFromXml();
                            barsHODimention1 = BarsHODimention1.LoadFromXml();
                            barsHODimention2 = BarsHODimention2.LoadFromXml();
                            barsHOThicknesses = BarsHOThicknesses.LoadFromXml();
                        }
                        #endregion
                        break;
                    case "HARDWARE MATERIAL":
                        #region Hardware Materials
                        if (hardwareItems == null)
                        {
                            hardwareItems = HardwareItems.LoadFromXml();
                            hardwareBoltSubTypes = HardwareBoltSubTypes.LoadFromXml();
                            hardwareScrewSubTypes = HardwareScrewSubTypes.LoadFromXml();
                            hardwareNutSubTypes = HardwareNutSubTypes.LoadFromXml();
                            hardwareWasherSubTypes = HardwareWasherSubTypes.LoadFromXml();
                            hardwareGrubScrewSubTypes = HardwareGrubScrewSubTypes.LoadFromXml();
                            hardwareStudSubTypes = HardwareStudSubTypes.LoadFromXml();

                            hardwareMaterials = HardwareMaterials.LoadFromXml();
                            hardwareSizes = HardwareSizes.LoadFromXml();
                            hardwareLengths = HardwareLengths.LoadFromXml();
                            hardwareThicknesses = HardwareThicknesses.LoadFromXml();
                            hardwareTreatments = HardwareTreatments.LoadFromXml();
                            hardwareStandards = HardwareStandards.LoadFromXml();
                            hardwareHoles = HardwareHoles.LoadFromXml();
                        }
                        #endregion
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void InitializeHullOutfitTab()
        {
            try
            {
                comboBox1HullOutfit.ItemsSource = null;
                cmbxItemGroupHullOutfit.ItemsSource = null;
                cmbxUnitHullOutfit.ItemsSource = null;
                comboBox1HullOutfit.ItemsSource = hullOutfitItems;
                cmbxItemGroupHullOutfit.ItemsSource = itemGroups;
                cmbxUnitHullOutfit.ItemsSource = units;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void OnHullOutfitSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                clearHullOutfitComboBoxes();

                loadHullOutfitItems(true);

                InitializeHullOutfitTab();

                //if (hullOutfitItems == null)
                //{
                //    loadHullOutfitItems(true);

                //    InitializeHullOutfitTab();
                //}
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private bool IsValidHullOutfit()
        {
            bool _IsValidHullOutfit = true;
            try
            {
                if ((comboBox1HullOutfit.IsVisible == true) && (comboBox1HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox2HullOutfit.IsVisible == true) && (comboBox2HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((cmbxItemGroupHullOutfit.IsVisible == true) && (cmbxItemGroupHullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((cmbxUnitHullOutfit.IsVisible == true) && (cmbxUnitHullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox3HullOutfit.IsVisible == true) && (comboBox3HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox4HullOutfit.IsVisible == true) && (comboBox4HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox5HullOutfit.IsVisible == true) && (comboBox5HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox6HullOutfit.IsVisible == true) && (comboBox6HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox7HullOutfit.IsVisible == true) && (comboBox7HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox8HullOutfit.IsVisible == true) && (comboBox8HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox9HullOutfit.IsVisible == true) && (comboBox9HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }
                if ((comboBox10HullOutfit.IsVisible == true) && (comboBox10HullOutfit.SelectedItem == null))
                {
                    _IsValidHullOutfit = false;
                }

                if (txtSFICodeHullOutfit.Text.Trim() == "")
                {
                    _IsValidHullOutfit = false;
                }
                if (txtSFICodeDescHullOutfit.Text.Trim() == "")
                {
                    _IsValidHullOutfit = false;
                }

                if (txtHulloutfitItemDesc.Text.Trim() == "")
                {
                    _IsValidHullOutfit = false;
                }

                if (txtGeneratedCodeHullOutfit.Text.Trim() == "")
                {
                    _IsValidHullOutfit = false;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidHullOutfit;

        }

        private void clearHullOutfitComboBoxes(bool isSecondLevel = true)
        {
            try
            {
                if (!isSecondLevel)
                {
                    comboBox2HullOutfit.ItemsSource = null;
                    cmbxItemGroupHullOutfit.ItemsSource = null;
                    cmbxUnitHullOutfit.ItemsSource = null;
                }

                comboBox3HullOutfit.ItemsSource = null;
                comboBox4HullOutfit.ItemsSource = null;
                comboBox5HullOutfit.ItemsSource = null;
                comboBox6HullOutfit.ItemsSource = null;
                comboBox7HullOutfit.ItemsSource = null;
                comboBox8HullOutfit.ItemsSource = null;
                comboBox9HullOutfit.ItemsSource = null;
                comboBox10HullOutfit.ItemsSource = null;
                txtSFICodeHullOutfit.Text = "";
                txtSFICodeDescHullOutfit.Text = "";
                txtHulloutfitItemDesc.Text = "";
                txtGeneratedCodeHullOutfit.Text = "";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void BindHulloutfitComboBoxesData()
        {
            HulloutfitDescription = "";

            try
            {
                if (comboBox1HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox1HullOutfit.SelectedItem.ToString();
                }
                if (comboBox2HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox2HullOutfit.SelectedItem.ToString();
                }

                if (comboBox3HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox3HullOutfit.SelectedItem.ToString();
                }

                if (comboBox4HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox4HullOutfit.SelectedItem.ToString();
                }

                if (comboBox5HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox5HullOutfit.SelectedItem.ToString();
                }

                if (comboBox6HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox6HullOutfit.SelectedItem.ToString();
                }

                if (comboBox7HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox7HullOutfit.SelectedItem.ToString();
                }

                if (comboBox8HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox8HullOutfit.SelectedItem.ToString();
                }

                if (comboBox9HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox9HullOutfit.SelectedItem.ToString();
                }

                if (comboBox10HullOutfit.SelectedItem != null)
                {
                    HulloutfitDescription = HulloutfitDescription + " " + comboBox10HullOutfit.SelectedItem.ToString();
                }

                txtHulloutfitItemDesc.Text = HulloutfitDescription.Trim();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void generateHullOutfitCode()
        {
            try
            {
                string code = textBox1HullOutfit.Text +
                                          textBox2HullOutfit.Text +
                                          textBox3HullOutfit.Text +
                                          textBox4HullOutfit.Text +
                                          textBox5HullOutfit.Text +
                                          textBox6HullOutfit.Text +
                                          textBox7HullOutfit.Text +
                                          textBox8HullOutfit.Text +
                                          textBox9HullOutfit.Text +
                                          textBox10HullOutfit.Text;
                txtGeneratedCodeHullOutfit.Text = code;

                clsStaticGlobal._ItemCode = code;
                clsStaticGlobal._ItemsProjectCode = "";
                clsStaticGlobal._Unit = textBoxUnitHullOutfit.Text;
                clsStaticGlobal._ItemGroup = textBoxItemGroupHullOutfit.Text;
                clsStaticGlobal._BudgetSFI = txtSFICodeHullOutfit.Text;
                clsStaticGlobal._Desc = txtHulloutfitItemDesc.Text;
                clsStaticGlobal._Title = "Standard Hull outfit";

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void hideUnwantedControls(int fromCount)
        {
            try
            {
                for (int i = 2; i <= 10; i++)
                {
                    string name = "comboBox" + i.ToString() + "HullOutfit";
                    ComboBox cbo = FindChild<ComboBox>(gridHullOutfit, name);
                    cbo.Visibility = System.Windows.Visibility.Visible;
                    cbo.ItemsSource = null;

                    name = "label" + i.ToString() + "HullOutfit";
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridHullOutfit, name);
                    lbl.Visibility = System.Windows.Visibility.Visible;

                    name = "textBox" + i.ToString() + "HullOutfit";
                    TextBox txt = FindChild<TextBox>(gridHullOutfit, name);
                    txt.Visibility = System.Windows.Visibility.Visible;
                }
                cmbxItemGroupHullOutfit.ItemsSource = null;
                cmbxUnitHullOutfit.ItemsSource = null;
                for (int i = fromCount + 1; i <= 10; i++)
                {
                    string name = "comboBox" + i.ToString() + "HullOutfit";
                    ComboBox cbo = FindChild<ComboBox>(gridHullOutfit, name);
                    cbo.Visibility = System.Windows.Visibility.Collapsed;

                    name = "label" + i.ToString() + "HullOutfit";
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridHullOutfit, name);
                    lbl.Visibility = System.Windows.Visibility.Collapsed;

                    name = "textBox" + i.ToString() + "HullOutfit";
                    TextBox txt = FindChild<TextBox>(gridHullOutfit, name);
                    txt.Visibility = System.Windows.Visibility.Collapsed;
                }
                cmbxItemGroupHullOutfit.ItemsSource = itemGroups;
                cmbxUnitHullOutfit.ItemsSource = units;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void btnGenItemHullOutfit_Click(object sender, RoutedEventArgs e)
        {
            if (IsValidHullOutfit() == true)
            {
                generateHullOutfitCode();

                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtGeneratedCodeHullOutfit.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtGeneratedCodeHullOutfit.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (AddItem(txtGeneratedCodeHullOutfit.Text))
                        {
                            ExportItemCodeDetails("Standard");
                            MessageBox.Show(txtGeneratedCodeHullOutfit.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);
                            //clearHullOutfitComboBoxes(true);
                            //comboBox1HullOutfit.SelectedItem = null;
                            //cmbxItemGroupHullOutfit.SelectedItem = null;
                            //cmbxUnitHullOutfit.SelectedItem = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        #endregion

        #region "Events"

        private void txtSFICodeHullOutfit_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void txtSFICodeHullOutfit_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSFICodeDescHullOutfit.Text = "";
                var _res = _SFIcodes.Where(n => n.Code == txtSFICodeHullOutfit.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtSFICodeDescHullOutfit.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox1HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox1HullOutfit.Text = ((NameCodePair)comboBox1HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox1HullOutfit.Text = string.Empty;
                }

                clearHullOutfitComboBoxes(false);
                cmbxItemGroupHullOutfit.ItemsSource = itemGroups;
                cmbxUnitHullOutfit.ItemsSource = units;

                switch (((NameCodePair)comboBox1HullOutfit.SelectedItem).Name.ToUpper())
                {
                    case "ANGLE":
                        loadHullOutfitItems(false, "ANGLE");
                        hideUnwantedControls(8);
                        comboBox2HullOutfit.ItemsSource = angleTypes;
                        comboBox3HullOutfit.ItemsSource = angleStandards;
                        comboBox4HullOutfit.ItemsSource = angleHOClassCertificates;
                        comboBox5HullOutfit.ItemsSource = angleHOMaterials;
                        comboBox6HullOutfit.ItemsSource = angleSize1Collection;
                        comboBox7HullOutfit.ItemsSource = angleSize2Collection;
                        comboBox8HullOutfit.ItemsSource = angleThicknessCollection;
                        label2HullOutfit.Content = "Types";
                        label3HullOutfit.Content = "Standards";
                        label4HullOutfit.Content = "Class Certificates";
                        label5HullOutfit.Content = "Material Grade";
                        label6HullOutfit.Content = "Width 1";
                        label7HullOutfit.Content = "Width 2";
                        label8HullOutfit.Content = "Thickness";
                        break;
                    case "CHANNEL":
                        loadHullOutfitItems(false, "CHANNEL");
                        hideUnwantedControls(9);
                        comboBox2HullOutfit.ItemsSource = channelTypes;
                        comboBox3HullOutfit.ItemsSource = channelStandards;
                        comboBox4HullOutfit.ItemsSource = channelClassCertificates;
                        comboBox5HullOutfit.ItemsSource = channelMaterials;
                        comboBox6HullOutfit.ItemsSource = channelBredths;
                        comboBox7HullOutfit.ItemsSource = channelWidths;
                        comboBox8HullOutfit.ItemsSource = channelWebThicknesses;
                        comboBox9HullOutfit.ItemsSource = channelFlangeThicknesses;

                        label2HullOutfit.Content = "Types";
                        label3HullOutfit.Content = "Standards";
                        label4HullOutfit.Content = "Class Certificates";
                        label5HullOutfit.Content = "Material Grade";
                        label6HullOutfit.Content = "Breadth";
                        label7HullOutfit.Content = "Width";
                        label8HullOutfit.Content = "Web Thickness";
                        label9HullOutfit.Content = "Flange Thickness";
                        break;
                    case "BEAMS":
                        loadHullOutfitItems(false, "BEAMS");
                        hideUnwantedControls(9);
                        comboBox2HullOutfit.ItemsSource = beamTypes;
                        comboBox3HullOutfit.ItemsSource = beamStandards;
                        comboBox4HullOutfit.ItemsSource = beamClassCertificates;
                        comboBox5HullOutfit.ItemsSource = beamMaterials;
                        comboBox6HullOutfit.ItemsSource = beamHeights;
                        comboBox7HullOutfit.ItemsSource = beamFlangeWidths;
                        comboBox8HullOutfit.ItemsSource = beamWebThicknesses;
                        comboBox9HullOutfit.ItemsSource = beamFlangeThicknesses;

                        label2HullOutfit.Content = "Types";
                        label3HullOutfit.Content = "Standards";
                        label4HullOutfit.Content = "Certificates";
                        label5HullOutfit.Content = "Material Grade";
                        label6HullOutfit.Content = "Beam Height";
                        label7HullOutfit.Content = "Flange Width";
                        label8HullOutfit.Content = "Web Thickness";
                        label9HullOutfit.Content = "Flange Thickness";
                        break;
                    case "BARS":
                        loadHullOutfitItems(false, "BARS");
                        hideUnwantedControls(8);
                        comboBox2HullOutfit.ItemsSource = barsHOTypes;
                        comboBox3HullOutfit.ItemsSource = barsHOStandards;
                        comboBox4HullOutfit.ItemsSource = barsHOClassCertificates;
                        comboBox5HullOutfit.ItemsSource = barsHOMaterials;
                        comboBox6HullOutfit.ItemsSource = barsHODimention1;
                        comboBox7HullOutfit.ItemsSource = barsHODimention1;
                        comboBox8HullOutfit.ItemsSource = barsHOThicknesses;

                        label2HullOutfit.Content = "Types";
                        label3HullOutfit.Content = "Standards";
                        label4HullOutfit.Content = "Certificates";
                        label5HullOutfit.Content = "Material Grade";
                        label6HullOutfit.Content = "Dimention 1(mm)";
                        label7HullOutfit.Content = "Dimention 2(mm)ss";
                        label8HullOutfit.Content = "Thickness";

                        break;
                    case "HARDWARE MATERIAL":
                        loadHullOutfitItems(false, "HARDWARE MATERIAL");
                        hideUnwantedControls(10);
                        comboBox2HullOutfit.ItemsSource = hardwareItems;
                        comboBox3HullOutfit.ItemsSource = nullCollection;
                        comboBox4HullOutfit.ItemsSource = hardwareMaterials;
                        comboBox5HullOutfit.ItemsSource = hardwareSizes;
                        comboBox6HullOutfit.ItemsSource = hardwareLengths;
                        comboBox7HullOutfit.ItemsSource = hardwareThicknesses;
                        comboBox8HullOutfit.ItemsSource = hardwareTreatments;
                        comboBox9HullOutfit.ItemsSource = hardwareStandards;
                        comboBox10HullOutfit.ItemsSource = hardwareHoles;

                        label2HullOutfit.Content = "Hardware Item";
                        label3HullOutfit.Content = "Sub Type";
                        label4HullOutfit.Content = "Material";
                        label5HullOutfit.Content = "Size";
                        label6HullOutfit.Content = "Length";
                        label7HullOutfit.Content = "Thickness";
                        label8HullOutfit.Content = "Treatment";
                        label9HullOutfit.Content = "Standard";
                        label10HullOutfit.Content = "Hole";

                        break;
                    case "GRATING":
                        loadHullOutfitItems(false, "GRATING");
                        hideUnwantedControls(1);
                        break;
                    default:
                        hideUnwantedControls(10);
                        break;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox2HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox2HullOutfit.Text = ((NameCodePair)comboBox2HullOutfit.SelectedItem).Code;
                    switch (((NameCodePair)comboBox1HullOutfit.SelectedItem).Name.ToUpper())
                    {
                        case "HARDWARE MATERIAL":
                            clearHullOutfitComboBoxes(true);

                            comboBox4HullOutfit.ItemsSource = hardwareMaterials;
                            comboBox5HullOutfit.ItemsSource = hardwareSizes;
                            comboBox6HullOutfit.ItemsSource = hardwareLengths;
                            comboBox7HullOutfit.ItemsSource = hardwareThicknesses;
                            comboBox8HullOutfit.ItemsSource = hardwareTreatments;
                            comboBox9HullOutfit.ItemsSource = hardwareStandards;
                            comboBox10HullOutfit.ItemsSource = hardwareHoles;
                            comboBox3HullOutfit.ItemsSource = nullCollection;
                            switch (((NameCodePair)comboBox2HullOutfit.SelectedItem).Name.ToUpper())
                            {
                                case "BOLT":
                                    comboBox3HullOutfit.ItemsSource = hardwareBoltSubTypes;
                                    break;
                                case "SCREW":
                                    comboBox3HullOutfit.ItemsSource = hardwareScrewSubTypes;
                                    break;
                                case "NUT":
                                    comboBox3HullOutfit.ItemsSource = hardwareNutSubTypes;
                                    break;
                                case "WASHER":
                                    comboBox3HullOutfit.ItemsSource = hardwareWasherSubTypes;
                                    break;
                                case "GRUB SCREW":
                                    comboBox3HullOutfit.ItemsSource = hardwareGrubScrewSubTypes;
                                    break;
                                case "STUD":
                                    comboBox3HullOutfit.ItemsSource = hardwareStudSubTypes;
                                    break;
                                default:
                                    comboBox3HullOutfit.ItemsSource = nullCollection;
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    textBox2HullOutfit.Text = string.Empty;
                    comboBox3HullOutfit.ItemsSource = nullCollection;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void comboBox3HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox3HullOutfit.Text = ((NameCodePair)comboBox3HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox3HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox4HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox4HullOutfit.Text = ((NameCodePair)comboBox4HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox4HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox5HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox5HullOutfit.Text = ((NameCodePair)comboBox5HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox5HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox6HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox6HullOutfit.Text = ((NameCodePair)comboBox6HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox6HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox7HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox7HullOutfit.Text = ((NameCodePair)comboBox7HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox7HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox8HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox8HullOutfit.Text = ((NameCodePair)comboBox8HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox8HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox9HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox9HullOutfit.Text = ((NameCodePair)comboBox9HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox9HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBox10HullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBox10HullOutfit.Text = ((NameCodePair)comboBox10HullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBox10HullOutfit.Text = string.Empty;
                }
                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbxItemGroupHullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxItemGroupHullOutfit.Text = ((NameCodePair)cmbxItemGroupHullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBoxItemGroupHullOutfit.Text = string.Empty;
                }

                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbxUnitHullOutfit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxUnitHullOutfit.Text = ((NameCodePair)cmbxUnitHullOutfit.SelectedItem).Code;
                }
                else
                {
                    textBoxUnitHullOutfit.Text = string.Empty;
                }

                BindHulloutfitComboBoxesData();
                generateHullOutfitCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }


        #endregion

        #endregion

        #region Electrical

        private string ElectricalDescription = "";

        #region Electrical Objects

        ElectricalItems electricalItems;
        ElectricalItemGroups electricalItemGroups;
        ElectricalUnits electricalUnits;

        #region Cable Tray
        CableTrayTypes cableTrayTypes;
        CableTraySubTypes cableTraySubTypes;
        CableTraySizes cableTraySizes;
        CableTrayMaterials cableTrayMaterials;
        CableTrayLengths cableTrayLengths;
        CableTrayConnectionTypes cableTrayConnectionTypes;
        CableTrayTiers cableTrayTiers;
        #endregion

        #region Cable
        CableTypes cableTypes;
        CableElectricalClassApprovals cableElectricalClassApprovals;
        CableSubTypes cableSubTypes;
        CableInsolutions cableInsolutions;
        CableVoltages cableVoltages;
        CableSizes cableSizes;
        #endregion

        #region Cable Terminal Lug
        CableTerminalLugsTypes cableTerminalLugsTypes;
        CTLElecClassApprovals cTLElecClassApprovals;
        CTLSizes cTLSizes;
        #endregion

        #region Cable Glands
        CableGlandTypes cableGlandTypes;
        CableGlandSubTypes cableGlandSubTypes;
        CableGlandCableTypes cableGlandCableTypes;
        CableGlandMaterials cableGlandMaterials;
        CableGlandProofAndIps cableGlandProofAndIps;
        CableGlandCableODs cableGlandCableODs;
        #endregion

        #region RECEPTACLES
        ReceptacleTypes receptacleTypes;
        RsElecClassApprovals rsElecClassApprovals;
        RsProvisions rsProvisions;
        RsDescriptions rsDescriptions;
        RsSubtypes rsSubtypes;
        RsVoltages rsVoltages;
        #endregion

        #endregion

        #region Generating Code

        private void loadElectricalItems(bool isTabLoaded = false, string item = "")
        {
            try
            {
                if (isTabLoaded)
                {
                    electricalItems = ElectricalItems.LoadFromXml(dataPath);
                    electricalItemGroups = ElectricalItemGroups.LoadFromXml();
                    electricalUnits = ElectricalUnits.LoadFromXml();
                }

                switch (item.ToUpper())
                {
                    case "CABLE TRAY":
                        if (cableTrayTypes == null)
                        {
                            cableTrayTypes = CableTrayTypes.LoadFromXml();
                            cableTraySubTypes = CableTraySubTypes.LoadFromXml();
                            cableTraySizes = CableTraySizes.LoadFromXml();
                            cableTrayMaterials = CableTrayMaterials.LoadFromXml();
                            cableTrayLengths = CableTrayLengths.LoadFromXml();
                            cableTrayConnectionTypes = CableTrayConnectionTypes.LoadFromXml();
                            cableTrayTiers = CableTrayTiers.LoadFromXml();

                        }
                        break;
                    case "CABLE":
                        if (cableTypes == null)
                        {
                            cableTypes = CableTypes.LoadFromXml();
                            cableElectricalClassApprovals = CableElectricalClassApprovals.LoadFromXml();
                            cableSubTypes = CableSubTypes.LoadFromXml();
                            cableInsolutions = CableInsolutions.LoadFromXml();
                            cableVoltages = CableVoltages.LoadFromXml();
                            cableSizes = CableSizes.LoadFromXml();
                        }
                        break;
                    case "CABLE TERMINALS LUGS":
                        if (cableTerminalLugsTypes == null)
                        {
                            cableTerminalLugsTypes = CableTerminalLugsTypes.LoadFromXml();
                            cTLElecClassApprovals = CTLElecClassApprovals.LoadFromXml();
                            cTLSizes = CTLSizes.LoadFromXml();
                        }
                        break;
                    case "CABLE GLANDS":
                        if (cableGlandCableTypes == null)
                        {
                            cableGlandTypes = CableGlandTypes.LoadFromXml();
                            cableGlandSubTypes = CableGlandSubTypes.LoadFromXml();
                            cableGlandCableTypes = CableGlandCableTypes.LoadFromXml();
                            cableGlandMaterials = CableGlandMaterials.LoadFromXml();
                            cableGlandProofAndIps = CableGlandProofAndIps.LoadFromXml();
                            cableGlandCableODs = CableGlandCableODs.LoadFromXml();
                        }
                        break;

                    case "RECEPTACLES":
                        if (receptacleTypes == null)
                        {
                            receptacleTypes = ReceptacleTypes.LoadFromXml();
                            rsElecClassApprovals = RsElecClassApprovals.LoadFromXml();
                            rsProvisions = RsProvisions.LoadFromXml();
                            rsDescriptions = RsDescriptions.LoadFromXml();
                            rsSubtypes = RsSubtypes.LoadFromXml();
                            rsVoltages = RsVoltages.LoadFromXml();
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void InitializeElectricalTab()
        {
            try
            {
                comboBoxEle.ItemsSource = null;
                cmbxEleItemGroup.ItemsSource = null;
                cmbxEleUnit.ItemsSource = null;
                comboBoxEle.ItemsSource = electricalItems;
                cmbxEleItemGroup.ItemsSource = electricalItemGroups;
                cmbxEleUnit.ItemsSource = electricalUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void hideUnwantedEleControls(int fromCount)
        {
            try
            {
                for (int i = 2; i <= 10; i++)
                {
                    string name = "comboBoxEle" + i.ToString();
                    ComboBox cbo = FindChild<ComboBox>(gridElectrical, name);
                    cbo.Visibility = System.Windows.Visibility.Visible;
                    cbo.ItemsSource = null;

                    name = "labelEle" + i.ToString();
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridElectrical, name);
                    lbl.Visibility = System.Windows.Visibility.Visible;

                    name = "textBoxEle" + i.ToString();
                    TextBox txt = FindChild<TextBox>(gridElectrical, name);
                    txt.Visibility = System.Windows.Visibility.Visible;
                }
                cmbxEleItemGroup.ItemsSource = null;
                cmbxEleUnit.ItemsSource = null;
                for (int i = fromCount + 1; i <= 10; i++)
                {
                    string name = "comboBoxEle" + i.ToString();
                    ComboBox cbo = FindChild<ComboBox>(gridElectrical, name);
                    cbo.Visibility = System.Windows.Visibility.Collapsed;

                    name = "labelEle" + i.ToString();
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridElectrical, name);
                    lbl.Visibility = System.Windows.Visibility.Collapsed;

                    name = "textBoxEle" + i.ToString();
                    TextBox txt = FindChild<TextBox>(gridElectrical, name);
                    txt.Visibility = System.Windows.Visibility.Collapsed;
                }
                cmbxEleItemGroup.ItemsSource = electricalItemGroups;
                cmbxEleUnit.ItemsSource = electricalUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void OnElectricalTabSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                clearElectricalComboBoxes();

                loadElectricalItems(true);

                InitializeElectricalTab();

                //if (electricalItems == null)
                //{
                //    loadElectricalItems(true);

                //    InitializeElectricalTab();
                //}
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void btnEleGenItem_Click(object sender, RoutedEventArgs e)
        {

            if (IsValidEle() == true)
            {
                generateElectricalCode();
                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtEleGeneratedCode.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtEleGeneratedCode.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (AddItem(txtEleGeneratedCode.Text))
                        {
                            ExportItemCodeDetails("Standard");
                            MessageBox.Show(txtEleGeneratedCode.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);
                            //clearElectricalComboBoxes(true);
                            //comboBoxEle.SelectedItem = null;
                            //cmbxEleItemGroup.SelectedItem = null;
                            //cmbxEleUnit.SelectedItem = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private bool IsValidEle()
        {
            bool _IsValidEle = true;
            try
            {
                if ((comboBoxEle.IsVisible == true) && (comboBoxEle.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle2.IsVisible == true) && (comboBoxEle2.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((cmbxEleItemGroup.IsVisible == true) && (cmbxEleItemGroup.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((cmbxEleUnit.IsVisible == true) && (cmbxEleUnit.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle3.IsVisible == true) && (comboBoxEle3.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle4.IsVisible == true) && (comboBoxEle4.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle5.IsVisible == true) && (comboBoxEle5.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle6.IsVisible == true) && (comboBoxEle6.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle7.IsVisible == true) && (comboBoxEle7.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle8.IsVisible == true) && (comboBoxEle8.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle9.IsVisible == true) && (comboBoxEle9.SelectedItem == null))
                {
                    _IsValidEle = false;
                }
                if ((comboBoxEle10.IsVisible == true) && (comboBoxEle10.SelectedItem == null))
                {
                    _IsValidEle = false;
                }

                if (txtSFICodeEle.Text.Trim() == "")
                {
                    _IsValidEle = false;
                }
                if (txtSFICodeDescEle.Text.Trim() == "")
                {
                    _IsValidEle = false;
                }

                if (txtEleItemDesc.Text.Trim() == "")
                {
                    _IsValidEle = false;
                }

                if (txtEleGeneratedCode.Text.Trim() == "")
                {
                    _IsValidEle = false;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidEle;

        }

        private void clearElectricalComboBoxes(bool isSecondLevel = true)
        {
            try
            {
                if (!isSecondLevel)
                {
                    comboBoxEle2.ItemsSource = null;
                    cmbxEleItemGroup.ItemsSource = null;
                    cmbxEleUnit.ItemsSource = null;
                }

                comboBoxEle3.ItemsSource = null;
                comboBoxEle4.ItemsSource = null;
                comboBoxEle5.ItemsSource = null;
                comboBoxEle6.ItemsSource = null;
                comboBoxEle7.ItemsSource = null;
                comboBoxEle8.ItemsSource = null;
                comboBoxEle9.ItemsSource = null;
                comboBoxEle10.ItemsSource = null;
                txtSFICodeEle.Text = "";
                txtSFICodeDescEle.Text = "";
                txtEleItemDesc.Text = "";
                txtEleGeneratedCode.Text = "";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void BindElectricalComboBoxesData()
        {
            ElectricalDescription = "";

            try
            {
                if (comboBoxEle.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle.SelectedItem.ToString();
                }
                if (comboBoxEle2.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle2.SelectedItem.ToString();
                }

                if (comboBoxEle3.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle3.SelectedItem.ToString();
                }

                if (comboBoxEle4.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle4.SelectedItem.ToString();
                }

                if (comboBoxEle5.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle5.SelectedItem.ToString();
                }

                if (comboBoxEle6.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle6.SelectedItem.ToString();
                }

                if (comboBoxEle7.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle7.SelectedItem.ToString();
                }

                if (comboBoxEle8.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle8.SelectedItem.ToString();
                }

                if (comboBoxEle9.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle9.SelectedItem.ToString();
                }

                if (comboBoxEle10.SelectedItem != null)
                {
                    ElectricalDescription = ElectricalDescription + " " + comboBoxEle10.SelectedItem.ToString();
                }

                txtEleItemDesc.Text = ElectricalDescription.Trim();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void generateElectricalCode()
        {
            try
            {
                string code = textBoxEle1.Text +
                                          textBoxEle2.Text +
                                          textBoxEle3.Text +
                                          textBoxEle4.Text +
                                          textBoxEle5.Text +
                                          textBoxEle6.Text +
                                          textBoxEle7.Text +
                                          textBoxEle8.Text +
                                          textBoxEle9.Text +
                                          textBoxEle10.Text;
                txtEleGeneratedCode.Text = code;

                clsStaticGlobal._ItemCode = code;
                clsStaticGlobal._ItemsProjectCode = "";
                clsStaticGlobal._Unit = textBoxEleUnit.Text;
                clsStaticGlobal._ItemGroup = textBoxEleItemGroup.Text;
                clsStaticGlobal._BudgetSFI = txtSFICodeEle.Text;
                clsStaticGlobal._Desc = txtEleItemDesc.Text;
                clsStaticGlobal._Title = "Standard Electrical";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        #endregion

        #region "Events"

        private void txtSFICodeEle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void txtSFICodeEle_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSFICodeDescEle.Text = "";
                var _res = _SFIcodes.Where(n => n.Code == txtSFICodeEle.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtSFICodeDescEle.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle1.Text = ((NameCodePair)comboBoxEle.SelectedItem).Code;
                }
                else
                {
                    textBoxEle1.Text = string.Empty;
                }

                clearElectricalComboBoxes(false);
                cmbxEleItemGroup.ItemsSource = electricalItemGroups;
                cmbxEleUnit.ItemsSource = electricalUnits;

                switch (((NameCodePair)comboBoxEle.SelectedItem).Name.ToUpper())
                {
                    case "CABLE TRAY":
                        loadElectricalItems(false, "CABLE TRAY");
                        hideUnwantedEleControls(8);
                        comboBoxEle2.ItemsSource = cableTrayTypes;
                        comboBoxEle3.ItemsSource = cableTraySubTypes;
                        comboBoxEle4.ItemsSource = cableTraySizes;
                        comboBoxEle5.ItemsSource = cableTrayMaterials;
                        comboBoxEle6.ItemsSource = cableTrayLengths;
                        comboBoxEle7.ItemsSource = cableTrayConnectionTypes;
                        comboBoxEle8.ItemsSource = cableTrayTiers;
                        labelEle2.Content = "Type";
                        labelEle3.Content = "Sub Type";
                        labelEle4.Content = "Size (mm)";
                        labelEle5.Content = "Material Grade";
                        labelEle6.Content = "Length mm";
                        labelEle7.Content = "Connection Type";
                        labelEle8.Content = "Tiers";
                        break;
                    case "CABLES":
                        loadElectricalItems(false, "CABLE");
                        hideUnwantedEleControls(7);
                        comboBoxEle2.ItemsSource = cableTypes;
                        comboBoxEle3.ItemsSource = cableElectricalClassApprovals;
                        comboBoxEle4.ItemsSource = cableSubTypes;
                        comboBoxEle5.ItemsSource = cableInsolutions;
                        comboBoxEle6.ItemsSource = cableVoltages;
                        comboBoxEle7.ItemsSource = cableSizes;
                        labelEle2.Content = "Type";
                        labelEle3.Content = "Electrical Class Approval";
                        labelEle4.Content = "Sub Type";
                        labelEle5.Content = "Insolution";
                        labelEle6.Content = "Voltage";
                        labelEle7.Content = "Size";
                        break;
                    case "CABLE TERMINALS LUGS":
                        loadElectricalItems(false, "CABLE TERMINALS LUGS");
                        hideUnwantedEleControls(4);
                        comboBoxEle2.ItemsSource = cableTerminalLugsTypes;
                        comboBoxEle3.ItemsSource = cTLElecClassApprovals;
                        comboBoxEle4.ItemsSource = cTLSizes;

                        labelEle2.Content = "Type";
                        labelEle3.Content = "Electrical Class Approval";
                        labelEle4.Content = "Size";

                        break;
                    case "CABLE GLANDS":
                        loadElectricalItems(false, "CABLE GLANDS");
                        hideUnwantedEleControls(7);
                        comboBoxEle2.ItemsSource = cableGlandTypes;
                        comboBoxEle3.ItemsSource = cableGlandSubTypes;
                        comboBoxEle4.ItemsSource = cableGlandCableTypes;
                        comboBoxEle5.ItemsSource = cableGlandMaterials;
                        comboBoxEle6.ItemsSource = cableGlandProofAndIps;
                        comboBoxEle7.ItemsSource = cableGlandCableODs;

                        labelEle2.Content = "Type";
                        labelEle3.Content = "Sub Type";
                        labelEle4.Content = "Cable Type";
                        labelEle5.Content = "Material Grade";
                        labelEle6.Content = "Proof And IP";
                        labelEle7.Content = "Cable OD";

                        break;
                    case "RECEPTACLES":
                        loadElectricalItems(false, "RECEPTACLES");
                        hideUnwantedEleControls(7);
                        comboBoxEle2.ItemsSource = receptacleTypes;
                        comboBoxEle3.ItemsSource = rsElecClassApprovals;
                        comboBoxEle4.ItemsSource = rsProvisions;
                        comboBoxEle5.ItemsSource = rsDescriptions;
                        comboBoxEle6.ItemsSource = rsSubtypes;
                        comboBoxEle7.ItemsSource = rsVoltages;

                        labelEle2.Content = "Type";
                        labelEle3.Content = "Electrical Class Approvals";
                        labelEle4.Content = "Provision";
                        labelEle5.Content = "Description";
                        labelEle6.Content = "Sub Type";
                        labelEle7.Content = "Voltage";

                        break;
                    default:
                        break;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle2.Text = ((NameCodePair)comboBoxEle2.SelectedItem).Code;
                }
                else
                {
                    textBoxEle2.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle3.Text = ((NameCodePair)comboBoxEle3.SelectedItem).Code;
                }
                else
                {
                    textBoxEle3.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void comboBoxEle4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle4.Text = ((NameCodePair)comboBoxEle4.SelectedItem).Code;
                }
                else
                {
                    textBoxEle4.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle5_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle5.Text = ((NameCodePair)comboBoxEle5.SelectedItem).Code;
                }
                else
                {
                    textBoxEle5.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle6_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle6.Text = ((NameCodePair)comboBoxEle6.SelectedItem).Code;
                }
                else
                {
                    textBoxEle6.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle7_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle7.Text = ((NameCodePair)comboBoxEle7.SelectedItem).Code;
                }
                else
                {
                    textBoxEle7.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle8_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle8.Text = ((NameCodePair)comboBoxEle8.SelectedItem).Code;
                }
                else
                {
                    textBoxEle8.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle9_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle9.Text = ((NameCodePair)comboBoxEle9.SelectedItem).Code;
                }
                else
                {
                    textBoxEle9.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEle10_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEle10.Text = ((NameCodePair)comboBoxEle10.SelectedItem).Code;
                }
                else
                {
                    textBoxEle10.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbxEleItemGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEleItemGroup.Text = ((NameCodePair)cmbxEleItemGroup.SelectedItem).Code;
                }
                else
                {
                    textBoxEleItemGroup.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbxELeUnit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEleUnit.Text = ((NameCodePair)cmbxEleUnit.SelectedItem).Code;
                }
                else
                {
                    textBoxEleUnit.Text = string.Empty;
                }
                BindElectricalComboBoxesData();
                generateElectricalCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        #endregion

        #endregion

        #region Engineering

        private string EngineeringDescription = "";

        #region Objects
        EngineeringItems engineeringItems;
        EngineeringItemGroups engineeringItemGroups;
        EngineeringUnits engineeringUnits;

        #region Pipe
        PipeMainTypes pipeMainTypes;
        PipeSubTypes pipeSubTypes;
        PipeMaterialAndGrades pipeMaterialAndGrades;
        PipeStandards pipeStandards;
        PipeTubeStandards pipeTubeStandards;
        PipeCertificates pipeCertificates;
        PipeClassSociety pipeClassSociety;
        PipeSizes pipeSizes;
        PipeTubeSizes pipeTubeSizes;
        PipeLengths pipeLengths;
        PipeSchedules pipeSchedules;
        PipeTubeThicknesses pipeTubeThicknesses;
        #endregion

        #region FLANGE AND GASKET
        FlangeGasketMainTypes flangeGasketMainTypes;
        FlangeTypes flangeTypes;
        GasketTypes gasketTypes;
        FlangeMaterialGrades flangeMaterialGrades;
        GasketMaterials gasketMaterials;
        FlangeStandards flangeStandards;
        FlangeCertificates flangeCertificates;
        FlangeClassSocietys flangeClassSocietys;
        FlangeSizes flangeSizes;
        FlangeRatings flangeRatings;
        GasketThicknesses gasketThicknesses;
        #endregion

        #region FITTINGS BW
        BWCertificates bWCertificates;
        BWClassSociety bWClassSociety;
        BWFittingsTypes bWFittingsTypes;
        BWElbowSubTypes bWElbowSubTypes;
        BWFittingMaterialGrades bWFittingMaterialGrades;
        BWFittingStandards bWFittingStandards;
        BWPipeElbowSizes bWPipeElbowSizes;
        BWPipeElbowSchedules bWPipeElbowSchedules;
        BWTubeElbowSizes bWTubeElbowSizes;
        BWTubeElbowThicknesses bWTubeElbowThicknesses;
        BWTeeSubTypes bWTeeSubTypes;
        BWPipeTeeSize1s bWPipeTeeSize1s;
        BWPipeTeeSize2s bWPipeTeeSize2s;
        BWTubeTeeSize1s bWTubeTeeSize1s;
        BWTubeTeeSize2s bWTubeTeeSize2s;
        BWTubeTeeThickness1s bWTubeTeeThickness1s;
        BWTubeTeeThickness2s bWTubeTeeThickness2s;
        BWPipeReducerSubTypes bWPipeReducerSubTypes;
        BWERWReducerSubTypes bWERWReducerSubTypes;
        #endregion

        #region PIPE FITTINGS
        PipeFittingTypes pipeFittingTypes;
        PipeFittingElbowSubTypes pipeFittingElbowSubTypes;
        PipeFittingMaterialGrades pipeFittingMaterialGrades;
        PipeFittingSeals pipeFittingSeals;
        PipeFittingStandards pipeFittingStandards;
        PipeFittingEndConnection1 pipeFittingEndConnection1;
        PipeFittingEndConnection2 pipeFittingEndConnection2;
        PipeFittingCertificates pipeFittingCertificates;
        PipeFittingClassSociety pipeFittingClassSociety;
        PipeFittingSize1 pipeFittingSize1;
        PipeFittingSize2 pipeFittingSize2;
        PipeFittingRating pipeFittingRating;

        PipeFittingTeeSubTypes pipeFittingTeeSubTypes;
        PipeFittingAdaptorSubTypes pipeFittingAdaptorSubTypes;
        PipeFittingCouplingSubTypes pipeFittingCouplingSubTypes;
        PipeFittingNippleSubTypes pipeFittingNippleSubTypes;
        PipeFittingPlugSubTypes pipeFittingPlugSubTypes;
        PipeFittingCapSubTypes pipeFittingCapSubTypes;
        PipeFittingBushingSubTypes pipeFittingBushingSubTypes;
        PipeFittingHoseConnectionSubTypes pipeFittingHoseConnectionSubTypes;
        PipeFittingCrossSubTypes pipeFittingCrossSubTypes;
        PipeFittingRoxtecPenetrationSubTypes pipeFittingRoxtecPenetrationSubTypes;
        PipeFittingScupperSubTypes pipeFittingScupperSubTypes;
        PipeFittingMaleConnectorTypes pipeFittingMaleConnectorTypes;
        PipeFittingFemaleConnectorTypes pipeFittingFemaleConnectorTypes;
        PipeFittingSeaFlangeSubTypes pipeFittingSeaFlangeSubTypes;
        #endregion

        #region Valves
        ValveTypes valveTypes;
        ValveBodyMaterialGrades valveBodyMaterialGrades;
        ValveTrims valveTrims;
        ValveSeats valveSeats;
        ValveStandards valveStandards;
        ValveRatings valveRatings;
        ValveCertificates valveCertificates;
        ValveClassSocietys valveClassSocietys;
        ValveSizes valveSizes;
        ValveEndTypes valveEndTypes;
        ValveEndConnectionStandards valveEndConnectionStandards;
        ValveActuatorTypes valveActuatorTypes;
        ValveReferences valveReferences;

        ValveBallSubTypes valveBallSubTypes;
        ValveButerflySubTypes valveButerflySubTypes;
        ValveGlobeSubTypes valveGlobeSubTypes;
        ValveGateSubTypes valveGateSubTypes;
        ValveCheckSubTypes valveCheckSubTypes;
        ValveNeedleSubTypes valveNeedleSubTypes;
        ValvePressureRelifeSubTypes valvePressureRelifeSubTypes;
        ValvePressureReducingSubTypes valvePressureReducingSubTypes;
        ValvePressureRegulatingSubTypes valvePressureRegulatingSubTypes;
        ValveOtherSubTypes valveOtherSubTypes;

        #endregion

        #region STRAINERS
        StrainersTypes strainersTypes;
        StrainersBodies strainersBodies;
        StrainersFilterGauges strainersFilterGauges;
        StrainersStandards strainersStandards;
        StrainersRating strainersRating;
        StrainersThreadEndTypes strainersThreadEndTypes;
        StrainersCertificates strainersCertificates;
        StrainersClassSocietys strainersClassSocietys;
        StrainersSizes1 strainersSizes1;
        StrainersMeshSizes strainersMeshSizes;
        StrainersEndTypes strainersEndTypes;
        StrainersEndConnStandards strainersEndConnStandards;
        StrainersReferences strainersReferences;

        StrainersSimplexSubTypes strainersSimplexSubTypes;
        StrainersDuplexSubTypes strainersDuplexSubTypes;
        StrainersYTypeSubTypes strainersYTypeSubTypes;
        StrainersFootValveSubTypes strainersFootValveSubTypes;
        StrainersStrumBoxSubTypes strainersStrumBoxSubTypes;
        StrainersMudBoxSubTypes strainersMudBoxSubTypes;
        StrainersOtherFiltersSubTypes strainersOtherFiltersSubTypes;
        #endregion

        #region SUPPORTS
        SupportsTypes supportsTypes;
        SupportsCClampSubTypes supportsCClampSubTypes;
        SupportsCClampMaterialGrades supportsCClampMaterialGrades;
        SupportsStandards supportsStandards;
        SupportsRatings supportsRatings;
        SupportsCCLampCertificates supportsCCLampCertificates;
        SupportsCCLampClasseSocietys supportsCCLampClasseSocietys;
        SupportsSizes supportsSizes;
        SupportsFastnerTypes supportsFastnerTypes;
        SupportsReferences supportsReferences;

        SupportsUBoltSubTypes supportsUBoltSubTypes;
        SupportsHYDClampSubTypes supportsHYDClampSubTypes;
        SupportsHYDClampMaterialGrades supportsHYDClampMaterialGrades;
        SupportsHYDClampFastnerMaterialGrades supportsHYDClampFastnerMaterialGrades;
        SupportsHYDClampPlateMaterialGrades supportsHYDClampPlateMaterialGrades;
        SupportsPlateThicknesses supportsPlateThicknesses;
        SupportsPipeClampSubTypes supportsPipeClampSubTypes;

        #endregion

        #endregion

        #region Engineering Objects

        private void loadEngineeringItems(bool isTabLoaded = false, string item = "")
        {
            try
            {
                if (isTabLoaded)
                {
                    engineeringItems = EngineeringItems.LoadFromXml(dataPath);
                    engineeringItemGroups = EngineeringItemGroups.LoadFromXml();
                    engineeringUnits = EngineeringUnits.LoadFromXml();
                }

                switch (item.ToUpper())
                {
                    case "PIPES":
                        if (pipeMainTypes == null)
                        {
                            pipeMainTypes = PipeMainTypes.LoadFromXml();
                            pipeSubTypes = PipeSubTypes.LoadFromXml();
                            pipeMaterialAndGrades = PipeMaterialAndGrades.LoadFromXml();
                            pipeStandards = PipeStandards.LoadFromXml();
                            pipeTubeStandards = PipeTubeStandards.LoadFromXml();
                            pipeCertificates = PipeCertificates.LoadFromXml();
                            pipeClassSociety = PipeClassSociety.LoadFromXml();
                            pipeSizes = PipeSizes.LoadFromXml();
                            pipeTubeSizes = PipeTubeSizes.LoadFromXml();
                            pipeLengths = PipeLengths.LoadFromXml();
                            pipeSchedules = PipeSchedules.LoadFromXml();
                            pipeTubeThicknesses = PipeTubeThicknesses.LoadFromXml();
                        }
                        break;
                    case "FLANGES AND GASKETS":
                        if (flangeGasketMainTypes == null)
                        {
                            flangeGasketMainTypes = FlangeGasketMainTypes.LoadFromXml();
                            flangeTypes = FlangeTypes.LoadFromXml();
                            gasketTypes = GasketTypes.LoadFromXml();
                            flangeMaterialGrades = FlangeMaterialGrades.LoadFromXml();
                            gasketMaterials = GasketMaterials.LoadFromXml();
                            flangeStandards = FlangeStandards.LoadFromXml();
                            flangeCertificates = FlangeCertificates.LoadFromXml();
                            flangeClassSocietys = FlangeClassSocietys.LoadFromXml();
                            flangeSizes = FlangeSizes.LoadFromXml();
                            flangeRatings = FlangeRatings.LoadFromXml();
                            gasketThicknesses = GasketThicknesses.LoadFromXml();
                        }
                        break;
                    case "FITTINGS BW":
                        if (bWFittingsTypes == null)
                        {
                            bWCertificates = BWCertificates.LoadFromXml();
                            bWClassSociety = BWClassSociety.LoadFromXml();
                            bWFittingsTypes = BWFittingsTypes.LoadFromXml();
                            bWElbowSubTypes = BWElbowSubTypes.LoadFromXml();
                            bWFittingMaterialGrades = BWFittingMaterialGrades.LoadFromXml();
                            bWFittingStandards = BWFittingStandards.LoadFromXml();
                            bWPipeElbowSizes = BWPipeElbowSizes.LoadFromXml();
                            bWPipeElbowSchedules = BWPipeElbowSchedules.LoadFromXml();
                            bWTubeElbowSizes = BWTubeElbowSizes.LoadFromXml();
                            bWTubeElbowThicknesses = BWTubeElbowThicknesses.LoadFromXml();
                            bWTeeSubTypes = BWTeeSubTypes.LoadFromXml();
                            bWPipeTeeSize1s = BWPipeTeeSize1s.LoadFromXml();
                            bWPipeTeeSize2s = BWPipeTeeSize2s.LoadFromXml();
                            bWTubeTeeSize1s = BWTubeTeeSize1s.LoadFromXml();
                            bWTubeTeeSize2s = BWTubeTeeSize2s.LoadFromXml();
                            bWTubeTeeThickness1s = BWTubeTeeThickness1s.LoadFromXml();
                            bWTubeTeeThickness2s = BWTubeTeeThickness2s.LoadFromXml();
                            bWPipeReducerSubTypes = BWPipeReducerSubTypes.LoadFromXml();
                            bWERWReducerSubTypes = BWERWReducerSubTypes.LoadFromXml();
                        }
                        break;
                    case "PIPE FITTINGS":
                        if (pipeFittingTypes == null)
                        {
                            pipeFittingTypes = PipeFittingTypes.LoadFromXml();
                            pipeFittingElbowSubTypes = PipeFittingElbowSubTypes.LoadFromXml();
                            pipeFittingMaterialGrades = PipeFittingMaterialGrades.LoadFromXml();
                            pipeFittingSeals = PipeFittingSeals.LoadFromXml();
                            pipeFittingStandards = PipeFittingStandards.LoadFromXml();
                            pipeFittingEndConnection1 = PipeFittingEndConnection1.LoadFromXml();
                            pipeFittingEndConnection2 = PipeFittingEndConnection2.LoadFromXml();
                            pipeFittingCertificates = PipeFittingCertificates.LoadFromXml();
                            pipeFittingClassSociety = PipeFittingClassSociety.LoadFromXml();
                            pipeFittingSize1 = PipeFittingSize1.LoadFromXml();
                            pipeFittingSize2 = PipeFittingSize2.LoadFromXml();
                            pipeFittingRating = PipeFittingRating.LoadFromXml();

                            pipeFittingTeeSubTypes = PipeFittingTeeSubTypes.LoadFromXml();
                            pipeFittingAdaptorSubTypes = PipeFittingAdaptorSubTypes.LoadFromXml();
                            pipeFittingCouplingSubTypes = PipeFittingCouplingSubTypes.LoadFromXml();
                            pipeFittingNippleSubTypes = PipeFittingNippleSubTypes.LoadFromXml();
                            pipeFittingPlugSubTypes = PipeFittingPlugSubTypes.LoadFromXml();
                            pipeFittingCapSubTypes = PipeFittingCapSubTypes.LoadFromXml();
                            pipeFittingBushingSubTypes = PipeFittingBushingSubTypes.LoadFromXml();
                            pipeFittingHoseConnectionSubTypes = PipeFittingHoseConnectionSubTypes.LoadFromXml();
                            pipeFittingCrossSubTypes = PipeFittingCrossSubTypes.LoadFromXml();
                            pipeFittingRoxtecPenetrationSubTypes = PipeFittingRoxtecPenetrationSubTypes.LoadFromXml();
                            pipeFittingScupperSubTypes = PipeFittingScupperSubTypes.LoadFromXml();
                            pipeFittingMaleConnectorTypes = PipeFittingMaleConnectorTypes.LoadFromXml();
                            pipeFittingFemaleConnectorTypes = PipeFittingFemaleConnectorTypes.LoadFromXml();
                            pipeFittingSeaFlangeSubTypes = PipeFittingSeaFlangeSubTypes.LoadFromXml();
                        }
                        break;
                    case "VALVES":
                        if (valveTypes == null)
                        {
                            valveTypes = ValveTypes.LoadFromXml();
                            valveBodyMaterialGrades = ValveBodyMaterialGrades.LoadFromXml();
                            valveTrims = ValveTrims.LoadFromXml();
                            valveSeats = ValveSeats.LoadFromXml();
                            valveStandards = ValveStandards.LoadFromXml();
                            valveRatings = ValveRatings.LoadFromXml();
                            valveCertificates = ValveCertificates.LoadFromXml();
                            valveClassSocietys = ValveClassSocietys.LoadFromXml();
                            valveSizes = ValveSizes.LoadFromXml();
                            valveEndTypes = ValveEndTypes.LoadFromXml();
                            valveEndConnectionStandards = ValveEndConnectionStandards.LoadFromXml();
                            valveActuatorTypes = ValveActuatorTypes.LoadFromXml();
                            valveReferences = ValveReferences.LoadFromXml();

                            valveBallSubTypes = ValveBallSubTypes.LoadFromXml();
                            valveButerflySubTypes = ValveButerflySubTypes.LoadFromXml();
                            valveGlobeSubTypes = ValveGlobeSubTypes.LoadFromXml();
                            valveGateSubTypes = ValveGateSubTypes.LoadFromXml();
                            valveCheckSubTypes = ValveCheckSubTypes.LoadFromXml();
                            valveNeedleSubTypes = ValveNeedleSubTypes.LoadFromXml();
                            valvePressureRelifeSubTypes = ValvePressureRelifeSubTypes.LoadFromXml();
                            valvePressureReducingSubTypes = ValvePressureReducingSubTypes.LoadFromXml();
                            valvePressureRegulatingSubTypes = ValvePressureRegulatingSubTypes.LoadFromXml();
                            valveOtherSubTypes = ValveOtherSubTypes.LoadFromXml();
                        }
                        break;
                    case "STRAINER":
                        if (strainersTypes == null)
                        {
                            strainersTypes = StrainersTypes.LoadFromXml();
                            strainersBodies = StrainersBodies.LoadFromXml();
                            strainersFilterGauges = StrainersFilterGauges.LoadFromXml();
                            strainersStandards = StrainersStandards.LoadFromXml();
                            strainersRating = StrainersRating.LoadFromXml();
                            strainersThreadEndTypes = StrainersThreadEndTypes.LoadFromXml();
                            strainersCertificates = StrainersCertificates.LoadFromXml();
                            strainersClassSocietys = StrainersClassSocietys.LoadFromXml();
                            strainersSizes1 = StrainersSizes1.LoadFromXml();
                            strainersMeshSizes = StrainersMeshSizes.LoadFromXml();
                            strainersEndTypes = StrainersEndTypes.LoadFromXml();
                            strainersEndConnStandards = StrainersEndConnStandards.LoadFromXml();
                            strainersReferences = StrainersReferences.LoadFromXml();

                            strainersSimplexSubTypes = StrainersSimplexSubTypes.LoadFromXml();
                            strainersDuplexSubTypes = StrainersDuplexSubTypes.LoadFromXml();
                            strainersYTypeSubTypes = StrainersYTypeSubTypes.LoadFromXml();
                            strainersFootValveSubTypes = StrainersFootValveSubTypes.LoadFromXml();
                            strainersStrumBoxSubTypes = StrainersStrumBoxSubTypes.LoadFromXml();
                            strainersMudBoxSubTypes = StrainersMudBoxSubTypes.LoadFromXml();
                            strainersOtherFiltersSubTypes = StrainersOtherFiltersSubTypes.LoadFromXml();
                        }
                        break;
                    case "SUPPORTS":
                        if (supportsTypes == null)
                        {
                            supportsTypes = SupportsTypes.LoadFromXml();
                            supportsCClampSubTypes = SupportsCClampSubTypes.LoadFromXml();
                            supportsCClampMaterialGrades = SupportsCClampMaterialGrades.LoadFromXml();
                            supportsStandards = SupportsStandards.LoadFromXml();
                            supportsRatings = SupportsRatings.LoadFromXml();
                            supportsCCLampCertificates = SupportsCCLampCertificates.LoadFromXml();
                            supportsCCLampClasseSocietys = SupportsCCLampClasseSocietys.LoadFromXml();
                            supportsSizes = SupportsSizes.LoadFromXml();
                            supportsFastnerTypes = SupportsFastnerTypes.LoadFromXml();
                            supportsReferences = SupportsReferences.LoadFromXml();

                            supportsUBoltSubTypes = SupportsUBoltSubTypes.LoadFromXml();
                            supportsHYDClampSubTypes = SupportsHYDClampSubTypes.LoadFromXml();
                            supportsHYDClampMaterialGrades = SupportsHYDClampMaterialGrades.LoadFromXml();
                            supportsHYDClampFastnerMaterialGrades = SupportsHYDClampFastnerMaterialGrades.LoadFromXml();
                            supportsHYDClampPlateMaterialGrades = SupportsHYDClampPlateMaterialGrades.LoadFromXml();
                            supportsPlateThicknesses = SupportsPlateThicknesses.LoadFromXml();
                            supportsPipeClampSubTypes = SupportsPipeClampSubTypes.LoadFromXml();
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void InitializeEngineeringTab()
        {
            try
            {
                comboBoxEngg.ItemsSource = engineeringItems;
                cmbxEnggItemGroup.ItemsSource = engineeringItemGroups;
                cmbxEnggUnit.ItemsSource = engineeringUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        int enggItemsCount = 16;

        private void hideUnwantedEnggControls(int fromCount)
        {
            try
            {
                for (int i = 2; i <= enggItemsCount; i++)
                {
                    string name = "comboBoxEngg" + i.ToString();
                    ComboBox cbo = FindChild<ComboBox>(gridEngg, name);
                    cbo.Visibility = System.Windows.Visibility.Visible;
                    cbo.ItemsSource = null;

                    name = "labelEngg" + i.ToString();
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridEngg, name);
                    lbl.Visibility = System.Windows.Visibility.Visible;

                    name = "textBoxEngg" + i.ToString();
                    TextBox txt = FindChild<TextBox>(gridEngg, name);
                    txt.Visibility = System.Windows.Visibility.Visible;
                }
                cmbxEnggItemGroup.ItemsSource = null;
                cmbxEnggUnit.ItemsSource = null;

                for (int i = fromCount + 1; i <= enggItemsCount; i++)
                {
                    string name = "comboBoxEngg" + i.ToString();
                    ComboBox cbo = FindChild<ComboBox>(gridEngg, name);
                    cbo.Visibility = System.Windows.Visibility.Collapsed;

                    name = "labelEngg" + i.ToString();
                    System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridEngg, name);
                    lbl.Visibility = System.Windows.Visibility.Collapsed;

                    name = "textBoxEngg" + i.ToString();
                    TextBox txt = FindChild<TextBox>(gridEngg, name);
                    txt.Visibility = System.Windows.Visibility.Collapsed;
                }
                cmbxEnggItemGroup.ItemsSource = engineeringItemGroups;
                cmbxEnggUnit.ItemsSource = engineeringUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void OnEngineeringTabSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                clearEngineeringComboBoxes();
                loadEngineeringItems(true);
                InitializeEngineeringTab();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void btnEnggGenItem_Click(object sender, RoutedEventArgs e)
        {
            if (IsValidEngg() == true)
            {
                generateEngineeringCode();
                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtEnggGeneratedCode.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtEnggGeneratedCode.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception)
                {
                    try
                    {
                        if (AddItem(txtEnggGeneratedCode.Text))
                        {
                            ExportItemCodeDetails("Standard");
                            MessageBox.Show(txtEnggGeneratedCode.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);
                            //clearEngineeringComboBoxes(true);
                            //comboBoxEngg.SelectedItem = null;
                            //cmbxEnggItemGroup.SelectedItem = null;
                            //cmbxEnggUnit.SelectedItem = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private bool IsValidEngg()
        {
            bool _IsValidEngg = true;
            try
            {
                if ((comboBoxEngg.IsVisible == true) && (comboBoxEngg.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg2.IsVisible == true) && (comboBoxEngg2.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((cmbxEnggItemGroup.IsVisible == true) && (cmbxEnggItemGroup.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((cmbxEnggUnit.IsVisible == true) && (cmbxEnggUnit.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg3.IsVisible == true) && (comboBoxEngg3.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg4.IsVisible == true) && (comboBoxEngg4.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg5.IsVisible == true) && (comboBoxEngg5.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg6.IsVisible == true) && (comboBoxEngg6.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg7.IsVisible == true) && (comboBoxEngg7.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg8.IsVisible == true) && (comboBoxEngg8.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg9.IsVisible == true) && (comboBoxEngg9.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg10.IsVisible == true) && (comboBoxEngg10.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }

                if ((comboBoxEngg11.IsVisible == true) && (comboBoxEngg11.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg12.IsVisible == true) && (comboBoxEngg12.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg13.IsVisible == true) && (comboBoxEngg13.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg14.IsVisible == true) && (comboBoxEngg14.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg15.IsVisible == true) && (comboBoxEngg15.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }
                if ((comboBoxEngg16.IsVisible == true) && (comboBoxEngg16.SelectedItem == null))
                {
                    _IsValidEngg = false;
                }

                if (txtSFICodeEngg.Text.Trim() == "")
                {
                    _IsValidEngg = false;
                }
                if (txtSFICodeDescEngg.Text.Trim() == "")
                {
                    _IsValidEngg = false;
                }

                if (txtEnggItemDesc.Text.Trim() == "")
                {
                    _IsValidEngg = false;
                }

                if (txtEnggGeneratedCode.Text.Trim() == "")
                {
                    _IsValidEngg = false;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidEngg;

        }

        private void clearEngineeringComboBoxes(bool isSecondLevel = true)
        {
            try
            {
                if (!isSecondLevel)
                {
                    comboBoxEngg2.ItemsSource = null;
                    cmbxEnggItemGroup.ItemsSource = null;
                    cmbxEnggUnit.ItemsSource = null;

                    HideShowEnggCombobox(false, 15);
                    HideShowEnggCombobox(false, 8);

                }
                comboBoxEngg3.ItemsSource = null;
                comboBoxEngg4.ItemsSource = null;
                comboBoxEngg5.ItemsSource = null;
                comboBoxEngg6.ItemsSource = null;
                comboBoxEngg7.ItemsSource = null;
                comboBoxEngg8.ItemsSource = null;
                comboBoxEngg9.ItemsSource = null;
                comboBoxEngg10.ItemsSource = null;
                comboBoxEngg11.ItemsSource = null;
                comboBoxEngg12.ItemsSource = null;
                comboBoxEngg13.ItemsSource = null;
                comboBoxEngg14.ItemsSource = null;
                comboBoxEngg15.ItemsSource = null;
                comboBoxEngg16.ItemsSource = null;
                comboBoxEngg16.Items.Clear();
                txtSFICodeEngg.Text = "";
                txtSFICodeDescEngg.Text = "";
                txtEnggItemDesc.Text = "";
                txtEnggGeneratedCode.Text = "";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void BindEngineeringComboBoxesData()
        {
            EngineeringDescription = "";

            try
            {
                if (comboBoxEngg.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg.SelectedItem.ToString();
                }
                if (comboBoxEngg2.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg2.SelectedItem.ToString();
                }

                if (comboBoxEngg3.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg3.SelectedItem.ToString();
                }

                if (comboBoxEngg4.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg4.SelectedItem.ToString();
                }

                if (comboBoxEngg5.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg5.SelectedItem.ToString();
                }

                if (comboBoxEngg6.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg6.SelectedItem.ToString();
                }

                if (comboBoxEngg7.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg7.SelectedItem.ToString();
                }

                if (comboBoxEngg8.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg8.SelectedItem.ToString();
                }

                if (comboBoxEngg9.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg9.SelectedItem.ToString();
                }

                if (comboBoxEngg10.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg10.SelectedItem.ToString();
                }

                if (comboBoxEngg11.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg11.SelectedItem.ToString();
                }

                if (comboBoxEngg12.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg12.SelectedItem.ToString();
                }

                if (comboBoxEngg13.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg13.SelectedItem.ToString();
                }

                if (comboBoxEngg14.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg14.SelectedItem.ToString();
                }

                if (comboBoxEngg15.SelectedItem != null)
                {
                    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg15.SelectedItem.ToString();
                }

                //if (comboBoxEngg16.SelectedItem != null)
                //{
                //    EngineeringDescription = EngineeringDescription + " " + comboBoxEngg16.SelectedItem.ToString();
                //}

                txtEnggItemDesc.Text = EngineeringDescription.Trim();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void generateEngineeringCode()
        {
            try
            {
                string code = (!string.IsNullOrEmpty(textBoxEngg1.Text) ? (textBoxEngg1.Text.Trim() == "-" ? "" : textBoxEngg1.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg2.Text) ? (textBoxEngg2.Text.Trim() == "-" ? "" : textBoxEngg2.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg3.Text) ? (textBoxEngg3.Text.Trim() == "-" ? "" : textBoxEngg3.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg4.Text) ? (textBoxEngg4.Text.Trim() == "-" ? "" : textBoxEngg4.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg5.Text) ? (textBoxEngg5.Text.Trim() == "-" ? "" : textBoxEngg5.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg6.Text) ? (textBoxEngg6.Text.Trim() == "-" ? "" : textBoxEngg6.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg7.Text) ? (textBoxEngg7.Text.Trim() == "-" ? "" : textBoxEngg7.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg8.Text) ? (textBoxEngg8.Text.Trim() == "-" ? "" : textBoxEngg8.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg9.Text) ? (textBoxEngg9.Text.Trim() == "-" ? "" : textBoxEngg9.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg10.Text) ? (textBoxEngg10.Text.Trim() == "-" ? "" : textBoxEngg10.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg11.Text) ? (textBoxEngg11.Text.Trim() == "-" ? "" : textBoxEngg11.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg12.Text) ? (textBoxEngg12.Text.Trim() == "-" ? "" : textBoxEngg12.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg13.Text) ? (textBoxEngg13.Text.Trim() == "-" ? "" : textBoxEngg13.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg14.Text) ? (textBoxEngg14.Text.Trim() == "-" ? "" : textBoxEngg14.Text.Trim()) : "") +
                                          (!string.IsNullOrEmpty(textBoxEngg15.Text) ? (textBoxEngg15.Text.Trim() == "-" ? "" : textBoxEngg15.Text.Trim()) : "");

                txtEnggGeneratedCode.Text = code;
                clsStaticGlobal._ItemCode = code;
                if (comboBoxEngg16.SelectedItem != null)
                {
                    if ((comboBoxEngg.SelectedItem.ToString() == "VALVES") || (comboBoxEngg.SelectedItem.ToString() == "STRAINER"))
                    {
                        clsStaticGlobal._ItemsProjectCode = comboBoxEngg16.SelectedItem.ToString();
                    }
                    else
                    {
                        clsStaticGlobal._ItemsProjectCode = "";
                    }
                }
                clsStaticGlobal._Unit = textBoxEnggUnit.Text;
                clsStaticGlobal._ItemGroup = textBoxEnggItemGroup.Text;
                clsStaticGlobal._BudgetSFI = txtSFICodeEngg.Text;
                clsStaticGlobal._Desc = txtEnggItemDesc.Text;
                clsStaticGlobal._Title = "Standard Engineering";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void HideShowEnggCombobox(bool Hide, int ComboboxCnt)
        {
            if (Hide)
            {
                string name = "comboBoxEngg" + ComboboxCnt.ToString();
                ComboBox cbo = FindChild<ComboBox>(gridEngg, name);
                cbo.Visibility = System.Windows.Visibility.Hidden;
                cbo.ItemsSource = null;

                name = "labelEngg" + ComboboxCnt.ToString();
                System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridEngg, name);
                lbl.Visibility = System.Windows.Visibility.Hidden;

                name = "textBoxEngg" + ComboboxCnt.ToString();
                TextBox txt = FindChild<TextBox>(gridEngg, name);
                txt.Visibility = System.Windows.Visibility.Hidden;
            }
            else
            {
                string name = "comboBoxEngg" + ComboboxCnt.ToString();
                ComboBox cbo = FindChild<ComboBox>(gridEngg, name);
                cbo.Visibility = System.Windows.Visibility.Visible;
                cbo.ItemsSource = null;

                name = "labelEngg" + ComboboxCnt.ToString();
                System.Windows.Controls.Label lbl = FindChild<System.Windows.Controls.Label>(gridEngg, name);
                lbl.Visibility = System.Windows.Visibility.Visible;

                name = "textBoxEngg" + ComboboxCnt.ToString();
                TextBox txt = FindChild<TextBox>(gridEngg, name);
                txt.Visibility = System.Windows.Visibility.Visible;
            }

        }

        #endregion

        #region "Events"

        private void txtSFICodeEngg_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSFICodeDescEngg.Text = "";
                var _res = _SFIcodes.Where(n => n.Code == txtSFICodeEngg.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtSFICodeDescEngg.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void txtSFICodeEngg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void comboBoxEngg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg1.Text = ((NameCodePair)comboBoxEngg.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg1.Text = string.Empty;
                }

                clearEngineeringComboBoxes(false);
                cmbxEnggItemGroup.ItemsSource = engineeringItemGroups;
                cmbxEnggUnit.ItemsSource = engineeringUnits;

                switch (((NameCodePair)comboBoxEngg.SelectedItem).Name.ToUpper())
                {
                    case "PIPES":
                        loadEngineeringItems(false, "PIPES");
                        hideUnwantedEnggControls(10);
                        comboBoxEngg2.ItemsSource = pipeMainTypes;
                        comboBoxEngg3.ItemsSource = pipeSubTypes;
                        comboBoxEngg4.ItemsSource = pipeMaterialAndGrades;
                        comboBoxEngg5.ItemsSource = pipeStandards;
                        comboBoxEngg6.ItemsSource = pipeCertificates;
                        comboBoxEngg7.ItemsSource = pipeClassSociety;
                        comboBoxEngg8.ItemsSource = pipeSizes;
                        comboBoxEngg9.ItemsSource = pipeLengths;
                        comboBoxEngg10.ItemsSource = pipeSchedules;
                        labelEngg2.Content = "Main Type";
                        labelEngg3.Content = "Sub Type";
                        labelEngg4.Content = "Material and Grade";
                        labelEngg5.Content = "Standard";
                        labelEngg6.Content = "Certificate";
                        labelEngg7.Content = "Class / Society";
                        labelEngg8.Content = "Size (NB)/(OD) ";
                        labelEngg9.Content = "Length (NB)";
                        labelEngg10.Content = "Schedule / Thickness";
                        break;
                    case "FLANGES AND GASKETS":
                        loadEngineeringItems(false, "FLANGES AND GASKETS");
                        hideUnwantedEnggControls(10);
                        comboBoxEngg2.ItemsSource = flangeGasketMainTypes;
                        comboBoxEngg3.ItemsSource = flangeTypes;
                        comboBoxEngg4.ItemsSource = flangeMaterialGrades;
                        comboBoxEngg5.ItemsSource = flangeStandards;
                        comboBoxEngg6.ItemsSource = flangeCertificates;
                        comboBoxEngg7.ItemsSource = flangeClassSocietys;
                        comboBoxEngg8.ItemsSource = flangeSizes;
                        comboBoxEngg9.ItemsSource = flangeRatings;
                        comboBoxEngg10.ItemsSource = nullCollection;
                        labelEngg2.Content = "FLANGE OR GASKET";
                        labelEngg3.Content = "Type";
                        labelEngg4.Content = "Material and Grade";
                        labelEngg5.Content = "Standard";
                        labelEngg6.Content = "Certificate";
                        labelEngg7.Content = "Class / Society";
                        labelEngg8.Content = "Size (NB)";
                        labelEngg9.Content = "RATING";
                        labelEngg10.Content = "Gasket Thickness";
                        break;
                    case "FITTINGS BW":
                        loadEngineeringItems(false, "FITTINGS BW");
                        hideUnwantedEnggControls(10);
                        comboBoxEngg2.ItemsSource = bWFittingsTypes;
                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = bWFittingMaterialGrades;
                        comboBoxEngg5.ItemsSource = bWFittingStandards;
                        comboBoxEngg6.ItemsSource = bWCertificates;
                        comboBoxEngg7.ItemsSource = bWClassSociety;
                        comboBoxEngg8.ItemsSource = nullCollection;
                        comboBoxEngg9.ItemsSource = nullCollection;
                        comboBoxEngg10.ItemsSource = nullCollection;
                        labelEngg2.Content = "BW Fittings Type";
                        labelEngg3.Content = "Sub Type";
                        labelEngg4.Content = "Material and Grade";
                        labelEngg5.Content = "Standard";
                        labelEngg6.Content = "Certificate";
                        labelEngg7.Content = "Class / Society";
                        labelEngg8.Content = "Tee Size 2";
                        labelEngg9.Content = "Tee Size 2";
                        labelEngg10.Content = "Elbow Thickness/Schedule/Tee Thichness 1";
                        labelEngg11.Content = "Tee Thichness 2";
                        break;
                    case "PIPE FITTINGS":
                        loadEngineeringItems(false, "PIPE FITTINGS");
                        hideUnwantedEnggControls(13);
                        comboBoxEngg2.ItemsSource = pipeFittingTypes;
                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = pipeFittingMaterialGrades;
                        comboBoxEngg5.ItemsSource = pipeFittingSeals;
                        comboBoxEngg6.ItemsSource = pipeFittingStandards;
                        comboBoxEngg7.ItemsSource = pipeFittingEndConnection1;
                        comboBoxEngg8.ItemsSource = pipeFittingEndConnection1;
                        comboBoxEngg9.ItemsSource = pipeFittingCertificates;
                        comboBoxEngg10.ItemsSource = pipeFittingClassSociety;
                        comboBoxEngg11.ItemsSource = pipeFittingSize1;
                        comboBoxEngg12.ItemsSource = pipeFittingSize2;
                        comboBoxEngg13.ItemsSource = pipeFittingRating;
                        labelEngg2.Content = "Main Type";
                        labelEngg3.Content = "N/A";
                        labelEngg4.Content = "Material and Grade";
                        labelEngg5.Content = "Seal";
                        labelEngg6.Content = "Standard";
                        labelEngg7.Content = "End Connection 1";
                        labelEngg8.Content = "End Connection 2";
                        labelEngg9.Content = "Certificate";
                        labelEngg10.Content = "Class / Society";
                        labelEngg11.Content = "Size 1";
                        labelEngg12.Content = "Size 2";
                        labelEngg13.Content = "Rating";
                        break;
                    case "VALVES":
                        loadEngineeringItems(false, "VALVES");
                        hideUnwantedEnggControls(16);
                        comboBoxEngg2.ItemsSource = valveTypes;
                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = valveBodyMaterialGrades;
                        comboBoxEngg5.ItemsSource = valveTrims;
                        comboBoxEngg6.ItemsSource = valveSeats;
                        comboBoxEngg7.ItemsSource = valveStandards;
                        comboBoxEngg8.ItemsSource = valveRatings;
                        comboBoxEngg9.ItemsSource = valveCertificates;
                        comboBoxEngg10.ItemsSource = valveClassSocietys;
                        comboBoxEngg11.ItemsSource = valveSizes;
                        comboBoxEngg12.ItemsSource = valveEndTypes;
                        comboBoxEngg13.ItemsSource = valveEndConnectionStandards;
                        comboBoxEngg14.ItemsSource = valveActuatorTypes;
                        //comboBoxEngg15.ItemsSource = valveReferences;

                        comboBoxEngg16.Items.Clear();
                        clsStaticGlobal.ProjectCodeItemCollection.Clear();
                        GetProjectCodes();
                        foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                        {
                            comboBoxEngg16.Items.Add(item.ProjectCodeName);
                        }

                        labelEngg2.Content = "Type";
                        labelEngg3.Content = "Sub Type";
                        labelEngg4.Content = "Body Material and Grade";
                        labelEngg5.Content = "Trim";
                        labelEngg6.Content = "Seat";
                        labelEngg7.Content = "Standard";
                        labelEngg8.Content = "Rating";
                        labelEngg9.Content = "Certificate";
                        labelEngg10.Content = "Class / Society";
                        labelEngg11.Content = "Size 1";
                        labelEngg12.Content = "End Type";
                        labelEngg13.Content = "End Conn. Standard";
                        labelEngg14.Content = "Actuator Type";
                        //labelEngg15.Content = "Reference";
                        labelEngg16.Content = "Project Number";
                        HideShowEnggCombobox(true, 15);
                        break;
                    case "STRAINER":
                        loadEngineeringItems(false, "STRAINER");
                        hideUnwantedEnggControls(16);
                        comboBoxEngg2.ItemsSource = strainersTypes;
                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = strainersBodies;
                        comboBoxEngg5.ItemsSource = strainersFilterGauges;
                        comboBoxEngg6.ItemsSource = strainersStandards;
                        comboBoxEngg7.ItemsSource = strainersRating;
                        //comboBoxEngg8.ItemsSource = strainersThreadEndTypes;
                        comboBoxEngg9.ItemsSource = strainersCertificates;
                        comboBoxEngg10.ItemsSource = strainersClassSocietys;
                        comboBoxEngg11.ItemsSource = strainersSizes1;
                        comboBoxEngg12.ItemsSource = nullCollection;//strainersMeshSizes
                        comboBoxEngg13.ItemsSource = strainersEndTypes;
                        comboBoxEngg14.ItemsSource = strainersEndConnStandards;
                        //comboBoxEngg15.ItemsSource = strainersReferences;

                        comboBoxEngg16.Items.Clear();
                        clsStaticGlobal.ProjectCodeItemCollection.Clear();
                        GetProjectCodes();
                        foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                        {
                            comboBoxEngg16.Items.Add(item.ProjectCodeName);
                        }

                        labelEngg2.Content = "Strainers Type";
                        labelEngg3.Content = "sub Type";
                        labelEngg4.Content = "Body";
                        labelEngg5.Content = "Filter / Gauge";
                        labelEngg6.Content = "Standard";
                        labelEngg7.Content = "Rating";
                        //labelEngg8.Content = "Thread End Type";
                        labelEngg9.Content = "Certificate";
                        labelEngg10.Content = "Class / Society";
                        labelEngg11.Content = "Size 1";
                        labelEngg12.Content = "N/A";//"Mesh Size"
                        labelEngg13.Content = "End Type";
                        labelEngg14.Content = "End Conn. Standard";
                        //labelEngg15.Content = "Reference";
                        labelEngg16.Content = "Project Number";
                        HideShowEnggCombobox(true, 15);

                        HideShowEnggCombobox(true, 8);
                        break;
                    case "SUPPORTS":
                        loadEngineeringItems(false, "SUPPORTS");
                        hideUnwantedEnggControls(14);
                        comboBoxEngg2.ItemsSource = supportsTypes;
                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = nullCollection;
                        comboBoxEngg5.ItemsSource = nullCollection;
                        comboBoxEngg6.ItemsSource = nullCollection;
                        comboBoxEngg7.ItemsSource = supportsStandards;
                        comboBoxEngg8.ItemsSource = supportsRatings;
                        comboBoxEngg9.ItemsSource = supportsCCLampCertificates;
                        comboBoxEngg10.ItemsSource = supportsCCLampClasseSocietys;
                        comboBoxEngg11.ItemsSource = supportsSizes;
                        comboBoxEngg12.ItemsSource = nullCollection;
                        comboBoxEngg13.ItemsSource = supportsFastnerTypes;
                        //comboBoxEngg14.ItemsSource = supportsReferences;
                        labelEngg2.Content = "Support Type";
                        labelEngg3.Content = "sub Type";
                        labelEngg4.Content = "Material";
                        labelEngg5.Content = "Fastner Material";
                        labelEngg6.Content = "Linear/Plate Material";
                        labelEngg7.Content = "Standard";
                        labelEngg8.Content = "Rating";
                        labelEngg9.Content = "Certificate";
                        labelEngg10.Content = "Class / Society";
                        labelEngg11.Content = "Size";
                        labelEngg12.Content = "Plate Thickness";
                        labelEngg13.Content = "Fastner Type";
                        //labelEngg14.Content = "Reference";
                        HideShowEnggCombobox(true, 14);
                        break;
                    default:
                        break;
                }

                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg2.Text = ((NameCodePair)comboBoxEngg2.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg2.Text = string.Empty;
                }

                if (comboBoxEngg2.SelectedItem == null) return;
                switch (((NameCodePair)comboBoxEngg.SelectedItem).Name.ToUpper())
                {
                    case "PIPES":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg3.ItemsSource = pipeSubTypes;
                        comboBoxEngg4.ItemsSource = pipeMaterialAndGrades;
                        comboBoxEngg5.ItemsSource = pipeStandards;
                        comboBoxEngg6.ItemsSource = pipeCertificates;
                        comboBoxEngg7.ItemsSource = pipeClassSociety;
                        comboBoxEngg8.ItemsSource = pipeSizes;
                        comboBoxEngg9.ItemsSource = pipeLengths;
                        comboBoxEngg10.ItemsSource = pipeSchedules;

                        comboBoxEngg8.ItemsSource = nullCollection;
                        comboBoxEngg9.ItemsSource = nullCollection;
                        comboBoxEngg10.ItemsSource = nullCollection;
                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "PIPE (NB/SCH)":
                                comboBoxEngg8.ItemsSource = pipeSizes;
                                comboBoxEngg9.ItemsSource = pipeLengths;
                                comboBoxEngg10.ItemsSource = pipeSchedules;
                                break;
                            case "TUBE (OD/THK)":
                                comboBoxEngg8.ItemsSource = pipeTubeSizes;
                                comboBoxEngg10.ItemsSource = pipeTubeThicknesses;
                                break;
                            default:
                                break;
                        }
                        break;
                    case "FLANGES AND GASKETS":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg3.ItemsSource = flangeTypes;
                        comboBoxEngg4.ItemsSource = flangeMaterialGrades;
                        comboBoxEngg5.ItemsSource = flangeStandards;
                        comboBoxEngg6.ItemsSource = flangeCertificates;
                        comboBoxEngg7.ItemsSource = flangeClassSocietys;
                        comboBoxEngg8.ItemsSource = flangeSizes;
                        comboBoxEngg9.ItemsSource = flangeRatings;

                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = nullCollection;
                        comboBoxEngg10.ItemsSource = nullCollection;
                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "FLANGE":
                                comboBoxEngg3.ItemsSource = flangeTypes;
                                comboBoxEngg4.ItemsSource = flangeMaterialGrades;
                                comboBoxEngg10.ItemsSource = nullCollection;
                                break;
                            case "GASKET":
                                comboBoxEngg3.ItemsSource = gasketTypes;
                                comboBoxEngg4.ItemsSource = gasketMaterials;
                                comboBoxEngg10.ItemsSource = gasketThicknesses;
                                break;
                            default:
                                break;
                        }
                        break;
                    case "FITTINGS BW":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg4.ItemsSource = bWFittingMaterialGrades;
                        comboBoxEngg5.ItemsSource = bWFittingStandards;
                        comboBoxEngg6.ItemsSource = bWCertificates;
                        comboBoxEngg7.ItemsSource = bWClassSociety;

                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg8.ItemsSource = nullCollection;
                        comboBoxEngg9.ItemsSource = nullCollection;
                        comboBoxEngg10.ItemsSource = nullCollection;
                        comboBoxEngg11.ItemsSource = nullCollection;

                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "PIPE ELBOW":
                                comboBoxEngg3.ItemsSource = bWElbowSubTypes;
                                comboBoxEngg8.ItemsSource = bWPipeElbowSizes;
                                comboBoxEngg9.ItemsSource = nullCollection;
                                comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
                                comboBoxEngg11.ItemsSource = nullCollection;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Pipe Elbow Sizes";
                                labelEngg9.Content = "N/A";
                                labelEngg10.Content = "Pipe Elbow Schedule";
                                labelEngg11.Content = "N/A";
                                break;
                            case "TUBE ELBOW":
                                comboBoxEngg3.ItemsSource = bWElbowSubTypes;
                                comboBoxEngg8.ItemsSource = bWTubeElbowSizes;
                                comboBoxEngg9.ItemsSource = nullCollection;
                                comboBoxEngg10.ItemsSource = bWTubeElbowThicknesses;
                                comboBoxEngg11.ItemsSource = nullCollection;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Tube Elbow Sizes";
                                labelEngg9.Content = "N/A";
                                labelEngg10.Content = "Tube Elbow Thicknesses";
                                labelEngg11.Content = "N/A";
                                break;
                            case "PIPE TEE":
                                comboBoxEngg3.ItemsSource = bWTeeSubTypes;
                                comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
                                comboBoxEngg9.ItemsSource = bWPipeTeeSize2s;
                                comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
                                comboBoxEngg11.ItemsSource = nullCollection;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Pipe Tee Size 1";
                                labelEngg9.Content = "Pipe Tee Size 2";
                                labelEngg10.Content = "Pipe Elbow Scheduled";
                                labelEngg11.Content = "N/A";
                                break;
                            case "TUBE TEE":
                                comboBoxEngg3.ItemsSource = bWTeeSubTypes;
                                comboBoxEngg8.ItemsSource = bWTubeTeeSize1s;
                                comboBoxEngg9.ItemsSource = bWTubeTeeSize2s;
                                comboBoxEngg10.ItemsSource = bWTubeTeeThickness1s;
                                comboBoxEngg11.ItemsSource = bWTubeTeeThickness2s;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Tube Tee Size 1";
                                labelEngg9.Content = "Tube Tee Size 2";
                                labelEngg10.Content = "Tube Tee Thickness 1";
                                labelEngg11.Content = "Tube Tee Thickness 1";
                                break;
                            case "PIPE REDUCER":
                                comboBoxEngg3.ItemsSource = bWPipeReducerSubTypes;
                                comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
                                comboBoxEngg9.ItemsSource = bWPipeTeeSize2s;
                                comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
                                comboBoxEngg11.ItemsSource = nullCollection;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Pipe Tee Size 1";
                                labelEngg9.Content = "Pipe Tee Size 2";
                                labelEngg10.Content = "Pipe Elbow Scheduled";
                                labelEngg11.Content = "N/A";
                                break;
                            case "TUBE REDUCER":
                                comboBoxEngg3.ItemsSource = bWPipeReducerSubTypes;
                                comboBoxEngg8.ItemsSource = bWTubeTeeSize1s;
                                comboBoxEngg9.ItemsSource = bWTubeTeeSize2s;
                                comboBoxEngg10.ItemsSource = bWTubeTeeThickness1s;
                                comboBoxEngg11.ItemsSource = bWTubeTeeThickness2s;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Tube Tee Size 1";
                                labelEngg9.Content = "Tube Tee Size 2";
                                labelEngg10.Content = "Tube Tee Thickness 1";
                                labelEngg11.Content = "Tube Tee Thickness 1";
                                break;
                            case "ERW ELBOW":
                                comboBoxEngg3.ItemsSource = bWElbowSubTypes;
                                comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
                                comboBoxEngg9.ItemsSource = nullCollection;
                                comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
                                comboBoxEngg11.ItemsSource = nullCollection;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Pipe Tee Size 1";
                                labelEngg9.Content = "N/A";
                                labelEngg10.Content = "Pipe Elbow Scheduled";
                                labelEngg11.Content = "N/A";
                                break;
                            case "ERW REDUCER":
                                comboBoxEngg3.ItemsSource = bWERWReducerSubTypes;
                                comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
                                comboBoxEngg9.ItemsSource = bWPipeTeeSize2s;
                                comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
                                comboBoxEngg11.ItemsSource = null;

                                labelEngg3.Content = "Sub Type";
                                labelEngg8.Content = "Pipe Tee Size 1";
                                labelEngg9.Content = "Pipe Tee Size 2";
                                labelEngg10.Content = "Pipe Elbow Scheduled";
                                labelEngg11.Content = "N/A";
                                break;
                            default:
                                break;
                        }

                        break;
                    case "PIPE FITTINGS":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg4.ItemsSource = pipeFittingMaterialGrades;
                        comboBoxEngg5.ItemsSource = pipeFittingSeals;
                        comboBoxEngg6.ItemsSource = pipeFittingStandards;
                        comboBoxEngg7.ItemsSource = pipeFittingEndConnection1;
                        comboBoxEngg8.ItemsSource = pipeFittingEndConnection1;
                        comboBoxEngg9.ItemsSource = pipeFittingCertificates;
                        comboBoxEngg10.ItemsSource = pipeFittingClassSociety;
                        comboBoxEngg11.ItemsSource = pipeFittingSize1;
                        comboBoxEngg12.ItemsSource = pipeFittingSize2;
                        comboBoxEngg13.ItemsSource = pipeFittingRating;

                        comboBoxEngg3.ItemsSource = nullCollection;
                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "ELBOW":
                                comboBoxEngg3.ItemsSource = pipeFittingElbowSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "TEE":
                                comboBoxEngg3.ItemsSource = pipeFittingTeeSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "ADAPTER":
                                comboBoxEngg3.ItemsSource = pipeFittingAdaptorSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "COUPLING":
                                comboBoxEngg3.ItemsSource = pipeFittingCouplingSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "NIPPLE":
                                comboBoxEngg3.ItemsSource = pipeFittingNippleSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "PLUG":
                                comboBoxEngg3.ItemsSource = pipeFittingPlugSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "CAP":
                                comboBoxEngg3.ItemsSource = pipeFittingCapSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "BUSHING":
                                comboBoxEngg3.ItemsSource = pipeFittingBushingSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "HOSE CONNECTION":
                                comboBoxEngg3.ItemsSource = pipeFittingHoseConnectionSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "CROSS":
                                comboBoxEngg3.ItemsSource = pipeFittingCrossSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "ROXTEC PENETRATION":
                                comboBoxEngg3.ItemsSource = pipeFittingRoxtecPenetrationSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "SCUPPER":
                                comboBoxEngg3.ItemsSource = pipeFittingScupperSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "MALE CONNECTOR":
                                comboBoxEngg3.ItemsSource = pipeFittingMaleConnectorTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "WELDING BULKHEAD UNION":
                                comboBoxEngg3.ItemsSource = nullCollection;
                                labelEngg3.Content = "N/A";
                                break;
                            case "REDUCING UNION":
                                comboBoxEngg3.ItemsSource = nullCollection;
                                labelEngg3.Content = "N/A";
                                break;
                            case "THREADED SOCKET":
                                comboBoxEngg3.ItemsSource = nullCollection;
                                labelEngg3.Content = "N/A";
                                break;
                            case "FLANGE ADAPTER":
                                comboBoxEngg3.ItemsSource = nullCollection;
                                labelEngg3.Content = "N/A";
                                break;
                            case "FEMALE CONNECTOR":
                                comboBoxEngg3.ItemsSource = pipeFittingFemaleConnectorTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            case "SAE FLANGE":
                                comboBoxEngg3.ItemsSource = pipeFittingSeaFlangeSubTypes;
                                labelEngg3.Content = "Sub Type";
                                break;
                            default:
                                break;
                        }
                        break;
                    case "VALVES":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg4.ItemsSource = valveBodyMaterialGrades;
                        comboBoxEngg5.ItemsSource = valveTrims;
                        comboBoxEngg6.ItemsSource = valveSeats;
                        comboBoxEngg7.ItemsSource = valveStandards;
                        comboBoxEngg8.ItemsSource = valveRatings;
                        comboBoxEngg9.ItemsSource = valveCertificates;
                        comboBoxEngg10.ItemsSource = valveClassSocietys;
                        comboBoxEngg11.ItemsSource = valveSizes;
                        comboBoxEngg12.ItemsSource = valveEndTypes;
                        comboBoxEngg13.ItemsSource = valveEndConnectionStandards;
                        comboBoxEngg14.ItemsSource = valveActuatorTypes;
                        comboBoxEngg15.ItemsSource = valveReferences;
                        comboBoxEngg16.ItemsSource = null;
                        comboBoxEngg16.Items.Clear();
                        clsStaticGlobal.ProjectCodeItemCollection.Clear();
                        GetProjectCodes();
                        foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                        {
                            comboBoxEngg16.Items.Add(item.ProjectCodeName);
                        }

                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "BALL":
                                comboBoxEngg3.ItemsSource = valveBallSubTypes;
                                break;
                            case "BUTTERFLY":
                                comboBoxEngg3.ItemsSource = valveButerflySubTypes;
                                break;
                            case "GLOBE":
                                comboBoxEngg3.ItemsSource = valveGlobeSubTypes;
                                break;
                            case "GATE":
                                comboBoxEngg3.ItemsSource = valveGateSubTypes;
                                break;
                            case "CHECK VALVE":
                                comboBoxEngg3.ItemsSource = valveCheckSubTypes;
                                break;
                            case "NEEDLE":
                                comboBoxEngg3.ItemsSource = valveNeedleSubTypes;
                                break;
                            case "PRESSURE RELIEF":
                                comboBoxEngg3.ItemsSource = valvePressureRelifeSubTypes;
                                break;
                            case "PRESSURE REDUCING":
                                comboBoxEngg3.ItemsSource = valvePressureReducingSubTypes;
                                break;
                            case "PRESSURE REGULATING VALVE":
                                comboBoxEngg3.ItemsSource = valvePressureRegulatingSubTypes;
                                break;
                            case "OTHER VALVE TYPES":
                                comboBoxEngg3.ItemsSource = valveOtherSubTypes;
                                break;
                        }
                        break;
                    case "STRAINER":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg4.ItemsSource = strainersBodies;
                        comboBoxEngg5.ItemsSource = strainersFilterGauges;
                        comboBoxEngg6.ItemsSource = strainersStandards;
                        comboBoxEngg7.ItemsSource = strainersRating;
                        comboBoxEngg8.ItemsSource = strainersThreadEndTypes;
                        comboBoxEngg9.ItemsSource = strainersCertificates;
                        comboBoxEngg10.ItemsSource = strainersClassSocietys;
                        comboBoxEngg11.ItemsSource = strainersSizes1;
                        comboBoxEngg13.ItemsSource = strainersEndTypes;
                        comboBoxEngg14.ItemsSource = strainersEndConnStandards;
                        comboBoxEngg15.ItemsSource = strainersReferences;

                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg12.ItemsSource = nullCollection;//strainersMeshSizes
                        labelEngg12.Content = "N/A";//"Mesh Size"

                        comboBoxEngg16.ItemsSource = null;
                        comboBoxEngg16.Items.Clear();
                        clsStaticGlobal.ProjectCodeItemCollection.Clear();
                        GetProjectCodes();
                        foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                        {
                            comboBoxEngg16.Items.Add(item.ProjectCodeName);
                        }

                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "SIMPLEX STRAINER":
                                comboBoxEngg3.ItemsSource = strainersSimplexSubTypes;
                                comboBoxEngg12.ItemsSource = strainersMeshSizes;
                                labelEngg12.Content = "Mesh Size";
                                break;
                            case "DUPLEX STRAINER":
                                comboBoxEngg3.ItemsSource = strainersDuplexSubTypes;
                                break;
                            case "Y-TYPE STRAINER":
                                comboBoxEngg3.ItemsSource = strainersYTypeSubTypes;
                                break;
                            case "FOOT VALVE WITH STRAINER":
                                comboBoxEngg3.ItemsSource = strainersFootValveSubTypes;
                                break;
                            case "STRUM BOX":
                                comboBoxEngg3.ItemsSource = strainersStrumBoxSubTypes;
                                break;
                            case "MUD BOX":
                                comboBoxEngg3.ItemsSource = strainersMudBoxSubTypes;
                                break;
                            case "OTHER FILTERS":
                                comboBoxEngg3.ItemsSource = strainersOtherFiltersSubTypes;
                                break;
                            default:
                                break;

                        }
                        break;
                    case "SUPPORTS":
                        clearEngineeringComboBoxes(true);
                        comboBoxEngg7.ItemsSource = supportsStandards;
                        comboBoxEngg8.ItemsSource = supportsRatings;
                        comboBoxEngg9.ItemsSource = supportsCCLampCertificates;
                        comboBoxEngg10.ItemsSource = supportsCCLampClasseSocietys;
                        comboBoxEngg11.ItemsSource = supportsSizes;
                        comboBoxEngg13.ItemsSource = supportsFastnerTypes;
                        comboBoxEngg14.ItemsSource = supportsReferences;

                        comboBoxEngg3.ItemsSource = nullCollection;
                        comboBoxEngg4.ItemsSource = nullCollection;
                        comboBoxEngg5.ItemsSource = nullCollection;
                        comboBoxEngg6.ItemsSource = nullCollection;
                        comboBoxEngg12.ItemsSource = nullCollection;
                        switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
                        {
                            case "C-CLAMP":
                                comboBoxEngg3.ItemsSource = supportsCClampSubTypes;
                                comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
                                comboBoxEngg5.ItemsSource = nullCollection;
                                comboBoxEngg6.ItemsSource = nullCollection;
                                comboBoxEngg12.ItemsSource = nullCollection;
                                labelEngg2.Content = "Support Type";
                                labelEngg3.Content = "sub Type";
                                labelEngg4.Content = "Material";
                                labelEngg5.Content = "Fastner Material";
                                labelEngg6.Content = "Linear Material";
                                labelEngg12.Content = "N/A";
                                break;
                            case "U BOLT":
                                comboBoxEngg3.ItemsSource = supportsUBoltSubTypes;
                                comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
                                comboBoxEngg5.ItemsSource = nullCollection;
                                comboBoxEngg6.ItemsSource = nullCollection;
                                comboBoxEngg12.ItemsSource = nullCollection;
                                labelEngg2.Content = "Support Type";
                                labelEngg3.Content = "sub Type";
                                labelEngg4.Content = "Material";
                                labelEngg5.Content = "Fastner Material";
                                labelEngg6.Content = "Linear Material";
                                labelEngg12.Content = "N/A";
                                break;
                            case "HYD CLAMP":
                                comboBoxEngg3.ItemsSource = supportsHYDClampSubTypes;
                                comboBoxEngg4.ItemsSource = supportsHYDClampMaterialGrades;
                                comboBoxEngg5.ItemsSource = supportsHYDClampFastnerMaterialGrades;
                                comboBoxEngg6.ItemsSource = supportsHYDClampPlateMaterialGrades;
                                comboBoxEngg12.ItemsSource = supportsPlateThicknesses;
                                labelEngg2.Content = "Support Type";
                                labelEngg3.Content = "sub Type";
                                labelEngg4.Content = "Material";
                                labelEngg5.Content = "Fastner Material";
                                labelEngg6.Content = "Plate Material";
                                labelEngg12.Content = "Plate Thickness";
                                break;
                            case "VIBRATION MOUNTS - BASIC SILENT":
                                comboBoxEngg3.ItemsSource = nullCollection;
                                comboBoxEngg4.ItemsSource = nullCollection;
                                comboBoxEngg5.ItemsSource = nullCollection;
                                comboBoxEngg6.ItemsSource = nullCollection;
                                comboBoxEngg12.ItemsSource = nullCollection;
                                labelEngg2.Content = "Support Type";
                                labelEngg3.Content = "sub Type";
                                labelEngg4.Content = "Material";
                                labelEngg5.Content = "Fastner Material";
                                labelEngg6.Content = "Linear/Plate Material";
                                labelEngg12.Content = "N/A";
                                break;
                            case "PIPE CLAMP (O-TYPE)":
                                comboBoxEngg3.ItemsSource = supportsPipeClampSubTypes;
                                comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
                                comboBoxEngg5.ItemsSource = nullCollection;
                                comboBoxEngg6.ItemsSource = nullCollection;
                                comboBoxEngg12.ItemsSource = nullCollection;
                                labelEngg2.Content = "Support Type";
                                labelEngg3.Content = "sub Type";
                                labelEngg4.Content = "Material";
                                labelEngg5.Content = "Fastner Material";
                                labelEngg6.Content = "Linear Material";
                                labelEngg12.Content = "N/A";
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }

                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        //private void comboBoxEngg2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    try
        //    {
        //        if (((ComboBox)sender).SelectedItem != null)
        //        {
        //            textBoxEngg2.Text = ((NameCodePair)comboBoxEngg2.SelectedItem).Code;
        //        }
        //        else
        //        {
        //            textBoxEngg2.Text = string.Empty;
        //        }

        //        if (comboBoxEngg2.SelectedItem == null) return;
        //        switch (((NameCodePair)comboBoxEngg.SelectedItem).Name.ToUpper())
        //        {
        //            case "PIPES":
        //                comboBoxEngg8.ItemsSource = nullCollection;
        //                comboBoxEngg9.ItemsSource = nullCollection;
        //                comboBoxEngg10.ItemsSource = nullCollection;
        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "PIPE (NB/SCH)":
        //                        comboBoxEngg8.ItemsSource = pipeSizes;
        //                        comboBoxEngg9.ItemsSource = pipeLengths;
        //                        comboBoxEngg10.ItemsSource = pipeSchedules;
        //                        break;
        //                    case "TUBE (OD/THK)":
        //                        comboBoxEngg8.ItemsSource = pipeTubeSizes;
        //                        comboBoxEngg10.ItemsSource = pipeTubeThicknesses;
        //                        break;
        //                    default:
        //                        break;
        //                }
        //                break;
        //            case "FLANGES AND GASKETS":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                comboBoxEngg4.ItemsSource = nullCollection;
        //                comboBoxEngg10.ItemsSource = nullCollection;
        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "FLANGE":
        //                        comboBoxEngg3.ItemsSource = flangeTypes;
        //                        comboBoxEngg4.ItemsSource = flangeMaterialGrades;
        //                        comboBoxEngg10.ItemsSource = nullCollection;
        //                        break;
        //                    case "GASKET":
        //                        comboBoxEngg3.ItemsSource = gasketTypes;
        //                        comboBoxEngg4.ItemsSource = gasketMaterials;
        //                        comboBoxEngg10.ItemsSource = gasketThicknesses;
        //                        break;
        //                    default:
        //                        break;
        //                }
        //                break;
        //            case "FITTINGS BW":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                comboBoxEngg8.ItemsSource = nullCollection;
        //                comboBoxEngg9.ItemsSource = nullCollection;
        //                comboBoxEngg10.ItemsSource = nullCollection;
        //                comboBoxEngg11.ItemsSource = nullCollection;

        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "PIPE ELBOW":
        //                        comboBoxEngg3.ItemsSource = bWElbowSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWPipeElbowSizes;
        //                        comboBoxEngg9.ItemsSource = nullCollection;
        //                        comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
        //                        comboBoxEngg11.ItemsSource = nullCollection;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Pipe Elbow Sizes";
        //                        labelEngg9.Content = "N/A";
        //                        labelEngg10.Content = "Pipe Elbow Schedule";
        //                        labelEngg11.Content = "N/A";
        //                        break;
        //                    case "TUBE ELBOW":
        //                        comboBoxEngg3.ItemsSource = bWElbowSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWTubeElbowSizes;
        //                        comboBoxEngg9.ItemsSource = nullCollection;
        //                        comboBoxEngg10.ItemsSource = bWTubeElbowThicknesses;
        //                        comboBoxEngg11.ItemsSource = nullCollection;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Tube Elbow Sizes";
        //                        labelEngg9.Content = "N/A";
        //                        labelEngg10.Content = "Tube Elbow Thicknesses";
        //                        labelEngg11.Content = "N/A";
        //                        break;
        //                    case "PIPE TEE":
        //                        comboBoxEngg3.ItemsSource = bWTeeSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
        //                        comboBoxEngg9.ItemsSource = bWPipeTeeSize2s;
        //                        comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
        //                        comboBoxEngg11.ItemsSource = nullCollection;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Pipe Tee Size 1";
        //                        labelEngg9.Content = "Pipe Tee Size 2";
        //                        labelEngg10.Content = "Pipe Elbow Scheduled";
        //                        labelEngg11.Content = "N/A";
        //                        break;
        //                    case "TUBE TEE":
        //                        comboBoxEngg3.ItemsSource = bWTeeSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWTubeTeeSize1s;
        //                        comboBoxEngg9.ItemsSource = bWTubeTeeSize2s;
        //                        comboBoxEngg10.ItemsSource = bWTubeTeeThickness1s;
        //                        comboBoxEngg11.ItemsSource = bWTubeTeeThickness2s;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Tube Tee Size 1";
        //                        labelEngg9.Content = "Tube Tee Size 2";
        //                        labelEngg10.Content = "Tube Tee Thickness 1";
        //                        labelEngg11.Content = "Tube Tee Thickness 1";
        //                        break;
        //                    case "PIPE REDUCER":
        //                        comboBoxEngg3.ItemsSource = bWPipeReducerSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
        //                        comboBoxEngg9.ItemsSource = bWPipeTeeSize2s;
        //                        comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
        //                        comboBoxEngg11.ItemsSource = nullCollection;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Pipe Tee Size 1";
        //                        labelEngg9.Content = "Pipe Tee Size 2";
        //                        labelEngg10.Content = "Pipe Elbow Scheduled";
        //                        labelEngg11.Content = "N/A";
        //                        break;
        //                    case "TUBE REDUCER":
        //                        comboBoxEngg3.ItemsSource = bWPipeReducerSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWTubeTeeSize1s;
        //                        comboBoxEngg9.ItemsSource = bWTubeTeeSize2s;
        //                        comboBoxEngg10.ItemsSource = bWTubeTeeThickness1s;
        //                        comboBoxEngg11.ItemsSource = bWTubeTeeThickness2s;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Tube Tee Size 1";
        //                        labelEngg9.Content = "Tube Tee Size 2";
        //                        labelEngg10.Content = "Tube Tee Thickness 1";
        //                        labelEngg11.Content = "Tube Tee Thickness 1";
        //                        break;
        //                    case "ERW ELBOW":
        //                        comboBoxEngg3.ItemsSource = bWElbowSubTypes;
        //                        comboBoxEngg8.ItemsSource = bWPipeTeeSize1s;
        //                        comboBoxEngg9.ItemsSource = nullCollection;
        //                        comboBoxEngg10.ItemsSource = bWPipeElbowSchedules;
        //                        comboBoxEngg11.ItemsSource = nullCollection;

        //                        labelEngg3.Content = "Sub Type";
        //                        labelEngg8.Content = "Pipe Tee Size 1";
        //                        labelEngg9.Content = "N/A";
        //                        labelEngg10.Content = "Pipe Elbow Scheduled";
        //                        labelEngg11.Content = "N/A";
        //                        break;
        //                    default:
        //                        break;
        //                }

        //                break;
        //            case "PIPE FITTINGS":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "ELBOW":
        //                        comboBoxEngg3.ItemsSource = pipeFittingElbowSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "TEE":
        //                        comboBoxEngg3.ItemsSource = pipeFittingTeeSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "ADAPTER":
        //                        comboBoxEngg3.ItemsSource = pipeFittingAdaptorSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "COUPLING":
        //                        comboBoxEngg3.ItemsSource = pipeFittingCouplingSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "NIPPLE":
        //                        comboBoxEngg3.ItemsSource = pipeFittingNippleSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "PLUG":
        //                        comboBoxEngg3.ItemsSource = pipeFittingPlugSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "CAP":
        //                        comboBoxEngg3.ItemsSource = pipeFittingCapSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "BUSHING":
        //                        comboBoxEngg3.ItemsSource = pipeFittingBushingSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "HOSE CONNECTION":
        //                        comboBoxEngg3.ItemsSource = pipeFittingHoseConnectionSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "CROSS":
        //                        comboBoxEngg3.ItemsSource = pipeFittingCrossSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "ROXTEC PENETRATION":
        //                        comboBoxEngg3.ItemsSource = pipeFittingRoxtecPenetrationSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "SCUPPER":
        //                        comboBoxEngg3.ItemsSource = pipeFittingScupperSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "MALE CONNECTOR":
        //                        comboBoxEngg3.ItemsSource = pipeFittingMaleConnectorTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "WELDING BULKHEAD UNION":
        //                        comboBoxEngg3.ItemsSource = nullCollection;
        //                        labelEngg3.Content = "N/A";
        //                        break;
        //                    case "REDUCING UNION":
        //                        comboBoxEngg3.ItemsSource = nullCollection;
        //                        labelEngg3.Content = "N/A";
        //                        break;
        //                    case "THREADED SOCKET":
        //                        comboBoxEngg3.ItemsSource = nullCollection;
        //                        labelEngg3.Content = "N/A";
        //                        break;
        //                    case "FLANGE ADAPTER":
        //                        comboBoxEngg3.ItemsSource = nullCollection;
        //                        labelEngg3.Content = "N/A";
        //                        break;
        //                    case "FEMALE CONNECTOR":
        //                        comboBoxEngg3.ItemsSource = pipeFittingFemaleConnectorTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    case "SAE FLANGE":
        //                        comboBoxEngg3.ItemsSource = pipeFittingSeaFlangeSubTypes;
        //                        labelEngg3.Content = "Sub Type";
        //                        break;
        //                    default:
        //                        break;
        //                }
        //                break;
        //            case "VALVES":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                comboBoxEngg4.ItemsSource = nullCollection;
        //                comboBoxEngg5.ItemsSource = nullCollection;
        //                comboBoxEngg6.ItemsSource = nullCollection;
        //                comboBoxEngg7.ItemsSource = nullCollection;
        //                comboBoxEngg8.ItemsSource = nullCollection;
        //                comboBoxEngg9.ItemsSource = nullCollection;
        //                comboBoxEngg10.ItemsSource = nullCollection;
        //                comboBoxEngg11.ItemsSource = nullCollection;
        //                comboBoxEngg12.ItemsSource = nullCollection;
        //                comboBoxEngg13.ItemsSource = nullCollection;
        //                comboBoxEngg14.ItemsSource = nullCollection;
        //                comboBoxEngg15.ItemsSource = nullCollection;

        //                comboBoxEngg4.ItemsSource = valveBodyMaterialGrades;
        //                comboBoxEngg5.ItemsSource = valveTrims;
        //                comboBoxEngg6.ItemsSource = valveSeats;
        //                comboBoxEngg7.ItemsSource = valveStandards;
        //                comboBoxEngg8.ItemsSource = valveRatings;
        //                comboBoxEngg9.ItemsSource = valveCertificates;
        //                comboBoxEngg10.ItemsSource = valveClassSocietys;
        //                comboBoxEngg11.ItemsSource = valveSizes;
        //                comboBoxEngg12.ItemsSource = valveEndTypes;
        //                comboBoxEngg13.ItemsSource = valveEndConnectionStandards;
        //                comboBoxEngg14.ItemsSource = valveActuatorTypes;
        //                comboBoxEngg15.ItemsSource = valveReferences;

        //                comboBoxEngg16.Items.Clear();
        //                clsStaticGlobal.ProjectCodeItemCollection.Clear();
        //                GetProjectCodes();
        //                foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
        //                {
        //                    comboBoxEngg16.Items.Add(item.ProjectCodeName);
        //                }

        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "BALL":
        //                        comboBoxEngg3.ItemsSource = valveBallSubTypes;
        //                        break;
        //                    case "BUTTERFLY":
        //                        comboBoxEngg3.ItemsSource = valveButerflySubTypes;
        //                        break;
        //                    case "GLOBE":
        //                        comboBoxEngg3.ItemsSource = valveGlobeSubTypes;
        //                        break;
        //                    case "GATE":
        //                        comboBoxEngg3.ItemsSource = valveGateSubTypes;
        //                        break;
        //                    case "CHECK VALVE":
        //                        comboBoxEngg3.ItemsSource = valveCheckSubTypes;
        //                        break;
        //                    case "NEEDLE":
        //                        comboBoxEngg3.ItemsSource = valveNeedleSubTypes;
        //                        break;
        //                    case "PRESSURE RELIEF":
        //                        comboBoxEngg3.ItemsSource = valvePressureRelifeSubTypes;
        //                        break;
        //                    case "PRESSURE REDUCING":
        //                        comboBoxEngg3.ItemsSource = valvePressureReducingSubTypes;
        //                        break;
        //                    case "PRESSURE REGULATING VALVE":
        //                        comboBoxEngg3.ItemsSource = valvePressureRegulatingSubTypes;
        //                        break;
        //                    case "OTHER VALVE TYPES":
        //                        comboBoxEngg3.ItemsSource = valveOtherSubTypes;
        //                        break;
        //                }
        //                break;
        //            case "STRAINER":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                comboBoxEngg12.ItemsSource = nullCollection;//strainersMeshSizes
        //                labelEngg12.Content = "N/A";//"Mesh Size"
        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "SIMPLEX STRAINER":
        //                        comboBoxEngg3.ItemsSource = strainersSimplexSubTypes;
        //                        comboBoxEngg12.ItemsSource = strainersMeshSizes;
        //                        labelEngg12.Content = "Mesh Size";
        //                        break;
        //                    case "DUPLEX STRAINER":
        //                        comboBoxEngg3.ItemsSource = strainersDuplexSubTypes;
        //                        break;
        //                    case "Y-TYPE STRAINER":
        //                        comboBoxEngg3.ItemsSource = strainersYTypeSubTypes;
        //                        break;
        //                    case "FOOT VALVE WITH STRAINER":
        //                        comboBoxEngg3.ItemsSource = strainersFootValveSubTypes;
        //                        break;
        //                    case "STRUM BOX":
        //                        comboBoxEngg3.ItemsSource = strainersStrumBoxSubTypes;
        //                        break;
        //                    case "MUD BOX":
        //                        comboBoxEngg3.ItemsSource = strainersMudBoxSubTypes;
        //                        break;
        //                    case "OTHER FILTERS":
        //                        comboBoxEngg3.ItemsSource = strainersOtherFiltersSubTypes;
        //                        break;
        //                    default:
        //                        break;

        //                }
        //                break;
        //            case "SUPPORTS":
        //                comboBoxEngg3.ItemsSource = nullCollection;
        //                comboBoxEngg4.ItemsSource = nullCollection;
        //                comboBoxEngg5.ItemsSource = nullCollection;
        //                comboBoxEngg6.ItemsSource = nullCollection;
        //                comboBoxEngg12.ItemsSource = nullCollection;
        //                switch (((NameCodePair)comboBoxEngg2.SelectedItem).Name.ToUpper())
        //                {
        //                    case "C-CLAMP":
        //                        comboBoxEngg3.ItemsSource = supportsCClampSubTypes;
        //                        comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
        //                        comboBoxEngg5.ItemsSource = nullCollection;
        //                        comboBoxEngg6.ItemsSource = nullCollection;
        //                        comboBoxEngg12.ItemsSource = nullCollection;
        //                        labelEngg2.Content = "Support Type";
        //                        labelEngg3.Content = "sub Type";
        //                        labelEngg4.Content = "Material";
        //                        labelEngg5.Content = "Fastner Material";
        //                        labelEngg6.Content = "Linear Material";
        //                        labelEngg12.Content = "N/A";
        //                        break;
        //                    case "U BOLT":
        //                        comboBoxEngg3.ItemsSource = supportsUBoltSubTypes;
        //                        comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
        //                        comboBoxEngg5.ItemsSource = nullCollection;
        //                        comboBoxEngg6.ItemsSource = nullCollection;
        //                        comboBoxEngg12.ItemsSource = nullCollection;
        //                        labelEngg2.Content = "Support Type";
        //                        labelEngg3.Content = "sub Type";
        //                        labelEngg4.Content = "Material";
        //                        labelEngg5.Content = "Fastner Material";
        //                        labelEngg6.Content = "Linear Material";
        //                        labelEngg12.Content = "N/A";
        //                        break;
        //                    case "HYD CLAMP":
        //                        comboBoxEngg3.ItemsSource = supportsHYDClampSubTypes;
        //                        comboBoxEngg4.ItemsSource = supportsHYDClampMaterialGrades;
        //                        comboBoxEngg5.ItemsSource = supportsHYDClampFastnerMaterialGrades;
        //                        comboBoxEngg6.ItemsSource = supportsHYDClampPlateMaterialGrades;
        //                        comboBoxEngg12.ItemsSource = supportsPlateThicknesses;
        //                        labelEngg2.Content = "Support Type";
        //                        labelEngg3.Content = "sub Type";
        //                        labelEngg4.Content = "Material";
        //                        labelEngg5.Content = "Fastner Material";
        //                        labelEngg6.Content = "Plate Material";
        //                        labelEngg12.Content = "Plate Thickness";
        //                        break;
        //                    case "VIBRATION MOUNTS - BASIC SILENT":
        //                        comboBoxEngg3.ItemsSource = nullCollection;
        //                        comboBoxEngg4.ItemsSource = nullCollection;
        //                        comboBoxEngg5.ItemsSource = nullCollection;
        //                        comboBoxEngg6.ItemsSource = nullCollection;
        //                        comboBoxEngg12.ItemsSource = nullCollection;
        //                        labelEngg2.Content = "Support Type";
        //                        labelEngg3.Content = "sub Type";
        //                        labelEngg4.Content = "Material";
        //                        labelEngg5.Content = "Fastner Material";
        //                        labelEngg6.Content = "Linear/Plate Material";
        //                        labelEngg12.Content = "N/A";
        //                        break;
        //                    case "PIPE CLAMP (O-TYPE)":
        //                        comboBoxEngg3.ItemsSource = supportsPipeClampSubTypes;
        //                        comboBoxEngg4.ItemsSource = supportsCClampMaterialGrades;
        //                        comboBoxEngg5.ItemsSource = nullCollection;
        //                        comboBoxEngg6.ItemsSource = nullCollection;
        //                        comboBoxEngg12.ItemsSource = nullCollection;
        //                        labelEngg2.Content = "Support Type";
        //                        labelEngg3.Content = "sub Type";
        //                        labelEngg4.Content = "Material";
        //                        labelEngg5.Content = "Fastner Material";
        //                        labelEngg6.Content = "Linear Material";
        //                        labelEngg12.Content = "N/A";
        //                        break;
        //                    default:
        //                        break;
        //                }
        //                break;
        //            default:
        //                break;
        //        }

        //        BindEngineeringComboBoxesData();
        //        generateEngineeringCode();
        //    }
        //    catch (Exception ex)
        //    {
        //        clsStaticGlobal.ErrHandlerLog(ex);
        //    }

        //}

        private void comboBoxEngg3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg3.Text = ((NameCodePair)comboBoxEngg3.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg3.Text = string.Empty;
                }

                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg4.Text = ((NameCodePair)comboBoxEngg4.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg4.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg5_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg5.Text = ((NameCodePair)comboBoxEngg5.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg5.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg6_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg6.Text = ((NameCodePair)comboBoxEngg6.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg6.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg7_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg7.Text = ((NameCodePair)comboBoxEngg7.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg7.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg8_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg8.Text = ((NameCodePair)comboBoxEngg8.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg8.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg9_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg9.Text = ((NameCodePair)comboBoxEngg9.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg9.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg10_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg10.Text = ((NameCodePair)comboBoxEngg10.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg10.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg11_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg11.Text = ((NameCodePair)comboBoxEngg11.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg11.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg12_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg12.Text = ((NameCodePair)comboBoxEngg12.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg12.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg13_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg13.Text = ((NameCodePair)comboBoxEngg13.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg13.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg14_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg14.Text = ((NameCodePair)comboBoxEngg14.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg14.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void comboBoxEngg15_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEngg15.Text = ((NameCodePair)comboBoxEngg15.SelectedItem).Code;
                }
                else
                {
                    textBoxEngg15.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbxEnggItemGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEnggItemGroup.Text = ((NameCodePair)cmbxEnggItemGroup.SelectedItem).Code;
                }
                else
                {
                    textBoxEnggItemGroup.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void cmbxEnggUnit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    textBoxEnggUnit.Text = ((NameCodePair)cmbxEnggUnit.SelectedItem).Code;
                }
                else
                {
                    textBoxEnggUnit.Text = string.Empty;
                }
                BindEngineeringComboBoxesData();
                generateEngineeringCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void textBoxEngg_TextChanged(object sender, TextChangedEventArgs e)
        {
            generateEngineeringCode();
        }

        #endregion

        #endregion

        #region "B & D"

        CommonItemGroups commonItemGroups;

        CommonUnits commonUnits;

        private void OnBaseAndSparesSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                commonItemGroups = CommonItemGroups.LoadFromXml(dataPath);
                commonUnits = CommonUnits.LoadFromXml(dataPath);
                txtBandDItemCode.Text = "";
                txtBandDSerialNumber.Text = "";
                txtBandDGeneratedCode.Text = "";
                txtBandDItemDesc.Text = "";
                txtBandDItemsUnit.Text = "";
                txtSFICodeBandD.Text = "";

                bool IsProjectNumberExist = false;

                if (cmbBandDProjectNumber.Items.Count > 0)
                {
                    IsProjectNumberExist = true;
                }
                if (IsProjectNumberExist)
                {
                    cmbBandDProjectNumber.Items.Clear();
                }

                clsStaticGlobal.ProjectCodeItemCollection.Clear();
                GetProjectCodes();

                foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                {
                    cmbBandDProjectNumber.Items.Add(item.ProjectCodeName);
                }

                txtBandDSerialNumber.Text = GetItemSerialNumber();

                cmbxItemGroupBandD.ItemsSource = commonItemGroups;
                cboBandDItemsUnit.ItemsSource = commonUnits;

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void btnBandDGenItem_Click(object sender, RoutedEventArgs e)
        {

            if (IsValidBandD() == true)
            {
                generateBandDCode();

                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtBandDGeneratedCode.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtBandDGeneratedCode.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception ex)
                {
                    if (AddItem(txtBandDGeneratedCode.Text))
                    {
                        ExportItemCodeDetails("Base and Depot Spares");
                        MessageBox.Show(txtBandDGeneratedCode.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);

                        //txtBandDItemCode.Text = "";
                        //txtBandDSerialNumber.Text = "";
                        //txtBandDGeneratedCode.Text = "";
                        //txtBandDItemDesc.Text = "";
                        //txtBandDItemsUnit.Text = "";
                        //txtSFICodeBandD.Text = "";
                        //txtSFICodeDescBandD.Text = "";
                        //cmbBandDProjectNumber.SelectedItem = null;
                        cmbxItemGroupBandD.ItemsSource = commonItemGroups;
                        cboBandDItemsUnit.ItemsSource = commonUnits;
                    }
                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private string GetItemSerialNumber()
        {
            string _serialNumber = "000";
            try
            {
                ItemService _ItemService = vConnection.WebServiceManager.ItemService;
                List<Item> _items = new List<Item> { };
                string bookmark = null;
                SrchStatus status = null;
                List<int> _SerialList = new List<int> { };
                while ((status == null) || (status.TotalHits < _items.Count))
                {
                    _items.AddRange(_ItemService.FindItemRevisionsBySearchConditions(null, null, true, ref bookmark, out status));
                }

                foreach (Item _item in _items)
                {
                    if (_item.ItemNum.ToString().Length > 3)
                    {
                        int _value;
                        string _lastThreeChar = _item.ItemNum.ToString().Substring(_item.ItemNum.ToString().Length - 3, 3);
                        if (int.TryParse(_lastThreeChar, out _value))
                        {
                            _SerialList.Add(_value);
                        }
                    }
                }

                if (_SerialList.Count > 0)
                {

                    _SerialList.Sort();
                    int _lastValue = _SerialList.Last();
                    if (_lastValue + 1 >= 100)
                    {
                        _serialNumber = Convert.ToString(_lastValue + 1);
                    }
                    else if (_lastValue + 1 >= 10)
                    {
                        _serialNumber = "0" + Convert.ToString(_lastValue + 1);
                    }
                    else
                    {
                        _serialNumber = "00" + Convert.ToString(_lastValue + 1);
                    }
                }
                else
                {
                    _serialNumber = "001";
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _serialNumber;
        }

        private void generateBandDCode()
        {
            try
            {
                string BandDEquipmentType = "";
                string caseSwitch = ((System.Windows.Controls.ContentControl)cmbBandDEquipmentType.SelectedItem).Content.ToString();
                switch (caseSwitch)
                {
                    case "E (for Engineering)":
                        BandDEquipmentType = "E";
                        break;
                    case "L (for electrical)":
                        BandDEquipmentType = "L";
                        break;
                    case "H (for Hull equipment)":
                        BandDEquipmentType = "H";
                        break;
                    default:
                        BandDEquipmentType = "";
                        break;
                }

                string code = txtBandDProjectCode.Text +
                              BandDEquipmentType +
                              txtBandDItemCode.Text +
                              txtBandDSerialNumber.Text;

                txtBandDGeneratedCode.Text = code;

                clsStaticGlobal._ItemCode = code;
                clsStaticGlobal._ItemsProjectCode = cmbBandDProjectNumber.SelectedItem.ToString();
                clsStaticGlobal._Unit = txtBandDItemsUnit.Text;
                clsStaticGlobal._ItemGroup = txtItemGroupBandD.Text;
                clsStaticGlobal._BudgetSFI = txtSFICodeBandD.Text;
                clsStaticGlobal._Desc = txtBandDItemDesc.Text;
                clsStaticGlobal._Title = "Base and Depot Spares";
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidBandD()
        {
            bool _IsValidBandD = true;
            try
            {
                if ((cmbBandDProjectNumber.IsVisible == true) && (cmbBandDProjectNumber.SelectedItem == null))
                {
                    _IsValidBandD = false;
                }
                if ((cmbxItemGroupBandD.IsVisible == true) && (cmbxItemGroupBandD.SelectedItem == null))
                {
                    _IsValidBandD = false;
                }
                if ((cboBandDItemsUnit.IsVisible == true) && (cboBandDItemsUnit.SelectedItem == null))
                {
                    _IsValidBandD = false;
                }

                if (txtBandDProjectCode.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }
                if (txtBandDItemCode.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

                if (txtBandDSerialNumber.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

                if (txtSFICodeBandD.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

                if (txtSFICodeDescBandD.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

                if (txtBandDItemDesc.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

                if (txtBandDGeneratedCode.Text.Trim() == "")
                {
                    _IsValidBandD = false;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidBandD;

        }

        private void cmbBandDProjectNumber_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            generateBandDCode();
        }

        private void cmbBandDEquipmentType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            generateBandDCode();
        }

        private void txtBandDProjectCode_LostFocus(object sender, RoutedEventArgs e)
        {
            generateBandDCode();
        }

        private void txtBandDItemCode_LostFocus(object sender, RoutedEventArgs e)
        {
            generateBandDCode();
        }

        private void txtBandDSerialNumber_LostFocus(object sender, RoutedEventArgs e)
        {
            generateBandDCode();
        }

        private void txtSFICodeBand_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSFICodeDescBandD.Text = "";
                var _res = _SFIcodes.Where(n => n.Code == txtSFICodeBandD.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtSFICodeDescBandD.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void txtSFICodeBand_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }

                }
            }
        }

        private void cboBandDItemsUnit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtBandDItemsUnit.Text = ((NameCodePair)cboBandDItemsUnit.SelectedItem).Code;
                }
                else
                {
                    txtBandDItemsUnit.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }


        }

        private void cboBandDGroupItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtItemGroupBandD.Text = ((NameCodePair)cmbxItemGroupBandD.SelectedItem).Code;
                }
                else
                {
                    txtItemGroupBandD.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        #endregion

        #region "Project Item Code"

        private void generateProjectItemCode()
        {
            try
            {
                string code = txtProjectItemCodeSFIcode.Text +
                              txtProjectItemCodeRunningnumber.Text;

                txtProjectItemCodeGenItem.Text = code;

                clsStaticGlobal._ItemCode = code;
                clsStaticGlobal._ItemsProjectCode = cmbProjectItemCodeProjectNumber.SelectedItem.ToString();
                clsStaticGlobal._Unit = txtProjectItemCodeItemsUnit.Text;
                clsStaticGlobal._ItemGroup = txtItemGroupProjectItemCode.Text;
                clsStaticGlobal._BudgetSFI = txtProjectItemCodeSFIcode.Text;
                clsStaticGlobal._Desc = txtProjectItemCodeItemDesc.Text;
                clsStaticGlobal._Title = "Project Item Code";

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private bool IsValidProjectItemCode()
        {
            bool _IsValidProjectItemCode = true;
            try
            {
                if ((cmbProjectItemCodeProjectNumber.IsVisible == true) && (cmbProjectItemCodeProjectNumber.SelectedItem == null))
                {
                    _IsValidProjectItemCode = false;
                }
                if ((cmbxItemGroupProjectItemCode.IsVisible == true) && (cmbxItemGroupProjectItemCode.SelectedItem == null))
                {
                    _IsValidProjectItemCode = false;
                }
                if ((cboProjectItemCodeItemsUnit.IsVisible == true) && (cboProjectItemCodeItemsUnit.SelectedItem == null))
                {
                    _IsValidProjectItemCode = false;
                }

                if (txtProjectItemCodeSFIcode.Text.Trim() == "")
                {
                    _IsValidProjectItemCode = false;
                }
                if (txtProjectItemCodeDescription.Text.Trim() == "")
                {
                    _IsValidProjectItemCode = false;
                }

                if (txtProjectItemCodeItemDesc.Text.Trim() == "")
                {
                    _IsValidProjectItemCode = false;
                }

                if (txtProjectItemCodeGenItem.Text.Trim() == "")
                {
                    _IsValidProjectItemCode = false;
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            return _IsValidProjectItemCode;

        }

        private void OnProjectItemCodeSelected(object sender, RoutedEventArgs e)
        {
            try
            {
                commonItemGroups = CommonItemGroups.LoadFromXml(dataPath);
                commonUnits = CommonUnits.LoadFromXml(dataPath);

                txtProjectItemCodeSFIcode.Text = "";
                txtProjectItemCodeRunningnumber.Text = "";
                txtProjectItemCodeDescription.Text = "";
                txtProjectItemCodeItemDesc.Text = "";
                txtProjectItemCodeGenItem.Text = "";

                cmbProjectItemCodeProjectNumber.Items.Clear();

                clsStaticGlobal.ProjectCodeItemCollection.Clear();
                GetProjectCodes();
                foreach (ProjectCodes item in clsStaticGlobal.ProjectCodeItemCollection)
                {
                    cmbProjectItemCodeProjectNumber.Items.Add(item.ProjectCodeName);
                }
                cmbProjectItemCodeProjectNumber.SelectedIndex = 1;
                txtProjectItemCodeRunningnumber.Text = GetItemSerialNumber();

                cmbxItemGroupProjectItemCode.ItemsSource = commonItemGroups;
                cboProjectItemCodeItemsUnit.ItemsSource = commonUnits;
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void btnProjectItemCodeGenItem_Click(object sender, RoutedEventArgs e)
        {

            if (IsValidProjectItemCode() == true)
            {
                generateProjectItemCode();

                try
                {
                    Item tItem = vConnection.WebServiceManager.ItemService.GetLatestItemByItemNumber(txtProjectItemCodeGenItem.Text);
                    if (tItem != null)
                    {
                        MessageBox.Show(txtProjectItemCodeGenItem.Text + " item already exist in Item Master.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception ex)
                {
                    if (AddItem(txtProjectItemCodeGenItem.Text))
                    {
                        ExportItemCodeDetails("Project Item Code");
                        MessageBox.Show(txtProjectItemCodeGenItem.Text + " item created in Item Master." + Environment.NewLine + "Exported data saved into Path: " + clsStaticGlobal._ItemexcelPath, "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Information);
                        //txtProjectItemCodeSFIcode.Text = "";
                        //txtProjectItemCodeRunningnumber.Text = "";
                        //txtProjectItemCodeDescription.Text = "";
                        //txtProjectItemCodeItemDesc.Text = "";
                        //txtProjectItemCodeGenItem.Text = "";
                        cmbxItemGroupProjectItemCode.ItemsSource = commonItemGroups;
                        cboProjectItemCodeItemsUnit.ItemsSource = commonUnits;
                    }
                }
            }
            else
            {
                MessageBox.Show("Item fields should not blank.", "Item Code Generator", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void txtProjectItemCodeDescription_LostFocus(object sender, RoutedEventArgs e)
        {
            generateProjectItemCode();
        }

        private void txtProjectItemCodeGeneratedCode_LostFocus(object sender, RoutedEventArgs e)
        {
            generateProjectItemCode();
        }

        private void txtProjectItemCodeSFIcode_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                txtProjectItemCodeDescription.Text = "";
                //System.Diagnostics.Debugger.Launch();
                var _res = _SFIcodes.Where(n => n.Code == txtProjectItemCodeSFIcode.Text);
                foreach (NameCodePair _NameCodePair in _res)
                {
                    txtProjectItemCodeDescription.Text = _NameCodePair.Name;
                    //Do your stuff on each selected user;
                }
                generateProjectItemCode();
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cmbProjectItemCodeProjectNumber_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            generateProjectItemCode();
        }

        private void txtProjectItemCodeSFIcode_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }

                }
            }
        }

        private void txtProjectItemCodeRunningnumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key < Key.D0 || e.Key > Key.D9)
            {
                if (e.Key < Key.NumPad0 || e.Key > Key.NumPad9)
                {
                    if ((e.Key != Key.Back) && (e.Key != Key.Tab))
                    {
                        e.Handled = true;
                    }
                }
            }
        }

        private void txtProjectItemCodeDescription_KeyDown(object sender, KeyEventArgs e)
        {
            {
                e.Handled = true;
            }
        }

        private void cboProjectItemCodeItemsUnit_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtProjectItemCodeItemsUnit.Text = ((NameCodePair)cboProjectItemCodeItemsUnit.SelectedItem).Code;
                }
                else
                {
                    txtProjectItemCodeItemsUnit.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void cboProjectItemCodeGroupItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (((ComboBox)sender).SelectedItem != null)
                {
                    txtItemGroupProjectItemCode.Text = ((NameCodePair)cmbxItemGroupProjectItemCode.SelectedItem).Code;
                }
                else
                {
                    txtItemGroupProjectItemCode.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {

                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        #endregion

        #region Finding Control

        /// <summary>
        /// Finds a Child of a given item in the visual tree. 
        /// </summary>
        /// <param name="parent">A direct parent of the queried item.</param>
        /// <typeparam name="T">The type of the queried item.</typeparam>
        /// <param name="childName">x:Name or Name of child. </param>
        /// <returns>The first parent item that matches the submitted type parameter. 
        /// If not matching item can be found, 
        /// a null parent is being returned.</returns>
        private T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            // Confirm parent and childName are valid. 
            if (parent == null) return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                // If the child is not of the request child type child
                T childType = child as T;
                if (childType == null)
                {
                    // recursively drill down the tree
                    foundChild = FindChild<T>(child, childName);

                    // If the child is found, break so we do not overwrite the found child. 
                    if (foundChild != null) break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    var frameworkElement = child as FrameworkElement;
                    // If the child's name is set for search
                    if (frameworkElement != null && frameworkElement.Name == childName)
                    {
                        // if the child's name is of the request name
                        foundChild = (T)child;
                        break;
                    }
                }
                else
                {
                    // child element found.
                    foundChild = (T)child;
                    break;
                }
            }

            return foundChild;
        }


        #endregion

        private bool ExportItemCodeDetails(string ItemCodeName)
        {
            bool isSuccess = false;
            excel.Application xlApp;
            excel.Workbook xlWorkBook;
            excel.Worksheet xlWorkSheet;
            try
            {

                string _Filename = "citm_" + clsStaticGlobal._ItemCode + ".xlsx";
                if ((ItemCodeName == "Base and Depot Spares") || (ItemCodeName == "Project Item Code"))
                {
                    _Filename = "citm_" + clsStaticGlobal._ItemsProjectCode + clsStaticGlobal._ItemCode + ".xlsx";
                }
                /////////////////////// Create Excel Application Object
                object mMissingValue = System.Reflection.Missing.Value;
                xlApp = new excel.Application();
                xlApp.DisplayAlerts = false;
                xlWorkBook = xlApp.Workbooks.Add(mMissingValue);
                xlWorkSheet = null;

                try
                {
                    var prevSheet = xlWorkSheet;

                    if (prevSheet == null)
                    {
                        xlWorkSheet = xlWorkBook.Sheets.Add(xlWorkBook.Sheets[1], mMissingValue, mMissingValue, mMissingValue);
                    }
                    else
                    {
                        xlWorkSheet = xlWorkBook.Sheets.Add(mMissingValue, prevSheet, mMissingValue, mMissingValue);
                    }
                    //xlWorkSheet.Name = clsStaticGlobal._ItemCode;
                    int BorderStartindex = 0;
                    int RowNo = 1;
                    int ColNo = 1;
                    int LoopRowNo = RowNo;
                    int LoopColNo = ColNo;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Item's Project code";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    ColNo = ColNo + 1;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Item code";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    ColNo = ColNo + 1;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Description";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    ColNo = ColNo + 1;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Item Group";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    ColNo = ColNo + 1;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Unit";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    ColNo = ColNo + 1;

                    xlWorkSheet.Cells[RowNo, ColNo] = "Budget SFI";
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;
                    xlWorkSheet.Cells[RowNo, ColNo].Interior.Color = System.Drawing.Color.FromArgb(67, 152, 236);
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Color = System.Drawing.Color.White;
                    xlWorkSheet.Cells[RowNo, ColNo].Font.Bold = true;

                    BorderStartindex = RowNo;
                    int SrNoCnt = 1;
                    int NextCol = ColNo;
                    LoopRowNo = LoopRowNo + 1;
                    NextCol = LoopColNo;

                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._ItemsProjectCode;
                    NextCol = NextCol + 1;
                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._ItemCode;
                    NextCol = NextCol + 1;
                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._Desc;
                    NextCol = NextCol + 1;
                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._ItemGroup;
                    NextCol = NextCol + 1;
                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._Unit;
                    NextCol = NextCol + 1;
                    xlWorkSheet.Cells[LoopRowNo, NextCol] = clsStaticGlobal._BudgetSFI;

                    for (int m = 2; m <= NextCol; m++)
                    {
                        xlWorkSheet.Columns[m].AutoFit();
                    }

                    xlWorkSheet.Range[xlWorkSheet.Cells[RowNo, ColNo], xlWorkSheet.Cells[LoopRowNo, NextCol]].Cells.Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;

                    xlWorkBook.SaveAs(clsStaticGlobal._ItemexcelPath + "\\" + _Filename, excel.XlFileFormat.xlWorkbookDefault, mMissingValue, mMissingValue, mMissingValue, mMissingValue, excel.XlSaveAsAccessMode.xlExclusive, mMissingValue, mMissingValue, mMissingValue, mMissingValue, mMissingValue);
                    xlWorkBook.Close(true, mMissingValue, mMissingValue);
                    //System.Windows.MessageBox.Show("Surveyor comment summary report exported successfully..!!", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Information);
                    isSuccess = true;
                }
                catch (Exception ex)
                {
                    //System.Windows.MessageBox.Show("Error in report export.", "Surveyor Comments", MessageBoxButton.OK, MessageBoxImage.Error);
                    clsStaticGlobal.ErrHandlerLog(ex);
                    isSuccess = false;
                }
                finally
                {
                    xlApp.Quit();

                    try
                    {
                        clsStaticGlobal.ReleaseObject(xlWorkBook);

                    }
                    catch (Exception)
                    {

                    }
                    clsStaticGlobal.ReleaseObject(xlApp);
                }
            }
            catch (Exception ex1)
            {
                System.Windows.MessageBox.Show("Excel application not installed to export", "Generate Item Code", MessageBoxButton.OK, MessageBoxImage.Warning);
                clsStaticGlobal.ErrHandlerLog(ex1);
                isSuccess = false;
            }

            return isSuccess;
        }

        private void GetProjectCodes()
        {
            Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder _rootfolder = vConnection.FolderManager.RootFolder;
            IEnumerable<Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder> folders = vConnection.FolderManager.GetChildFolders(_rootfolder, false, false);
            if (folders != null && folders.Any())
            {
                foreach (Autodesk.DataManagement.Client.Framework.Vault.Currency.Entities.Folder folder in folders)
                {
                    if (folder.Category.Name.ToUpper() == "PROJECT")
                    {
                        clsStaticGlobal.ProjectCodeItemCollection.Add(new ProjectCodes() { ProjectCodeName = folder.EntityName.ToString() });
                    }
                }
            }
        }

        private void btnSFIbrowseHullItemCode_Click(object sender, RoutedEventArgs e)
        {            
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtSFICodeHull.Text = sfi.SFIcodenumber;
                txtSFICodeDescHull.Text = sfi.SFIcodeDesc;
            }
        }

        private void btnSFIbrowseHullOutfit_Click(object sender, RoutedEventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtSFICodeHullOutfit.Text = sfi.SFIcodenumber;
                txtSFICodeDescHullOutfit.Text = sfi.SFIcodeDesc;
            }
        }

        private void btnSFIbrowseEle_Click(object sender, RoutedEventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtSFICodeEle.Text = sfi.SFIcodenumber;
                txtSFICodeDescEle.Text = sfi.SFIcodeDesc;
            }
        }

        private void btnSFIbrowseEngg_Click(object sender, RoutedEventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtSFICodeEngg.Text = sfi.SFIcodenumber;
                txtSFICodeDescEngg.Text = sfi.SFIcodeDesc;
            }
        }

        private void btnSFIbrowseBandD_Click(object sender, RoutedEventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtSFICodeBandD.Text = sfi.SFIcodenumber;
                txtSFICodeDescBandD.Text = sfi.SFIcodeDesc;                
            }
        }

        private void btnSFIbrowseProjectItem_Click(object sender, RoutedEventArgs e)
        {
            SFIcode sfi = new SFIcode();
            sfi.ShowDialog();
            if (sfi._DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                txtProjectItemCodeSFIcode.Text = sfi.SFIcodenumber;
                txtProjectItemCodeDescription.Text = sfi.SFIcodeDesc;
                try
                {                   
                    generateProjectItemCode();
                }
                catch (Exception ex)
                {
                    clsStaticGlobal.ErrHandlerLog(ex);
                }
            }
        }

    }

    public class ProjectCodes
    {
        private string mProjectCode;

        public string ProjectCodeName
        {
            get { return mProjectCode; }
            set { mProjectCode = value; }
        }
    }
}
