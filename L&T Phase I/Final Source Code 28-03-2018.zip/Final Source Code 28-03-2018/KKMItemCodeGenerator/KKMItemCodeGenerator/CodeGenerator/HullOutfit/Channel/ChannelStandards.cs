﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelStandards : ObservableCollection<NameCodePair>
    {
        public static ChannelStandards LoadList()
        {
            ChannelStandards items = new ChannelStandards();
            items.Add(new NameCodePair() { Code = "01", Name = "Non - Std" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISMC" });
            items.Add(new NameCodePair() { Code = "03", Name = "ISLC" });
            items.Add(new NameCodePair() { Code = "04", Name = "ISJC" });
            items.Add(new NameCodePair() { Code = "05", Name = "UPN" });
            items.Add(new NameCodePair() { Code = "05", Name = "ISMCP" });
            return items;
        }
        public static ChannelStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelStandards LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelStandards>(HullOutfitItems.DataPath + @"\Channel\ChannelStandards.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelStandards>(this, HullOutfitItems.DataPath + @"\Channel\ChannelStandards.xml");
        }
    }
}
