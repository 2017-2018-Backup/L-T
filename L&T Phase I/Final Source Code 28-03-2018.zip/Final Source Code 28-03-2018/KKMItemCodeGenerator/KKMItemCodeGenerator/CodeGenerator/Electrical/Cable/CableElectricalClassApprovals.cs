﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableElectricalClassApprovals : ObservableCollection<NameCodePair>
    {
        public static CableElectricalClassApprovals LoadList()
        {
            CableElectricalClassApprovals items = new CableElectricalClassApprovals();
            items.Add(new NameCodePair() { Code = "01", Name = "LR" });
            items.Add(new NameCodePair() { Code = "02", Name = "GL" });
            items.Add(new NameCodePair() { Code = "03", Name = "NIL" });
            items.Add(new NameCodePair() { Code = "04", Name = "DNV" });
            items.Add(new NameCodePair() { Code = "05", Name = "ABS" });
            items.Add(new NameCodePair() { Code = "06", Name = "IRS" });

            return items;
        }
        public static CableElectricalClassApprovals LoadFromExcel(String path)
        {
            return null;
        }

        public static CableElectricalClassApprovals LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableElectricalClassApprovals>(ElectricalItems.DataPath + @"\Cable\ElectricalClassApprovals.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableElectricalClassApprovals>(this, ElectricalItems.DataPath + @"\Cable\ElectricalClassApprovals.xml");
        }

    }
}
