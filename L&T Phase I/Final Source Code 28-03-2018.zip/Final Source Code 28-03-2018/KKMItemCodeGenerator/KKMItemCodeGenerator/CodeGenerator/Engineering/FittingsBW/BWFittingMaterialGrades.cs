﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BWFittingMaterialGrades : ObservableCollection<NameCodePair>
    {
        public static BWFittingMaterialGrades LoadList()
        {
            BWFittingMaterialGrades items = new BWFittingMaterialGrades();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ASTM A105 GRWPB" });
            items.Add(new NameCodePair() { Code = "02", Name = "ASTM A234 GRWPB" });
            items.Add(new NameCodePair() { Code = "03", Name = "ASTM A403 Gr. WP316LS" });
            items.Add(new NameCodePair() { Code = "04", Name = "ASTM B88 No. 10200" });
            items.Add(new NameCodePair() { Code = "05", Name = "MTL 35" });
            items.Add(new NameCodePair() { Code = "06", Name = "ASTM A403 Gr. WP316S" });
            items.Add(new NameCodePair() { Code = "07", Name = "-" });
            items.Add(new NameCodePair() { Code = "08", Name = "Galvanised Iron" });
            items.Add(new NameCodePair() { Code = "09", Name = "Cu Ni 90/10" });
            items.Add(new NameCodePair() { Code = "10", Name = "P 235" });
            items.Add(new NameCodePair() { Code = "11", Name = "NAB (NES 747 Part II)" });
            items.Add(new NameCodePair() { Code = "12", Name = "GM to BS 1400 LG4C" });
            items.Add(new NameCodePair() { Code = "13", Name = "SS 304 (ERW)" });
            items.Add(new NameCodePair() { Code = "14", Name = "SS 304" });
            items.Add(new NameCodePair() { Code = "15", Name = "SS 316" });
            items.Add(new NameCodePair() { Code = "16", Name = "SS 304L" });
            return items;
        }
        public static BWFittingMaterialGrades LoadFromExcel(String path)
        {
            return null;
        }

        public static BWFittingMaterialGrades LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BWFittingMaterialGrades>(EngineeringItems.DataPath + @"\FittingsBW\BWFittingMaterialGrades.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FittingsBW"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FittingsBW");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BWFittingMaterialGrades>(this, EngineeringItems.DataPath + @"\FittingsBW\BWFittingMaterialGrades.xml");
        }

    }
}
