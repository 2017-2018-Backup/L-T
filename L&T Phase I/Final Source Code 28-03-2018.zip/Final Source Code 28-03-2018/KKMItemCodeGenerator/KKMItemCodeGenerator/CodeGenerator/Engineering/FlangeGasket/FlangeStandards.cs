﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class FlangeStandards : ObservableCollection<NameCodePair>
    {
        public static FlangeStandards LoadList()
        {
            FlangeStandards items = new FlangeStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "DIN2576" });
            items.Add(new NameCodePair() { Code = "02", Name = "DIN2527-B" });
            items.Add(new NameCodePair() { Code = "03", Name = "DIN2575" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN2501" });
            items.Add(new NameCodePair() { Code = "05", Name = "DIN2577" });
            items.Add(new NameCodePair() { Code = "06", Name = "DIN2633-C1" });
            items.Add(new NameCodePair() { Code = "07", Name = "DIN2635" });
            items.Add(new NameCodePair() { Code = "08", Name = "DIN2636" });
            items.Add(new NameCodePair() { Code = "09", Name = "DIN86041" });
            items.Add(new NameCodePair() { Code = "10", Name = "DIN86044" });
            items.Add(new NameCodePair() { Code = "11", Name = "NS2526" });
            items.Add(new NameCodePair() { Code = "12", Name = "NS2548" });
            items.Add(new NameCodePair() { Code = "13", Name = "ISO-7005-1" });
            items.Add(new NameCodePair() { Code = "14", Name = "DIN2632" });
            items.Add(new NameCodePair() { Code = "15", Name = "DIN2642" });
            items.Add(new NameCodePair() { Code = "16", Name = "EN 1092-1" });
            items.Add(new NameCodePair() { Code = "17", Name = "JIS F7804" });
            items.Add(new NameCodePair() { Code = "18", Name = "JIS B2220" });
            items.Add(new NameCodePair() { Code = "19", Name = "JIS F7806" });
            items.Add(new NameCodePair() { Code = "20", Name = "DIN 2573" });
            items.Add(new NameCodePair() { Code = "21", Name = "JIS 3005" });
            items.Add(new NameCodePair() { Code = "22", Name = "EN 1092-3" });
            items.Add(new NameCodePair() { Code = "23", Name = "DIN 86037" });
            items.Add(new NameCodePair() { Code = "24", Name = "ASME-B16.5" });
            items.Add(new NameCodePair() { Code = "25", Name = "ASME B16.21" });
            items.Add(new NameCodePair() { Code = "26", Name = "DIN 28011" });
            items.Add(new NameCodePair() { Code = "27", Name = "DIN EN 1514-1" });
            items.Add(new NameCodePair() { Code = "28", Name = "ASME B16.24" });
            items.Add(new NameCodePair() { Code = "29", Name = "ASME B16.20" });
            items.Add(new NameCodePair() { Code = "30", Name = "DIN 2543" });
            return items;
        }
        public static FlangeStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static FlangeStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<FlangeStandards>(EngineeringItems.DataPath + @"\FlangeGasket\FlangeStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\FlangeGasket"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\FlangeGasket");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<FlangeStandards>(this, EngineeringItems.DataPath + @"\FlangeGasket\FlangeStandards.xml");
        }

    }
}
