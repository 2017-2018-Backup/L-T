﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveTypes : ObservableCollection<NameCodePair>
    {
        public static ValveTypes LoadList()
        {
            ValveTypes items = new ValveTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "BALL" });
            items.Add(new NameCodePair() { Code = "02", Name = "BUTTERFLY" });
            items.Add(new NameCodePair() { Code = "03", Name = "GLOBE" });
            items.Add(new NameCodePair() { Code = "04", Name = "GATE" });
            items.Add(new NameCodePair() { Code = "05", Name = "CHECK VALVE" });
            items.Add(new NameCodePair() { Code = "06", Name = "NEEDLE" });
            items.Add(new NameCodePair() { Code = "07", Name = "PRESSURE RELIEF" });
            items.Add(new NameCodePair() { Code = "08", Name = "PRESSURE REDUCING" });
            items.Add(new NameCodePair() { Code = "09", Name = "PRESSURE REGULATING VALVE" });
            items.Add(new NameCodePair() { Code = "10", Name = "OTHER VALVE TYPES" });
            return items;
        }
        public static ValveTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveTypes>(EngineeringItems.DataPath + @"\Valves\ValveTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveTypes.xml");
        }

    }
}
