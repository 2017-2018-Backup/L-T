﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableSubTypes : ObservableCollection<NameCodePair>
    {
        public static CableSubTypes LoadList()
        {
            CableSubTypes items = new CableSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "CANBUS" });
            items.Add(new NameCodePair() { Code = "02", Name = "ETHERNET CABLE" });
            items.Add(new NameCodePair() { Code = "03", Name = "FIBER OPTICAL CABLE" });
            items.Add(new NameCodePair() { Code = "04", Name = "FIRE RESISTANT UNARMOURED" });
            items.Add(new NameCodePair() { Code = "05", Name = "FIRE RESISTANT ARMOURED" });
            items.Add(new NameCodePair() { Code = "06", Name = "FIRE RESISTANT SCREENED" });
            items.Add(new NameCodePair() { Code = "07", Name = "FIRE RESISTANT ARMOURED FLEXIBLE CABLE" });
            items.Add(new NameCodePair() { Code = "08", Name = "FIRE RESISTANT UNARMOURED FLEXIBLE CABLE" });
            items.Add(new NameCodePair() { Code = "09", Name = "FIRE RESISTANT TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "10", Name = "FIRE RESISTANT COLLECTIVELY TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "11", Name = "FLAME RETARDANT ARMOURED" });
            items.Add(new NameCodePair() { Code = "12", Name = "FLAME RETARDANT ARMOURED FLEXIBLE CABLE" });
            items.Add(new NameCodePair() { Code = "13", Name = "FLAME RETARDANT COLLECTIVELY TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "14", Name = "FLAME RETARDANT SCREENED" });
            items.Add(new NameCodePair() { Code = "15", Name = "FLAME RETARDANT TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "16", Name = "FLAME RETARDANT UNARMOURED" });
            items.Add(new NameCodePair() { Code = "17", Name = "FLAME RETARDANT UNARMOURED FLEXIBLE CABLE" });
            items.Add(new NameCodePair() { Code = "18", Name = "EMC CABLE" });
            items.Add(new NameCodePair() { Code = "19", Name = "VFD CABLE" });
            items.Add(new NameCodePair() { Code = "20", Name = "CAT 5" });
            items.Add(new NameCodePair() { Code = "21", Name = "CAT 5E" });
            items.Add(new NameCodePair() { Code = "22", Name = "CAT 7" });
            items.Add(new NameCodePair() { Code = "23", Name = "RG 11" });
            items.Add(new NameCodePair() { Code = "24", Name = "RG 213" });
            items.Add(new NameCodePair() { Code = "25", Name = "RG 214" });
            items.Add(new NameCodePair() { Code = "26", Name = "RG 58" });
            items.Add(new NameCodePair() { Code = "27", Name = "RG 59" });
            items.Add(new NameCodePair() { Code = "28", Name = "RG 6" });
            items.Add(new NameCodePair() { Code = "29", Name = "MODBUS" });
            items.Add(new NameCodePair() { Code = "30", Name = "PROFIBUS" });
            items.Add(new NameCodePair() { Code = "31", Name = "CAT 6" });
            items.Add(new NameCodePair() { Code = "32", Name = "UTP LAN" });
            items.Add(new NameCodePair() { Code = "33", Name = "FLEXIBLE CABLES" });
            items.Add(new NameCodePair() { Code = "34", Name = "HEAT RESISTANT CABLE" });
            items.Add(new NameCodePair() { Code = "35", Name = "FLAME RETARDANT ARMOURED (EMC) FOR VFD" });
            items.Add(new NameCodePair() { Code = "36", Name = "FIRE RESISTANT TWISTED PAIR" });
            items.Add(new NameCodePair() { Code = "37", Name = "CAT 7 SFTP" });
            items.Add(new NameCodePair() { Code = "38", Name = "FIRE RESISTANT INDIVIDUAL AND COLLECTIVE TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "39", Name = "RG 10" });
            items.Add(new NameCodePair() { Code = "40", Name = "RG 12" });
            items.Add(new NameCodePair() { Code = "41", Name = "FLAME RETARDANT INDIVIDUAL AND COLLECTIVE TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "42", Name = "CAT 6 SFTP" });
            items.Add(new NameCodePair() { Code = "43", Name = "CAT 5E SFTP" });
            items.Add(new NameCodePair() { Code = "44", Name = "RG 8" });
            items.Add(new NameCodePair() { Code = "45", Name = "FLAME RETARDANT UNSCREENED" });
            items.Add(new NameCodePair() { Code = "46", Name = "CAT6A" });
            items.Add(new NameCodePair() { Code = "47", Name = "FIBRE OPTIC CABLE-SINGLE MODE" });
            items.Add(new NameCodePair() { Code = "48", Name = "FIBRE OPTIC CABLE-MULTI MODE" });
            items.Add(new NameCodePair() { Code = "49", Name = "FIRE RESISTANT UNSCREENED CABLE" });
            items.Add(new NameCodePair() { Code = "50", Name = "FLAME RETARDANT INDIVIDUALLY TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "51", Name = "FLAME RETARDANT SCREENED (EMC) FOR VFD" });
            items.Add(new NameCodePair() { Code = "52", Name = "FLAME RETARDANT COLLECTIVELY SCREENED" });
            items.Add(new NameCodePair() { Code = "53", Name = "FIRE RESISTANT INDIVIDUALLY TWISTED PAIR SCREENED" });
            items.Add(new NameCodePair() { Code = "54", Name = "FIRE RESISTANT COLLECTIVELY SCREENED" });
            return items;
        }
        public static CableSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static CableSubTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableSubTypes>(ElectricalItems.DataPath + @"\Cable\CableSubTypes.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableSubTypes>(this, ElectricalItems.DataPath + @"\Cable\CableSubTypes.xml");
        }

    }
}
