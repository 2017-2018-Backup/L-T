﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class AngleSize1Collection : ObservableCollection<NameCodePair>
    {
        public static AngleSize1Collection LoadList()
        {
            AngleSize1Collection items = new AngleSize1Collection();
            items.Add(new NameCodePair() { Code = "020", Name = "20" });
            items.Add(new NameCodePair() { Code = "025", Name = "25" });
            items.Add(new NameCodePair() { Code = "030", Name = "30" });
            items.Add(new NameCodePair() { Code = "035", Name = "35" });
            items.Add(new NameCodePair() { Code = "040", Name = "40" });
            items.Add(new NameCodePair() { Code = "045", Name = "45" });
            items.Add(new NameCodePair() { Code = "050", Name = "50" });
            items.Add(new NameCodePair() { Code = "055", Name = "55" });
            items.Add(new NameCodePair() { Code = "060", Name = "60" });
            items.Add(new NameCodePair() { Code = "065", Name = "65" });
            items.Add(new NameCodePair() { Code = "070", Name = "70" });
            items.Add(new NameCodePair() { Code = "075", Name = "75" });
            items.Add(new NameCodePair() { Code = "080", Name = "80" });
            items.Add(new NameCodePair() { Code = "090", Name = "90" });
            items.Add(new NameCodePair() { Code = "100", Name = "100" });
            items.Add(new NameCodePair() { Code = "110", Name = "110" });
            items.Add(new NameCodePair() { Code = "120", Name = "120" });
            items.Add(new NameCodePair() { Code = "125", Name = "125" });
            items.Add(new NameCodePair() { Code = "130", Name = "130" });
            items.Add(new NameCodePair() { Code = "135", Name = "135" });
            items.Add(new NameCodePair() { Code = "150", Name = "150" });
            items.Add(new NameCodePair() { Code = "180", Name = "180" });
            items.Add(new NameCodePair() { Code = "200", Name = "200" });


            return items;
        }

        public static AngleSize1Collection LoadFromExcel(String path)
        {
            return null;
        }

        public static AngleSize1Collection LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<AngleSize1Collection>(HullItems.HullDataPath + @"\Angle\AngleSize1Collection.xml");
        }


        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<AngleSize1Collection>(this, HullItems.HullDataPath + @"\Angle\AngleSize1Collection.xml");
        }
    }
}
