﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveEndConnectionStandards : ObservableCollection<NameCodePair>
    {
        public static ValveEndConnectionStandards LoadList()
        {
            ValveEndConnectionStandards items = new ValveEndConnectionStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ISO 228/1" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISO 7/1" });
            items.Add(new NameCodePair() { Code = "03", Name = "DIN 2576" });
            items.Add(new NameCodePair() { Code = "04", Name = "EN 1092-1" });
            items.Add(new NameCodePair() { Code = "05", Name = "ASME-B16.5" });
            items.Add(new NameCodePair() { Code = "06", Name = "DIN-86037" });
            items.Add(new NameCodePair() { Code = "07", Name = "BSP/NPT" });
            items.Add(new NameCodePair() { Code = "08", Name = "EN1092-3" });
            return items;
        }
        public static ValveEndConnectionStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveEndConnectionStandards LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveEndConnectionStandards>(EngineeringItems.DataPath + @"\Valves\ValveEndConnectionStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveEndConnectionStandards>(this, EngineeringItems.DataPath + @"\Valves\ValveEndConnectionStandards.xml");
        }

    }
}
