﻿Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Runtime.InteropServices

Friend Class OfficeHelpers
    ' Methods
    Friend Shared Function BuildOfficeConnection(ByVal officeFilePath As String, ByVal officeConnection As OfficeConnectionStringType, Optional ByVal excelFirstRowHeader As Boolean = True) As String
        Dim str2 As String = String.Empty
        Select Case officeConnection
            Case OfficeConnectionStringType.ocsExcel
                Return Conversions.ToString(Operators.ConcatenateObject((("provider=Microsoft.ACE.OLEDB.12.0; data source='" & officeFilePath) & " '; " & "Extended Properties=Excel 12.0; "), Interaction.IIf(excelFirstRowHeader, "", "HDR=No;")))
            Case OfficeConnectionStringType.ocsAccess
                Return str2
        End Select
        Return str2
    End Function
    ' Nested Types
    Friend Enum OfficeConnectionStringType As Byte
        ' Fields
        ocsAccess = 1
        ocsExcel = 0
    End Enum
End Class


