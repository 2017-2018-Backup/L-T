﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValveNeedleSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValveNeedleSubTypes LoadList()
        {
            ValveNeedleSubTypes items = new ValveNeedleSubTypes();

            items.Add(new NameCodePair() { Code = "01", Name = "ANGLE TYPE" });
            return items;
        }
        public static ValveNeedleSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValveNeedleSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValveNeedleSubTypes>(EngineeringItems.DataPath + @"\Valves\ValveNeedleSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValveNeedleSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValveNeedleSubTypes.xml");
        }

    }
}
