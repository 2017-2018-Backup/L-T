﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class PipeFittingMaleConnectorTypes : ObservableCollection<NameCodePair>
    {
        public static PipeFittingMaleConnectorTypes LoadList()
        {
            PipeFittingMaleConnectorTypes items = new PipeFittingMaleConnectorTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "MALE CONNECTOR" });
            return items;
        }
        public static PipeFittingMaleConnectorTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static PipeFittingMaleConnectorTypes LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<PipeFittingMaleConnectorTypes>(EngineeringItems.DataPath + @"\PipeFitting\PipeFittingMaleConnectorTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\PipeFitting"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\PipeFitting");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<PipeFittingMaleConnectorTypes>(this, EngineeringItems.DataPath + @"\PipeFitting\PipeFittingMaleConnectorTypes.xml");
        }

    }
}
