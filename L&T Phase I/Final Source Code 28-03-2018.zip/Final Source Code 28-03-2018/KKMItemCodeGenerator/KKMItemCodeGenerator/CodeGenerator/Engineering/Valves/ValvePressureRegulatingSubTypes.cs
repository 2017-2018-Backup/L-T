﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ValvePressureRegulatingSubTypes : ObservableCollection<NameCodePair>
    {
        public static ValvePressureRegulatingSubTypes LoadList()
        {
            ValvePressureRegulatingSubTypes items = new ValvePressureRegulatingSubTypes();
            return items;
        }
        public static ValvePressureRegulatingSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ValvePressureRegulatingSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ValvePressureRegulatingSubTypes>(EngineeringItems.DataPath + @"\Valves\ValvePressureRegulatingSubTypes.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Valves"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Valves");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ValvePressureRegulatingSubTypes>(this, EngineeringItems.DataPath + @"\Valves\ValvePressureRegulatingSubTypes.xml");
        }

    }
}
