﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class ChannelTypes : ObservableCollection<NameCodePair>
    {
        public static ChannelTypes LoadList()
        {
            ChannelTypes items = new ChannelTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "U CHANNEL" });
            items.Add(new NameCodePair() { Code = "02", Name = "C CHANNEL" });
            items.Add(new NameCodePair() { Code = "03", Name = "J CHANNEL" });
            items.Add(new NameCodePair() { Code = "04", Name = "HAT CHANNEL" });
            items.Add(new NameCodePair() { Code = "05", Name = "STRUT CHANNEL" });

            return items;
        }
        public static ChannelTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static ChannelTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<ChannelTypes>(HullOutfitItems.DataPath + @"\Channel\ChannelTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<ChannelTypes>(this, HullOutfitItems.DataPath + @"\Channel\ChannelTypes.xml");
        }
    }
}
