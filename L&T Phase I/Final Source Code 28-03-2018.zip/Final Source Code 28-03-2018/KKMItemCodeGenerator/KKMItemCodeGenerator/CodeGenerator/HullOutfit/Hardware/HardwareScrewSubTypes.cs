﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class HardwareScrewSubTypes : ObservableCollection<NameCodePair>
    {
        public static HardwareScrewSubTypes LoadList()
        {
            HardwareScrewSubTypes items = new HardwareScrewSubTypes();
            items.Add(new NameCodePair() { Code = "01", Name = "Hex.Hd.Scr." });
            items.Add(new NameCodePair() { Code = "02", Name = "Hex.Soc.Hd.Cap.Scr" });
            items.Add(new NameCodePair() { Code = "03", Name = "Slotted Countersunk Screw" });
            items.Add(new NameCodePair() { Code = "04", Name = "Slotted Raised Countersunk Screw" });
            items.Add(new NameCodePair() { Code = "05", Name = "Slotted Cheese Head Screw" });
            items.Add(new NameCodePair() { Code = "06", Name = "Hex.Countersunk Head Screw" });
            items.Add(new NameCodePair() { Code = "07", Name = "flat headed screw" });
            return items;
        }
        public static HardwareScrewSubTypes LoadFromExcel(String path)
        {
            return null;
        }

        public static HardwareScrewSubTypes LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<HardwareScrewSubTypes>(HullOutfitItems.DataPath + @"\Hardware\HardwareScrewSubTypes.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<HardwareScrewSubTypes>(this, HullOutfitItems.DataPath + @"\Hardware\HardwareScrewSubTypes.xml");
        }
    }
}
