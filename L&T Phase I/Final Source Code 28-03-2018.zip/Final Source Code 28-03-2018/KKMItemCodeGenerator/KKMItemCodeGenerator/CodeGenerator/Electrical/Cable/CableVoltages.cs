﻿using System;
using System.Collections.ObjectModel;


namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class CableVoltages : ObservableCollection<NameCodePair>
    {
        public static CableVoltages LoadList()
        {
            CableVoltages items = new CableVoltages();
            items.Add(new NameCodePair() { Code = "01", Name = "24 V" });
            items.Add(new NameCodePair() { Code = "02", Name = "250 V" });
            items.Add(new NameCodePair() { Code = "03", Name = "0.6/1 KV" });
            items.Add(new NameCodePair() { Code = "04", Name = "11 KV" });
            items.Add(new NameCodePair() { Code = "05", Name = "32 KV" });
            items.Add(new NameCodePair() { Code = "06", Name = "NA" });
            items.Add(new NameCodePair() { Code = "07", Name = "1.8 KV" });
            items.Add(new NameCodePair() { Code = "08", Name = "440 V" });

            return items;
        }
        public static CableVoltages LoadFromExcel(String path)
        {
            return null;
        }

        public static CableVoltages LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<CableVoltages>(ElectricalItems.DataPath + @"\Cable\CableVoltages.xml");
        }

        public void ExportToXml()
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<CableVoltages>(this, ElectricalItems.DataPath + @"\Cable\CableVoltages.xml");
        }

    }
}
