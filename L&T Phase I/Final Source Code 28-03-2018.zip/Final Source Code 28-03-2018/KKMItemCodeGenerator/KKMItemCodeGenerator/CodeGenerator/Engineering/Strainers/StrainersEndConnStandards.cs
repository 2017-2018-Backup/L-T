﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class StrainersEndConnStandards : ObservableCollection<NameCodePair>
    {
        public static StrainersEndConnStandards LoadList()
        {
            StrainersEndConnStandards items = new StrainersEndConnStandards();
            items.Add(new NameCodePair() { Code = "00", Name = "NOT APPLICABLE" });
            items.Add(new NameCodePair() { Code = "01", Name = "ISO 228/1" });
            items.Add(new NameCodePair() { Code = "02", Name = "ISO 7/1" });
            items.Add(new NameCodePair() { Code = "03", Name = "ANSI B.1.20.1" });
            items.Add(new NameCodePair() { Code = "04", Name = "DIN 86037" });
            items.Add(new NameCodePair() { Code = "05", Name = "ASME B16.10" });
            items.Add(new NameCodePair() { Code = "06", Name = "ASME B16.5" });
            items.Add(new NameCodePair() { Code = "07", Name = "EN 1092-3" });
            items.Add(new NameCodePair() { Code = "08", Name = "EN-1092-1" });
            return items;
        }
        public static StrainersEndConnStandards LoadFromExcel(String path)
        {
            return null;
        }

        public static StrainersEndConnStandards LoadFromXml()
        {            
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<StrainersEndConnStandards>(EngineeringItems.DataPath + @"\Strainers\StrainersEndConnStandards.xml");
        }

        public void ExportToXml()
        {
            if (!System.IO.Directory.Exists(EngineeringItems.DataPath + @"\Strainers"))
            {
                System.IO.Directory.CreateDirectory(EngineeringItems.DataPath + @"\Strainers");
            }
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<StrainersEndConnStandards>(this, EngineeringItems.DataPath + @"\Strainers\StrainersEndConnStandards.xml");
        }

    }
}
