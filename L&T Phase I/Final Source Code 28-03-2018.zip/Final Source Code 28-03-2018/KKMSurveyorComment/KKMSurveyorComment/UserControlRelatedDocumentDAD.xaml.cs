﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KKMSurveyorComment;
using VDF = Autodesk.DataManagement.Client.Framework;
using Autodesk.Connectivity.WebServices;
using System.Collections.ObjectModel;

namespace KKMSurveyorComment
{
    /// <summary>
    /// Interaction logic for VaultSearch.xaml
    /// </summary>
    public partial class UserControlRelatedDocumentDAD : Window
    {
        public event EventHandler<EventArgs> CloseButtonClicked;
        public System.Windows.Forms.DialogResult DialogResUserControlRelatedDocumentDAD = System.Windows.Forms.DialogResult.Cancel;
        bool IsEditMode = false;
        bool IsCheckedOut = false;
        string checkedOutUsername = "";

        public UserControlRelatedDocumentDAD(bool _IsEditMode, bool _IsCheckedOut, string _checkedOutUsername)
        {
            InitializeComponent();
            IsEditMode = _IsEditMode;
            IsCheckedOut = _IsCheckedOut;
            checkedOutUsername = _checkedOutUsername;
            try
            {
                clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.Clear();
                int cnt = 1;
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.RelatedDocumentDADFiles)
                {
                    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                    string filePath = folder.FullName + "/" + _item.Name;
                    string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                    string fileName = _item.Name;
                    int fileExtPos = fileName.LastIndexOf(".");
                    if (fileExtPos >= 0)
                        fileName = fileName.Substring(0, fileExtPos);
                    string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _item.Id, false);
                    if (fileDec == null)
                    {
                        fileDec = "";
                    }
                    clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.Add(new RelatedDocumentDAD { Count = cnt, IsCheckedRelatedDocumentDAD = false, FileType = "Related Document (DAD)", FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                    cnt += 1;
                }

                clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(RelatedDocumentDADSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListRelatedDocumentDAD_CollectionChanged);

                RelatedDocumentDADSearchGridViewBox.ItemsSource = clsStaticGlobal.RelatedDocumentDADSearchedItemCollection;
                CollectionView viewSearch = (CollectionView)CollectionViewSource.GetDefaultView(RelatedDocumentDADSearchGridViewBox.ItemsSource);
                viewSearch.Filter = UserFilter;
                RelatedDocumentDADSearchGridViewBox.UpdateLayout();

                if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                {
                    RelatedDocumentDADGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD;
                    RelatedDocumentDADGridViewBox.UpdateLayout();
                }

                try
                {
                    if (clsStaticGlobal.IsReadOnly == true)
                    {
                        cmdRemove.Visibility = Visibility.Collapsed;
                        cmdSave.Visibility = Visibility.Collapsed;
                        cmdAddApprovedDocument.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        cmdRemove.Visibility = Visibility.Visible;
                        cmdSave.Visibility = Visibility.Visible;
                        cmdAddApprovedDocument.Visibility = Visibility.Visible;
                    }
                }
                catch (Exception)
                {

                }                

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

            if (IsCheckedOut == true)
            {
                System.Windows.MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not edit at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.Clear();
                foreach (Autodesk.Connectivity.WebServices.File _item in clsStaticGlobal.RelatedDocumentDADFiles)
                {
                    Folder folder = clsStaticGlobal.connection.WebServiceManager.DocumentService.GetFolderById(_item.FolderId);
                    string filePath = folder.FullName + "/" + _item.Name;
                    string fileext = clsStaticGlobal.GetFileExtension(_item.Name);
                    string fileName = _item.Name;
                    int fileExtPos = fileName.LastIndexOf(".");
                    if (fileExtPos >= 0)
                        fileName = fileName.Substring(0, fileExtPos);
                    string fileDec = clsStaticGlobal.GetFilePropertyValue("Description", _item.Id, false);
                    if (fileDec == null)
                    {
                        fileDec = "";
                    }
                    clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.Add(new RelatedDocumentDAD { IsCheckedRelatedDocumentDAD = false, FileType = "Related Document (DAD)", FileName = fileName, FileDesc = fileDec, FilePath = filePath, FileRemark = _item.Comm, FileRevision = _item.FileRev.Label.ToString(), FileStatus = _item.FileLfCyc.LfCycStateName.ToString() });
                }

                clsStaticGlobal.RelatedDocumentDADSearchedItemCollection.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(RelatedDocumentDADSearchedItemCollection_CollectionChanged);
                clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(ListRelatedDocumentDAD_CollectionChanged);

                RelatedDocumentDADSearchGridViewBox.ItemsSource = clsStaticGlobal.RelatedDocumentDADSearchedItemCollection;
                RelatedDocumentDADSearchGridViewBox.UpdateLayout();

                if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                {
                    RelatedDocumentDADGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD;
                    RelatedDocumentDADGridViewBox.UpdateLayout();
                }

            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }

        }

        private void RelatedDocumentDADSearchedItemCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.RelatedDocumentDADSearchedItemCollection)
                {
                    item.Count = k;
                    k++;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void ListRelatedDocumentDAD_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            try
            {
                int k = 1;
                foreach (var item in clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD)
                {
                    item.Count = k;
                    k++;

                    string _status = "";
                    string _remark = "";
                    clsStaticGlobal.VaultFileGetStateAndComment(item.FilePath, out _status, out _remark);
                    item.FileStatus = _status;
                }
            }
            catch (Exception ex)
            {
                clsStaticGlobal.ErrHandlerLog(ex);
            }
        }

        private void cmdCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlRelatedDocumentDAD = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void cmdAddApprovedDocument_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        RelatedDocumentDADSearchGridViewBox.UpdateLayout();
                        RelatedDocumentDADGridViewBox.Items.Refresh();

                        foreach (RelatedDocumentDAD _item in clsStaticGlobal.RelatedDocumentDADSearchedItemCollection)
                        {
                            if (_item.IsCheckedRelatedDocumentDAD == true)
                            {
                                bool IsFileExist = false;
                                foreach (RelatedDocumentDAD _itemExist in clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD)
                                {

                                    if (_itemExist.FileName == _item.FileName)
                                    {
                                        IsFileExist = true;
                                    }
                                    else
                                    {
                                        var _itemExistTemp = _itemExist.FileName.Split(new char[] { '.' });
                                        var _itemTemp = _item.FileName.Split(new char[] { '.' });
                                        if (_itemExistTemp[0].ToUpper() == _itemTemp[0].ToUpper())
                                        {
                                            IsFileExist = true;
                                        }
                                    }

                                }
                                if (IsFileExist == false)
                                {
                                    //clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDAD = _item.FileName;
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Add(new RelatedDocumentDAD { IsCheckedRelatedDocumentDAD = true, FileType = "Related Document (DAD)", FileName = _item.FileName, FileDesc = _item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString() });
                                }
                            }
                        }
                        //////
                        //if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count == 0)
                        //{
                        //    foreach (RelatedDocumentDAD _item in clsStaticGlobal.RelatedDocumentDADSearchedItemCollection)
                        //    {
                        //        if ((_item.IsCheckedRelatedDocumentDAD == true) && (IsAdded == false))
                        //        {
                        //            IsAdded = true;
                        //            clsStaticGlobal.objSingleSurveyorCommentSummary.RelatedDocumentDAD = _item.FileName;
                        //            clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Add(new RelatedDocumentDAD { IsCheckedRelatedDocumentDAD = true, FileType = "Related Document (DAD)", FileName = _item.FileName, FileDesc=_item.FileDesc, FilePath = _item.FilePath, FileRemark = _item.FileRemark, FileRevision = _item.FileRevision.ToString(), FileStatus = _item.FileStatus.ToString() });
                        //        }
                        //    }
                        //    RelatedDocumentDADGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD;
                        //}
                        //else
                        //{
                        //    System.Windows.Forms.MessageBox.Show("First remove attached Related Document (DAD).", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                        //}

                        RelatedDocumentDADGridViewBox.ItemsSource = clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD;

                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }
                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            RelatedDocumentDADGridViewBox.UpdateLayout();
        }

        //private void cmdSaveandClose_Click(object sender, RoutedEventArgs e)
        //{
        //    if (clsStaticGlobal.IsReadOnly == false)
        //    {
        //        try
        //        {
        //            if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count == 0)
        //            {
        //                System.Windows.Forms.MessageBox.Show("There is no attached Related Document (DAD)..!", "Surveyor Comment", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
        //            }

        //            RelatedDocumentDADGridViewBox.UpdateLayout();
        //            if (this.CloseButtonClicked != null)
        //                CloseButtonClicked(sender, e);
        //        }
        //        catch (Exception ex)
        //        {
        //            clsStaticGlobal.ErrHandlerLog(ex);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
        //    }


        //}

        private void cmdRemove_Click(object sender, RoutedEventArgs e)
        {
            if (IsCheckedOut == false)
            {
                if (clsStaticGlobal.IsReadOnly == false)
                {
                    try
                    {
                        if (clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Count > 0)
                        {
                            try
                            {
                                bool isChecked = false;
                                List<RelatedDocumentDAD> listOfRelatedDocumentDAD = new List<RelatedDocumentDAD>();
                                foreach (var itemRelatedDocumentDAD in RelatedDocumentDADGridViewBox.Items)
                                {
                                    RelatedDocumentDAD objRelatedDocumentDAD = (RelatedDocumentDAD)itemRelatedDocumentDAD;

                                    if (objRelatedDocumentDAD.IsCheckedRelatedDocumentDAD == true)
                                    {
                                        isChecked = true;
                                        listOfRelatedDocumentDAD.Add(objRelatedDocumentDAD);
                                    }
                                }

                                foreach (RelatedDocumentDAD item in listOfRelatedDocumentDAD)
                                {
                                    clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Remove(item);
                                }

                                RelatedDocumentDADGridViewBox.Items.Refresh();

                                if (isChecked == false)
                                {
                                    MessageBox.Show("Select single file first.", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                                }
                            }
                            catch (Exception ex)
                            {
                                clsStaticGlobal.ErrHandlerLog(ex);
                            }
                            //clsStaticGlobal.objSingleSurveyorCommentSummary.ListRelatedDocumentDAD.Clear();
                            //RelatedDocumentDADGridViewBox.UpdateLayout();
                        }
                    }
                    catch (Exception ex)
                    {
                        clsStaticGlobal.ErrHandlerLog(ex);
                    }

                }
                else
                {
                    MessageBox.Show("Surveyor comment in Release state. User can not edit..!!", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Selected Surveyor Comment checked out by user : " + checkedOutUsername + Environment.NewLine + "So you can not save at this time..", "Surveyor Comment", MessageBoxButton.OK, MessageBoxImage.Information);
            }

        }

        private void RelatedDocumentDADSearchGridViewBox_GotFocus(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.DataGridCell cell = e.OriginalSource as System.Windows.Controls.DataGridCell;
            if (cell != null && cell.Column is DataGridCheckBoxColumn)
            {
                RelatedDocumentDADSearchGridViewBox.BeginEdit();
                System.Windows.Controls.CheckBox chkBox = cell.Content as System.Windows.Controls.CheckBox;
                if (chkBox != null)
                {
                    chkBox.IsChecked = !chkBox.IsChecked;
                }
            }
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            DialogResUserControlRelatedDocumentDAD = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }

        private bool UserFilter(object item)
        {
            if (String.IsNullOrEmpty(searchedtxt.Text))
            {
                return true;
            }
            else
            //return ((item as RelatedDocumentDAD).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);

            // object coll = ((item as RelatedDocumentDAD).FileName.StartsWith(searchedtxt.Text));

            {
                //RelatedDocumentDAD itemitem = (RelatedDocumentDAD)item;

                //if (itemitem.FileName.ToUpper().StartsWith(searchedtxt.Text.ToUpper()) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}

                return ((item as RelatedDocumentDAD).FileName.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as RelatedDocumentDAD).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);

            }

            //((item as RelatedDocumentDAD).FileName.StartsWith(searchedtxt.Text, StringComparison.OrdinalIgnoreCase); //((item as RelatedDocumentDAD).FileName.StartsWith(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0) || ((item as RelatedDocumentDAD).FileDesc.IndexOf(searchedtxt.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void searchedtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(RelatedDocumentDADSearchGridViewBox.ItemsSource).Refresh();
        }

    }

}
