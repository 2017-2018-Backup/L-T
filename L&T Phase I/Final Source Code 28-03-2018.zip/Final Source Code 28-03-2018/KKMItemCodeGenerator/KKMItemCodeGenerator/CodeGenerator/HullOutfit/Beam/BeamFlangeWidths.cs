﻿using System;
using System.Collections.ObjectModel;

namespace KKMItemCodeGenerator
{
    [Serializable()]
    public class BeamFlangeWidths : ObservableCollection<NameCodePair>
    {
        public static BeamFlangeWidths LoadList()
        {
            BeamFlangeWidths items = new BeamFlangeWidths();
            items.Add(new NameCodePair() { Code = "050", Name = "50 mm" });
            items.Add(new NameCodePair() { Code = "060", Name = "60 mm" });
            items.Add(new NameCodePair() { Code = "070", Name = "70 mm" });
            items.Add(new NameCodePair() { Code = "075", Name = "75 mm" });
            items.Add(new NameCodePair() { Code = "080", Name = "80 mm" });
            items.Add(new NameCodePair() { Code = "085", Name = "85 mm" });
            items.Add(new NameCodePair() { Code = "100", Name = "100 mm" });
            items.Add(new NameCodePair() { Code = "110", Name = "110 mm" });
            items.Add(new NameCodePair() { Code = "125", Name = "125 mm" });
            items.Add(new NameCodePair() { Code = "140", Name = "140 mm" });
            items.Add(new NameCodePair() { Code = "150", Name = "150 mm" });
            items.Add(new NameCodePair() { Code = "152", Name = "152 mm" });
            items.Add(new NameCodePair() { Code = "180", Name = "180 mm" });
            items.Add(new NameCodePair() { Code = "190", Name = "190 mm" });
            items.Add(new NameCodePair() { Code = "200", Name = "200 mm" });
            items.Add(new NameCodePair() { Code = "203", Name = "203 mm" });
            items.Add(new NameCodePair() { Code = "225", Name = "225 mm" });
            items.Add(new NameCodePair() { Code = "210", Name = "210 mm" });
            items.Add(new NameCodePair() { Code = "250", Name = "250 mm" });

            return items;
        }
        public static BeamFlangeWidths LoadFromExcel(String path)
        {
            return null;
        }

        public static BeamFlangeWidths LoadFromXml()
        {
            ObjectHelper helper = new ObjectHelper();
            return helper.DeSerializeObject<BeamFlangeWidths>(HullOutfitItems.DataPath + @"\Beam\BeamFlangeWidths.xml");
        }

        public void ExportToXml(string path)
        {
            ObjectHelper helper = new ObjectHelper();
            helper.SerializeObject<BeamFlangeWidths>(this, HullOutfitItems.DataPath + @"\Beam\BeamFlangeWidths.xml");
        }
    }
}
